/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        PoisonDartAbility                                                              *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            October 27th,2016                                                              *
 *                                                                                                 *
 * Checks for hits and applies damage as well as temporarily slowing the enemy                     *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - October 27th,2016                                           *
 * V 1.3 - Added aim assist (Jon Roffey) - December 7th, 2016                                      *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class PoisonDartAbility : Ability
{
    //
    //Private
    //
    private Player m_ReferenceToPlayerHit;
    private PoisonDartImageEffectScript m_PoisonEffectScript;
    private Vector3 m_DirectionToEnemy;
    private List<Player> m_PlayersThatCanBeHit;
    private Player m_ClosestEnemy;
    private AudioClip m_HitClip;
    private float m_PoisonDartCooldown = 9f;
    //private float m_MaxFireDistance = 50f;
    //private float m_SecondsBetweenDamage = 1.0f;
    private int m_LayerMask;
    private float m_ThrowForce = 200f;
    private float m_PoisonDartAbilityTimer = 0f;
    private float m_PoisonDuration = 5f;
    private float m_PoisonTimer = 0.0f;
    private float m_AimAssistSphereCastRadius = 2f;
    //private int m_DamagePerSecond = 4;
    private bool m_PlayerHit = false;

    private const string m_ZephPoisonDartHitResource = "Audio/SoundFX/zeph_poison_dart_hit";

    public PoisonDartAbility(InputName aKey)
    {
        Key = aKey;
        m_HitClip = Resources.Load(m_ZephPoisonDartHitResource) as AudioClip;
        HasAnimationTime = true;
        AnimatorString = "PoisonDart";
    }

    public override void SetOwner(Player owner)
    {
        Owner = owner;

        m_LayerMask = ~((1 << LayerMask.NameToLayer("UnplacedObjects")) |
                        (1 << LayerMask.NameToLayer("WallCollider")) |
                        (1 << LayerMask.NameToLayer("Ignore Raycast")) |
                        (1 << Owner.gameObject.layer));
    }

    public override void OnStartAbility()
    {
        if (m_PoisonDartAbilityTimer <= 0)
        {
            AddAssist();

            Owner.AudioSourceAbility3.Play();

            if (m_PlayerHit)
            {
                ContinuousAbilityStarted = true;
                ContinuousAbilityInUse = true;
                m_ReferenceToPlayerHit = m_ClosestEnemy;

                Owner.AudioSourceAbility3.PlayOneShot(m_HitClip, 1f);

                //Deal 0 damage so that the damage indicator shows up when the player is hit by the dart
                m_ReferenceToPlayerHit.GetComponent<Health>().Damage(Owner, Owner.gameObject, 0f, DeathType.Spikes, true);

                m_ReferenceToPlayerHit.Poison(m_PoisonDuration, Owner);
                m_PoisonTimer -= Time.fixedDeltaTime;
            }

            GameObject InstancedObjectContainer = InputManager.CM.GetInstancedObjectContainer();

            //Spawn the dart and shoot it
            GameObject obj = GameObject.Instantiate(Owner.GetComponent<Zeph>().PoisonDartPrefab, Owner.PlayerCamera.transform.position + Owner.PlayerCamera.transform.forward, Owner.PlayerCamera.transform.rotation) as GameObject;
            obj.GetComponent<Rigidbody>().AddForce(m_DirectionToEnemy.normalized * m_ThrowForce, ForceMode.Impulse);

            obj.transform.SetParent(InstancedObjectContainer.transform);

            m_PoisonDartAbilityTimer = m_PoisonDartCooldown;
        }
    }

    public override void OnContinueAbility()
    {
    }

    public override void OnEndAbility()
    {
    }

    void AddAssist()
    {
        m_PlayerHit = false;
        m_PlayersThatCanBeHit = new List<Player>();
        m_ClosestEnemy = null;
        m_PlayersThatCanBeHit.Clear();

        //Set direction to enemy to players forward, so if no enemy is closeby, just shoot straight
        m_DirectionToEnemy = Owner.PlayerCamera.transform.forward;

        //Spherecast infront of the player and check for only other players, m_SphereCastRadius is the variable to adjust to change the amount of assist(lul)
        RaycastHit[] hits = Physics.SphereCastAll(Owner.transform.position, m_AimAssistSphereCastRadius, Owner.transform.forward, Mathf.Infinity, m_LayerMask, QueryTriggerInteraction.Ignore);
        for (int i = 0; i < hits.Length; i++)
        {
            RaycastHit hitInArray = hits[i];

            Player player = null;
            if (hitInArray.collider.GetComponent<PlayerHitboxScript>() != null)
                player = hitInArray.collider.GetComponent<PlayerHitboxScript>().Owner;

            if (player != null)
            {
                if (player.TeamIndex != Owner.TeamIndex)
                {
                    if (player != Owner)
                    {
                        //If a player was hit, add them to a list
                        m_PlayersThatCanBeHit.Add(player);
                    }
                }
            }
        }

        float angleToEnemy = float.MaxValue;

        //If there were any players hit, check the angle between where the player is looking, and the enemy
        //If there is more than one enemy in the list, set the one that has the lowest angle to m_ClosestEnemy, since that's the closest one to where the player is aiming
        if (m_PlayersThatCanBeHit.Count > 0)
        {
            for (int i = 0; i < m_PlayersThatCanBeHit.Count; i++)
            {
                Player ObjectInList = m_PlayersThatCanBeHit[i];

                m_DirectionToEnemy = ObjectInList.transform.position - Owner.transform.position;

                if (Vector3.Angle(Owner.PlayerCamera.transform.forward, m_DirectionToEnemy) < angleToEnemy)
                {
                    angleToEnemy = Vector3.Angle(Owner.PlayerCamera.transform.forward, m_DirectionToEnemy);
                    //Debug.Log(angleToEnemy);
                    m_ClosestEnemy = ObjectInList;
                }
            }
        }

        //If there is an enemy, raycast to it, to make sure you can't hit through a wall
        if (m_ClosestEnemy != null)
        {
            RaycastHit hit;
            if (Physics.Raycast(Owner.transform.position, m_DirectionToEnemy, out hit, Mathf.Infinity))
            {
                m_PlayerHit = true;
            }
        }
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        if (m_PoisonDartAbilityTimer > 0f)
            m_PoisonDartAbilityTimer -= Time.fixedDeltaTime;

        if (Owner.IsAI)
            return;

        //Do UI stuff
        Owner.AbilityUICooldowns.Ability3Info.UseCooldown = m_PoisonDartAbilityTimer / m_PoisonDartCooldown;
        if (m_PoisonDartAbilityTimer <= 0)
        {
            Owner.AbilityUICooldowns.Ability3Info.Usable = true;
        }
        else
        {
            Owner.AbilityUICooldowns.Ability3Info.Usable = false;
        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_PoisonDartAbilityTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_PoisonDartAbilityTimer <= 0)
            return true;
        return false;
    }
}