﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        TurretScript                                                                   *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 22th, 2016                                                             *
 *                                                                                                 *
 * This script is meant to be attached to Quark's turret. This script will handle the aiming,      *
 * shooting, and health of the turret.                                                             *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 22th, 2016                                          *
\***************************************************************************************************/
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TurretScript : MonoBehaviour
{
    //
    //public
    //
    public Player Owner;
    public float RotationSpeed = 0.5f;
    public const float TurretRange = 30.0f;
    public float TurretDamage = 2.5f;
    public float DamageCooldown = 0.35f;
    public bool IsActivated { get; private set; }
    public AudioClip ShootClip;
    [HideInInspector]
    public bool IsInSmoke = false;
    public GameObject m_RagdollPrefab;

    public BoxCollider BoxCollider
    {
        get
        {
            if (m_BoxCollider == null)
            {
                m_BoxCollider = GetComponent<BoxCollider>();
            }
            return m_BoxCollider;
        }
    }

    //
    //private
    //
    private AudioSource m_Audiosource;
    private List<Player> ListOfPlayers;
    private List<TurretScript> ListOfTurrets;
    private GameObject m_Target;
    private Vector3 m_TargetPosition;
    private int m_LayerMask;
    private float m_DamageTimer;
    private Transform m_Stand;
    private Transform m_ShootPoint;
    private Transform m_HorizontalRotationPoint;
    private Transform m_VerticalRotationPoint;
    private ParticleSystem m_MuzzleFlashLeft;
    private ParticleSystem m_MuzzleFlashRight;
    private Health m_Health;
    private bool m_initializing = true;
    private BoxCollider m_BoxCollider;
    private bool m_HasSpawnedRagdoll = false;
    private Collider m_TargetCollider;

    //strings
    private const string m_PlayerTagString = "Player";

    private const string m_ShootPointTransform = "ShootPoint";
    private const string m_SidewaysTransform = "Sideways";
    private const string m_StandTransform = "Stand";
    private const string m_TurretHeadTransform = "Turret Head";
    private const string m_MuzzleFlashLeftTransform = "MuzzleFlashLeft";
    private const string m_MuzzleFlashRightTransform = "MuzzleFlashRight";

    private const string m_UnplacedObjectsMask = "UnplacedObjects";
    private const string m_QuarkCameraMask = "QuarkCamera";
    private const string m_QuarkTurretMask = "QuarkTurret";
    private const string m_IgnoreRaycastMask = "Ignore Raycast";
    private const string m_RagdollMask = "Ragdoll";

    void Start ()
    {
        Information.AddTurret(this);

        m_DamageTimer = 0;
        IsActivated = false;
        ListOfPlayers = Information.AllPlayers;
        m_ShootPoint = transform.FindChild(m_ShootPointTransform);
        m_HorizontalRotationPoint = transform.FindChild(m_SidewaysTransform).transform.FindChild(m_StandTransform);
        m_VerticalRotationPoint = transform.FindChild(m_SidewaysTransform).FindChild(m_StandTransform).FindChild(m_TurretHeadTransform);
        m_MuzzleFlashLeft = m_VerticalRotationPoint.Find(m_MuzzleFlashLeftTransform).gameObject.GetComponent<ParticleSystem>();
        m_MuzzleFlashRight = m_VerticalRotationPoint.Find(m_MuzzleFlashRightTransform).gameObject.GetComponent<ParticleSystem>();
        m_Health = gameObject.GetComponent<Health>();
        m_Audiosource = GetComponent<AudioSource>();

        m_BoxCollider = GetComponent<BoxCollider>();
    }

    public void SetOwner(Player owner)
    {
        Owner = owner;
        LayerMask ownerLayer = Owner.gameObject.layer;
        m_LayerMask = ~((1 << LayerMask.NameToLayer(m_UnplacedObjectsMask)) |
            (1 << LayerMask.NameToLayer(m_QuarkCameraMask)) |
            (1 << LayerMask.NameToLayer(m_QuarkTurretMask)) |
            (1 << LayerMask.NameToLayer("WallCollider")) |
            (1 << LayerMask.NameToLayer(m_IgnoreRaycastMask)) |
            (1 << LayerMask.NameToLayer(m_RagdollMask)) |
            (1 << ownerLayer));
    }
	
	void FixedUpdate ()
    {
        if(m_initializing)
        {
            m_initializing = false;
            gameObject.SetActive(false);
        }
        //Check to see if the turret is finished building
        if(IsActivated)
        {
            ListOfPlayers = Information.AllPlayers;
            ListOfTurrets = Information.AllTurrets;

            //See if target from previous frame is still a valid target
            if (m_Target != null)
            {
                if(CheckIfValidTarget(m_Target, Vector3.up) == false)
                {
                    //Target is no longer valid
                    m_Target = null;
                    Retarget();
                }
                else
                {
                    //raycast hit the target or another player. don't change target
                }
            }
            else
            {
                Retarget();
            }

            //if the turret has a target, face and deal damage to it as long as the turret isn't in smoke
            if (m_Target != null && !IsInSmoke)
            {
                float targetHeightHalf = 0;
                Vector3 targetHeightAdjustment = Vector3.zero;

                Player player = m_Target.GetComponent<Player>();
                //if the target is a player, the height must be accounted for
                if (player != null)
                {
                    //TODO: actually calculate player height
                    targetHeightHalf = 1.0f;
                    targetHeightAdjustment = new Vector3(0.0f, targetHeightHalf, 0.0f);
                }

                m_TargetPosition = m_Target.transform.position + targetHeightAdjustment;
                //Debug.DrawLine(m_ShootPoint.position, m_Target.transform.position + playerHeight, Color.red);

                m_DamageTimer += Time.fixedDeltaTime;


                //rotate turret to face current target
                Vector3 targetPosition = new Vector3(m_TargetPosition.x,
                                            m_HorizontalRotationPoint.position.y,
                                            m_TargetPosition.z);

                //Modify the yaw of the turret
                Vector3 dir = targetPosition - m_HorizontalRotationPoint.position;
                Quaternion rot = Quaternion.LookRotation(dir);
                m_HorizontalRotationPoint.rotation = Quaternion.Slerp(m_HorizontalRotationPoint.rotation, rot, 15 * Time.fixedDeltaTime);

                Vector3 horizontalAngle = m_HorizontalRotationPoint.localEulerAngles;
                horizontalAngle.x = 0;
                horizontalAngle.z = 0;
                m_HorizontalRotationPoint.localEulerAngles = horizontalAngle;

                //Modify the pitch of the turret
                targetPosition = m_TargetPosition;
                dir = targetPosition - m_VerticalRotationPoint.position;
                rot = Quaternion.LookRotation(dir);
                m_VerticalRotationPoint.rotation = Quaternion.Slerp(m_VerticalRotationPoint.rotation, rot, 15 * Time.fixedDeltaTime);

                //Make sure the pitch adjustment doesn't also change the yaw
                Vector3 verticalAngles = m_VerticalRotationPoint.eulerAngles;
                verticalAngles.y = m_HorizontalRotationPoint.eulerAngles.y;
                verticalAngles.z = m_HorizontalRotationPoint.eulerAngles.z;
                m_VerticalRotationPoint.eulerAngles = verticalAngles;



                //Deal damage to the target
                if (m_DamageTimer > DamageCooldown)
                {
                    Health health = m_Target.GetComponent<Health>();
                    if (health != null)
                    {
                        if(health.IsDead == false)
                        {
                            m_Audiosource.clip = ShootClip;
                            m_Audiosource.PlayOneShot(m_Audiosource.clip, 0.65f);
                            m_MuzzleFlashLeft.Play();
                            m_MuzzleFlashRight.Play();

                            m_DamageTimer -= DamageCooldown;

                            if (health.Damage(Owner, gameObject, TurretDamage, DeathType.Turret, true) && m_TargetCollider.GetComponent<PlayerHitboxScript>() != null)
                            {
                                m_TargetCollider.GetComponent<PlayerHitboxScript>().AddForce(m_ShootPoint.forward * 40, m_TargetCollider.transform.position);
                            }
                            if (player != null)
                                AchievementsManager.IncrementInteger(player, Achievements.TimesShotByTurret, 1);
                        }
                    }
                }
            }
            //Make the turret spin around as if it's looking for targets
            else
            {
                Quaternion verticalAngles = m_VerticalRotationPoint.transform.rotation;
                Quaternion rot = Quaternion.LookRotation(m_HorizontalRotationPoint.forward, m_HorizontalRotationPoint.up);
                verticalAngles = Quaternion.Slerp(verticalAngles, rot, 15 * Time.fixedDeltaTime);
                m_VerticalRotationPoint.rotation = verticalAngles;

                m_HorizontalRotationPoint.RotateAround(transform.up, RotationSpeed * Time.fixedDeltaTime);
            }
        }
        else
        {
            m_HorizontalRotationPoint.localEulerAngles = Vector3.zero;
            m_VerticalRotationPoint.localEulerAngles = Vector3.zero;
        }

        if (m_Health.IsDead)
        {
            SpawnRagdoll(gameObject.transform);
            gameObject.SetActive(false);
        }

        IsInSmoke = false;
    }

    //Makes turret target the closest player that isn't behind a wall or the owner
    void Retarget()
    {
        Vector3 targetHeightAdjustment = Vector3.zero;

        for (int i = 0; i < ListOfPlayers.Count; i++)
        {
            Player player = ListOfPlayers[i];

            if (player == null || player == Owner || player.TeamIndex == Owner.TeamIndex || player.IsDead)
                continue;

            //TODO: calculate actual player height
            float playerHeightHalf = 1.0f;
            targetHeightAdjustment = new Vector3(0.0f, playerHeightHalf, 0.0f);

            //did we hit a player?
            if (CheckIfValidTarget(player.gameObject, targetHeightAdjustment) == true)
            {
                if (m_Target == null)
                {
                    m_Target = player.gameObject;
                    m_TargetPosition = m_Target.transform.position;
                }
                else
                {
                    //See if player is closer than current target
                    float currentTargetDistance = Vector3.Distance(transform.position, m_TargetPosition);
                    float newTargetDistance = Vector3.Distance(transform.position, player.transform.position);
                    if (newTargetDistance < currentTargetDistance)
                    {
                        //new target is closer. they are now the target
                        m_Target = player.gameObject;
                        m_TargetPosition = m_Target.transform.position;
                    }
                }
            }
        }

        //we found a player to target
        if (m_Target != null)
        {
            m_TargetPosition = m_Target.transform.position + targetHeightAdjustment;
            return;
        }

        //If there are no players around, target enemy turrets
        for (int i = 0; i < ListOfTurrets.Count; i++)
        {
            TurretScript turret = ListOfTurrets[i];

            if (turret.Owner == Owner || turret.Owner.TeamIndex == Owner.TeamIndex )
                continue;

            float turretHeightHalf = turret.BoxCollider.size.y / 2.0f;
            targetHeightAdjustment = new Vector3(0.0f, turretHeightHalf, 0.0f);

            //did we hit a turret that's been placed?
            if (CheckIfValidTarget(turret.gameObject, targetHeightAdjustment) == true)
            {
                if (m_Target == null)
                {
                    m_Target = turret.gameObject;
                    m_TargetPosition = m_Target.transform.position;
                }
                else
                {
                    //See if target is closer than current target
                    float currentTargetDistance = Vector3.Distance(transform.position, m_TargetPosition);
                    float newTargetDistance = Vector3.Distance(transform.position, turret.transform.position);
                    if (newTargetDistance < currentTargetDistance)
                    {
                        //new target is closer. they are now the target
                        m_Target = turret.gameObject;
                        m_TargetPosition = m_Target.transform.position;
                    }
                }
            }
        }

        //we found a turret to target
        if (m_Target != null)
        {
            // Set target position at turret half height?
            return;
        }
    }

    bool CheckIfValidTarget(GameObject target, Vector3 targetHeightAdjustment)
    {
        //Owner and this are not valid targets
        if (target != Owner && target != gameObject)
        {
            if (Vector3.Distance(m_ShootPoint.position, target.transform.position) <= TurretRange)
            {
                //raycast to make sure the player isn't behind a wall
                RaycastHit hitInfo;
                if (Physics.Raycast(m_ShootPoint.position, target.transform.position - m_ShootPoint.position + targetHeightAdjustment, out hitInfo, TurretRange, m_LayerMask, QueryTriggerInteraction.Ignore))
                {
                    //The raycast hit something
                    GameObject hitObject = hitInfo.collider.gameObject;

                    Health health = hitObject.GetComponent<Health>();
                    if(health != null)
                    {
                        //It hit our target
                        if (hitObject == target)
                        {
                            m_TargetCollider = hitObject.GetComponent<Collider>();
                            return true;
                        }
                    }

                    else
                    {
                        PlayerHitboxScript playerHitbox = hitObject.GetComponent<PlayerHitboxScript>();
                        if(playerHitbox != null && target.GetComponent<Player>() != null)
                        {
                            if (playerHitbox.Owner == target.GetComponent<Player>())
                            {
                                health = playerHitbox.Owner.GetComponent<Health>();

                                if(health != null)
                                {
                                    if(health.IsDead == false)
                                    {
                                        m_TargetCollider = hitObject.GetComponent<Collider>();
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public void Reset(Vector3 position, Quaternion rotation)
    {
        gameObject.SetActive(true);
        transform.position = position;
        transform.rotation = rotation;
        IsActivated = false;
        m_HasSpawnedRagdoll = false;
        m_Health.CurrentHealth = m_Health.MaxHealth;
    }

    public void ActivateTurret()
    {
        IsActivated = true;
    }

    public void SpawnRagdoll(Transform trans)
    {
        if(m_HasSpawnedRagdoll == false && m_RagdollPrefab != null)
        {
            GameObject ragdoll = GameObject.Instantiate(m_RagdollPrefab, trans) as GameObject;
            ragdoll.transform.SetParent(null);
            ragdoll.transform.position = trans.position;
            ragdoll.transform.rotation = trans.rotation;
            ragdoll.GetComponent<QuarkTurretRagdollInfo>().SetBoneInfo(GetComponent<QuarkTurretRagdollInfo>());
            m_HasSpawnedRagdoll = true;
        }
    }
}
