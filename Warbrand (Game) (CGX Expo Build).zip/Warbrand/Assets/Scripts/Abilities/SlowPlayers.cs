﻿using UnityEngine;
using System.Collections;

public class SlowPlayers : MonoBehaviour
{
    public TMNThrowableFunctionality Adhesive;
	void Start ()
    {
	
	}
	
	void Update ()
    {
	
	}

    void OnTriggerEnter(Collider other)
    {
        Adhesive.SlowPlayer(other);
    }

    void OnTriggerExit(Collider other)
    {
        Adhesive.UnslowPlayer(other);
    }
}
