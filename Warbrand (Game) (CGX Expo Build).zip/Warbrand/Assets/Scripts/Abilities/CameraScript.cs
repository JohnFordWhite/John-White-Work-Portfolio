﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        CameraScript                                                                   *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 23th, 2016                                                             *
 *                                                                                                 *
 * This script is meant to be attached to Quark's camera. The camera will aim at the closest player*
 * (other than the owner) and will keep aiming at them until they are no longer a valid target. The*
 * camera will determine which players are visible to it and within range and will change the      *
 * CanSeePlayer?XRay in Player.cs to reflect this                                                  *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 23rd, 2016                                          *
 * V 1.1 - Added placement functionality similar to BuildTurret.cs (John White) - October 29, 2016 *
\***************************************************************************************************/
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CameraScript : MonoBehaviour
{
    //
    //public
    //
    public float CameraRange = 100.0f;
    public float PropellerRotationSpeed = 1440;
    public float OscillateAmount = 0.2f;
    public float OscillateSpeed = 4.0f;
    public GameObject m_RagdollPrefab;

    [HideInInspector]
    public Player Owner;
    [HideInInspector]
    public bool IsInSmoke = false;

    //
    //private
    //
    private List<Player> ListOfPlayers;
    private Player m_Target;
    private int m_LayerMask;
    private Transform m_Body;
    private Transform m_LookPoint;
    private Transform m_RotationPoint;
    private Health m_Health;
    private NavMeshAgent m_Agent;
    private bool m_Initializing = true;
    private bool m_HasSpawnedRagdoll = false;

    //strings
    private const string m_PlayerTagString = "Player";

    private const string m_BodyTransform = "Body";
    private const string m_LookPointTransform = "LookPoint";
    private const string m_CameraTransform = "Camera";

    private const float RecheckDestinationWaitTime = 0.2f;
    private WaitForSeconds RecheckDestinationWait = new WaitForSeconds(RecheckDestinationWaitTime);

    void Start()
    {
        m_LayerMask = ~((1 << LayerMask.NameToLayer("UnplacedObjects")) |
            (1 << LayerMask.NameToLayer("QuarkCamera")) |
            (1 << LayerMask.NameToLayer("Ignore Raycast")) |
            (1 << LayerMask.NameToLayer("WallCollider")) |
            (1 << LayerMask.NameToLayer("Ragdoll")));

        ListOfPlayers = Information.AllPlayers;
        m_Body = transform.FindChild(m_BodyTransform);
        m_LookPoint = transform.FindChild(m_LookPointTransform);
        m_RotationPoint = transform.FindChild(m_CameraTransform);

        m_Body.gameObject.GetComponent<Renderer>().material.SetColor("_Color", BaseGameMode.TeamColors[Owner.TeamIndex]);
        m_RotationPoint.gameObject.GetComponent<Renderer>().material.SetColor("_Color", BaseGameMode.TeamColors[Owner.TeamIndex]);

        m_Health = GetComponent<Health>();
        m_Agent = GetComponent<NavMeshAgent>();

        StartCoroutine(RecheckDestination());
    }

    // Update is called once per frame
    void Update()
    {
        if(m_Initializing)
        {
            m_Initializing = false;
            Deactivate();
            return;
        }
        if (ListOfPlayers == null || ListOfPlayers.Count <= 0)
        {
            ListOfPlayers = Information.AllPlayers;
        }

        if(m_Agent.enabled == false)
        {
            m_Agent.enabled = true;
        }

        //See if target from previous frame is still a valid target
        if (m_Target != null && !(m_Target.IsDead))
        {
            //TODO: make the camera look at it's target
            if (CheckIfValidTarget(m_Target) == false)
            {
                //Target is no longer valid
                m_Target = null;
            }
            else
            {
                //raycast hit the target or another player. don't change target
                m_Agent.SetDestination(m_Target.transform.position);
            }
        }
        else
        {
            Retarget();
        }

        //tell the owner which players the camera can and can't see
        DetermineVisiblePlayers();

        if (m_Health.IsDead)
        {
            SpawnRagdoll(gameObject.transform);
            Deactivate();
        }

        //Rotate the "body" to look like propellers
        Vector3 angle = m_Body.transform.eulerAngles;
        angle.y += PropellerRotationSpeed * Time.deltaTime;
        m_Body.transform.eulerAngles = angle;

        //Move up and down to look like the camera is hovering
        transform.position += new Vector3(0, Mathf.Sin(Time.realtimeSinceStartup * OscillateSpeed) * OscillateAmount * Time.deltaTime, 0);

        IsInSmoke = false;
    }

    //Makes turret target the closest player that isn't behind a wall or the owner
    void Retarget()
    {
        for (int i = 0; i < ListOfPlayers.Count; i++)
        {
            Player player = ListOfPlayers[i];

            if (CheckIfValidTarget(player) == true)
            {
                if (m_Target == null)
                {
                    m_Target = player;
                }
                else
                {
                    //See if player is closer than current target
                    float currentTargetDistance = Vector3.Distance(transform.position, m_Target.transform.position);
                    float newTargetDistance = Vector3.Distance(transform.position, player.transform.position);
                    if (newTargetDistance < currentTargetDistance)
                    {
                        //new target is closer. they are now the target
                        m_Target = player;
                    }
                }
            }

        }
    }

    public void Deactivate()
    {
        Owner.CanSeePlayer1XRay = false;
        Owner.CanSeePlayer2XRay = false;
        Owner.CanSeePlayer3XRay = false;
        Owner.CanSeePlayer4XRay = false;
        Owner.CanSeePlayer5XRay = false;
        Owner.CanSeePlayer6XRay = false;
        Owner.CanSeePlayer7XRay = false;
        Owner.CanSeePlayer8XRay = false;
        gameObject.SetActive(false);
    }

    bool CheckIfValidTarget(Player player)
    {
        //Owner is not a valid target
        if (player != Owner && player.TeamIndex != Owner.TeamIndex)
        {
            RaycastHit[] hits = Physics.RaycastAll(m_LookPoint.position, MathUtils.DirectionVector(m_LookPoint.position, player.transform.position + Vector3.up), Vector3.Distance(m_LookPoint.position, player.transform.position + Vector3.up));
            
            for (int i = 0; i < hits.Length; i++)
            {
                RaycastHit hit = hits[i];

                if (hit.collider.isTrigger)
                    continue;
                if (hit.transform.gameObject == gameObject)
                    continue;
                if (hit.transform.parent != null)
                    if (hit.transform.parent.gameObject == gameObject)
                        continue;
                if (hit.transform.gameObject == player.gameObject)
                    continue;
                if (hit.transform.parent != null)
                    if (hit.transform.parent.gameObject == player.gameObject)
                        continue;

                return false;
            }

            return true;
        }

        return false;
    }

    void DetermineVisiblePlayers()
    {
        //Clear the players that can be seen. This is for the ai
        Owner.CanSeePlayer1XRay = false;
        Owner.CanSeePlayer2XRay = false;
        Owner.CanSeePlayer3XRay = false;
        Owner.CanSeePlayer4XRay = false;
        Owner.CanSeePlayer5XRay = false;
        Owner.CanSeePlayer6XRay = false;
        Owner.CanSeePlayer7XRay = false;
        Owner.CanSeePlayer8XRay = false;

        for (int i = 0; i < ListOfPlayers.Count; i++)
        {
            Player player = ListOfPlayers[i];

            if (player != Owner && player.TeamIndex != Owner.TeamIndex)
            {
                int id = player.GameInput.PlayerID;

                switch (id)
                {
                    case 1:
                        if(CheckIfValidTarget(player) && !IsInSmoke)
                        {
                            Owner.CanSeePlayer1XRay = true;
                            AchievementsManager.IncrementFloat(player, Achievements.TimeSeenByCamera, Time.deltaTime);
                        }
                        break;
                    case 2:
                        if (CheckIfValidTarget(player) && !IsInSmoke)
                        {
                            Owner.CanSeePlayer2XRay = true;
                            AchievementsManager.IncrementFloat(player, Achievements.TimeSeenByCamera, Time.deltaTime);
                        }
                        break;
                    case 3:
                        if (CheckIfValidTarget(player) && !IsInSmoke)
                        {
                            Owner.CanSeePlayer3XRay = true;
                            AchievementsManager.IncrementFloat(player, Achievements.TimeSeenByCamera, Time.deltaTime);
                        }
                        break;
                    case 4:
                        if (CheckIfValidTarget(player) && !IsInSmoke)
                        {
                            Owner.CanSeePlayer4XRay = true;
                            AchievementsManager.IncrementFloat(player, Achievements.TimeSeenByCamera, Time.deltaTime);
                        }
                        break;
                    case 5:
                        if (CheckIfValidTarget(player) && !IsInSmoke)
                        {
                            Owner.CanSeePlayer5XRay = true;
                            AchievementsManager.IncrementFloat(player, Achievements.TimeSeenByCamera, Time.deltaTime);
                        }
                        break;
                    case 6:
                        if (CheckIfValidTarget(player) && !IsInSmoke)
                        {
                            Owner.CanSeePlayer6XRay = true;
                            AchievementsManager.IncrementFloat(player, Achievements.TimeSeenByCamera, Time.deltaTime);
                        }
                        break;
                    case 7:
                        if (CheckIfValidTarget(player) && !IsInSmoke)
                        {
                            Owner.CanSeePlayer7XRay = true;
                            AchievementsManager.IncrementFloat(player, Achievements.TimeSeenByCamera, Time.deltaTime);
                        }
                        break;
                    case 8:
                        if (CheckIfValidTarget(player) && !IsInSmoke)
                        {
                            Owner.CanSeePlayer8XRay = true;
                            AchievementsManager.IncrementFloat(player, Achievements.TimeSeenByCamera, Time.deltaTime);
                        }
                        break;
                    default:
#if UNITY_EDITOR
                        DebugManager.LogError("CameraScript.DetermineVisiblePlayers() - Couldn't figure out player number: " + id, Developmer.John);
#endif
                        break;
                }

                //make sure players can see the same xray outlines that thier teammates can
                for (int j = 0; j < ListOfPlayers.Count; j++)
                {
                    if (ListOfPlayers[j] != Owner && ListOfPlayers[j].TeamIndex == Owner.TeamIndex)
                    {
                        if (Owner.CanSeePlayer1XRay)
                        {
                            ListOfPlayers[j].CanSeePlayer1XRay = true;
                        }
                        if (Owner.CanSeePlayer2XRay)
                        {
                            ListOfPlayers[j].CanSeePlayer2XRay = true;
                        }
                        if (Owner.CanSeePlayer3XRay)
                        {
                            ListOfPlayers[j].CanSeePlayer3XRay = true;
                        }
                        if (Owner.CanSeePlayer4XRay)
                        {
                            ListOfPlayers[j].CanSeePlayer4XRay = true;
                        }
                        if (Owner.CanSeePlayer5XRay)
                        {
                            ListOfPlayers[j].CanSeePlayer5XRay = true;
                        }
                        if (Owner.CanSeePlayer6XRay)
                        {
                            ListOfPlayers[j].CanSeePlayer6XRay = true;
                        }
                        if (Owner.CanSeePlayer7XRay)
                        {
                            ListOfPlayers[j].CanSeePlayer7XRay = true;
                        }
                        if (Owner.CanSeePlayer8XRay)
                        {
                            ListOfPlayers[j].CanSeePlayer8XRay = true;
                        }
                    }
                }
            }
        }
    }

    private int m_NumberOfChecks = 0;
    private float m_RadiusToCheck = 15f;
    IEnumerator RecheckDestination()
    {
        while(true)
        {
            yield return RecheckDestinationWait;
            //DebugManager.Log("Camera Target: " + m_Target, Developmer.Nathan);
            if (m_Target != null)
                m_Agent.SetDestination(m_Target.transform.position);
            else
            {
                if(m_Agent.pathStatus == NavMeshPathStatus.PathComplete || m_Agent.pathStatus == NavMeshPathStatus.PathInvalid)
                {
                    Vector3 point = transform.position;
                    {
                        float angle = UnityEngine.Random.Range(-45f, 45f) + transform.eulerAngles.y;
                        if (m_NumberOfChecks++ % 10 == 0)
                        {
                            point.x -= m_RadiusToCheck * Mathf.Sin(angle * Mathf.Deg2Rad);
                            point.z -= m_RadiusToCheck * Mathf.Cos(angle * Mathf.Deg2Rad);
                        }
                        else
                        {
                            point.x += m_RadiusToCheck * Mathf.Sin(angle * Mathf.Deg2Rad);
                            point.z += m_RadiusToCheck * Mathf.Cos(angle * Mathf.Deg2Rad);
                        }
                    }
                    m_Agent.SetDestination(point);
                }
            }
        }
    }

    IEnumerator CheckForOutOfBounds()
    {
        while(true)
        {
            yield return new WaitForEndOfFrame();

            if (Mathf.Abs(transform.position.x) > 1000f)
                Deactivate();
            if (Mathf.Abs(transform.position.y) > 1000f)
                Deactivate();
            if (Mathf.Abs(transform.position.z) > 1000f)
                Deactivate();
        }
    }

    public void Reset()
    {
        //reset stuff
        m_Health.CurrentHealth = m_Health.MaxHealth;
        gameObject.SetActive(true);
        m_HasSpawnedRagdoll = false;
        return;
    }

    public void SpawnRagdoll(Transform trans)
    {
        if (m_HasSpawnedRagdoll == false && m_RagdollPrefab != null)
        {
            GameObject ragdoll = GameObject.Instantiate(m_RagdollPrefab, trans) as GameObject;
            ragdoll.transform.SetParent(null);
            ragdoll.transform.position = trans.position;
            ragdoll.transform.rotation = trans.rotation;
            ragdoll.GetComponent<QuarkCameraRagdollInfo>().SetBoneInfo(GetComponent<QuarkCameraRagdollInfo>());
            m_HasSpawnedRagdoll = true;
        }
    }
}