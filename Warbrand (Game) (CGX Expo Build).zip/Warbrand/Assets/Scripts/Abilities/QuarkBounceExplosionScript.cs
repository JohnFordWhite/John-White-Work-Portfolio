﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        QuarkBounceExplosionScript                                                     *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 16th, 2016                                                             *
 *                                                                                                 *
 * This script is to be attached to a sphere that represents the blast from Quark's bounce ability.*
 * This script is purely for visual effect. It is essentially the same as ExplosionScript.cs, but  *
 * it does not deal damage.                                                                        *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 16th, 2016                                          *
 *                                                                                                 *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;

public class QuarkBounceExplosionScript : MonoBehaviour {

    public float MaxRadius = 5.0f;

    private float m_Life;
    private float m_RadiusIncreasePerSecond = 0f; // HACK: This was originally not set as anything. Have changed it to be zero to get rid of a warning -Nathan

    private ParticleSystem m_BounceExplosionParticleEffect;

    private const string m_BounceExplosionTransform = "BounceExplosion";
    private const string m_OrbittersTransform = "Orbitters";

    // Use this for initialization
    void Start ()
    {
        m_Life = 0.0f;

        //One of the particle systems in the bounce explosion effect. has the longest time, so this can be used to find when the explosion effect is done playing
        m_BounceExplosionParticleEffect = gameObject.transform.FindChild(m_BounceExplosionTransform).FindChild(m_OrbittersTransform).gameObject.GetComponent<ParticleSystem>();
    }
	
	void FixedUpdate ()
    {
        m_Life += Time.fixedDeltaTime;

        float radius = m_RadiusIncreasePerSecond * m_Life;
        Vector3 newScale = new Vector3(radius, radius, radius);
        transform.localScale = newScale;

        if (m_BounceExplosionParticleEffect.isPlaying)
        {
            GetComponent<SphereCollider>().enabled = false;
        }
        else
        {
            Destroy(gameObject);
        }
	}
}
