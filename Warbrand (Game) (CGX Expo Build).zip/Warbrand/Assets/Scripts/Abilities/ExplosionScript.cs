﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ExplosionScript                                                                *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 16th, 2016                                                             *
 *                                                                                                 *
 * This script is to be attached a sphere (or any object you want to represent an explosion). This *
 *  script will make the object expand until it eventually reaches it's maximum radius. If the     *
 * explosion touches a player, it will deal damage to them based on how close they were to the     *
 * explosion                                                                                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 16th, 2016                                          *
 *                                                                                                 *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Audio;

public class ExplosionScript : MonoBehaviour
{

    public float Radius = 5.0f;
    public float Damage = 30.0f;
    [HideInInspector]
    public Player Owner;

    private float m_Life;
    private float m_ChanceToPlayDialogue = 0.1f;
    private AudioSource m_AudioSource;
    private ParticleSystem m_ExplosionParticleEffect;
    private List<Player> m_PlayersHit = null;

    private int m_LayerMask;

    private bool m_GrenadeHitDialoguePlayed = false;

    private const string m_ExplosiveGrenadeLPF = "ExplosiveGrenadeLPF";

    private const string m_GrenadeExplosionTransform = "GrenadeExplosion";
    private const string m_ShowerTransform = "Shower";

    void Start ()
    {
        m_Life = 0.0f;
        m_AudioSource = GetComponent<AudioSource>();

        AudioUtils.SetLPF(this.gameObject, m_ExplosiveGrenadeLPF);
        AudioUtils.SetVolumeByDistance(this.gameObject,false);
        m_AudioSource.Play();

        m_LayerMask = ~((1 << LayerMask.NameToLayer("UnplacedObjects")) |
                        (1 << LayerMask.NameToLayer("WallCollider")) |
                        (1 << LayerMask.NameToLayer("Ignore Raycast")));

        m_PlayersHit = new List<Player>();
        m_PlayersHit.Capacity = Information.AllPlayers.Count;
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }

        //One of the particle systems in the explosion effect. has the longest time, so this can be used to find when the explosion effect is done playing
        m_ExplosionParticleEffect = gameObject.transform.FindChild(m_GrenadeExplosionTransform).FindChild(m_ShowerTransform).gameObject.GetComponent<ParticleSystem>();

        HandleExplosionDamage();
    }
	
	void FixedUpdate ()
    {
        m_Life += Time.fixedDeltaTime;

        if (m_AudioSource.isPlaying || m_ExplosionParticleEffect.isPlaying)
        {
            //do nothing
        }
        else
        {
            Destroy(gameObject);
        }
	}
    
    void HandleExplosionDamage()
    {
        //Debug.Log("Explode" + Time.realtimeSinceStartup);
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, Radius, m_LayerMask, QueryTriggerInteraction.Collide);
        
        for (int i = 0; i < hitColliders.Length; i++)
        {
            Collider collider = hitColliders[i];

            Player player = null;

            if (collider.GetComponent<PlayerHitboxScript>() != null)
                player = collider.GetComponent<PlayerHitboxScript>().Owner;

            Health colliderHealth = null;

            if(player != null)
            {
                if(!m_PlayersHit.Contains(player))
                {
                    colliderHealth = player.GetComponent<Health>();
                    m_PlayersHit.Add(player);
                }
                else if(player.GetComponent<Health>().IsDead && collider.GetComponent<PlayerHitboxScript>() != null)
                {
                    ApplyPhysics(collider);
                }
            }
            else
            {
                colliderHealth = collider.gameObject.GetComponent<Health>();
            }

            if (colliderHealth != null)
            {
                {
                    float damagePerDistance = Damage / Radius;
                    float distanceFromExplosion = Vector3.Distance(collider.gameObject.transform.position, transform.position);
                    float damageToDeal = Damage - (distanceFromExplosion * damagePerDistance);
                    
                    //make sure the explosion can't heal the player
                    if (damageToDeal > 0)
                    {
                        float damageModifier = 1;
                        if (player != null && player != Owner)
                            damageModifier = 0.5f;

                        if (colliderHealth.Damage(Owner, gameObject, damageToDeal * damageModifier, DeathType.Physics) && collider.GetComponent<PlayerHitboxScript>() != null)
                        {
                            if(!m_GrenadeHitDialoguePlayed)
                            {
                                bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
                                if (playDialogue)
                                {
                                    DialogueManager.Instance.PlayDialogue(CharacterTypes.Leeroy, DialogueContext.LeeroyGrenadeHit, false, true);
                                    m_GrenadeHitDialoguePlayed = true;
                                }
                            }

                            ApplyPhysics(collider);
                        }
                    }
                }
            }
        }
    }

    void ApplyPhysics(Collider collider)
    {
        Vector3 direction = collider.transform.position - transform.position;
        direction = direction.normalized;
        float forceAmount = 20;
        float forcePerDistance = forceAmount / Radius;
        float distanceFromExplosion = Vector3.Distance(collider.gameObject.transform.position, transform.position);
        float forceToApply = forceAmount - (distanceFromExplosion * forcePerDistance);
        collider.GetComponent<PlayerHitboxScript>().AddForce(direction * forceToApply, collider.transform.position);
    }
}
