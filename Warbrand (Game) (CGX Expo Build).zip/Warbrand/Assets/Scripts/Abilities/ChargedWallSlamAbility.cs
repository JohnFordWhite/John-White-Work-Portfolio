﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ChargedWallSlamAbility                                                         *
 * FileExtension:   .cs                                                                            *
 * Author:          Evan Campbell                                                                  *
 * Date:            Oct. 28th, 2016                                                                *
 *                                                                                                 *
 * Description of file usage                                                                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Evan Campbell) - Oct. 28th, 2016                                          *
\***************************************************************************************************/

using System;
using UnityEngine;

public class ChargedWallSlamAbility : Ability
{
    //
    // Public
    //

    // Max distance to travel
    public float MaxChargeDistance = 25.0f;

    // The Player GameObject that we slammed into
    public Player TargetPlayer = null;

    public float CooldownTime = 12.0f;

    public Vector3 Velocity = Vector3.zero;

    public bool IsCharging { get { return m_IsCharging; } }

    public Rigidbody RigidBody;

    //
    //Private
    //
    private float m_DistanceTravelled;
    private float m_CooldownTime;
    private bool m_IsCharging;

    //strings
    private const string m_PlayerTagString = "Player";

    public ChargedWallSlamAbility(InputName aKey)
    {
        Key = aKey;
        m_DistanceTravelled = 0.0f;
        m_CooldownTime = 0.0f;
        m_IsCharging = false;

        AbilityBlocksMovement = true;
        AbilityBlocksRotation = true;
        AbilityBlocksOtherAbilities = true;
    }

    public override void OnStartAbility()
    {
        if (m_CooldownTime <= 0.0f)
        {
            m_DistanceTravelled = 0.0f;
            m_CooldownTime = CooldownTime;
            m_IsCharging = true;

            BlockInput();

#if UNITY_EDITOR
            DebugManager.Log("Charge Started", Developmer.AllDevelopmers);
#endif

            if (RigidBody == null)
            {
                RigidBody = Owner.RigidBody;
            }
            if (RigidBody != null)
            {
                RigidBody.useGravity = false;
            }
        }
    }

    public override void OnContinueAbility()
    {

    }

    public override void OnEndAbility()
    {
        EndCharge();
    }

    void EndCharge()
    {
        if (m_IsCharging && m_DistanceTravelled >= MaxChargeDistance)
        {
            m_IsCharging = false;
            TargetPlayer = null;

            UnblockInput();
#if UNITY_EDITOR
            DebugManager.Log("Charge Ended", Developmer.AllDevelopmers);
#endif

            if (RigidBody == null)
            {
                RigidBody = Owner.RigidBody;
            }
            if (RigidBody != null)
            {
                RigidBody.useGravity = true;
            }
        }
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        // Cooldown of ability
        if (m_IsCharging == false)
        {
            m_CooldownTime -= aFixedDelta;
            if (m_CooldownTime < 0.0f)
                m_CooldownTime = 0.0f;
        }
        // Charging
        else
        {
            if (RigidBody == null)
            {
                RigidBody = Owner.RigidBody;

                Vector3 previousPosition = Owner.transform.position;
                Vector3 tempVelocity = Velocity;

                Vector3 newPosition = previousPosition + tempVelocity;

                float newDistanceTravelled = (newPosition - previousPosition).magnitude;

                // Need to make sure that the distance travelled does not exceed the maximum distance.

                if (m_DistanceTravelled + newDistanceTravelled > MaxChargeDistance)
                {
                    newDistanceTravelled = MaxChargeDistance - m_DistanceTravelled;

                    tempVelocity = tempVelocity.normalized * newDistanceTravelled;

                    m_DistanceTravelled += newDistanceTravelled;

                    newPosition = previousPosition + tempVelocity;
                }
                else
                {
                    m_DistanceTravelled += newDistanceTravelled;
                }
#if UNITY_EDITOR
                DebugManager.Log("Distance Charged: " + m_DistanceTravelled, Developmer.AllDevelopmers);
#endif
                RigidBody.MovePosition(newPosition);

                // Check if distance travelled
                if (m_DistanceTravelled >= MaxChargeDistance)
                {
                    OnEndAbility();
                }
            }
        }
    }
    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == m_PlayerTagString)
        {
#if UNITY_EDITOR
            DebugManager.Log("Charge hit player: " + other.gameObject, Developmer.AllDevelopmers);
#endif
        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_CooldownTime = 0;
    }
    public override bool CanUseAbility()
    {
        return false;
    }}