/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        GauntletSmokeAbility                                                           *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 30th, 2016                                                             *
 *                                                                                                 *
 * This will spawn a grenade from leeroy's gauntlet that will travel at a medium speed. Once the   *
 * grenade touches the ground or another player, it will create a smoke clould.                    *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 30th, 2016                                          *
 *                                                                                                 *
\***************************************************************************************************/

using System;
using UnityEngine;

public class GauntletSmokeAbility : Ability
{
	//
	// Public
	//
    public float UseCooldown = 15.0f;

    //
    //Private
    //
    private float m_UseCooldownTimer;
    private GameObject m_SmokeGrenadePrefab;
    private GameObject m_SmokeGrenade;

    private const string m_SmokeGrenadeResource = "Prefabs/Projectiles/SmokeGrenade";

    public GauntletSmokeAbility(InputName aKey)
    {
        Key = aKey;
        m_UseCooldownTimer = 0.0f;
        m_SmokeGrenadePrefab = Resources.Load(m_SmokeGrenadeResource) as GameObject;
        AnimatorString = "SmokeGrenade";
        HasAnimationTime = true;
    }

    public override void SetOwner(Player owner)
    {
        Owner = owner;
        m_SmokeGrenadePrefab.GetComponent<SmokeGrenadeScript>().Owner = this.Owner;
    }

    public override void OnStartAbility ()
	{
        if(m_UseCooldownTimer <= 0)
        {
            m_UseCooldownTimer = UseCooldown;

            GameObject InstancedObjectContainer = InputManager.CM.GetInstancedObjectContainer();

            //Fire the explosive
            m_SmokeGrenade = GameObject.Instantiate(m_SmokeGrenadePrefab, Owner.PlayerCamera.transform.position, Owner.PlayerCamera.transform.rotation) as GameObject;

            SmokeGrenadeScript smoke = m_SmokeGrenade.GetComponent<SmokeGrenadeScript>();

            smoke.Owner = Owner;
            smoke.Init();

            m_SmokeGrenade.transform.SetParent(InstancedObjectContainer.transform);
            
            Owner.AudioSourceAbility2.Play();
        }
	}

	public override void OnContinueAbility ()
	{
        
	}

	public override void OnEndAbility ()
	{
        
	}

    //Occurs every frame
    public override void UpdateAbility(float aFixedDelta)
    {
        m_UseCooldownTimer -= aFixedDelta;

        //Do UI stuff
        if (Owner.IsAI)
            return;

        Owner.AbilityUICooldowns.Ability2Info.UseCooldown = m_UseCooldownTimer / UseCooldown;
        if (m_UseCooldownTimer <= 0)
        {
            Owner.AbilityUICooldowns.Ability2Info.Usable = true;
        }
        else
        {
            Owner.AbilityUICooldowns.Ability2Info.Usable = false;

        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_UseCooldownTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_UseCooldownTimer <= 0)
            return true;
        return false;
    }
}