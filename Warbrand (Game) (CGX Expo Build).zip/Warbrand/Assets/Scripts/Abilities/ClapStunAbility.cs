/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ClapStunAbility                                                                *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            October 25th, 2016                                                             *
 *                                                                                                 *
 * Description of file usage                                                                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - October 25th, 2016                                          *
 * V 1.1 - Changed to work with collision (John White) - October 30th, 2016                        *
\***************************************************************************************************/

using UnityEngine;
using System.Collections.Generic;
using System;

public class ClapStunAbility : Ability
{
    //
    // Public
    //
    public float ClapStunCooldown = 7.0f;

    //
    //Private
    //
    private GameObject m_ClapStunPrefab;
    private GameObject m_ClapStun;
    private ClapStunShaderScript m_ClapStunScript;
    private float m_WaitForAnimationTimer;
    private float m_TimeBeforeStun = 0.0f;
    private float m_ChanceToPlayDialogue = 0.1f;
    //private float m_MaxDistanceToStun = 10f;
    //private float m_SphereCastRadius = 5f;
    private float m_ClapStunTimer;
    private float m_StunDuration = 2f;
    private float m_StunRadius = 4.0f;
    private bool m_AbilityCasted = false;

    private List<Player> m_PlayersHit = null;

    private const string ClapStunDistortionPrefabString = "Prefabs/Projectiles/ClapStunDistortion";
    private const string m_ClapStunAnimatorString = "ClapStun";

    public ClapStunAbility(InputName aKey)
    {
        Key = aKey;
        IsContinuousAbility = true;
        m_ClapStunTimer = 0;
        m_ClapStunPrefab = Resources.Load(ClapStunDistortionPrefabString) as GameObject;
        m_ClapStun = UnityEngine.Object.Instantiate(m_ClapStunPrefab, Vector3.zero, Quaternion.identity) as GameObject;
        m_ClapStunScript = m_ClapStun.GetComponent<ClapStunShaderScript>();

        GameObject InstancedObjectContainer = InputManager.CM.GetInstancedObjectContainer();

        GameObject.DontDestroyOnLoad(m_ClapStun);

        m_ClapStun.transform.SetParent(InstancedObjectContainer.transform);

        m_WaitForAnimationTimer = m_TimeBeforeStun;

        m_PlayersHit = new List<Player>();
        m_PlayersHit.Capacity = Information.AllPlayers.Count;
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }

        AnimatorString = m_ClapStunAnimatorString;
        HasAnimationTime = true;

    }

    public override void OnStartAbility ()
	{
        if (m_ClapStunTimer <= 0)
        {
            bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
            if (playDialogue)
            {
                DialogueManager.Instance.PlayDialogue(CharacterTypes.Leeroy, DialogueContext.LeeroyClapstun, false, true);
            }

            m_ClapStunScript.Reset(Owner.transform.position + Owner.transform.forward + Owner.transform.up);
            ContinuousAbilityStarted = true;
            ContinuousAbilityInUse = true;
            m_ClapStunTimer = ClapStunCooldown;

            //do overlap sphere and stun players based on it
            Collider[] hitColliders = Physics.OverlapSphere(Owner.transform.position, m_StunRadius, ~Physics.IgnoreRaycastLayer, QueryTriggerInteraction.Collide);
            
            for (int i = 0; i < hitColliders.Length; i++)
            {
                Collider collider = hitColliders[i];

                Player player = null;

                if (collider.GetComponent<PlayerHitboxScript>() != null)
                    player = collider.GetComponent<PlayerHitboxScript>().Owner;

                if(player != null && player != Owner && !m_PlayersHit.Contains(player))
                {
                    player.Stun(m_StunDuration);
                    m_PlayersHit.Add(player);
                }
            }
        }
    }

    public override void OnContinueAbility ()
	{
        m_WaitForAnimationTimer -= Time.deltaTime;

        if (m_WaitForAnimationTimer <= 0 && !m_AbilityCasted)
        {
            Owner.AudioSourceAbility1.Play();

            m_AbilityCasted = true;
        }

        if(m_AbilityCasted)
        {
                ContinuousAbilityInUse = false;
        }
    }

    public override void OnEndAbility ()
	{
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }

        ContinuousAbilityStarted = false;
        m_AbilityCasted = false;
        m_WaitForAnimationTimer = m_TimeBeforeStun;
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        m_ClapStunTimer -= Time.fixedDeltaTime;


        //Do UI stuff
        if (Owner.IsAI)
            return;

        Owner.AbilityUICooldowns.Ability1Info.UseCooldown = m_ClapStunTimer / ClapStunCooldown;
        if (m_ClapStunTimer > 0f || ContinuousAbilityInUse)
        {
            Owner.AbilityUICooldowns.Ability1Info.Usable = false;
        }
        else
        {
            Owner.AbilityUICooldowns.Ability1Info.Usable = true;
        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_ClapStunTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_ClapStunTimer > 0f || ContinuousAbilityInUse)
            return false;
        return true;
    }
}