/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Filename                                                                       *
 * FileExtension:   .cs                                                                            *
 * Author:          AuthorName                                                                     *
 * Date:            Month #th, year                                                                *
 *                                                                                                 *
 * Description of file usage                                                                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Author) - Date                                                            *
 * V 1.1 - Changelog (Author) - Date                                                               *
\***************************************************************************************************/

using System;
using UnityEngine;

public class InjectionAbility : Ability
{
	//
	// Public
	//
    public float InjectionCooldown = 10.0f;
    public float InjectionDuration = 6.0f;

    public float MovementSpeedIncrease = 0.3f;
    public float AttackSpeedIncrease = 0.3f;
    public float DamageReductionIncrease = 0.3f;

    //
    //Private
    //
    private float m_CooldownTimer;
    private float m_DurationTimer;
    private float m_ChanceToPlayDialogue = 0.1f;
    private InjectionImageEffectScript m_InjectionImageEffect;

    private const string m_InjectionAnimatorString = "InjectLeeroidRage";

    public InjectionAbility(InputName aKey)
    {
        Key = aKey;
        IsContinuousAbility = true;
        ContinuousAbilityInUse = false;
        m_CooldownTimer = 0;
        m_DurationTimer = 0;
        HasAnimationTime = true;
        AnimatorString = m_InjectionAnimatorString;
    }

    public override void SetOwner(Player owner)
    {
        Owner = owner;
        m_InjectionImageEffect = owner.FirstPersonModelCamera.GetComponent<InjectionImageEffectScript>();
    }

    public override void OnStartAbility ()
	{
        if(m_CooldownTimer <= 0)
        {
            bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
            if (playDialogue)
            {
                DialogueManager.Instance.PlayDialogue(CharacterTypes.Leeroy, DialogueContext.LeeroidRage, false, true);
            }

            Owner.GetComponent<BasicMovementScript>().AddMovementSpeedModifier(MovementSpeedIncrease);
            Owner.AddAttackSpeedModifier(AttackSpeedIncrease);
            Owner.Health.AddDamageTakenModifier(-DamageReductionIncrease);

            m_DurationTimer = InjectionDuration;
            ContinuousAbilityInUse = true;
            m_InjectionImageEffect.enabled = true;
            m_InjectionImageEffect.EnableEffect();
        }
	}

	public override void OnContinueAbility ()
	{
        m_DurationTimer -= Time.fixedDeltaTime;
        if (m_DurationTimer <= 0)
        {
            ContinuousAbilityInUse = false;
            m_CooldownTimer = InjectionCooldown;
        }
	}

	public override void OnEndAbility ()
	{
        Owner.GetComponent<BasicMovementScript>().RemoveMovementSpeedModifier(MovementSpeedIncrease);
        Owner.RemoveAttackSpeedModifier(AttackSpeedIncrease);
        Owner.Health.RemoveDamageTakenModifier(-DamageReductionIncrease);

        m_InjectionImageEffect.EffectEnabled = false;
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        if(ContinuousAbilityInUse == false)
        {
            m_CooldownTimer -= Time.fixedDeltaTime;
        }

        if (Owner.IsAI)
            return;

        Owner.AbilityUICooldowns.Ability3Info.UseCooldown = m_CooldownTimer / InjectionCooldown;
        Owner.AbilityUICooldowns.Ability3Info.Usable = CanUseAbility();
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_CooldownTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_CooldownTimer <= 0 && ContinuousAbilityInUse == false)
            return true;
        return false;
    }
}