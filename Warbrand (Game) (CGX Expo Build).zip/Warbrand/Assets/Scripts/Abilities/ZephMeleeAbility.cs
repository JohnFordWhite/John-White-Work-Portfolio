/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Filename                                                                       *
 * FileExtension:   .cs                                                                            *
 * Author:          AuthorName                                                                     *
 * Date:            Month #th, year                                                                *
 *                                                                                                 *
 * Description of file usage                                                                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Author) - Date                                                            *
 * V 1.1 - Changelog (Author) - Date                                                               *
\***************************************************************************************************/

using System;
using UnityEngine;
using System.Collections.Generic;

public class ZephMeleeAbility : Ability
{
    // As of now, this MeleeAbility is based off of the prototype build of the game.

    //
    // Public
    //
    // Delay time between attacks
    public float DamageValue = 7f;
    public float AttackCooldown = 0.25f;

    //
    // Private
    //
    private BasicMovementScript m_MovementScript;
    private List<GameObject> m_ObjectsThatCanBeHit;
    private List<AudioClip> m_HitClipList = new List<AudioClip>();
    private GameObject m_ClosestEnemy;
    private Rigidbody m_Rigidbody;
     //private Quaternion m_CurrentRotation;
    private bool m_CurrentlyAttacking;
    private bool m_AddingClips = true;
    private string m_ClipString;
    private float m_AttackTimeout;
    private float m_ChanceToPlayDialogue = 0.1f;

    private int m_LayerMask;
    private int m_ClipCounter;

    // Transform skeleton for right arm and sword
    Transform m_CorePivot = null;
    Transform m_RightArmPivot = null;
    Transform m_SwordAttackPivot = null;
    Transform m_SwordRestPivot = null; 
    Transform m_SwordPivot = null;
    Transform m_SwordTip = null;

    GameObject m_ParticleManager;

    private const string m_ParticleManagerTransform = "ParticleManager";

    private const string m_CameraTransform = "Camera - 1P - Zeph";
    private const string m_CorePivotTransform = "CorePivot";
    private const string m_RightArmPivotTransform = "RightArmPivot";
    private const string m_SwordAttackPivotTransform = "SwordAttackPivot";
    private const string m_SwordRestPivotTransform = "SwordRestPivot";
    private const string m_SwordPivotTransform = "SwordPivot";
    private const string m_SwordTipTransform = "SwordTip";
    private const string m_ShieldLayer = "Shield";

    private const string m_IgnoreRaycastMask = "Ignore Raycast";
    private const string m_RagdollMask = "Ragdoll";

    private Vector3 m_RaycastStart;
    private Vector3 m_RaycastDirection;
    private Vector3 m_RaycastStartDirection;
    private Vector3 m_RaycastEndDirection;

    public ZephMeleeAbility(InputName aKey)
    {
        Key = aKey;
        m_CurrentlyAttacking = false;
        m_AttackTimeout = 0.0f;
        m_ParticleManager = GameObject.Find(m_ParticleManagerTransform);

        //TODO: implement proper layer mask

        m_ClipCounter = 1;

        while (m_AddingClips)
        {
            // TODO: Make using this file path less brittle - find a way to pre-cache all file paths.

            m_ClipString = "Audio/SoundFX/zeph_melee_hit (" + m_ClipCounter.ToString() + ")";

            if ((AudioClip)Resources.Load(m_ClipString) != null)
            {
                m_HitClipList.Add((AudioClip)Resources.Load(m_ClipString));
                m_ClipCounter++;
            }
            else
            {
                m_AddingClips = false;
            }
        }
        HasAnimationTime = true;
        AnimatorString = "ZephMelee";
    }

    public override void SetOwner(Player owner)
    {
        base.SetOwner(owner);

        m_RaycastStartDirection = (Owner.PlayerCamera.transform.forward + Owner.PlayerCamera.transform.right).normalized;
        m_RaycastEndDirection = (Owner.PlayerCamera.transform.forward - Owner.PlayerCamera.transform.right).normalized;
        m_RaycastDirection = m_RaycastStartDirection;

        m_LayerMask = ~((1 << LayerMask.NameToLayer(m_IgnoreRaycastMask)) |
                (1 << LayerMask.NameToLayer("WallCollider")) |
                (1 << LayerMask.NameToLayer(m_RagdollMask)) |
                (1 << Owner.gameObject.layer));
    }

    public override void OnStartAbility()
    {
        if (m_CorePivot == null)
        {
            SetupMeleeAbility();
        }

        m_ObjectsThatCanBeHit = new List<GameObject>();
        m_ClosestEnemy = null;
        m_Rigidbody = Owner.GetComponent<Rigidbody>();
    }

    public override void OnContinueAbility()
    {
        // Input and state change
        if (m_CurrentlyAttacking == false && m_AttackTimeout <= 0.0f)
        {
            bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
            if (playDialogue)
            {
                DialogueManager.Instance.PlayDialogue(CharacterTypes.Zeph, DialogueContext.MainAttack, false, true);

            }
            
            Owner.AudioSourceMainAttack.Play();

            m_CurrentlyAttacking = true;

            m_AttackTimeout = AttackCooldown;

            m_RaycastStart = Owner.transform.position + Vector3.up * 1.0f;
            m_RaycastStartDirection = (Owner.PlayerCamera.transform.forward + Owner.PlayerCamera.transform.right).normalized;
            m_RaycastEndDirection = (Owner.PlayerCamera.transform.forward - Owner.PlayerCamera.transform.right).normalized;

            //Every time Zeph attacks, do a spherecast to check if anything damagable is in range
            //Debug.Log(m_LayerMask);
            RaycastHit[] hits = Physics.SphereCastAll(m_RaycastStart, 0.2f, m_RaycastDirection, 2.0f, m_LayerMask, QueryTriggerInteraction.Collide);
            
            for (int i = 0; i < hits.Length; i++)
            {
                RaycastHit hit = hits[i];

                if (hit.distance>1)
                {
                    Health healthScript = null;

                    Player player = null;
                    if (hit.collider.GetComponent<PlayerHitboxScript>() != null)
                        player = hit.collider.GetComponent<PlayerHitboxScript>().Owner;

                    if(player != null)
                    {
                        healthScript = player.GetComponent<Health>();
                    }
                    else
                    {
                        healthScript = hit.collider.GetComponent<Health>();
                    }

                    if (healthScript != null)
                    {
                        if (player != null)
                        {
                            if (player.TeamIndex != Owner.TeamIndex)
                            {
                                m_ObjectsThatCanBeHit.Add(hit.transform.gameObject);
                            }
                        }
                        else
                        {
                            m_ObjectsThatCanBeHit.Add(hit.transform.gameObject);
                        }
                    }
                }
            }

            float distanceToEnemy = float.MaxValue;

            if (m_ObjectsThatCanBeHit != null && m_ObjectsThatCanBeHit.Count > 0)
            {
                for (int i = 0; i < m_ObjectsThatCanBeHit.Count; i++)
                {
                    GameObject ObjectInList = m_ObjectsThatCanBeHit[i];

                    if (Vector3.Distance(Owner.transform.position, ObjectInList.transform.position) < distanceToEnemy)
                    {
                        distanceToEnemy = Vector3.Distance(Owner.transform.position, ObjectInList.transform.position);
                        m_ClosestEnemy = ObjectInList;
                    }
                }
            }

            //If there is a damageable thing within range, push Zeph towards the closest one
            if (m_ClosestEnemy != null)
            {
                Vector3 directionToClosestEnemy = m_ClosestEnemy.transform.position - Owner.transform.position;
                m_Rigidbody.AddForce(directionToClosestEnemy * 50, ForceMode.Impulse);
                m_ClosestEnemy = null;
                m_ObjectsThatCanBeHit.Clear();
            }
        }
        else
        {
            m_RaycastDirection = m_RaycastStartDirection;
        }
    }

    void OnDrawGizmos()
    {

        Gizmos.DrawLine(m_RaycastStart, m_RaycastStart + (m_RaycastDirection * 2.0f));
    }

    public override void OnEndAbility()
    {
        Owner.PlayerAnimator.SetBool("ZephMelee", false);
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        m_AttackTimeout -= aFixedDelta * Owner.AttackSpeedPercent;
        if (m_AttackTimeout < 0)
            m_AttackTimeout = 0.0f;

        if (m_CorePivot != null)
        {
            // Reset currently attacking
            if (m_AttackTimeout <= 0.0f)
            {
                if (m_CurrentlyAttacking == true)
                {
                    m_CurrentlyAttacking = false;
                }
            }

            // Attack animation
            if (m_CurrentlyAttacking == true)
            {
                m_SwordPivot.position = Vector3.Lerp(m_SwordPivot.position, m_SwordAttackPivot.position, aFixedDelta * 16.0f * Owner.AttackSpeedPercent);
                m_SwordPivot.rotation = Quaternion.Slerp(m_SwordPivot.rotation, m_SwordAttackPivot.rotation, aFixedDelta * 16.0f * Owner.AttackSpeedPercent);

                // Enable to this to see the hit line. Turn off the Sword mesh renderer in the editor to see this.
                // Debug.DrawLine(m_SwordPivot.position, m_SwordTip.position, Color.red);

                // Raycast from the sword hilt to tip. Detect collision with GameObjects with the "Player"
                // tag and apply damage to them.
                RaycastHit hitInfo;
                if (Physics.Linecast(m_SwordPivot.position, m_SwordTip.position, out hitInfo, m_LayerMask))
                {
                    //check to see if a Leeroy shield was hit
                    if (LayerMask.LayerToName(hitInfo.collider.gameObject.layer) == m_ShieldLayer)
                    {
                        PlasmaShaderHitboxScript shieldScript = hitInfo.collider.gameObject.GetComponent<PlasmaShaderHitboxScript>();
                        if (shieldScript != null)
                        {
                            shieldScript.ManualHit(hitInfo.point);
                            m_CurrentlyAttacking = false;
                            return;
                        }
                    }
                    else if (hitInfo.transform.GetComponent<Health>() != null)
                    {
                        if(hitInfo.transform.GetComponent<Player>() != Owner)
                        {
                            if(!Owner.IsAI)
                            {
                                AudioClip clip = m_HitClipList[UnityEngine.Random.Range(0, m_HitClipList.Count)];

                                Owner.AudioSourceMainAttack.PlayOneShot(clip, 1f);
                            }

                            Health health = hitInfo.transform.GetComponent<Health>();
                            if(health.Damage(Owner, Owner.gameObject, DamageValue, DeathType.Physics) && hitInfo.collider.GetComponent<PlayerHitboxScript>() != null)
                            {
                                hitInfo.collider.GetComponent<PlayerHitboxScript>().AddForce(Owner.transform.forward * 40, Owner.transform.position + Vector3.up * 0.5f);
                            }
                            
                        }
                    }

                    // Recoil attack
                    m_CurrentlyAttacking = false;
                    m_ParticleManager.GetComponent<ParticleManager>().SpawnHitEffect(hitInfo.point, hitInfo.normal);
                }
            }
            else
            {
                m_SwordPivot.position = Vector3.Lerp(m_SwordPivot.position, m_SwordRestPivot.position, aFixedDelta * 32.0f * Owner.AttackSpeedPercent);
                m_SwordPivot.rotation = Quaternion.Slerp(m_SwordPivot.rotation, m_SwordRestPivot.rotation, aFixedDelta * 32.0f * Owner.AttackSpeedPercent);
            }
        }
    }

    void SetupMeleeAbility()
    {
        m_CorePivot = Owner.transform.FindChild(m_CameraTransform).transform.FindChild(m_CorePivotTransform);
        m_RightArmPivot = m_CorePivot.FindChild(m_RightArmPivotTransform);
        m_SwordAttackPivot = m_CorePivot.FindChild(m_SwordAttackPivotTransform);
        m_SwordRestPivot = m_CorePivot.FindChild(m_SwordRestPivotTransform);
        m_SwordPivot = m_RightArmPivot.FindChild(m_SwordPivotTransform);
        m_SwordTip = m_SwordPivot.FindChild(m_SwordTipTransform);
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_CurrentlyAttacking = false;
    }

    public override bool CanUseAbility()
    {
        return !m_CurrentlyAttacking;
    }
}