﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        LeeroyMeleeDamage                                                              *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            March 16th, 2017                                                               *
 *                                                                                                 *
 * Handles damaging players who are hit by Leeroy's melee, and playing hit audio,                  *
 * particle effects etc.                                                                           *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - March 16th, 2017                                            *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LeeroyMeleeDamage : MonoBehaviour
{
    //
    //Public
    //
    public GameObject PlayerGameObject;
    public GameObject SwordTip;
    public Player Owner;
    public bool Attacking = false;
    [SerializeField]
    private float DamageValue = 9f;
    [SerializeField]
    private float AttackRange = 3.0f;

    //
    //Private
    //
    private List<Player> m_HitPlayers = new List<Player>();
    private List<Collider> m_HitColliders = new List<Collider>();
    private List<AudioClip> m_HitClipList = new List<AudioClip>();
    private GameObject m_ParticleManager;
    private int m_ClipCounter;
    private int m_HitLeeroyShieldHash = Animator.StringToHash("HitLeeroyShield");
    private string m_ClipString;
    private bool m_AddingClips = true;
    private const string StringShield = "Shield";
    private const string m_EmptyStateString = "Empty";
    private const string m_ParticleManagerName = "ParticleManager";
    private int m_LayerMask;
    private bool m_AlreadyHitPlayer = false;

    private Vector3 m_RaycastStart;
    private Vector3 m_RaycastDirection;
    private Vector3 m_RaycastStartDirection;
    private Vector3 m_RaycastEndDirection;

    void Start()
    {
        DamageValue = 12;
        Owner = PlayerGameObject.GetComponent<Player>();

        m_LayerMask = ~((1 << LayerMask.NameToLayer("Ignore Raycast")) |
                        (1 << LayerMask.NameToLayer("WallCollider")) |
                        (1 << Owner.gameObject.layer) | 
                        (1 << LayerMask.NameToLayer("Ragdoll")));

        m_ParticleManager = GameObject.Find(m_ParticleManagerName);
        GameObject.DontDestroyOnLoad(m_ParticleManager);

        m_ClipCounter = 1;

        while (m_AddingClips)
        {
            // TODO: Make file loading path less brittle - find way to pre-cache all file paths ahead of time.

            m_ClipString = "Audio/SoundFX/leeroy_melee_hit (" + m_ClipCounter.ToString() + ")";

            if ((AudioClip)Resources.Load(m_ClipString) != null)
            {
                m_HitClipList.Add((AudioClip)Resources.Load(m_ClipString));
                m_ClipCounter++;
            }
            else
            {
                m_AddingClips = false;
            }
        }

        m_RaycastStartDirection = (Owner.PlayerCamera.transform.forward + Owner.PlayerCamera.transform.right).normalized;
        m_RaycastEndDirection = (Owner.PlayerCamera.transform.forward - Owner.PlayerCamera.transform.right).normalized;
        m_RaycastDirection = m_RaycastStartDirection;
    }

    void Update()
    {
        m_RaycastStart = Owner.transform.position + Vector3.up * 1.5f;
        m_RaycastStartDirection = (Owner.PlayerCamera.transform.forward + Owner.PlayerCamera.transform.right).normalized;
        m_RaycastEndDirection = (Owner.PlayerCamera.transform.forward - Owner.PlayerCamera.transform.right).normalized;

        if (Owner.PlayerAnimator.GetCurrentAnimatorStateInfo(2).IsName(m_EmptyStateString))
        {
            m_HitPlayers.Clear();
            m_HitColliders.Clear();
        }

        //Raycast on leeroy's right side

        if(Attacking)
        {
            m_RaycastDirection = Vector3.Slerp(m_RaycastDirection, m_RaycastEndDirection, 15 * Time.fixedDeltaTime);
            RaycastHit[] hitInfos = Physics.SphereCastAll(m_RaycastStart, 0.1f, m_RaycastDirection, AttackRange, m_LayerMask, QueryTriggerInteraction.Collide);
            for(int i = 0; i < hitInfos.Length; i++)
            {
                if(!m_HitColliders.Contains(hitInfos[i].collider))
                {
                    m_AlreadyHitPlayer = false;
                    m_HitColliders.Add(hitInfos[i].collider);
                    Player hitPlayer = null;

                    if (hitInfos[i].collider.GetComponent<PlayerHitboxScript>() != null)
                        hitPlayer = hitInfos[i].collider.GetComponent<PlayerHitboxScript>().Owner;

                    Health targetHealth = null;

                    if (hitPlayer != null)
                    {
                        if (!m_HitPlayers.Contains(hitPlayer))
                        {
                            targetHealth = hitPlayer.GetComponent<Health>();
                            m_HitPlayers.Add(hitPlayer);
                        }
                        else
                        {
                            m_AlreadyHitPlayer = true;
                        }
                    }
                    else
                    {
                        targetHealth = hitInfos[i].collider.GetComponent<Health>();
                    }

                    if (targetHealth != null)
                    {
                        if (hitPlayer != null)
                        {
                            if (hitPlayer.GetComponent<Leeroy>() != null)
                            {
                                if (hitPlayer.GetComponent<Leeroy>().LeeroyShieldAbility.CurrentlyBlocking)
                                {
                                    if (Vector3.Angle(Owner.transform.forward, hitPlayer.transform.forward) > 80)
                                    {
                                        return;
                                    }
                                }
                            }
                        }

                        if (targetHealth.Damage(Owner, Owner.gameObject, DamageValue, DeathType.Physics) && hitInfos[i].collider.GetComponent<PlayerHitboxScript>() != null)
                        {
                            hitInfos[i].collider.GetComponent<PlayerHitboxScript>().AddForce(Owner.transform.forward * 40, SwordTip.transform.position);
                        }


                        Owner.AudioSourceMainAttack.PlayOneShot(m_HitClipList[UnityEngine.Random.Range(0, m_HitClipList.Count)], 1f);
                    }
                    else if (LayerMask.LayerToName(hitInfos[i].collider.gameObject.layer) == StringShield)
                    {
                        PlasmaShaderHitboxScript shieldScript = hitInfos[i].collider.gameObject.GetComponent<PlasmaShaderHitboxScript>();
                        if (shieldScript != null && hitInfos[i].collider.gameObject != transform.gameObject)
                        {
                            shieldScript.ManualHit(shieldScript.transform.localPosition);

                            Owner.PlayerAnimator.SetTrigger(m_HitLeeroyShieldHash);
                            return;
                        }
                    }

                    if (!m_AlreadyHitPlayer)
                    {
                        m_ParticleManager.GetComponent<ParticleManager>().SpawnHitEffect(hitInfos[i].point, -Owner.transform.forward);
                    }
                }
            }
        }
        else
        {
            m_RaycastDirection = m_RaycastStartDirection;
        }
    }

    void OnDrawGizmos()
    {

        Gizmos.DrawLine(m_RaycastStart, m_RaycastStart + (m_RaycastDirection * AttackRange));
    }

    void OnTriggerEnter(Collider collider)
    {
        if (Attacking)
        {
            //Player hitPlayer = null;

            //if (collider.GetComponent<PlayerHitboxScript>() != null)
            //    hitPlayer = collider.GetComponent<PlayerHitboxScript>().Owner;

            //Health targetHealth = null;

            //if(hitPlayer != null)
            //{
            //    if (!m_HitPlayers.Contains(hitPlayer))
            //    {
            //        targetHealth = hitPlayer.GetComponent<Health>();
            //        m_HitPlayers.Add(hitPlayer);
            //    }
            //}
            //else
            //{
            //    targetHealth = collider.GetComponent<Health>();
            //}

            ////check to see if another Leeroy's shield was hit
            //if (LayerMask.LayerToName(collider.gameObject.layer) == StringShield)
            //{
            //    PlasmaShaderHitboxScript shieldScript = collider.gameObject.GetComponent<PlasmaShaderHitboxScript>();
            //    if (shieldScript != null && collider.gameObject != transform.gameObject)
            //    {
            //        shieldScript.ManualHit(shieldScript.transform.localPosition);

            //        Owner.PlayerAnimator.SetTrigger(m_HitLeeroyShieldHash);
            //        return;
            //    }
            //}
            
            //if (targetHealth != null)
            //{
            //    if (hitPlayer != null)
            //    {
            //        if(hitPlayer.GetComponent<Leeroy>() != null)
            //        {
            //            if (hitPlayer.GetComponent<Leeroy>().LeeroyShieldAbility.CurrentlyBlocking)
            //            {
            //                if (Vector3.Angle(Owner.transform.forward, hitPlayer.transform.forward) > 80)
            //                {
            //                    return;
            //                }
            //            }
            //        }
            //    }

            //    if (targetHealth.Damage(Owner, Owner.gameObject, DamageValue, DeathType.Physics) && collider.GetComponent<PlayerHitboxScript>() != null)
            //    {
            //        collider.GetComponent<PlayerHitboxScript>().AddForce(Owner.transform.forward * 40, SwordTip.transform.position);
            //    }
                

            //    Owner.AudioSourceMainAttack.PlayOneShot(m_HitClipList[UnityEngine.Random.Range(0, m_HitClipList.Count)], 1f);
            //}

            //m_ParticleManager.GetComponent<ParticleManager>().SpawnHitEffect(SwordTip.transform.position,-Owner.transform.forward);
        }
    }
}