/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ShotgunAbility                                                                 *
 * FileExtension:   .cs                                                                            *
 * Author:          Evan Campbell                                                                  *
 * Date:            October 21st, 2016                                                             *
 *                                                                                                 *
 * The purpose of this ability is to shoot a scattered shotgun blast in a cone in front of the     *
 * player. The bullets will deal less damage the farther they are from the point they are shot     *
 * from, and they will disappear when they have reached the maximum distance. For each shotgun     *
 * bullet prefab that reaches their target, inflict damage on that target.                         *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Evan Campbell) - October 21st, 2016                                       *
 * V 1.1 - Added a normal distribution to the bullets (Jon Roffey) - February 15th, 2017           *
\***************************************************************************************************/

using UnityEngine;
using System.Collections.Generic;

public class ShotgunAbility : Ability
{
	//
	// Public
	//
	public GameObject Shotgun;
    public float FireSpeed = 100.0f;
    public float AimDeviation = 5.0f;
    public float MaxShotDistance = 80.0f;
    public float TimeBetweenShots = 1.0f;
    public float BaseDamage = 10.0f;
    public int NumBulletsInSpread = 15;
    public ObjectPool ShotgunHitEffects { get; private set; }

    //
    // Private
    //
    private ObjectPool m_ShotgunBullets;
    private GameObject m_ShotgunHitEffectPrefab;
    private CameraRecoil m_RecoilScript;
    private float m_ShotTimeout;
    private float m_Mean = 0;
    private float m_YAxisDexiation = 2f;
    private float m_XAxisDexiation = 2f;

    private const string m_ShotgunHitEffectResource = "Particle Effects/Prefabs/ShotgunHitEffect";

    public ShotgunAbility(Player aOwner, InputName aKey, GameObject aShotgunBulletPrefab)
    {
        m_ShotTimeout = 0.0f;
        Owner = aOwner;
        Key = aKey;

        m_ShotgunBullets = new ObjectPool();
        m_ShotgunBullets.Initialize(NumBulletsInSpread * 2);
        m_ShotgunBullets.FillPoolWithPrefab(aShotgunBulletPrefab);


        m_ShotgunHitEffectPrefab = Resources.Load(m_ShotgunHitEffectResource) as GameObject;
        ShotgunHitEffects = new ObjectPool();
        ShotgunHitEffects.Initialize(NumBulletsInSpread * 3);
        ShotgunHitEffects.FillPoolWithPrefab(m_ShotgunHitEffectPrefab);

        m_RecoilScript = Owner.GetComponentInChildren<CameraRecoil>();

        HasAnimationTime = true;
        AnimatorString = "Shotgun";
    }

    public override void OnStartAbility ()
	{

	}

	public override void OnContinueAbility ()
	{
        if (m_ShotTimeout <= 0.0f)
        {
            Owner.AudioSourceMainAttack.Play();
            ((Paige)Owner).ShotgunMuzzleFlash.Play();

            m_ShotTimeout = TimeBetweenShots;

            for (int i = 0; i < NumBulletsInSpread; i++)
            {
                GameObject shotgunBullet = m_ShotgunBullets.GetFirstInactiveObject();
                shotgunBullet.transform.position = Owner.PlayerCamera.transform.position;
                shotgunBullet.transform.rotation = Owner.PlayerCamera.transform.rotation;
                
                //ignore collision between bullet and owner
                Owner.IgnoreCollision(shotgunBullet.GetComponent<Collider>());

                //m_Mean should almost always be 0. It can be changed to make the shots inacurate(maybe as a temp effect) 
                float deviationX = NormalDistribution(m_Mean, m_XAxisDexiation);
                float deviationY = NormalDistribution(m_Mean, m_YAxisDexiation);

                //Initialize the projectile
                shotgunBullet.SetActive(true);
                ShotgunProjectile bullet = shotgunBullet.GetComponent<ShotgunProjectile>();
                bullet.Init(Owner, Owner.PlayerCamera.transform.position, FireSpeed);
                bullet.MaxDistance = MaxShotDistance;
                bullet.BaseDamage = BaseDamage;
                bullet.transform.Rotate(deviationX, deviationY, 0);

                bullet.ShotgunHitEffectPrefab = ShotgunHitEffects.GetFirstInactiveObject();
                if (bullet.ShotgunHitEffectPrefab != null)
                {
                    bullet.ShotgunHitEffectPrefab.SetActive(true);
                }
            }

            m_RecoilScript.Recoil();

        }
    }

    public float NormalDistribution(float aMean, float aStandardDeviation)
    {
        //Box�Muller method
        float f1 = 1.0f - Random.value;
        float f2 = 1.0f - Random.value;
        float randStdNormal = Mathf.Sqrt(-2.0f * Mathf.Log(f1)) * Mathf.Sin(2.0f * Mathf.PI * f2);
        float randNormal = aMean + aStandardDeviation * randStdNormal;

        return randNormal;
    }

    public override void OnEndAbility ()
	{
        
	}

    public override void UpdateAbility(float aFixedDelta)
    {
        m_ShotTimeout -= aFixedDelta;
        if (m_ShotTimeout <= 0.0f)
        {
            m_ShotTimeout = 0.0f;
        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_ShotTimeout = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_ShotTimeout <= 0.0f)
            return true;
        return false;
    }
}