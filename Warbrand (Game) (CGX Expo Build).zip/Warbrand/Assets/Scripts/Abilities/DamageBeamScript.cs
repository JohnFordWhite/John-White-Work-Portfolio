﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        DamageBeamScript                                                               *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 22th, 2016                                                             *
 *                                                                                                 *
 * This script is meant to be attached to a an object that represents a damage beam. The object    *
 * should be a child of quark.                                                                     *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 22th, 2016                                          *
\***************************************************************************************************/
using UnityEngine;
using System.Collections;

public class DamageBeamScript : MonoBehaviour
{
    //
    //Public
    //
    public float BeamDamage = 25;
    public const float BeamLength = 10;
    public Player Owner;

    //
    //Private
    //
    private bool m_BeamOn;
    //private MeshRenderer m_Renderer;
    //private CapsuleCollider m_Collider;
    private Transform m_BeamStartPoint;
    private Transform m_BeamEndPoint;
    private Vector3 m_LookPosition;
    private LineRenderer m_LineRenderer;
    private GameObject m_HitEffect;
    private GameObject m_BeamParticles;
    private ParticleSystem[] m_Particles;
    private AudioClip m_HitClip;
    private Renderer m_Renderer;
    private int m_LayerMask;
    private float m_ShieldHitCooldown = 0.25f;
    private float m_ShieldHitTimer = 0;
    private float m_HitTimer = 0f;

    private const string m_BeamStartPointTransform = "BeamStartPoint";
    private const string m_BeamEndPointTransform = "BeamEndPoint";
    private const string m_QuarkBeamEffectTransform = "QuarkBeamHitEffect";
    private const string m_BeamParticlesTransform = "BeamParticles";

    private const string m_UnplacedObjectsMask = "UnplacedObjects";
    private const string m_IgnoreRaycastMask = "Ignore Raycast";
    private const string m_RagdollMask = "Ragdoll";
    private const string m_ShieldMask = "Shield";

    private const string m_QuarkBeamHitResource = "Audio/SoundFX/quark_beam_hit";

    void Start ()
    {
        m_BeamStartPoint = transform.Find(m_BeamStartPointTransform);
        m_BeamEndPoint = transform.Find(m_BeamEndPointTransform);
        //m_Renderer = GetComponent<MeshRenderer>();
        //m_Collider = GetComponent<CapsuleCollider>();
        m_LineRenderer = GetComponent<LineRenderer>();
        m_HitEffect = transform.Find(m_QuarkBeamEffectTransform).gameObject;
        m_Particles = m_HitEffect.GetComponentsInChildren<ParticleSystem>();
        m_BeamParticles = m_BeamStartPoint.Find(m_BeamParticlesTransform).gameObject;
        m_LineRenderer.SetPosition(0, m_BeamStartPoint.position);
        m_LineRenderer.SetPosition(1, m_BeamEndPoint.position);

        m_LayerMask = ~((1 << LayerMask.NameToLayer(m_UnplacedObjectsMask)) |
            (1 << LayerMask.NameToLayer(m_IgnoreRaycastMask)) |
            (1 << LayerMask.NameToLayer("WallCollider")) |
            (1 << LayerMask.NameToLayer(m_RagdollMask)) |
            (1 << Owner.gameObject.layer));
        DeactivateBeam();

        m_HitClip = Resources.Load(m_QuarkBeamHitResource) as AudioClip;

        m_Renderer = GetComponent<Renderer>();
    }
	
	void Update ()
    {
        if(m_ShieldHitCooldown > 0)
            m_ShieldHitTimer -= Time.deltaTime;

        if (!m_BeamOn)
        {
            return;
        }

        RaycastHit hit;
        m_LookPosition = Owner.PlayerCamera.transform.position;
        m_LookPosition += Owner.PlayerCamera.transform.forward * BeamLength;

        float difference = Vector3.Distance(m_BeamStartPoint.position, m_LookPosition);
        //Do a second raycast from the gun to wherever the player is looking
        if (Physics.Raycast(m_BeamStartPoint.position, m_LookPosition - m_BeamStartPoint.position, out hit, difference, m_LayerMask, QueryTriggerInteraction.Ignore))
        {
            for (int i = 0; i < m_Particles.Length; i++)
            {
                ParticleSystem particle = m_Particles[i];

                if (!particle.isPlaying)
                    particle.Play();
                particle.gameObject.SetActive(true);
            }
            m_BeamEndPoint.position = hit.point;
            //m_HitEffect.transform.up = hit.normal;

            //Debug.Log("Dealing " + BeamDamage * Time.fixedDeltaTime + " beam damage");
            TurretScript turret = hit.collider.gameObject.GetComponent<TurretScript>();
            QuarkTrapScript trap = hit.collider.gameObject.GetComponent<QuarkTrapScript>();
            CameraScript camera = hit.collider.gameObject.GetComponent<CameraScript>();

            Health health = null;

            Player player = null;
            if (hit.collider.GetComponent<PlayerHitboxScript>() != null)
                player = hit.collider.GetComponent<PlayerHitboxScript>().Owner;

            if(player != null)
            {
                health = player.Health;
            }
            else
            {
                health = hit.collider.gameObject.GetComponent<Health>();
            }

            m_HitTimer -= Time.deltaTime;
            //Deal damage to Quark turrets, Quark cameras, and other players
            if (health != null)
            {
                if (m_HitTimer < 0)
                {
                    Owner.AudioSourceMainAttack.PlayOneShot(m_HitClip, 1f);
                    m_HitTimer = 0.1f;
                }

                //Debug.Log(hit.collider.name);
                if (turret != null)
                {
                    if (turret.Owner != Owner)
                    {
                        health.Damage(Owner, Owner.gameObject, BeamDamage * Time.deltaTime);
                    }
                }
                else if (trap != null)
                {
                    if (trap.Owner != Owner)
                    {
                        health.Damage(Owner, Owner.gameObject, BeamDamage * Time.deltaTime);
                    }
                }
                else if (camera != null)
                {
                    if (camera.Owner != Owner)
                    {
                        health.Damage(Owner, Owner.gameObject, BeamDamage * Time.deltaTime);
                    }
                }
                else
                {
                    if(health.Damage(Owner, Owner.gameObject, BeamDamage * Time.deltaTime, DeathType.Physics) && hit.collider.GetComponent<PlayerHitboxScript>() != null)
                    {
                        hit.collider.GetComponent<PlayerHitboxScript>().AddForce(Owner.transform.forward * 30, hit.point);
                    }
                }
            }
            else if(LayerMask.LayerToName(hit.collider.gameObject.layer) == m_ShieldMask)
            {
                if(m_ShieldHitTimer <= 0)
                {
                    hit.collider.gameObject.GetComponent<PlasmaShaderHitboxScript>().ManualHit(hit.point);
                    m_ShieldHitTimer = m_ShieldHitCooldown;
                }
            }
        }
        else
        {
            m_BeamEndPoint.position = m_LookPosition;
            
            for (int i = 0; i < m_Particles.Length; i++)
            {
                ParticleSystem particle = m_Particles[i];

                particle.Stop();
                particle.gameObject.SetActive(false);
            }
        }

        m_LineRenderer.SetPosition(0, m_BeamStartPoint.position);
        m_LineRenderer.SetPosition(1, m_BeamEndPoint.position);

        m_Renderer.material.mainTextureScale = new Vector2(Vector3.Distance(m_BeamStartPoint.position, m_BeamEndPoint.position), 1);
        m_BeamParticles.transform.position = m_BeamStartPoint.transform.position;
        m_BeamParticles.transform.LookAt(m_BeamEndPoint);

        m_HitEffect.transform.position = m_BeamEndPoint.position - m_BeamParticles.transform.forward * 0.1f;
    }

    public void ActivateBeam()
    {
        m_BeamOn = true;
        m_BeamParticles.GetComponent<ParticleSystem>().Play();
        m_BeamParticles.SetActive(true);
        m_LineRenderer.enabled = true;
    }

    public void DeactivateBeam()
    {
        for (int i = 0; i < m_Particles.Length; i++)
        {
            ParticleSystem particle = m_Particles[i];

            particle.Stop();
            particle.gameObject.SetActive(false);
        }
        m_BeamParticles.GetComponent<ParticleSystem>().Stop();
        m_BeamParticles.SetActive(false);
        m_BeamOn = false;
        m_LineRenderer.enabled = false;
    }

    void OnTriggerStay(Collider other)
    {
        var collider = other.GetComponent<Health>();

        if (collider != null)
        {
            if (collider.gameObject != Owner.gameObject)
            {
                //Debug.Log("Dealing " + BeamDamage * Time.fixedDeltaTime + " beam damage");
                TurretScript turret = collider.gameObject.GetComponent<TurretScript>();
                QuarkTrapScript trap = collider.gameObject.GetComponent<QuarkTrapScript>();
                CameraScript camera = collider.gameObject.GetComponent<CameraScript>();
                if (turret != null)
                {
                    if (turret.Owner != Owner)
                    {
                        collider.Damage(Owner, Owner.gameObject, BeamDamage * Time.deltaTime);
                    }
                }
                else if (trap != null)
                {
                    if(trap.Owner != Owner)
                    {
                        collider.Damage(Owner, Owner.gameObject, BeamDamage * Time.deltaTime);
                    }
                }
                else if (camera != null)
                {
                    if (camera.Owner != Owner)
                    {
                        collider.Damage(Owner, Owner.gameObject, BeamDamage * Time.deltaTime);
                    }
                }
                else
                {
                    collider.Damage(Owner, Owner.gameObject, BeamDamage * Time.deltaTime);
                }
            }
        }
    }
}
