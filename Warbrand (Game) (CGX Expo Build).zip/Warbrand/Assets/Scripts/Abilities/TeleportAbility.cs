/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Filename                                                                       *
 * FileExtension:   .cs                                                                            *
 * Author:          AuthorName                                                                     *
 * Date:            Month #th, year                                                                *
 *                                                                                                 *
 * Description of file usage                                                                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Author) - Date                                                            *
 * V 1.1 - Improved code readablity (John White) - October 27th 2016                               *
 * V 1.2 - Cleaned up/updated code to stop teleportation out of map - March 9th 2017               *
\***************************************************************************************************/

using System;
using UnityEngine;

public class TeleportAbility : Ability
{
    //
    // Public
    //
    public const float TeleportDistance = 15.0f;
    public const float TeleportChargeCooldown = 5.0f;
    public const float TeleportUseCooldown = 1.0f;
    public const int MaxTelportCharges = 2;

    //
    // Private
    //
    private const string m_WallsMask = "Walls";
    private const string m_FloorMask = "Floor";

    private const string m_ParticleEffectsTransform = "ParticleEffects";
    private const string m_TeleportSmoke1Transform = "TeleportSmoke1";
    private const string m_TeleportSmoke2Transform = "TeleportSmoke2";

    private const string m_ParticleManagerTransform = "ParticleManager";

    private LayerMask m_LayerMask;
    private Rigidbody m_Rigidbody;
    private Camera m_Camera;
    private Vector3 m_LookDirection = Vector3.zero;

    private float m_DistanceSafetyCheck = 2;
    private float m_CheckSphereRadius = 1.5f;
    private float m_TeleportChargeTimer;
    private float m_TeleportUseTimer;
    private float m_ChanceToPlayDialogue = 0.1f;

    private int m_TeleportCharges;

    private ParticleSystem m_TeleportSmoke1;
    private ParticleSystem m_TeleportSmoke2;

    public TeleportAbility(InputName aKey)
    {
        Key = aKey;
        m_TeleportChargeTimer = 0;
        m_TeleportUseTimer = 0;
        m_TeleportCharges = MaxTelportCharges;
    }

    public override void SetOwner(Player owner)
    {
        Owner = owner;

        if (!(Owner.IsAI))
        {
            Owner.AbilityUICooldowns.MovementAbilityInfo.HasCharges = true;
            Owner.AbilityUICooldowns.MovementAbilityInfo.MaxCharges = MaxTelportCharges;
        }
        m_TeleportSmoke1 = owner.transform.FindChild(m_ParticleEffectsTransform).FindChild(m_TeleportSmoke1Transform).GetComponent<ParticleSystem>();
        m_TeleportSmoke2 = owner.transform.FindChild(m_ParticleEffectsTransform).FindChild(m_TeleportSmoke2Transform).GetComponent<ParticleSystem>();

        m_Camera = Owner.FirstPersonPlayerCamera;

        owner.transform.FindChild(m_ParticleEffectsTransform).parent = GameObject.Find(m_ParticleManagerTransform).transform;

        m_LayerMask = ~(Physics.IgnoreRaycastLayer | 1 << owner.gameObject.layer);
    }

    public override void OnStartAbility ()
	{

        if (!Owner.CanUseMovementAbility)
            return;

        if (m_TeleportUseTimer <= 0 && m_TeleportCharges > 0)
        {
            GameInput = Owner.GameInput;
            m_Camera = Owner.FirstPersonPlayerCamera;
            
            if (m_Camera != null)
                m_LookDirection = m_Camera.transform.forward;
            else
                m_LookDirection = Owner.transform.forward;

            if (Owner.GetComponent<BasicMovementScript>() != null)
                Owner.GetComponent<BasicMovementScript>().AffectedByOutsideForce();

            bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
            if (playDialogue)
            {
                DialogueManager.Instance.PlayDialogue(CharacterTypes.Zeph, DialogueContext.ZephTeleport, false, true);
            }

            Owner.AudioSourceMovement.Play();

            if (m_TeleportSmoke1.isPlaying)
            {
                m_TeleportSmoke2.transform.position = Owner.transform.position;
                m_TeleportSmoke2.Play();
            }
            else
            {
                m_TeleportSmoke1.transform.position = Owner.transform.position;
                m_TeleportSmoke1.Play();
            }

            Vector3 teleportPosCheck = Owner.PlayerCamera.transform.position + (m_LookDirection * TeleportDistance);

            if(Physics.CheckSphere(teleportPosCheck, m_CheckSphereRadius))
            {
                //Something in the way at max teleport distance, so just teleport to the closest point infront of Zeph
                //TeleportDistance + m_CheckSphereRadius because CheckSphere() has a radius and might throw off the check sometimes
                RaycastHit hit;
                if (Physics.Raycast(Owner.PlayerCamera.transform.position, m_LookDirection, out hit, TeleportDistance + m_CheckSphereRadius, m_LayerMask, QueryTriggerInteraction.Ignore))
                {
                    if (hit.distance > m_DistanceSafetyCheck)
                    {
                        float yDifference = Mathf.Abs(Owner.transform.position.y - hit.point.y);

                        float yAdjustment;
                        if(yDifference <= 1.0f)
                        {
                            yAdjustment = yDifference;
                        }
                        else
                        {
                            yAdjustment = 1.0f;
                        }
                        //If there is a raycast hit, teleport to the hit point minus the look direction, so Zeph teleports just infront of things
                        Owner.transform.position = hit.point - (m_LookDirection * 2) - (Vector3.up * yAdjustment);
                        //Debug.Log("Something in checksphere, raycast succeeded. Hit: " + hit.transform.name);
                    }
                }
                else
                {
                    if (Physics.Raycast(Owner.PlayerCamera.transform.position + (m_LookDirection * TeleportDistance), -Vector3.up, out hit, 1, m_LayerMask, QueryTriggerInteraction.Ignore))
                    {
                        Owner.transform.position = hit.point;
                    }
                    else
                    {
                        //If there was no hit, teleport regularly
                        Owner.transform.position += m_LookDirection * TeleportDistance;
                        //Debug.Log("Something in checksphere, raycast failed");
                    }

                }
            }
            else
            {
                RaycastHit hit;
                if (Physics.Raycast(Owner.PlayerCamera.transform.position, m_LookDirection, out hit, TeleportDistance, m_LayerMask, QueryTriggerInteraction.Ignore))
                {
                    if (hit.distance > m_DistanceSafetyCheck)
                    {
                        float yDifference = Mathf.Abs(Owner.transform.position.y - hit.point.y);

                        float yAdjustment;
                        if (yDifference <= 1.0f)
                        {
                            yAdjustment = yDifference;
                        }
                        else
                        {
                            yAdjustment = 1.0f;
                        }
                        //Nothing in Checksphere, but raycast hit level bounds, teleport to that point
                        Owner.transform.position = hit.point - (m_LookDirection * 2) - (Vector3.up * yAdjustment);
                        //Debug.Log("Nothing in checksphere, raycast succeeded, hit: " + hit.transform.name);
                    }
                }
                else
                {
                    if (Physics.Raycast(Owner.PlayerCamera.transform.position + (m_LookDirection * TeleportDistance), -Vector3.up, out hit, 1, m_LayerMask, QueryTriggerInteraction.Ignore))
                    {
                        Owner.transform.position = hit.point;
                    }
                    else
                    {
                        //If there was no hit, teleport regularly
                        Owner.transform.position += m_LookDirection * TeleportDistance;
                        //Debug.Log("Something in checksphere, raycast failed");
                    }
                }
            }

            m_TeleportUseTimer = TeleportUseCooldown;

            m_TeleportCharges--;
        }
    }

	public override void OnContinueAbility ()
	{
		
	}

	public override void OnEndAbility ()
	{
		
	}

    public override void UpdateAbility(float aFixedDelta)
    {
        m_TeleportUseTimer -= aFixedDelta;

        if(m_TeleportCharges < MaxTelportCharges)
        {
            m_TeleportChargeTimer -= aFixedDelta;
            if (Owner.AbilityUICooldowns)
                Owner.AbilityUICooldowns.MovementAbilityInfo.ChargeCooldown = m_TeleportChargeTimer / TeleportChargeCooldown;
            if (m_TeleportChargeTimer <= 0)
            {
                m_TeleportChargeTimer = TeleportChargeCooldown;
                m_TeleportCharges++;
            }
        }
        else
        {
            m_TeleportChargeTimer = TeleportChargeCooldown;
            if(Owner.AbilityUICooldowns)
                Owner.AbilityUICooldowns.MovementAbilityInfo.ChargeCooldown = 1;
        }


        //Set UI values
        if (Owner.IsAI)
            return;
        Owner.AbilityUICooldowns.MovementAbilityInfo.ChargesLeft = m_TeleportCharges;
        Owner.AbilityUICooldowns.MovementAbilityInfo.UseCooldown = m_TeleportUseTimer / TeleportUseCooldown;
        if (m_TeleportCharges > 0 && m_TeleportUseTimer < 0)
        {
            Owner.AbilityUICooldowns.MovementAbilityInfo.Usable = Owner.CanUseMovementAbility;
        }
        else
        {
            Owner.AbilityUICooldowns.MovementAbilityInfo.Usable = false;
        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_TeleportCharges = 2;
        m_TeleportUseTimer = 0;
        m_TeleportChargeTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_TeleportCharges > 0 && m_TeleportUseTimer < 0)
            return Owner.CanUseMovementAbility;
        return false;
    }
}