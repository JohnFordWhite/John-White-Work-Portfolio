﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        SmokeGrenadeScript                                                             *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 16th, 2016                                                             *
 *                                                                                                 *
 * This script is to be attached to a smoke grenade. When the grenade makes contact with anything  *
 * other than the person that fired it, it's spawns a smoke cloud and deletes itself. This script  *
 * handles the grenade's movement and hit detection, as well as taking in values to apply to the   *
 * smoke cloud.                                                                                    *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 16th, 2016                                          *
 *                                                                                                 *
\***************************************************************************************************/
using UnityEngine;
using System.Collections;

public class SmokeGrenadeScript : MonoBehaviour
{

    public float Speed = 25;
    public float Gravity = 9.81f;
    public float MaxLife = 10.0f;
    [HideInInspector]
    public Player Owner;

    private Vector3 m_Velocity;
    private float m_Life;
    private GameObject m_SmokePrefab;

    private const string m_SmokeResource = "Prefabs/Projectiles/Smoke";

    // Use this for initialization
    void Start ()
    {

    }

    public void Init()
    {
        m_Velocity = transform.forward * Speed;
        m_Life = MaxLife;
        m_SmokePrefab = Resources.Load(m_SmokeResource) as GameObject;
        m_SmokePrefab.GetComponent<SmokeScript>().Owner = this.Owner;

        //ignore collision between projectile and owner
        Owner.IgnoreCollision(GetComponent<Collider>());
    }
	
    void FixedUpdate()
    {
        m_Life -= Time.fixedDeltaTime;
        if(m_Life <= 0)
        {
            Explode();
        }

        transform.position += m_Velocity * Time.fixedDeltaTime;

        m_Velocity.y -= Gravity * Time.fixedDeltaTime;
    }

    void OnTriggerEnter(Collider other)
    {
        //Make it doesn't istantly explode on the user
        if (Owner != null)
        {
            // Ensure the collision isn't just a trigger box
            if (other.isTrigger)
                return;

            Player player = null;

            if (other.GetComponent<PlayerHitboxScript>() != null)
                player = other.GetComponent<PlayerHitboxScript>().Owner;

            if (other.GetComponent<PlayerHitboxScript>() != null || !other.isTrigger)
            {
                Explode();
            }
        }
    }

    public void Explode()
    {
        GameObject InstancedObjectContainer = InputManager.CM.GetInstancedObjectContainer();

        GameObject smoke = Object.Instantiate(m_SmokePrefab, transform.position, transform.rotation) as GameObject;

        smoke.transform.SetParent(InstancedObjectContainer.transform);

        Destroy(gameObject);
    }
}
