/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        LeeroyMeleeAbility                                                             *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            March 16th, 2017                                                               *
 *                                                                                                 *
 * Handles triggering the LeeroyMeleeDamage script based on animation states and animation speed   *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - (This file had no info on who created it. I re-wrote it, so put my name in)             *
 * Overhauled to work with attacking animations (Jon Roffey) - March 16th, 2017                    *
\***************************************************************************************************/

using System;
using UnityEngine;
using System.Collections.Generic;

public class LeeroyMeleeAbility : Ability
{
    //
    // Public
    //
    public float AnimationSpeedModifier = 2.75f;
    public float AbilityCooldown = 0.35f;
    public float AbilityTimer = 0;

    //
    // Private
    //
    private LeeroyMeleeDamage m_LeeroyMeleeDamageScript;
    private bool m_CurrentlyAttacking;
    private int m_LeeroyMeleeModHash = Animator.StringToHash("MeleeSpeedMod");
    private float m_ChanceToPlayDialogue = 0.1f;

    private const string m_EmptyStateString = "Empty";
    private const string m_LeeroyMeleeString = "LeeroyMelee";

    public LeeroyMeleeAbility(InputName aKey)
    {
        Key = aKey;
        m_CurrentlyAttacking = false;

        AnimatorString = m_LeeroyMeleeString;
        HasAnimationTime = true;
    }



    public override void OnStartAbility()
    {
        if (!m_CurrentlyAttacking)
        {
            m_CurrentlyAttacking = true;

            bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
            if (playDialogue)
            {
                if (((Leeroy)Owner).InjectionAbility.ContinuousAbilityInUse)
                {
                    DialogueManager.Instance.PlayDialogue(CharacterTypes.Leeroy, DialogueContext.LeeroyMainAttackRaged, false, true);
                }
                else
                {
                    DialogueManager.Instance.PlayDialogue(CharacterTypes.Leeroy, DialogueContext.MainAttack, false, true);
                }

            }

            Owner.AudioSourceMainAttack.Play();
        }
    }

    public override void OnContinueAbility()
    {
        AbilityTimer -= Time.fixedDeltaTime * Owner.AttackSpeedPercent;
        if(AbilityTimer <= 0)
        {
            Owner.TriggerAbilityAnimations(this);
            AbilityTimer = AbilityCooldown;
        }
    }

    public override void OnEndAbility()
    {
        AbilityTimer = AbilityCooldown;
        Owner.PlayerAnimator.SetBool(m_LeeroyMeleeString, false);
        m_CurrentlyAttacking = false;
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        if (m_LeeroyMeleeDamageScript == null)
        {
            m_LeeroyMeleeDamageScript = Owner.GetComponentInChildren<LeeroyMeleeDamage>();
        }

        //If the state name of the animator on layer 2(Leeroy's melee layer) is "Empty", then -
        //he is not currently in a melee attack animation
        if (Owner.PlayerAnimator.GetCurrentAnimatorStateInfo(2).IsName(m_EmptyStateString))
        {
            m_CurrentlyAttacking = false;

            Owner.PlayerAnimator.SetBool(m_LeeroyMeleeString, false);
        }

        Owner.PlayerAnimator.SetFloat(m_LeeroyMeleeModHash, AnimationSpeedModifier * Owner.AttackSpeedPercent);

        m_LeeroyMeleeDamageScript.Attacking = m_CurrentlyAttacking;
    }

    public override void ResetAbility()
    {
        OnEndAbility();
    }

    public override bool CanUseAbility()
    {
        return !m_CurrentlyAttacking;
    }
}