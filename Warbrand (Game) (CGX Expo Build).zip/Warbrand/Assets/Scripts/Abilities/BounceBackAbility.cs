/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        BounceBackAbility                                                              *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            October 13th, 2016                                                             *
 *                                                                                                 *
 * Ability that bounces the player in their backwards direction, as well as bouncing any enemies   *
 * within a certain distance infront of the player in the opposite direction.                      *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - October 13th, 2016                                          *
 * V 1.1 - Changelog (Author) - Date                                                               *
\***************************************************************************************************/

using System;
using UnityEngine;
using System.Collections.Generic;

public class BounceBackAbility : Ability
{
    //
    //Public
    //
    public float BounceBackCooldown = 3.0f;

    //
    //Private
    //
    private Rigidbody m_Rigidbody;
    private Vector3 m_LookRotation = Vector3.zero;
    private float m_ForceMultiplier = 35f;
    private float m_UpwardsForceModifier = 0.5f;
    private float m_MaxDistanceToActivate = 2f;
    private float m_SphereCastAllRadius = 5f;
    private float m_BounceBackTimer = 0f;
    private float m_ChanceToPlayDialogue = 0.1f;

    private GameObject m_BounceExplosionPrefab;

    private List<Player> m_PlayersHit = null;

    private const string m_QuarkBounceExplosionResource = "Prefabs/Projectiles/QuarkBounceExplosion";

    public BounceBackAbility(InputName aKey)
    {
        Key = aKey;
        m_BounceExplosionPrefab = Resources.Load(m_QuarkBounceExplosionResource) as GameObject;
        m_BounceExplosionPrefab.GetComponent<QuarkBounceExplosionScript>().MaxRadius = m_SphereCastAllRadius;

        m_PlayersHit = new List<Player>();
        m_PlayersHit.Capacity = Information.AllPlayers.Count;
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }

        HasAnimationTime = true;
        AnimatorString = "BounceBack";
    }

    public override void OnStartAbility ()
	{
        if (!Owner.CanUseMovementAbility)
            return;

        if (m_BounceBackTimer <= 0)
        {
            m_Rigidbody = Owner.GetComponent<Rigidbody>();
            m_LookRotation = m_Rigidbody.transform.eulerAngles;

            BasicMovementScript movement = Owner.GetComponent<BasicMovementScript>();

            if (movement != null)
                movement.AffectedByOutsideForce();

            GameObject.Instantiate(m_BounceExplosionPrefab, Owner.transform.position, Owner.transform.rotation);

            RaycastHit[] hits = Physics.SphereCastAll(Owner.transform.position, m_SphereCastAllRadius, Owner.transform.forward);
            
            for (int i = 0; i < hits.Length; i++)
            {
                RaycastHit hit = hits[i];

                Player player = null;
                Rigidbody rigidBody = hit.rigidbody;

                if (hit.collider.GetComponent<PlayerHitboxScript>() != null)
                    player = hit.collider.GetComponent<PlayerHitboxScript>().Owner;

                if(player != null)
                {
                    //If hit is a rigidbody, but not the player who used the ability, check the distance
                    if (player.GetComponent<Rigidbody>() != null && player != Owner)
                    {
                        if(!m_PlayersHit.Contains(player))
                        {
                            m_PlayersHit.Add(player);
                            //If the hit player is close enough, bounce them back
                            if (hit.distance < m_MaxDistanceToActivate)
                            {
                                Vector3 hitForce = Owner.transform.forward;
                                hitForce.y = m_UpwardsForceModifier;
                                hitForce *= m_ForceMultiplier;

                                rigidBody.velocity = Vector3.zero;
                                rigidBody.AddForce(hitForce, ForceMode.Impulse);

                                BasicMovementScript colliderMovement = player.GetComponent<BasicMovementScript>();

                                if (colliderMovement != null)
                                {
                                    colliderMovement.AffectedByOutsideForce();
                                }

                            }
                        }
                    }
                }
                else if(rigidBody != null)
                {
                    if (hit.distance < m_MaxDistanceToActivate)
                    {
                        Vector3 hitForce = Owner.transform.forward;
                        hitForce.y = m_UpwardsForceModifier;
                        hitForce *= m_ForceMultiplier / 2.0f;

                        rigidBody.velocity = Vector3.zero;
                        rigidBody.AddForce(hitForce, ForceMode.Impulse);
                    }
                }
            }

            if (m_PlayersHit.Count > 0)
            {
                bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
                if (playDialogue)
                {
                    DialogueManager.Instance.PlayDialogue(CharacterTypes.Quark, DialogueContext.QuarkMovementAbilityConnects, false, true);
                }
            }

            //Direction to push Quark
            Vector3 quarkForce = -Owner.transform.forward;

            //If Quark is looking up too high, adjust the direction he'll be pushed to keep ability movement consistent(i.e., behind him)
            if (m_LookRotation.x < 300 && m_LookRotation.x > 270)
                quarkForce = Owner.transform.up;

            //If Quark is looking down too low, adjust the direction he'll be pushed to keep ability movement consistent(i.e., behind him)
            if (m_LookRotation.x < 90 && m_LookRotation.x > 30)
                quarkForce = -Owner.transform.up;

            //Add an upwards bump and multiply the force
            quarkForce.y = m_UpwardsForceModifier;
            quarkForce *= m_ForceMultiplier;

            Owner.AudioSourceMovement.Play();

            //Always bounce Quark back when this ability is used
            m_Rigidbody.velocity = Vector3.zero;
            m_Rigidbody.AddForce(quarkForce, ForceMode.Impulse);

            m_BounceBackTimer = BounceBackCooldown;
        }
    }

	public override void OnContinueAbility ()
	{

    }

	public override void OnEndAbility ()
	{
        m_PlayersHit.Clear();
	}

    public override void UpdateAbility(float aFixedDelta)
    {
        m_BounceBackTimer -= aFixedDelta;


        //Do UI stuff
        if (Owner.IsAI)
            return;

        Owner.AbilityUICooldowns.MovementAbilityInfo.UseCooldown = (m_BounceBackTimer / BounceBackCooldown);
        if (m_BounceBackTimer > 0)
        {
            Owner.AbilityUICooldowns.MovementAbilityInfo.Usable = false;
        }
        else
        {
            Owner.AbilityUICooldowns.MovementAbilityInfo.Usable = Owner.CanUseMovementAbility;
        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_BounceBackTimer = 0;
    }

    public override bool CanUseAbility()
    {
        return ((m_BounceBackTimer > 0) ? false : true);
    }
}