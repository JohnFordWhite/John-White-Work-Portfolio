﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class ClapStunScript : MonoBehaviour
{
    //
    //Public
    //
    [HideInInspector]
    public Player Owner;
    public float MaxDuration = 0.05f;
    [HideInInspector]
    public float StunTime;

    //
    //Private
    //
    private float m_Life;
    private List<Player> m_Players;

	void Start ()
    {
        m_Players = new List<Player>();
        m_Players.Capacity = Information.AllPlayers.Count;
        m_Life = MaxDuration;
	}
	
	void Update ()
    {
        m_Life -= Time.deltaTime;

        if(m_Life <= 0.0f)
        {
            Destroy(gameObject);
        }
	}

    void OnTriggerEnter(Collider other)
    {
        Player player = other.GetComponent<PlayerHitboxScript>().Owner;
        if(player != null && player != Owner)
        {
            if(m_Players.Contains(player) == false)
            {
                player.Stun(StunTime);
                m_Players.Add(player);
            }
        }
    }
}
