﻿using UnityEngine;
using System.Collections;

public class HookHitboxScript : MonoBehaviour
{
    [HideInInspector]
    public Player Owner;
    [HideInInspector]
    public HookScript Hook;
	void Start ()
    {
        Hook = transform.parent.gameObject.GetComponent<HookScript>();
	}
	
	void Update ()
    {
	
	}

    void OnTriggerEnter(Collider other)
    {
        Player player = null;

        if(other.GetComponent<PlayerHitboxScript>() != null)
            player = other.GetComponent<PlayerHitboxScript>().Owner;

        //if (other.GetComponent<PlayerHitboxScript>().Owner != null && !HitAPlayer)
        //if (other.transform.root.GetComponentInChildren<Player>() != null && !Hook.HitAPlayer)
        if(player != null && player.TeamIndex != Owner.TeamIndex && !Hook.HitAPlayer)
        {
            //if(other.transform.root.GetComponentInChildren<Player>() != Owner)
            if(player != Owner)
            {
                //Debug.Log(other.name);
                Hook.HookedPlayer = player;

                Hook.HitAPlayer = true;
            }
        }
    }
}
