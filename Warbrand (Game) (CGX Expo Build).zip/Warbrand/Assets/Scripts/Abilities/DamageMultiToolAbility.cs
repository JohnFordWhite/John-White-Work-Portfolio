/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        DamageMultiToolAbility                                                         *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 222th, 2016                                                            *
 *                                                                                                 *
 * This is an ability that is meant to be added to quark. It allows him to use his damage multitool*
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 22th, 2016                                          *
\***************************************************************************************************/

using System;
using UnityEngine;

public class DamageMultiToolAbility : Ability
{
    DamageBeamScript DamageBeam;

    bool AbilityStarted;

    private AudioSource m_PlayerAudioSource;
    private float m_StartVolume = 0.1f;

    public DamageMultiToolAbility(InputName aKey)
    {
        Key = aKey;
        AbilityStarted = false;
    }

    override public void SetOwner(Player owner)
    {
        Owner = owner;
        DamageBeam = owner.GetComponentInChildren<DamageBeamScript>();
        DamageBeam.Owner = owner;

        HasAnimationTime = true;
        AnimatorString = "Beam";
    }

    public override void OnStartAbility ()
	{
        Quark quark = Owner.GetComponent<Quark>();

        if (quark.PlacingObject == false)
        {
            Owner.AudioSourceMainAttack.clip = quark.MainAttackDamageBeam;
            Owner.AudioSourceMainAttack.Play();

            DamageBeam.ActivateBeam();
            AbilityStarted = true;
        }
	}

	public override void OnContinueAbility ()
	{
        if (Owner.GetComponent<Quark>().PlacingObject == false)
        {
            if (Owner.IsStunned == false)
            {
                //If the player switched to the damage tool while holding down the button, activate the beam
                if(AbilityStarted == false)
                {
                    OnStartAbility();
                }
            }
            else
            {
                //If the player switched tools while using the damage tool, deactivate the beam
                StopDealingDamage();
            }
        }
        else
        {
            StopDealingDamage();
        }
    }

	public override void OnEndAbility ()
	{
        //If the player let go of the key, deactivate the beam
        SimpleCoroutine.Instance.StartCoroutine(AudioUtils.FadeOut(Owner.AudioSourceMainAttack, m_StartVolume, 0.05f));

        Owner.PlayerAnimator.SetBool("Beam", false);

        StopDealingDamage(); 
    }

    void StopDealingDamage()
    {
        DamageBeam.DeactivateBeam();
        AbilityStarted = false;
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        
    }

    public override void ResetAbility()
    {
        OnEndAbility();
    }

    public override bool CanUseAbility()
    {
        return true;
    }
}