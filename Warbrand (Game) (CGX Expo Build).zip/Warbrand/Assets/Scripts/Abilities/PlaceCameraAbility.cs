/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        PlaceCameraAbility                                                             *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 29th, 2016                                                             *
 *                                                                                                 *
 * This script is an ability that is to be added to Quark. This script allows Quark to place his   *
 * Camera. The Camera must be on the ground, ceiling, or wall and can't be colliding with any other*
 * objects. If more than 2 cameras are placed, the oldest one gets destroyed                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 29th, 2016                                          *
\***************************************************************************************************/

using System;
using UnityEngine;

public class PlaceCameraAbility : Ability
{
    //
    // Public
    //
    public float PlacementCooldown = 3.0f;
    public float PlacementRange = 2;

    //
    //Private
    //
    private float m_PlacementTimer;
    private float m_ChanceToPlayDialogue = 0.1f;
    private GameObject m_NewCamera;
    private GameObject m_Camera1;
    private GameObject m_Camera2;
    private GameObject m_CameraPrefab;

    private Quaternion m_CameraRotation;
    private Vector3 m_CameraOffset;

    private const string m_QuarkCameraResource = "Prefabs/Quark_Camera";

    public PlaceCameraAbility(InputName aKey)
    {
        Key = aKey;
        m_CameraPrefab = Resources.Load(m_QuarkCameraResource) as GameObject;
        m_PlacementTimer = 0;

        GameObject InstancedObjectContainer = InputManager.CM.GetInstancedObjectContainer();

        m_Camera1 = GameObject.Instantiate(m_CameraPrefab, Vector3.zero, Quaternion.identity) as GameObject;
        m_Camera2 = GameObject.Instantiate(m_CameraPrefab, Vector3.zero, Quaternion.identity) as GameObject;

        m_Camera1.GetComponent<BoxCollider>().isTrigger = false;
        m_Camera2.GetComponent<BoxCollider>().isTrigger = false;

        GameObject.DontDestroyOnLoad(m_Camera1);
        GameObject.DontDestroyOnLoad(m_Camera2);

        m_Camera1.transform.SetParent(InstancedObjectContainer.transform);
        m_Camera2.transform.SetParent(InstancedObjectContainer.transform);

        HasAnimationTime = true;
        AnimatorString = "ThrowCamera";
    }

    public override void SetOwner(Player owner)
    {
        Owner = owner;
        if (!(Owner.IsAI))
        {
            Owner.AbilityUICooldowns.Ability3Info.HasCharges = true;
            Owner.AbilityUICooldowns.Ability3Info.ChargeCooldown = 1;
            Owner.AbilityUICooldowns.Ability3Info.MaxCharges = 2;
        }

        m_Camera1.GetComponent<CameraScript>().Owner = owner;
        m_Camera2.GetComponent<CameraScript>().Owner = owner;
    }

    public override void OnStartAbility ()
    {
        if (m_PlacementTimer <= 0)
        {
            //Determine how which of quark's cameras should be reset based on the ones that are currently placed
            if(m_Camera1.activeInHierarchy == false)
            {
                m_NewCamera = m_Camera1;
            }
            else
            {
                m_NewCamera = m_Camera2;
                m_Camera2 = m_Camera1;
            }

            Owner.GetComponent<Quark>().PlacingObject = true;
            if (Owner != null && GameInput == null)
                GameInput = Owner.GameInput;

            m_CameraRotation = Owner.PlayerCamera.transform.rotation;
            m_CameraRotation.x = 0;
            m_CameraRotation.z = 0;

            //Make sure the Camera doesn't get placed under the ground
            m_CameraOffset = Owner.PlayerCamera.transform.forward * PlacementRange;

            m_NewCamera.transform.position = Owner.PlayerCamera.transform.position + m_CameraOffset;
            m_NewCamera.transform.rotation = m_CameraRotation;

            //If the player would be placing the camera into a wall, place it closer to the player
            RaycastHit hitInfo;
            if (Physics.Linecast(Owner.PlayerCamera.transform.position, Owner.PlayerCamera.transform.position + Owner.PlayerCamera.transform.forward * PlacementRange, out hitInfo))
            {
                m_NewCamera.transform.position = hitInfo.point + hitInfo.normal * 0.3f;
                //m_NewCamera.transform.up -= (m_NewCamera.transform.up - hitInfo.normal) * .1f;
            }

            PlaceCamera();
        }
    }

	public override void OnContinueAbility ()
	{
        
    }

    public override void OnEndAbility()
    {

    }

    public int CamerasPlaced { get; private set; }
    public override void UpdateAbility(float aFixedDelta)
    {
        m_PlacementTimer -= aFixedDelta;

        CamerasPlaced = 0;
        if (m_Camera1.activeInHierarchy == true)
            CamerasPlaced++;
        if (m_Camera2.activeInHierarchy == true)
            CamerasPlaced++;


        if (Owner.IsAI)
            return;

        Owner.AbilityUICooldowns.Ability3Info.ChargesLeft = CamerasPlaced;

        //Do UI stuff
        Owner.AbilityUICooldowns.Ability3Info.UseCooldown = m_PlacementTimer / PlacementCooldown;
        Owner.AbilityUICooldowns.Ability3Info.Usable = CanUseAbility();
    }

    public void PlaceCamera()
    {
        //player left-clicked to place Camera, or pressed a different ability button to cancel the placement

        if (m_NewCamera != null)
        {
            m_PlacementTimer = PlacementCooldown;
            m_NewCamera.GetComponent<CameraScript>().Reset();

            bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
            if (playDialogue)
            {
                DialogueManager.Instance.PlayDialogue(CharacterTypes.Quark, DialogueContext.QuarkThrowCamera, false, true);
            }

            Owner.AudioSourceAbility3.Play();

            m_Camera1 = m_NewCamera;
            m_NewCamera = null;
        }

        Owner.GetComponent<Quark>().PlacingObject = false;
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_PlacementTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_PlacementTimer <= 0)
            return true;
        return false;
    }
}