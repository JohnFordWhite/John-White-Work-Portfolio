﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        TMNThrowableFunctionality                                                      *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            October 27th,2016                                                              *
 *                                                                                                 *
 * When a player enters the trigger, they are slowed, can't jump, and can't use their movement     *
 * ability                                                                                         *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - October 27th,2016                                           *
 * V 1.1 - Changelog (Author) - Date                                                               *
\***************************************************************************************************/

using UnityEngine;
using System.Collections.Generic;

public class TMNThrowableFunctionality : MonoBehaviour
{
    //
    //Public
    //
    public Player Owner;
    public float SlowAmount = 0.5f;
    public float TimeToRemoveSlow = 0.5f;
    public GameObject SplatterPrefab;
    [HideInInspector]
    public bool IsOnGround = false;
    public List<Player> PlayersAffected { get { return m_PlayersAffected; } }

    //
    //Private
    //
    private AudioSource m_AudioSource;
    private Rigidbody m_RigidBody;
    private BoxCollider m_BoxCollider;
    private List<Player> m_PlayersAffected = new List<Player>();
    public ObjectPool m_Splatters;
    private float m_TimeSinceCast = 0f;
    private bool m_Initializing = true;
    private bool m_TargetInAdhesiveDialoguePlayed = false;
    private int m_NumOfSplatters = 100;
    private float m_GroundCheckRange = 30;
    private float m_ChanceToPlayDialogue = 0.1f;
    private int m_LayerMask;

    //strings
    private const string m_GroundTagString = "Ground";

    private const string m_TMNLPF = "TMNLPF";

    private const string m_UnplacedObjectsMask = "UnplacedObjects";
    private const string m_QuarkCameraMask = "QuarkCamera";
    private const string m_RagdollMask = "Ragdoll";
    private const string m_ShieldMask = "Shield";

    void Start()
    {
        m_AudioSource = gameObject.GetComponent<AudioSource>();

        m_RigidBody = GetComponent<Rigidbody>();

        m_LayerMask = ~((1 << gameObject.layer) |
            (1 << LayerMask.NameToLayer(m_UnplacedObjectsMask)) |
            (1 << LayerMask.NameToLayer(m_QuarkCameraMask)) |
            (1 << LayerMask.NameToLayer(m_RagdollMask)) |
            (1 << LayerMask.NameToLayer(m_ShieldMask)));
    }

    public void SetOwner(Player owner)
    {
        Owner = owner;

        m_Splatters = new ObjectPool();
        m_Splatters.Initialize(m_NumOfSplatters);
        m_Splatters.FillPoolWithPrefab(SplatterPrefab);

        for (int i = 0; i < m_NumOfSplatters; i++)
        {
            m_Splatters.GetPool()[i].GetComponentInChildren<SlowPlayers>().Adhesive = this;
        }
    }

    void Update()
    {
        if(m_Initializing)
        {
            m_Initializing = false;
            gameObject.SetActive(false);
        }

        if (IsOnGround)
        {
            m_TimeSinceCast += Time.deltaTime;

            //Check for players that need to be unslowed
            for(int i = 0; i < m_PlayersAffected.Count; i++)
            {
                Player player = m_PlayersAffected[i];
                if(player.IsInAdhesive == false && player.TimeOutOfAdhesive > TimeToRemoveSlow)
                {
                    BasicMovementScript movement = player.GetComponent<BasicMovementScript>();
                    if(movement != null)
                    {
                        movement.RemoveMovementSpeedModifier(-SlowAmount);
                        movement.CanJump = true;
                        player.CanUseMovementAbility = true;

                        m_PlayersAffected.Remove(player);
                    }
                }
            }
        }

        if (!IsOnGround)
        {
            RaycastHit hit;

            if (Physics.Raycast(transform.position, Vector3.down, out hit, GetComponent<CapsuleCollider>().bounds.extents.y + 0.1f))
            {
                //Debug.Log(hit.transform.tag);
                if (hit.transform.tag == m_GroundTagString)
                {
                    //m_Splatter.gameObject.transform.eulerAngles = hit.normal;
                    AudioUtils.SetLPF(this.gameObject, m_TMNLPF);
                    AudioUtils.SetVolumeByDistance(this.gameObject,false);
                    m_AudioSource.Play();


                    //Hit ground, zero velocities and set position to the hit point
                    transform.position = new Vector3(hit.point.x, hit.point.y + 0.25f, hit.point.z);
                    IsOnGround = true;

                    //Enable the collider that will affect players
                    //m_BoxCollider.enabled = true;

                    //Freeze the rigidbody, remove the capsule collider, hide the capsule
                    transform.GetComponent<CapsuleCollider>().enabled = false;
                    transform.GetComponent<MeshRenderer>().enabled = false;
                    m_RigidBody.constraints = RigidbodyConstraints.FreezeAll;

                    // Add the adhesive to the list
                    Information.AddAdhesive(this);

                    //Set splatters to be visible
                    for(int i = 0; i < m_NumOfSplatters; i++)
                    {
                        ResetSplatter(m_Splatters.GetPool()[i]);
                    }
                }
            }
        }

        for (int i = 0; i < PlayersAffected.Count; i++)
            AchievementsManager.IncrementFloat(PlayersAffected[i], Achievements.TimeInAdhesive, Time.deltaTime);

        if (m_TimeSinceCast >= 9.0f)
        {
            Deactivate();
        }

    }

    void ResetSplatter(GameObject splatter)
    {
        splatter.SetActive(true);
        Vector3 offset = Vector3.zero;
        float angle = Random.Range(0, 359);
        float dist = Random.Range(0, 5);
        offset.x = Mathf.Cos(angle * 0.0174533f) * dist;
        offset.z = Mathf.Sin(angle * 0.0174533f) * dist;
        splatter.transform.position = gameObject.transform.position + offset;

        RaycastHit hitInfo;
        if (Physics.Linecast(splatter.transform.position, splatter.transform.position - Vector3.up * m_GroundCheckRange, out hitInfo, m_LayerMask, QueryTriggerInteraction.Ignore))
        {
            Vector3 newRotation = Vector3.zero;
            Vector3 normalizedX = hitInfo.normal;
            normalizedX.z = 0;
            normalizedX.Normalize();

            newRotation.x = Vector3.Angle(normalizedX, Vector3.up) * Mathf.Sign(normalizedX.x);


            newRotation.y = 90;

            Vector3 normalizedZ = hitInfo.normal;
            normalizedZ.x = 0;
            normalizedZ.Normalize();

            newRotation.z = Vector3.Angle(normalizedZ, Vector3.up) * Mathf.Sign(normalizedZ.z);

            splatter.transform.localEulerAngles = newRotation;

            splatter.transform.position = hitInfo.point;
            splatter.transform.position += splatter.transform.up * 0.01f;
        }

        splatter.transform.RotateAround(splatter.transform.up, Random.Range(0, 360));
    }

    public void SlowPlayer(Collider collider)
    {
        //If a player is in the goop, make them slow, unable to jump, and unable to use their movement ability
        Player player = null;

        if(collider.GetComponent<PlayerHitboxScript>() != null)
            player = collider.GetComponent<PlayerHitboxScript>().Owner;

        if (player != null)
        {
            BasicMovementScript movement = player.GetComponent<BasicMovementScript>();
            if (player != Owner && !m_PlayersAffected.Contains(player) && movement != null && player.TeamIndex != Owner.TeamIndex)
            {
                m_PlayersAffected.Add(player);

                if (!m_TargetInAdhesiveDialoguePlayed)
                {
                    bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
                    if (playDialogue)
                    {
                        DialogueManager.Instance.PlayDialogue(CharacterTypes.Paige, DialogueContext.PaigeTargetInAdhesiveOnLand, false, true);
                        m_TargetInAdhesiveDialoguePlayed = true;
                    }
                }

                player.GetComponent<BasicMovementScript>().AddMovementSpeedModifier(-SlowAmount);
                player.GetComponent<BasicMovementScript>().CanJump = false;
                player.CanUseMovementAbility = false;

                if (player.IsAI)
                    player.GetComponent<AICharacter>().SetAdhesiveReaction();
            }

            player.IsInAdhesive = true;
            player.TimeOutOfAdhesive = 0.0f;
        }
    }

    public void UnslowPlayer(Collider collider)
    {
        Player player = null;

        if (collider.GetComponent<PlayerHitboxScript>() != null)
            player = collider.GetComponent<PlayerHitboxScript>().Owner;

        if (player != null)
        {
            BasicMovementScript movement = player.GetComponent<BasicMovementScript>();
            if (m_PlayersAffected.Contains(player) && movement != null)
            {
                player.IsInAdhesive = false;
            }
        }
    }

    public void Deactivate()
    {
        //Ability is over, reset each players speed, ability to jump, and to use movement ability
        for (int i = 0; i < m_PlayersAffected.Count; i++)
        {
            Player playerKey = m_PlayersAffected[i];

            BasicMovementScript movement = playerKey.GetComponent<BasicMovementScript>();
            if (movement != null)
            {
                movement.RemoveMovementSpeedModifier(-SlowAmount);
                movement.CanJump = true;
                playerKey.CanUseMovementAbility = true;
            }
        }
        Information.RemoveAdhesive(this);

        for (int i = 0; i < m_NumOfSplatters; i++)
        {
            m_Splatters.GetPool()[i].SetActive(false);
        }
        gameObject.SetActive(false);
    }

    public void Reset()
    {
        m_TargetInAdhesiveDialoguePlayed = false;
        IsOnGround = false;
        m_RigidBody.velocity = Vector3.zero;
        m_RigidBody.constraints = RigidbodyConstraints.FreezeRotation;
        m_TimeSinceCast = 0;
        transform.GetComponent<CapsuleCollider>().enabled = true;
        transform.GetComponent<MeshRenderer>().enabled = true;
        gameObject.SetActive(true);
    }
}
