﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Dart                                                                           *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            October 27th,2016                                                              *
 *                                                                                                 *
 * Simple script to check collisions on poison dart prefab for removal of itself                   *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - October 27th,2016                                           *
 * V 1.1 - Changelog (Author) - Date                                                               *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;

public class Dart : MonoBehaviour
{
    //
    //Public
    //

    //
    //Private
    //
    private float m_TimeSinceCast = 0f;
    
    void Update()
    {
        m_TimeSinceCast += Time.deltaTime;

        Collider[] overlapColliders = Physics.OverlapSphere(transform.position, 0.35f);
        
        //If there is a collision with anything other than itself, destroy
        for (int i = 0; i < overlapColliders.Length; i++)
        {
            Collider collider = overlapColliders[i];

            if (collider.gameObject != gameObject)
                Destroy(gameObject);
        }

        //If alive for more than 0.5 secs, destroy
        if(m_TimeSinceCast >0.5f)
            Destroy(gameObject);
    }
}
