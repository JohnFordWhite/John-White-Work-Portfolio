/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Filename                                                                       *
 * FileExtension:   .cs                                                                            *
 * Author:          AuthorName                                                                     *
 * Date:            Month #th, year                                                                *
 *                                                                                                 *
 * Description of file usage                                                                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Author) - Date                                                            *
 * V 1.1 - Changelog (Author) - Date                                                               *
\***************************************************************************************************/

using System;
using UnityEngine;

public class NewAbilityTemplate : Ability
{
	//
	// Public
	//

    //
    //Private
    //

    public NewAbilityTemplate(InputName aKey)
    {
        Key = aKey;
    }

    public override void OnStartAbility ()
	{
        
	}

	public override void OnContinueAbility ()
	{
        
	}

	public override void OnEndAbility ()
	{
        
	}

    public override void UpdateAbility(float aFixedDelta)
    {

    }

    public override void ResetAbility()
    {
        throw new NotImplementedException();
    }

    public override bool CanUseAbility()
    {
        throw new NotImplementedException();
    }
}