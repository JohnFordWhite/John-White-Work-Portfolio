﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        SmokeScript                                                                    *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 20th, 2016                                                             *
 *                                                                                                 *
 * This script is to be attached a sphere (or any object you want to represent a smoke cloud). When*
 *  a player collides with the object, the FadeIn function in the player's smoke overlay effect    *
 *  will be called. FadeOut will be called when the player exits the cloud.                        *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 20th, 2016                                          *
 *                                                                                                 *
\***************************************************************************************************/
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class SmokeScript : MonoBehaviour
{
    //
    //Public
    //
    [HideInInspector]
    public Player Owner;
    public float Radius;

    //
    //Private
    //
    float m_Life;
    private float m_CaughtPplInSmokeDialogueTimer = 1;
    private float m_ChanceToPlayDialogue = 0.001f;

    private bool m_CaughtPplInSMokeDialoguePlayed = false;
    private AudioSource m_AudioSource;
    private ParticleSystem m_SmokeEffect;
    private List<Player> m_PlayersWhoHaveCoughedLul = new List<Player>();

    private const string m_SmokeGrenadeLPF = "SmokeGrenadeLPF";
    private const string m_SmokeGrenadeSmokeTransform = "SmokeGrenadeSmoke";


    void Start ()
    {
        GetComponent<SphereCollider>().radius = Radius;

        m_AudioSource = GetComponent<AudioSource>();

        AudioUtils.SetVolumeByDistance(this.gameObject, false, 0.7f);
        AudioUtils.SetLPF(this.gameObject, m_SmokeGrenadeLPF);
        m_AudioSource.Play();

        m_SmokeEffect = gameObject.transform.FindChild(m_SmokeGrenadeSmokeTransform).gameObject.GetComponent<ParticleSystem>();
        m_SmokeEffect.Play();
	}
	
	void Update ()
    {
        AudioUtils.SetVolumeByDistance(this.gameObject, false, 0.7f);

        if (m_SmokeEffect.isPlaying == false)
        {
            m_CaughtPplInSMokeDialoguePlayed = false;
            m_CaughtPplInSmokeDialogueTimer = 1;
            GameObject.Destroy(gameObject);
        }

        if (m_PlayersWhoHaveCoughedLul.Count > 0)
        {
            m_CaughtPplInSmokeDialogueTimer -= Time.deltaTime;

            if (m_CaughtPplInSmokeDialogueTimer <= 0 && !m_CaughtPplInSMokeDialoguePlayed)
            {
                DialogueManager.Instance.PlayDialogue(CharacterTypes.Zeph, DialogueContext.ZephCatchesPplInSmoke, false, true);
                m_CaughtPplInSMokeDialoguePlayed = true;
            }
        }
	}

    void OnTriggerEnter(Collider collider)
    {
        if (collider.GetComponent<PlayerHitboxScript>() != null)
        {
            Player player = collider.GetComponent<PlayerHitboxScript>().Owner;

            if(m_PlayersWhoHaveCoughedLul.Contains(player))
            {
                return;
            }

            m_PlayersWhoHaveCoughedLul.Add(player);

            bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
            if (playDialogue)
            {
                DialogueManager.Instance.PlayDialogue(player.Character, DialogueContext.InSmoke, false, true);
            }
        }
    }

    void OnTriggerStay(Collider other)
    {
        Player player = null;

        if(other.GetComponent<PlayerHitboxScript>() != null)
            player = other.GetComponent<PlayerHitboxScript>().Owner;

        if (player != null)
        {
            if(player != Owner && player.TeamIndex != Owner.TeamIndex)
            {
                if (player.IsAI)
                {
                    player.GetComponent<AICharacter>().SetSmokeScreenReaction();
                }
                else
                {
                    SmokeImageEffectScript smoke = player.FirstPersonModelCamera.GetComponent<SmokeImageEffectScript>();
                    if (smoke != null)
                    {
                        smoke.enabled = true;
                        smoke.FadeIn();
                    }
                }

                AchievementsManager.IncrementFloat(player, Achievements.TimeInSmokescreen, Time.fixedDeltaTime);
            }
            //if it's a player, it can't be a camera or a turret, so don't bother checking
            return;
        }

        CameraScript camera = other.GetComponent<CameraScript>();
        if(camera != null)
        {
            camera.IsInSmoke = true;
        }

        TurretScript turret = other.GetComponent<TurretScript>();
        if (turret != null)
        {
            turret.IsInSmoke = true;
        }
    }

    void OnTriggerExit(Collider collider)
    {
        //Debug.Log("left smoke screen");
        //if (collider.GetComponent<PlayerHitboxScript>() != null)
        //{
        //    Player player = collider.GetComponent<PlayerHitboxScript>().Owner;

        //    if (m_PlayersWhoHaveCoughedLul.Contains(player))
        //    {
        //        m_PlayersWhoHaveCoughedLul.Remove(player);
        //    }
            
        //}
    }
}
