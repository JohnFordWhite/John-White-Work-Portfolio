﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ElectricWallScript                                                             *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 29th, 2016                                                             *
 *                                                                                                 *
 * This script is meant to be attached to Quark's electric wall. While any player other than Quark *
 * is in the electric wall, their movement speed is slowed, they can't use their movement ability, *
 * and they will take damage                                                                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 29th, 2016                                          *
\***************************************************************************************************/
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class ElectricWallScript : MonoBehaviour
{
    //
    //Public
    //
    [HideInInspector]
    public Player Owner;
    public float WallDamage = 5.0f;
    public float SlowAmount = 0.75f;

    //
    //Private
    //
    //float m_DamageTimer;
    bool m_IsActivated;
    List<Player> m_Players;
    List<BasicMovementScript> m_Movements;

    void Start ()
    {
        //m_DamageTimer = 0;
        m_IsActivated = false;

        int capacity = Information.AllPlayers.Count;

        m_Players = new List<Player>();
        m_Players.Capacity = capacity;
        for (int i = 0; i < m_Players.Capacity; i++)
        {
            m_Players.Add(null);
        }

        m_Movements = new List<BasicMovementScript>();
        m_Movements.Capacity = capacity;
        for (int i = 0; i < m_Movements.Capacity; i++)
        {
            m_Movements.Add(null);
        }
    }
	
	void FixedUpdate ()
    {
	}

    public void ActivateWall()
    {
        m_IsActivated = true;
    }

    void OnTriggerStay(Collider other)
    {
        var health = other.GetComponent<Health>();

        if (health != null)
        {
            if (health.gameObject != Owner.gameObject && m_IsActivated)
            {
                //Debug.Log("Dealing " + BeamDamage * Time.fixedDeltaTime + " beam damage");
                health.Damage(Owner, gameObject, WallDamage * Time.fixedDeltaTime);
            }
        }
    }

    void OnTriggerEnter(Collider other)
    {

        Player player = other.GetComponent<PlayerHitboxScript>().Owner;
        if (player != null)
        {
            if (player.gameObject != Owner.gameObject && m_IsActivated)
            {
                player.gameObject.GetComponent<BasicMovementScript>().AddMovementSpeedModifier(-SlowAmount);
                player.CanUseMovementAbility = false;

                int id = player.GameInput.PlayerID;

                if (m_Players[id - 1] != player)
                    m_Players[id - 1] = player;
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        var player = other.GetComponent<PlayerHitboxScript>().Owner;
        if (player != null)
        {
            if (player.gameObject != Owner.gameObject && m_IsActivated)
            {
                player.gameObject.GetComponent<BasicMovementScript>().RemoveMovementSpeedModifier(-SlowAmount);
                player.CanUseMovementAbility = true;

                int id = player.GameInput.PlayerID;

                if (m_Players[id - 1] != player)
                    m_Players[id - 1] = player;
            }
        }
    }

    public void Destroy()
    {
        for (int i = 0; i < m_Players.Count; i++)
        {
            Player player = m_Players[i];

            if (player != null)
            {
                player.gameObject.GetComponent<BasicMovementScript>().RemoveMovementSpeedModifier(-SlowAmount);
                player.CanUseMovementAbility = true;
            }

            Destroy(gameObject);
        }
    }
}
