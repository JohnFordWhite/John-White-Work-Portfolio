﻿using UnityEngine;
using System.Collections;

public class QuarkTrapScript : MonoBehaviour
{
    //
    //public
    //
    public AudioClip LandClip;
    public AudioClip IdleClip;
    public AudioClip DamageClip;
    public float TrapDuration = 3.2f;
    public float TrapDamage = 10.0f;
    public GameObject LightningSpawner;
    public Material PlacedMaterial;

    [HideInInspector]
    public Player Owner;

    [HideInInspector]
    public bool IsUnobstructed;
    [HideInInspector]
    public bool IsOnGround;
    [HideInInspector]
    public bool IsInValidPlacementLocation;
    [HideInInspector]
    public bool IsPlaced;

    //
    //private
    //
    private AudioSource m_AudioSource;
    private Player m_TrappedPlayer;
    private Renderer[] m_Renderers;
    private Health m_Health;
    private bool m_ShadersSwitched = false;
    private bool m_TrapTriggered = false;

    private Shader m_StandardShader;
    //strings
    private const string m_PlacementColorUniform = "_PlacementColor";

    private const string m_StandardShaderName = "Standard";
    private const string m_PlaceObjectShaderName = "Custom/PlaceObject";

    //private string m_PlayerTagString = "Player";

    void Start ()
    {
        m_AudioSource = GetComponent<AudioSource>();
        IsPlaced = false;
        IsUnobstructed = true;

        m_StandardShader = Shader.Find(m_StandardShaderName);

        m_Renderers = gameObject.GetComponentsInChildren<Renderer>();
        
        for (int i = 0; i < m_Renderers.Length; i++)
        {
            Renderer renderer = m_Renderers[i];

            renderer.material.shader = Shader.Find(m_PlaceObjectShaderName);
        }

        m_Health = GetComponent<Health>();
    }
	
	// Update is called once per frame
	void Update ()
    {
        if (IsUnobstructed == true && IsOnGround == true)
        {
            IsInValidPlacementLocation = true;
        }
        else
        {
            IsInValidPlacementLocation = false;
        }

        //Trap is being placed
        if (IsPlaced == false)
        {
            for (int i = 0; i < m_Renderers.Length; i++)
            {
                Renderer renderer = m_Renderers[i];

                if (IsInValidPlacementLocation)
                {
                    renderer.material.SetColor(m_PlacementColorUniform, Color.green);
                }
                else
                {
                    renderer.material.SetColor(m_PlacementColorUniform, Color.red);
                }
            }
        }
        //Trap has already been placed
        else
        {
            //Only swap out the shaders once
            if(m_ShadersSwitched == false)
            {
                for (int i = 0; i < m_Renderers.Length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    renderer.material.shader = m_StandardShader;
                }
                m_ShadersSwitched = true;

                m_AudioSource.clip = LandClip;
                m_AudioSource.loop = false;
                m_AudioSource.volume = 0.8f;
                m_AudioSource.Play();
            }

            //trap logic
            if(m_TrapTriggered == true)
            {
                TrapDuration -= Time.fixedDeltaTime;
            }
        }

        if (m_Health.IsDead || TrapDuration <= 0)
        {
            if(m_TrappedPlayer != null)
            {
                m_TrappedPlayer.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeRotation;
            }
            Destroy();
        }

        if (m_TrappedPlayer != null)
        {
            Health health = m_TrappedPlayer.GetComponent<Health>();
            if (health.IsDead || health.IsInvincible)
            {
                m_TrappedPlayer.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeRotation;
                Destroy();
            }
        }
    }

    void OnTriggerStay(Collider other)
    {
        if(IsPlaced)
        {
            if(m_TrappedPlayer == null)
            {
                if (!m_AudioSource.isPlaying)
                {
                    m_AudioSource.clip = IdleClip;
                    m_AudioSource.loop = true;
                    m_AudioSource.Play();
                }

                AudioUtils.SetVolumeByDistance(gameObject, true);

                Player player = null;

                if (other.GetComponent<PlayerHitboxScript>() != null)
                    player = other.GetComponent<PlayerHitboxScript>().Owner;

                if (player != null && player != Owner)
                {
                    if(player.TeamIndex != Owner.TeamIndex)
                    {
                        //TODO: Change this to raycast to Quark and check if he has LOS instead of just playing it whenever someone gets trapped
                        DialogueManager.Instance.PlayDialogue(CharacterTypes.Quark, DialogueContext.QuarkSeeTrapTriggered, false, true);

                        AchievementsManager.IncrementInteger(player, Achievements.TimesTrapped, 1);
                        m_AudioSource.clip = DamageClip;
                        m_AudioSource.loop = true;
                        m_AudioSource.volume = 1;
                        m_AudioSource.Play();
                        m_TrappedPlayer = player;
                        m_TrappedPlayer.GetComponent<Health>().Damage(Owner, gameObject, TrapDamage);
                        m_TrappedPlayer.AbilityBlockingMovement = true;
                        m_TrappedPlayer.CanUseMovementAbility = false;
                        m_Health.IsInvincible = true;
                        m_TrapTriggered = true;
                        m_TrappedPlayer.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeAll;
                        m_TrappedPlayer.transform.position = transform.position;
                        if (LightningSpawner.activeInHierarchy == false)
                        {
                            LightningSpawner.SetActive(true);
                        }
                    }
                }
            }
            else
            {
                m_TrappedPlayer.AbilityBlockingMovement = true;
                m_TrappedPlayer.CanUseMovementAbility = false;
            }
        }
        else
        {
            if (other.isTrigger == false)
            {
                IsUnobstructed = false;
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.isTrigger == false)
        {
            IsUnobstructed = true;
        }
    }

    public void Destroy()
    {
        if (m_AudioSource.isPlaying)
            m_AudioSource.Stop();
        if(m_TrappedPlayer != null)
        {
            m_TrappedPlayer.AbilityBlockingMovement = false;
            m_TrappedPlayer.CanUseMovementAbility = true;
        }
        GameObject.Destroy(gameObject);
    }
}
