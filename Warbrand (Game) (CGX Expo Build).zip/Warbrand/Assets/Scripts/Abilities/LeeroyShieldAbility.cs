﻿using UnityEngine;
using System.Collections;
using System;

public class LeeroyShieldAbility : Ability
{

    //
    //Public
    //
    public float BlockAnimationSpeedModifier = 8.0f;
    public bool CurrentlyBlocking;

    //
    //Private
    //
    private Vector3 m_InitialScale;
    private Vector3 m_InitialPosition;
    private Quaternion m_InitialRotation;
    private BoxCollider[] m_BoxColliders;
    private Vector3 m_BlockingPosition;
    private Vector3 m_BlockingScale = new Vector3(1.5f, 1.5f, 1.5f);
    private Quaternion m_BlockingRotation = Quaternion.Euler(new Vector3(0, 0, -90));

    private const string m_ShieldActiveString = "ShieldActive";
    private int m_ShieldActiveHash = Animator.StringToHash(m_ShieldActiveString);

    GameObject m_Shield = null;

    public LeeroyShieldAbility(InputName aKey)
    {
        Key = aKey;
    }

    public override void SetOwner(Player owner)
    {
        Owner = owner;
        m_Shield = (Owner as Leeroy).Shield;
        m_BoxColliders = m_Shield.GetComponentsInChildren<BoxCollider>();
        m_InitialScale = m_Shield.transform.localScale;
        m_InitialPosition = m_Shield.transform.localPosition;
        m_InitialRotation = m_Shield.transform.localRotation;

        m_BlockingPosition = m_Shield.transform.InverseTransformPoint(m_Shield.transform.TransformPoint(m_InitialPosition) + Vector3.up * 0.04f);

        CurrentlyBlocking = false;

        HasAnimationTime = true;
        AnimatorString = m_ShieldActiveString;
    }
    public override void OnStartAbility()
    {
        // Input and state change
        if (CurrentlyBlocking == false)
        {
            Owner.PlayerAnimator.SetBool(m_ShieldActiveHash, true);
            CurrentlyBlocking = true;
        }
    }

    public override void OnContinueAbility()
    {

    }

    public override void OnEndAbility()
    {
        Owner.PlayerAnimator.SetBool(m_ShieldActiveHash, false);
        CurrentlyBlocking = false;
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        if (CurrentlyBlocking)
        {
            for (int i = 0; i < m_BoxColliders.Length; i++)
            {
                m_BoxColliders[i].enabled = true;
            }
            m_Shield.transform.localPosition = Vector3.Lerp(m_Shield.transform.localPosition, m_BlockingPosition, aFixedDelta * 15);
            m_Shield.transform.localScale = Vector3.Lerp(m_Shield.transform.localScale, m_BlockingScale, aFixedDelta * 15);
            m_Shield.transform.localRotation = Quaternion.Slerp(m_Shield.transform.localRotation, m_BlockingRotation, aFixedDelta * 15);

        }
        else
        {
            for (int i = 0; i < m_BoxColliders.Length; i++)
            {
                m_BoxColliders[i].enabled = false;
            }
            m_Shield.transform.localPosition = Vector3.Lerp(m_Shield.transform.localPosition, m_InitialPosition, aFixedDelta * 15);
            m_Shield.transform.localScale = Vector3.Lerp(m_Shield.transform.localScale, m_InitialScale, aFixedDelta * 15);
            m_Shield.transform.localRotation = Quaternion.Slerp(m_Shield.transform.localRotation, m_InitialRotation, aFixedDelta * 15);
        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
    }

    public override bool CanUseAbility()
    {
        return !CurrentlyBlocking;
    }
}
