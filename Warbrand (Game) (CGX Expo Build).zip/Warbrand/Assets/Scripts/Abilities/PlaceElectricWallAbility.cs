/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        PlaceWallAbility                                                               *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 29th, 2016                                                             *
 *                                                                                                 *
 * This script is an ability that is to be added to Quark. This script allows Quark to place his   *
 * Wall. The Wall must be on the ground and can't be colliding with any other objects. If a        *
 * new Wall is placed, his old one gets destroyed.                                                 *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 29th, 2016                                          *
\***************************************************************************************************/

using System;
using UnityEngine;

public class PlaceElectricWallAbility : Ability
{
    //
    // Public
    //
    public float PlacementCooldown = 5.0f;
    public float PlacementRange = 3.0f;

    //
    //Private
    //
    float m_PlacementTimer;
    GameObject m_OldWall;
    GameObject m_NewWall;
    GameObject m_WallPrefab;

    Quaternion m_WallRotation;
    Vector3 m_WallOffset;

    bool PlacingWall;

    private const string m_ElectricWallResource = "Prefabs/Electric Wall";

    public PlaceElectricWallAbility(InputName aKey)
    {
        Key = aKey;
        m_WallPrefab = Resources.Load(m_ElectricWallResource) as GameObject;
        m_PlacementTimer = 0;
    }

    public override void OnStartAbility ()
    {
        if(PlacingWall == false && m_PlacementTimer <= 0 && Owner.GetComponent<Quark>().PlacingObject == false)
        {
            PlacingWall = true;
            Owner.GetComponent<Quark>().PlacingObject = true;
            if (Owner != null && GameInput == null)
                GameInput = Owner.GameInput;

            m_WallRotation = Owner.PlayerCamera.transform.rotation;
            m_WallRotation.x = 0;
            m_WallRotation.z = 0;

            //Make sure the Wall doesn't get placed under the ground
            m_WallOffset = Owner.PlayerCamera.transform.forward * PlacementRange;
            m_WallOffset.y = 0;

            m_NewWall = GameObject.Instantiate(m_WallPrefab, Owner.PlayerCamera.transform.position + m_WallOffset, m_WallRotation) as GameObject;
            m_NewWall.GetComponent<ElectricWallScript>().Owner = Owner;
            m_NewWall.GetComponent<Rigidbody>().detectCollisions = true;
            m_NewWall.GetComponent<BoxCollider>().isTrigger = true;
        }
    }

	public override void OnContinueAbility ()
	{
        
    }

    public override void OnEndAbility()
    {

    }

    public override void UpdateAbility(float aFixedDelta)
    {
        m_PlacementTimer -= aFixedDelta;

        //only do this if the player is trying to place a Wall
        if(PlacingWall == true)
        {
            m_WallRotation = Owner.PlayerCamera.transform.rotation;
            m_WallRotation.x = 0;
            m_WallRotation.z = 0;

            m_WallOffset = Owner.PlayerCamera.transform.forward * PlacementRange;

            m_NewWall.transform.rotation = m_WallRotation;
            m_NewWall.transform.position = Owner.PlayerCamera.transform.position + m_WallOffset;

            RaycastHit hitInfo;
            //Make sure the player is trying to place the Wall on the ground. Snap the Wall to the ground if it is
            if (Physics.Linecast(m_NewWall.transform.position, m_NewWall.transform.position - m_NewWall.transform.up * PlacementRange, out hitInfo))
            {

                m_NewWall.transform.position = hitInfo.point;
                //m_Wall.transform.up -= (m_Wall.transform.up - hitInfo.normal) * .1f;
                m_NewWall.GetComponent<BuildElectricWall>().IsOnGround = true;
            }
            else
            {
                m_NewWall.transform.position = Owner.PlayerCamera.transform.position + m_WallOffset - Owner.PlayerCamera.transform.up;
                m_NewWall.GetComponent<BuildElectricWall>().IsOnGround = false;
            }

            //Place the Wall if the player left-clicks in a valid location
            if ((GameInput.GetInput(InputName.Attack1, InputType.ButtonPressed) != 0.0f ||
                GameInput.GetInput(InputName.Attack1, InputType.ButtonHeld) != 0.0f) &&
                m_NewWall.GetComponent<BuildElectricWall>().IsInValidPlacementLocation == true)
            {
                PlaceWall();
            }
            //If the player pushes another ability button or his secondary attack button, cancel the Wall placement
            else if (GameInput.GetInput(InputName.Ability1, InputType.ButtonPressed) != 0.0f ||
                    GameInput.GetInput(InputName.Ability1, InputType.ButtonHeld) != 0.0f ||
                    GameInput.GetInput(InputName.Ability3, InputType.ButtonPressed) != 0.0f ||
                    GameInput.GetInput(InputName.Ability3, InputType.ButtonHeld) != 0.0f ||
                    GameInput.GetInput(InputName.Attack2, InputType.ButtonPressed) != 0.0f ||
                    GameInput.GetInput(InputName.Attack2, InputType.ButtonHeld) != 0.0f ||
                    GameInput.GetInput(InputName.TauntHorizontal, InputType.ButtonPressed) != 0.0f ||
                    GameInput.GetInput(InputName.TauntHorizontal, InputType.ButtonHeld) != 0.0f ||
                    GameInput.GetInput(InputName.TauntVertical, InputType.ButtonPressed) != 0.0f ||
                    GameInput.GetInput(InputName.TauntVertical, InputType.ButtonHeld) != 0.0f)
            {
                m_NewWall.GetComponent<ElectricWallScript>().Destroy();
                PlacingWall = false;
                Owner.GetComponent<Quark>().PlacingObject = false;
            }
        }

        //Do UI stuff
        Owner.AbilityUICooldowns.Ability2Info.UseCooldown = m_PlacementTimer / PlacementCooldown;
        if(PlacingWall == false && m_PlacementTimer <= 0)
        {
            Owner.AbilityUICooldowns.Ability2Info.Usable = true;
        }
        else
        {
            Owner.AbilityUICooldowns.Ability2Info.Usable = false;
        }
    }

    public void PlaceWall()
    {
        //player left-clicked to place Wall, or pressed a different ability button to cancel the placement
        if (m_NewWall != null)
        {
            m_PlacementTimer = PlacementCooldown;
            if (m_OldWall != null)
            {
                m_OldWall.GetComponent<ElectricWallScript>().Destroy();
            }

            m_NewWall.GetComponent<Rigidbody>().detectCollisions = true;
            m_NewWall.GetComponent<BuildElectricWall>().IsPlaced = true;
            m_OldWall = m_NewWall;
            m_NewWall = null;
        }

        PlacingWall = false;
        Owner.GetComponent<Quark>().PlacingObject = false;
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_PlacementTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (PlacingWall == false && m_PlacementTimer <= 0)
            return true;
        return false;
    }
}