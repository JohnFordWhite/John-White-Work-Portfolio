/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        GauntletJumpAbility                                                            *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            October 13th, 2016                                                             *
 *                                                                                                 *
 * Ability that allows the player to jump in the direction they're looking, if using a first       *
 * person camera. If using a 3rd person camera, allows for a high jump in the forward direction.   *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - October 13th, 2016                                          *
 * V 1.1 - Changelog (Author) - Date                                                               *
\***************************************************************************************************/

using System;
using UnityEngine;

public class GauntletJumpAbility : Ability
{
    //
    //Public
    //
    public float GauntletJumpCooldown = 4.5f;

    //
    //Private
    //
    private Rigidbody m_RigidBody;
    private BasicMovementScript m_MovementScript;
    private FirstPersonCamera m_FirstPersonCamera;
    private Vector3 m_GauntletJumpYMask = new Vector3(0,2,0);
    private Vector3 m_PlayerForwardDir = Vector3.zero;
    private Vector3 m_LookDirection = Vector3.zero;
    private float m_GauntletForwardMask = 2f;
    private float m_ForceMultiplier = 60f;
    private float m_MinimumJumpHeight = 7f;
    private float m_GauntletJumpTimer;
    private const string m_GauntletJumpString = "GauntletJump";

    public GauntletJumpAbility(InputName aKey)
    {
        Key = aKey;
        m_GauntletJumpTimer = 0;
        AnimatorString = m_GauntletJumpString;
    }

    public override void OnStartAbility ()
	{
        if (!Owner.CanUseMovementAbility)
            return;

        if (m_GauntletJumpTimer <= 0)
        {
            bool chance = UnityEngine.Random.value < 0.1;
            if (chance)
            {
                Debug.Log("sound played");
                DialogueManager.Instance.PlayDialogue(CharacterTypes.Leeroy, DialogueContext.LeeroyPounce, false, true);
            }

            m_RigidBody = Owner.GetComponent<Rigidbody>();
            m_MovementScript = Owner.GetComponent<BasicMovementScript>();
            m_FirstPersonCamera = Owner.GetComponentInChildren<FirstPersonCamera>();
            m_MovementScript.enabled = false;
            m_RigidBody.useGravity = true;

            //Get forward direction of player and multiply it for direction of the jump
            m_PlayerForwardDir = Owner.transform.forward;
            m_PlayerForwardDir *= m_GauntletForwardMask;

            //Get look direction of player camera
            if (m_FirstPersonCamera != null)
            {
                m_LookDirection = m_FirstPersonCamera.transform.forward;
            }
            else
            {
                m_LookDirection = Owner.transform.forward;
            }

            //Set force to the forward direction + the look direction + a Y height mask, normalize for direction of movement, then multiply
            Vector3 force = m_LookDirection * 3 + m_GauntletJumpYMask;
            force = Vector3.Normalize(force);
            force *= m_ForceMultiplier;

            //Safety check to make sure we jump up no matter what, so the movement script gets enabled
            if (m_FirstPersonCamera != null)
            {
                if (m_FirstPersonCamera.transform.eulerAngles.x < 90 && m_FirstPersonCamera.transform.eulerAngles.x > 30)
                    force.y = m_MinimumJumpHeight;
            }

            BasicMovementScript movement = Owner.GetComponent<BasicMovementScript>();

            if (movement != null)
                movement.AffectedByOutsideForce();

            Owner.AudioSourceMovement.Play();

            //Zero velocities and apply force
            m_RigidBody.velocity = Vector3.zero;
            m_RigidBody.angularVelocity = Vector3.zero;
            m_RigidBody.AddForce(force, ForceMode.Impulse);

            m_GauntletJumpTimer = GauntletJumpCooldown;
        }
    }

	public override void OnContinueAbility ()
	{
        //Once in the air, enable the movement script
        m_MovementScript.CheckGround();
        if (!m_MovementScript.IsGrounded)
        {
            m_MovementScript.enabled = true;
            return;
        }
    }

	public override void OnEndAbility ()
	{
        m_MovementScript = Owner.GetComponent<BasicMovementScript>();

        //Once in the air, enable the movement script
        m_MovementScript.CheckGround();
        if (!m_MovementScript.IsGrounded)
        {
            m_MovementScript.enabled = true;
            return;
        }
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        m_GauntletJumpTimer -= aFixedDelta;

        //Do UI stuff
        if (Owner.IsAI)
            return;

        Owner.AbilityUICooldowns.MovementAbilityInfo.UseCooldown = m_GauntletJumpTimer / GauntletJumpCooldown;
        if (m_GauntletJumpTimer > 0f)
        {
            Owner.AbilityUICooldowns.MovementAbilityInfo.Usable = false;
        }
        else
        {
            Owner.AbilityUICooldowns.MovementAbilityInfo.Usable = Owner.CanUseMovementAbility;
        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_GauntletJumpTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_GauntletJumpTimer > 0f)
            return false;
        return Owner.CanUseMovementAbility;
    }
}