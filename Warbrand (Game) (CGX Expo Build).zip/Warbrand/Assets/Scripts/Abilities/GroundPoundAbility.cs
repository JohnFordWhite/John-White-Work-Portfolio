/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        GroundPoundAbility                                                             *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            December 8th, 2016                                                             *
 *                                                                                                 *
 * Ability that allows a character to quickly drop down. Once close contact with anything in a     *
 * level is registered, an AOE damage will be applied around the character that dropped.           *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - December 8th, 2016                                          *
 * V 1.1 - Changelog (Author) - Date                                                               *
\***************************************************************************************************/

using System;
using UnityEngine;
using System.Collections.Generic;

public class GroundPoundAbility : Ability
{
    //
    // Public
    //
    public float GroundPoundCooldown = 12f;

    //
    //Private
    //
    private Rigidbody m_Rigidbody = null;
    // private BasicMovementScript m_MovementScript = null;

    private const string m_WallsMask = "Walls";
    private const string m_FloorMask = "Floor";

    private const string m_GroundPoundEffectResource = "Particle Effects/Prefabs/GroundPoundEffect";

    private LayerMask LevelBoundsLayerMask = (1 << LayerMask.NameToLayer(m_WallsMask) | 1 << LayerMask.NameToLayer(m_FloorMask));
    private float m_Force = 125f;
    private float m_GroundPoundTimer = 0;
    private float m_GroundPoundDamage = 34f;
    private float m_GroundPoundDamageRadius = 13f;
    private float m_MinimumEffectPercentage = 0.3f;
    private bool m_TooCloseToGround = false;
    private Vector3 m_RaycastOffset;
    private int m_LayerMask;
    private List<Player> m_PlayersHit = null;

    private GameObject m_GroundPoundEffectPrefab;
    private GameObject m_GroundPoundEffect;

    public GroundPoundAbility(InputName aKey)
    {
        Key = aKey;
        IsContinuousAbility = true;
        AbilityBlocksMovement = true;
        AbilityBlocksRotation = true;
        AbilityBlocksOtherAbilities = true;

        m_RaycastOffset = new Vector3(0, 0.2f, 0);

        GameObject InstancedObjectContainer = InputManager.CM.GetInstancedObjectContainer();

        m_GroundPoundEffectPrefab = Resources.Load(m_GroundPoundEffectResource) as GameObject;
        m_GroundPoundEffect = MonoBehaviour.Instantiate(m_GroundPoundEffectPrefab);
        GameObject.DontDestroyOnLoad(m_GroundPoundEffect);

        m_PlayersHit = new List<Player>();
        m_PlayersHit.Capacity = Information.AllPlayers.Count;
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }

        m_GroundPoundEffect.transform.SetParent(InstancedObjectContainer.transform);

        HasAnimationTime = true;
        AnimatorString = "GroundPound";
    }

    public override void OnStartAbility ()
	{
        if (m_GroundPoundTimer <= 0 && !m_TooCloseToGround)
        {
            BlockInput();

            if (m_Rigidbody == null)
                m_Rigidbody = Owner.GetComponent<Rigidbody>();

            Owner.AudioSourceAbility3.Play();

            ContinuousAbilityStarted = true;
            ContinuousAbilityInUse = true;

            m_Rigidbody.AddForce(Vector3.down * m_Force, ForceMode.Impulse);

            m_GroundPoundTimer = GroundPoundCooldown;
        }
	}

    public override void SetOwner(Player owner)
    {
        Owner = owner;
        m_LayerMask = ~((1 << LayerMask.NameToLayer("UnplacedObjects")) |
                        (1 << LayerMask.NameToLayer("WallCollider")) |
                        (1 << LayerMask.NameToLayer("Ignore Raycast")) |
                        (1 << Owner.gameObject.layer));
    }

	public override void OnContinueAbility ()
	{
        if(Owner.GetComponent<Health>().IsDead)
        {
            ContinuousAbilityStarted = false;
            UnblockInput();
            OnEndAbility();
        }

        if(Physics.Raycast(Owner.transform.position + m_RaycastOffset,-Owner.transform.up, 1.0f, m_LayerMask,QueryTriggerInteraction.Ignore))
        {
            Owner.AudioSourceAbility3.PlayOneShot(Owner.GetComponent<Paige>().GroundPoundEndClip);
            
            m_Rigidbody.velocity /= 2;
            AbilityBlocksMovement = true;
            AbilityBlocksRotation = true;
            AbilityBlocksOtherAbilities = true;
            ContinuousAbilityInUse = false;
        }
	}

	public override void OnEndAbility ()
	{
        if(ContinuousAbilityStarted)
        {
            Collider[] hitColliders = Physics.OverlapSphere(Owner.transform.position, m_GroundPoundDamageRadius, m_LayerMask, QueryTriggerInteraction.Collide);
            for (int i = 0; i < hitColliders.Length; i++)
            {
                Collider collider = hitColliders[i];

                Player player = null;
                if (collider.GetComponent<PlayerHitboxScript>() != null)
                    player = collider.GetComponent<PlayerHitboxScript>().Owner;

                Health colliderHealth = null;


                if(player != null && player != Owner)
                {
                    if(!m_PlayersHit.Contains(player))
                    {
                        colliderHealth = player.GetComponent<Health>();
                        m_PlayersHit.Add(player);
                    }
                    else if(player.GetComponent<Health>().IsDead && collider.GetComponent<PlayerHitboxScript>() != null)
                    {
                        ApplyPhysics(collider);
                    }
                }
                else
                {
                    colliderHealth = collider.GetComponent<Health>();
                }

                if (colliderHealth != null)
                {
                    if (collider.gameObject != Owner.gameObject)
                    {
                        float proximity = (Owner.transform.position - collider.transform.position).magnitude;
                        float effectPercentage = 1 - (proximity / m_GroundPoundDamageRadius);

                        //Debug.Log(m_GroundPoundDamage * effect);
                        //Debug.Log(effect);

                        if (effectPercentage < m_MinimumEffectPercentage)
                            effectPercentage = m_MinimumEffectPercentage;


                        if(colliderHealth.Damage(Owner, Owner.gameObject, m_GroundPoundDamage * effectPercentage, DeathType.Physics) && collider.GetComponent<PlayerHitboxScript>() != null)
                        {
                            ApplyPhysics(collider);
                        }
                    }
                }
            }

            UnblockInput();
            m_GroundPoundEffect.transform.position = Owner.transform.position;

            ParticleSystem[] particles = m_GroundPoundEffect.GetComponentsInChildren<ParticleSystem>();
            for (int i = 0; i < particles.Length; i++)
            {
                ParticleSystem part = particles[i];

                part.Play();
            }
        }

        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }

        ContinuousAbilityStarted = false;

    }

    public const float MinimumHeight = 5f;
    public override void UpdateAbility(float aFixedDelta)
    {
        RaycastHit temphit;
        if (Physics.Raycast(Owner.transform.position + m_RaycastOffset, Vector3.down, out temphit, MinimumHeight, LevelBoundsLayerMask, QueryTriggerInteraction.Ignore))
        {
            m_TooCloseToGround = true;
        }
        else
        {
            m_TooCloseToGround = false;
        }

        m_GroundPoundTimer -= aFixedDelta;

        //Do UI stuff
        if (Owner.IsAI)
            return;

        Owner.AbilityUICooldowns.Ability3Info.UseCooldown = m_GroundPoundTimer / GroundPoundCooldown;
        Owner.AbilityUICooldowns.Ability3Info.Usable = CanUseAbility();
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_GroundPoundTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_GroundPoundTimer <= 0 && !ContinuousAbilityStarted && !m_TooCloseToGround)
            return true;
        return false;
    }

    public bool CanAIUseAbility()
    {
        if (m_GroundPoundTimer <= 0 && !ContinuousAbilityStarted)
            return true;
        return false;
    }

    void ApplyPhysics(Collider collider)
    {
        Vector3 direction = collider.transform.position - Owner.transform.position;
        direction = direction.normalized;
        float forceAmount = 25;
        float forcePerDistance = forceAmount / m_GroundPoundDamageRadius;
        float distanceFromExplosion = Vector3.Distance(collider.gameObject.transform.position, Owner.transform.position);
        float forceToApply = forceAmount - (distanceFromExplosion * forcePerDistance);
        collider.GetComponent<PlayerHitboxScript>().AddForce(direction * forceToApply, collider.transform.position);
    }
}