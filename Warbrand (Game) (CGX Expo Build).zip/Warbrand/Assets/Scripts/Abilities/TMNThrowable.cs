﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        TMNThrowable                                                                   *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            October 27th,2016                                                              *
 *                                                                                                 *
 * Spawns the TMN Adhesive prefab, which handles the ability                                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - October 27th,2016                                           *
 * V 1.1 - Changelog (Author) - Date                                                               *
\***************************************************************************************************/

using UnityEngine;
using System.Collections.Generic;
using System;

public class TMNThrowable : Ability
{
    //
    // Public
    //
    public bool IsOnGround = false;
    public float TMNCooldown = 10f;


    //
    // Private
    //
    private BoxCollider m_BoxCollider;
    private Rigidbody m_Rigidbody;
    //private List<Player> m_PlayersAffected = new List<Player>();
    //private Dictionary<Player, float> m_InitialPlayerSpeeds = new Dictionary<Player, float>();
    private GameObject m_TMNObj;
    private GameObject m_SplatterPrefab;
    private float m_ThrowForce = 20f;
    //private float m_AbilityTimer = 10f;
    private float m_TMNAbilityTimer;

    private const string m_PoolManagerTransform = "PoolManager";

    public TMNThrowable(InputName aKey, GameObject aSplatterPrefab)
    {
        Key = aKey;
        m_TMNAbilityTimer = 0;
        m_SplatterPrefab = aSplatterPrefab;

        HasAnimationTime = true;
        AnimatorString = "TMNThrowable";
    }

    public override void OnStartAbility()
    {
        //Debug.Log("In Start Ability");
        if (m_TMNAbilityTimer <= 0)
        {
            m_TMNObj.GetComponent<TMNThrowableFunctionality>().Reset();

            m_TMNObj.transform.position = Owner.PlayerCamera.transform.position + Owner.PlayerCamera.transform.forward;
            m_TMNObj.GetComponent<Rigidbody>().AddForce(Owner.PlayerCamera.transform.forward * m_ThrowForce, ForceMode.Impulse);
            Owner.AudioSourceAbility1.Play();

            m_TMNAbilityTimer = TMNCooldown;
        }
    }

    public override void SetOwner(Player owner)
    {
        base.SetOwner(owner);

        m_TMNObj = GameObject.Instantiate(Owner.GetComponent<Paige>().TMNAdhesivePrefab, Vector3.zero, Quaternion.identity) as GameObject;
        m_TMNObj.GetComponent<TMNThrowableFunctionality>().SplatterPrefab = m_SplatterPrefab;
        m_TMNObj.GetComponent<TMNThrowableFunctionality>().SetOwner(owner);
        GameObject.DontDestroyOnLoad(m_TMNObj);
        m_TMNObj.transform.parent = GameObject.Find(m_PoolManagerTransform).transform;
    }

    public override void OnContinueAbility()
    {

    }

    public override void OnEndAbility()
    {
        
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        m_TMNAbilityTimer -= Time.fixedDeltaTime;

        if (Owner.IsAI)
            return;

        //Do UI stuff
        Owner.AbilityUICooldowns.Ability1Info.UseCooldown = m_TMNAbilityTimer / TMNCooldown;
        if (m_TMNAbilityTimer <= 0.0f)
        {
            Owner.AbilityUICooldowns.Ability1Info.Usable = true;
        }
        else
        {
            Owner.AbilityUICooldowns.Ability1Info.Usable = false;
        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_TMNAbilityTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_TMNAbilityTimer <= 0.0f)
            return true;
        return false;
    }
}
