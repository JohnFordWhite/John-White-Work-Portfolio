﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Ability                                                                        *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            September 28th, 2016                                                           *
 *                                                                                                 *
 * This is an abstract class, used to create and store different abilities.                        *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - September 28th, 2016                                    *
 * V 1.1 - Added members for continuous abilities (Jon Roffey) - October 21st, 2016                *
\***************************************************************************************************/

public abstract class Ability
{
    public bool IsToggle = false;
    public bool Toggled = false;
    public bool IsContinuousAbility = false;
    public bool ContinuousAbilityInUse = false;
    public bool ContinuousAbilityStarted = false;
    public Player Owner = null;
    public GameInputComponent GameInput = null;
    public InputName Key;

    public bool AbilityBlocksMovement = false;
    public bool AbilityBlocksRotation = false;
    public bool AbilityBlocksOtherAbilities = false;
    public bool ActivateOnStartPointReached = false;
    public bool HasAnimationTime = false;

    public string AnimatorString;

    public abstract void OnStartAbility();
    public abstract void OnContinueAbility();
    public abstract void OnEndAbility();

    public virtual void SetOwner(Player owner)
    {
        Owner = owner;
    }

    public abstract void UpdateAbility(float aFixedDelta);

    public abstract bool CanUseAbility();

    public abstract void ResetAbility();

    // This ability blocks specific inputs when activated.
    public void BlockInput()
    {
        if (Owner != null)
        {
            if (AbilityBlocksMovement)
                Owner.AbilityBlockingMovement = true;
            if (AbilityBlocksRotation)
                Owner.AbilityBlockingRotation = true;
            if (AbilityBlocksOtherAbilities)
                if (Owner.BlockingAbility == null)
                    Owner.BlockingAbility = this;
        }
    }

    // Unblock any blocked inputs.
    public void UnblockInput()
    {
        if (Owner != null)
        {
            // Need to check if we don't block specific inputs, because other abilities might block as well.
            if (AbilityBlocksMovement)
                Owner.AbilityBlockingMovement = false;
            if (AbilityBlocksRotation)
                Owner.AbilityBlockingRotation = false;
            if (AbilityBlocksOtherAbilities)
                if (Owner.BlockingAbility == this)
                    Owner.BlockingAbility = null;
        }
    }

    public void SetBlockedInputs(bool aBlockMovement, bool aBlockRotation, bool aBlockAbility)
    {
        AbilityBlocksMovement = aBlockMovement;
        AbilityBlocksRotation = aBlockRotation;
        AbilityBlocksOtherAbilities = aBlockAbility;
    }
}
