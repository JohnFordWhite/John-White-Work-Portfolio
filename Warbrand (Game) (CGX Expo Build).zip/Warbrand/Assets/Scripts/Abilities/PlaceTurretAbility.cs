/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        PlaceTurretAbility                                                             *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 24th, 2016                                                             *
 *                                                                                                 *
 * This script is an ability that is to be added to Quark. This script allows Quark to place his   *
 * turret. The turret must be on the ground and can't be colliding with any other objects. If a    *
 * new turret is placed, his old one gets destroyed.                                               *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 24th, 2016                                          *
\***************************************************************************************************/

using System;
using UnityEngine;

public class PlaceTurretAbility : Ability
{
    //
    // Public
    //
    public float PlacementCooldown = 5.0f;
    public float PlacementRange = 3.0f;
    public float GroundCheckRange = 2.0f;

    //
    //Private
    //
    private float m_PlacementTimer;
    private float m_ChanceToPlayDialogue = 0.1f;

    private GameObject m_NewTurret;
    private GameObject m_Turret1;
    private GameObject m_Turret2;
    private GameObject m_TurretPrefab;

    private Vector3 m_TurretRotation;
    private Vector3 m_TurretOffset;

    private int m_LayerMask;

    public bool PlacingTurret;

    private const string m_TurretResource = "Prefabs/Turret";

    private const string m_UnplacedObjectsMask = "UnplacedObjects";
    private const string m_QuarkCameraMask = "QuarkCamera";
    private const string m_IgnoreRaycastMask = "Ignore Raycast";
    private const string m_RagdollMask = "Ragdoll";
    private const string m_PropsMask = "Props";
    private const string m_QuarkTurretMask = "QuarkTurret";
    private const string m_Player1ModelMask = "Player1Model";
    private const string m_Player2ModelMask = "Player2Model";
    private const string m_Player3ModelMask = "Player3Model";
    private const string m_Player4ModelMask = "Player4Model";
    private const string m_Player5ModelMask = "Player5Model";
    private const string m_Player6ModelMask = "Player6Model";
    private const string m_Player7ModelMask = "Player7Model";
    private const string m_Player8ModelMask = "Player8Model";

    public PlaceTurretAbility(InputName aKey)
    {
        Key = aKey;
        m_TurretPrefab = Resources.Load(m_TurretResource) as GameObject;
        m_PlacementTimer = 0;

        GameObject InstancedObjectContainer = InputManager.CM.GetInstancedObjectContainer();

        m_NewTurret = GameObject.Instantiate(m_TurretPrefab, Vector3.zero, Quaternion.identity) as GameObject;
        m_Turret1 = GameObject.Instantiate(m_TurretPrefab, Vector3.zero, Quaternion.identity) as GameObject;
        m_Turret2 = GameObject.Instantiate(m_TurretPrefab, Vector3.zero, Quaternion.identity) as GameObject;

        m_NewTurret.GetComponent<BoxCollider>().isTrigger = true;
        m_Turret1.GetComponent<BoxCollider>().isTrigger = false;
        m_Turret2.GetComponent<BoxCollider>().isTrigger = false;

        GameObject.DontDestroyOnLoad(m_NewTurret);
        GameObject.DontDestroyOnLoad(m_Turret1);
        GameObject.DontDestroyOnLoad(m_Turret2);

        m_NewTurret.transform.SetParent(InstancedObjectContainer.transform);
        m_Turret1.transform.SetParent(InstancedObjectContainer.transform);
        m_Turret2.transform.SetParent(InstancedObjectContainer.transform);

        HasAnimationTime = true;
        AnimatorString = "PlaceTurret";
    }

    public override void SetOwner(Player owner)
    {
        Owner = owner;
        if (!(Owner.IsAI))
        {
            Owner.AbilityUICooldowns.Ability1Info.HasCharges = true;
            Owner.AbilityUICooldowns.Ability1Info.ChargeCooldown = 1;
            Owner.AbilityUICooldowns.Ability1Info.MaxCharges = 2;
        }

        m_NewTurret.GetComponent<TurretScript>().SetOwner(Owner);
        m_Turret1.GetComponent<TurretScript>().SetOwner(Owner);
        m_Turret2.GetComponent<TurretScript>().SetOwner(Owner);

        m_NewTurret.GetComponent<BuildTurret>().SetOwner(Owner);
        m_Turret1.GetComponent<BuildTurret>().SetOwner(Owner);
        m_Turret2.GetComponent<BuildTurret>().SetOwner(Owner);


        m_LayerMask = ~((1 << LayerMask.NameToLayer(m_UnplacedObjectsMask)) |
                (1 << LayerMask.NameToLayer(m_QuarkCameraMask)) |
                (1 << LayerMask.NameToLayer(m_IgnoreRaycastMask)) |
                (1 << LayerMask.NameToLayer(m_RagdollMask)) |
                (1 << LayerMask.NameToLayer(m_PropsMask)) |
                (1 << LayerMask.NameToLayer("WallCollider")) |
                (1 << LayerMask.NameToLayer(m_QuarkTurretMask)) |
                (1 << LayerMask.NameToLayer(m_Player1ModelMask)) |
                (1 << LayerMask.NameToLayer(m_Player2ModelMask)) |
                (1 << LayerMask.NameToLayer(m_Player3ModelMask)) |
                (1 << LayerMask.NameToLayer(m_Player4ModelMask)) |
                (1 << LayerMask.NameToLayer(m_Player5ModelMask)) |
                (1 << LayerMask.NameToLayer(m_Player6ModelMask)) |
                (1 << LayerMask.NameToLayer(m_Player7ModelMask)) |
                (1 << LayerMask.NameToLayer(m_Player8ModelMask)));
    }

    public override void OnStartAbility ()
    {
        if(PlacingTurret == false && m_PlacementTimer <= 0 && Owner.GetComponent<Quark>().PlacingObject == false)
        {
            PlacingTurret = true;
            Owner.GetComponent<Quark>().PlacingObject = true;
            if (Owner != null && GameInput == null)
                GameInput = Owner.GameInput;
        }
    }

	public override void OnContinueAbility ()
	{
        
    }

    public override void OnEndAbility()
    {
        //TODO: figure out why this gets called when it shouldn't
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        m_PlacementTimer -= aFixedDelta;

        int turretsPlaced = 0;
        if (m_Turret1.activeInHierarchy == true)
            turretsPlaced++;
        if (m_Turret2.activeInHierarchy == true)
            turretsPlaced++;

        if (Owner.IsAI == false)
            Owner.AbilityUICooldowns.Ability1Info.ChargesLeft = turretsPlaced;

        //only do this if the player is trying to place a turret
        if (PlacingTurret == true)
        {
            m_TurretRotation = Vector3.up * 90;

            m_TurretOffset = Owner.PlayerCamera.transform.forward * PlacementRange;

            m_NewTurret.transform.position = Owner.PlayerCamera.transform.position + m_TurretOffset;

            if(m_NewTurret.activeInHierarchy == false)
            {
                m_NewTurret.SetActive(true);
                m_NewTurret.GetComponent<BuildTurret>().Reset();
            }

            RaycastHit hitInfo;
            //Make sure the player is trying to place the turret on the ground. Snap the turret to the ground if it is
            if (Physics.Linecast(m_NewTurret.transform.position, m_NewTurret.transform.position - Vector3.up * GroundCheckRange, out hitInfo, m_LayerMask, QueryTriggerInteraction.Ignore))
            {
                Vector3 newRotation = Vector3.zero;
                Vector3 normalizedX = hitInfo.normal;
                normalizedX.z = 0;
                normalizedX.Normalize();

                newRotation.x = Vector3.Angle(normalizedX, Vector3.up) * Math.Sign(normalizedX.x);


                newRotation.y = 90;

                Vector3 normalizedZ = hitInfo.normal;
                normalizedZ.x = 0;
                normalizedZ.Normalize();

                newRotation.z = Vector3.Angle(normalizedZ, Vector3.up) * Math.Sign(normalizedZ.z);

                m_NewTurret.transform.localEulerAngles = newRotation;

                m_NewTurret.transform.position = hitInfo.point + m_NewTurret.transform.up * 0.01f;

                m_NewTurret.transform.RotateAround(m_NewTurret.transform.up, (Owner.PlayerCamera.transform.eulerAngles.y - m_NewTurret.transform.eulerAngles.y) * 0.0174533f);

                m_NewTurret.GetComponent<BuildTurret>().IsOnGround = true;
            }
            else
            {

                //m_NewTurret.transform.eulerAngles = Vector3.up;
                m_NewTurret.transform.position = Owner.PlayerCamera.transform.position + m_TurretOffset;
                m_NewTurret.transform.rotation = Owner.transform.rotation;
                m_NewTurret.GetComponent<BuildTurret>().IsOnGround = false;
            }

            //Place the turret if the player left-clicks in a valid location
            if ((GameInput.GetInput(InputName.Attack1, InputType.ButtonPressed) != 0.0f ||
                GameInput.GetInput(InputName.Attack1, InputType.ButtonHeld) != 0.0f) &&
                m_NewTurret.GetComponent<BuildTurret>().IsInValidPlacementLocation == true)
            {
                PlaceTurret();
            }
            //If the player pushes another ability button or his secondary attack button, cancel the turret placement
            else if (GameInput.GetInput(InputName.Ability2, InputType.ButtonPressed) != 0.0f ||
                    GameInput.GetInput(InputName.Ability2, InputType.ButtonHeld) != 0.0f ||
                    GameInput.GetInput(InputName.Ability3, InputType.ButtonPressed) != 0.0f ||
                    GameInput.GetInput(InputName.Ability3, InputType.ButtonHeld) != 0.0f ||
                    GameInput.GetInput(InputName.Attack2, InputType.ButtonPressed) != 0.0f ||
                    GameInput.GetInput(InputName.Attack2, InputType.ButtonHeld) != 0.0f/* ||
                    GameInput.GetInput(InputName.TauntHorizontal, InputType.ButtonPressed) != 0.0f ||
                    GameInput.GetInput(InputName.TauntHorizontal, InputType.ButtonHeld) != 0.0f ||
                    GameInput.GetInput(InputName.TauntVertical, InputType.ButtonPressed) != 0.0f ||
                    GameInput.GetInput(InputName.TauntVertical, InputType.ButtonHeld) != 0.0f*/)
            {
                Owner.PlayerAnimator.SetBool("PlacingTurret", false);
                m_NewTurret.SetActive(false);
                PlacingTurret = false;
                Owner.GetComponent<Quark>().PlacingObject = false;
            }
        }

        //Do UI stuff
        if (Owner.IsAI)
            return;

        Owner.AbilityUICooldowns.Ability1Info.UseCooldown = m_PlacementTimer / PlacementCooldown;
        if (PlacingTurret == false && m_PlacementTimer <= 0)
        {
            Owner.AbilityUICooldowns.Ability1Info.Usable = true;
        }
        else
        {
            Owner.AbilityUICooldowns.Ability1Info.Usable = false;
        }
    }

    public void PlaceTurret()
    {
        Owner.PlayerAnimator.SetTrigger("PlacedTurret");
        Owner.PlayerAnimator.SetBool("PlacingTurret", false);

        //player left-clicked to place turret, or pressed a different ability button to cancel the placement
        if (m_NewTurret.activeInHierarchy == true)
        {
            m_PlacementTimer = PlacementCooldown;

            GameObject turretToReset;

            //Check if the turret already has a turret placed and is about to placed another one.
            //Turret1 may have been shot and destroyed, don't destroy Turret2 if this has happened
            if (m_Turret1.activeInHierarchy == true)
            {
                if (m_Turret2.activeInHierarchy == true)
                {
                    m_Turret2.SetActive(false);
                }
                turretToReset = m_Turret2;
                m_Turret2 = m_Turret1;
                m_Turret1 = turretToReset;

                Owner.AudioSourceAbility3.Play();
            }
            bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
            if (playDialogue)
            {
                DialogueManager.Instance.PlayDialogue(CharacterTypes.Quark, DialogueContext.QuarkPlaceTurret, false, true);
            }
            Owner.AudioSourceAbility3.Play();

            m_Turret1.GetComponent<TurretScript>().Reset(m_NewTurret.transform.position, m_NewTurret.transform.rotation);
            m_Turret1.GetComponent<BuildTurret>().enabled = true;
            m_Turret1.GetComponent<BuildTurret>().Reset();
            m_Turret1.GetComponent<BuildTurret>().Place();
            m_Turret1.GetComponent<BuildTurret>().IsPlaced = true;

            if(Owner.IsAI)
            {
                Owner.GetComponent<QuarkAICharacter>().AddTurret(m_Turret1);
            }
        }
        m_NewTurret.SetActive(false);
        PlacingTurret = false;
        Owner.GetComponent<Quark>().PlacingObject = false;
    }

    public override void ResetAbility()
    {
        m_NewTurret.SetActive(false);
        PlacingTurret = false;
        Owner.GetComponent<Quark>().PlacingObject = false;
        m_PlacementTimer = 0;
    }
    public override bool CanUseAbility()
    {
        if (PlacingTurret == false && m_PlacementTimer <= 0)
            return true;
        return false;
    }

    public bool AI_CanPlace()
    {
        return m_NewTurret.GetComponent<BuildTurret>().IsInValidPlacementLocation;
    }
}