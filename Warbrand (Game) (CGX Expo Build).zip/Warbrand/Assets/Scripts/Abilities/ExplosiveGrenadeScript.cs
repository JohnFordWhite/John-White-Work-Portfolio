﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ExplosiveGrenadeScript                                                         *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 16th, 2016                                                             *
 *                                                                                                 *
 * This script is to be attached to a grenade. When the grenade makes contact with anything other  *
 * than the person that fired it, it spawn and explosion and delete. This script handles the       *
 * grenade's movement and hit detection, as well as taking in values to apply to the explosion     *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 16th, 2016                                          *
 *                                                                                                 *
\***************************************************************************************************/
using UnityEngine;
using System.Collections;

public class ExplosiveGrenadeScript : MonoBehaviour {

    public float Speed = 25;
    public float Gravity = 9.81f;
    public float MaxLife = 10.0f;
    [SerializeField]
    public float ExplosionRadius = 5.0f;
    [SerializeField]
    private float ExplosionDamage = 30.0f;
    [HideInInspector]
    public Player Owner;

    private Vector3 m_Velocity;
    private float m_Life;
    private GameObject m_ExplosionPrefab;
    private bool m_HasExploded = false;

    private const string m_ExplosionResource = "Prefabs/Projectiles/Explosion";

    public void Init()
    {
        m_Velocity = transform.forward * Speed;
        m_Life = MaxLife;
        m_ExplosionPrefab = Resources.Load(m_ExplosionResource) as GameObject;
        m_ExplosionPrefab.GetComponent<ExplosionScript>().Radius = ExplosionRadius;
        m_ExplosionPrefab.GetComponent<ExplosionScript>().Damage = ExplosionDamage;
        m_ExplosionPrefab.GetComponent<ExplosionScript>().Owner = Owner;

        //ignore collision between projectile and owner
        Owner.IgnoreCollision(GetComponent<Collider>());
    }
	
    void FixedUpdate()
    {
        m_Life -= Time.fixedDeltaTime;
        if(m_Life <= 0 && m_HasExploded == false)
        {
            Explode();
        }
        transform.position += m_Velocity * Time.fixedDeltaTime;

        m_Velocity.y -= Gravity * Time.fixedDeltaTime;
    }

    void OnTriggerEnter(Collider other)
    {
        //Make sure it doesn't instantly explode on the user
        if (Owner != null)
        {
            if (other.GetComponent<PlayerHitboxScript>() != null || (!other.isTrigger && m_HasExploded == false))
            {
                Explode();
            }
        }
    }

    public void Explode()
    {
        if (m_HasExploded)
            return;
        m_HasExploded = true;
        Object.Instantiate(m_ExplosionPrefab, transform.position, transform.rotation);
        Destroy(gameObject);
    }
}
