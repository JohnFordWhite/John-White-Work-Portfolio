﻿using UnityEngine;
using System.Collections;
using System;

public class JetpackAbility : Ability
{
    //
    // Public
    //
    public float UpwardsForce = 3600f;
    public float MaxUpwardsSpeed = 10f;

    //
    // Private
    //
    private Rigidbody m_Rigidbody = null;
    private bool m_UsingAbility = false;
    private ParticleSystem[] m_JetpackParticles;
    private float m_MaxFuel = 100.0f;
    private float m_FuelConsumptionRate = 35.0f;
    private float m_FuelRegenRate = 10.0f;
    private float m_CurrentFuel;
    private float m_StartVolume = 0.8f;
    //Because the fuel is constantly regening, letting the player use the jetpack if they are above 0 will result in spastic jetpack behaviour if held down
    private float m_MinimumFuelNeeded = 10.0f;
    //This variable is used so that player can use their fuel up completely, but can't use the jetpack again until regens to the minimum amount needed
    private bool m_CanUseJetpack = true;
    private bool m_UsingJetpack = false;

    private BasicMovementScript m_Movement;

    private const string m_JetpackTransform = "Jetpack";

    public JetpackAbility(InputName aKey)
    {
        Key = aKey;
        m_CurrentFuel = m_MaxFuel;

        HasAnimationTime = true;
        AnimatorString = "StartJetpack";
    }

    public override void SetOwner(Player owner)
    {
        Owner = owner;
        if (Owner.IsAI)
            return;
        Owner.AbilityUICooldowns.MovementAbilityInfo.Usable = true;
        //Debug.Log(owner);
        m_JetpackParticles = owner.transform.FindChild(m_JetpackTransform).gameObject.GetComponentsInChildren<ParticleSystem>();
        for (int i = 0; i < m_JetpackParticles.Length; i++)
        {
            m_JetpackParticles[i].Stop();
        }
    }

    public override void OnStartAbility()
    {
        if (!Owner.IsAI && m_CurrentFuel < m_MinimumFuelNeeded)
            Owner.AbilityUICooldowns.MovementAbilityInfo.Usable = false;

        if (m_CurrentFuel >= m_MinimumFuelNeeded)
        {
            m_UsingAbility = true;

            if (m_Movement == null)
                m_Movement = Owner.GetComponent<BasicMovementScript>();

            m_Movement.OverrideAirControls(true);

            if (!Owner.IsAI)
            {
                for (int i = 0; i < m_JetpackParticles.Length; i++)
                    m_JetpackParticles[i].Play();
            }
        }
    }

    public override void OnContinueAbility()
    {
        if (!Owner.CanUseMovementAbility || m_CanUseJetpack == false)
            return;

        if (m_Movement == null)
            m_Movement = Owner.GetComponent<BasicMovementScript>();

        if (m_Movement != null)
            m_Movement.AffectedByOutsideForce();

        if (m_Rigidbody == null)
            m_Rigidbody = Owner.GetComponent<Rigidbody>();

        if (m_Rigidbody == null)
            return;

        m_CurrentFuel -= m_FuelConsumptionRate * Time.deltaTime;

        if (m_CurrentFuel < 0)
        {
            SimpleCoroutine.Instance.StartCoroutine(AudioUtils.FadeOut(Owner.AudioSourceMovement, m_StartVolume, 0.3f));

            m_CurrentFuel = 0;
            m_CanUseJetpack = false;
        }

        if (!Owner.AudioSourceMovement.isPlaying)
            Owner.AudioSourceMovement.Play();

        m_UsingJetpack = true;
        Owner.PlayerAnimator.SetBool("UsingJetpack", m_UsingJetpack);
    }

    public override void OnEndAbility()
    {
        SimpleCoroutine.Instance.StartCoroutine(AudioUtils.FadeOut(Owner.AudioSourceMovement, m_StartVolume, 0.3f));

        m_UsingAbility = false;
        m_UsingJetpack = false;
        Owner.PlayerAnimator.SetBool("UsingJetpack", m_UsingJetpack);

        if (m_Movement == null)
            m_Movement = Owner.GetComponent<BasicMovementScript>();

        m_Movement.OverrideAirControls(false);

        if (m_Rigidbody == null)
            m_Rigidbody = Owner.GetComponent<Rigidbody>();

        if (m_Rigidbody.velocity.y > 0f)
        {
            Vector3 vel = m_Rigidbody.velocity;
            vel.y *= 0.75f;
            m_Rigidbody.velocity = vel;
        }

        if (!Owner.IsAI)
        {
            for (int i = 0; i < m_JetpackParticles.Length; i++)
                m_JetpackParticles[i].Stop();
        }
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        m_CurrentFuel += m_FuelRegenRate * Time.fixedDeltaTime;

        //Debug.Log(m_CurrentFuel);

        if (m_CurrentFuel > m_MaxFuel)
            m_CurrentFuel = m_MaxFuel;

        if (m_CurrentFuel > m_MinimumFuelNeeded)
            m_CanUseJetpack = true;

        if (m_UsingJetpack && m_CanUseJetpack)
        {
            m_Rigidbody.AddForce(Vector3.up * UpwardsForce * aFixedDelta);

            Vector3 vel = m_Rigidbody.velocity;
            vel.y = Mathf.Clamp(vel.y, float.MinValue, MaxUpwardsSpeed);
            m_Rigidbody.velocity = vel;
        }

        if (Owner.IsAI)
            return;

        if (!m_UsingAbility && Owner.CanUseMovementAbility && m_CurrentFuel > m_MinimumFuelNeeded)
        {
            Owner.AbilityUICooldowns.MovementAbilityInfo.Usable = true;
        }
        else
        {
            Owner.AbilityUICooldowns.MovementAbilityInfo.Usable = false;
        }

        Owner.AbilityUICooldowns.MovementAbilityInfo.UseCooldown = 1 - (m_CurrentFuel / m_MaxFuel);
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_CurrentFuel = m_MaxFuel;
    }

    public override bool CanUseAbility()
    {
        return Owner.CanUseMovementAbility;
    }

    public float TimeRemaining
    {
        get
        {
            return m_CurrentFuel / m_FuelConsumptionRate;
        }
    }
    
    public float PercentFuelRemaining
    {
        get
        {
            return m_CurrentFuel / m_MaxFuel;
        }
    }
}