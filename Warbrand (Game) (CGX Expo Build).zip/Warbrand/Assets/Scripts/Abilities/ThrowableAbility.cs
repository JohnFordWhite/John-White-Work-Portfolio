﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Filename                                                                       *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            October 14th, 2016                                                             *
 *                                                                                                 *
 * Description of file usage                                                                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - October 14th, 2016                                          *
 * V 1.1 - Added Camera Functionality (John White) - October 23rd, 2016                            *
 * V 1.2 - Moved Turret Functionality to PlaceTurretAbility.cs (John White) - October 24th, 2016   *
 * V 1.3 - Moved Camera Functionality to PlaceCameraAbility.cs (John White) - October 29th, 2016   *
\***************************************************************************************************/

using System;
using UnityEngine;

public class ThrowableAbility : Ability
{
    //
    // Public
    //
    public GameObject ThrowableObject = null;

    //
    // Private
    //
    private float m_ThrowForce;

    public ThrowableAbility(InputName aKey, GameObject aPrefab, float aForce = 1f)
    {
        Key = aKey;
        ThrowableObject = aPrefab;
        m_ThrowForce = aForce;
    }

    public override void OnStartAbility()
    {
        GameObject obj = GameObject.Instantiate(ThrowableObject, Owner.transform.position + Owner.transform.forward, Quaternion.identity) as GameObject;
        obj.GetComponent<Rigidbody>().AddForce(Owner.transform.forward * m_ThrowForce, ForceMode.Impulse);

        switch (obj.GetComponent<ThrowableComponent>().Type)
        {
            case ThrowableType.ElectricWall:
                // TODO: Implement Electric Wall
                break;
            case ThrowableType.PoisonDart:
                // TODO: Implement Poison Dart
                break;
            case ThrowableType.SmokeScreenGrenade:
                // TODO: Implement Smoke Screen Grenade
                break;
            case ThrowableType.TMNAdhesive:
                // TODO: Implement TMN Adhesive
                break;
        }
    }

    public override void OnContinueAbility()
    {

    }

    public override void OnEndAbility()
    {

    }

    public override void UpdateAbility(float aFixedDelta)
    {
        
    }

    public override void ResetAbility()
    {
        OnEndAbility();
    }

    public override bool CanUseAbility()
    {
        throw new NotImplementedException();
    }
}