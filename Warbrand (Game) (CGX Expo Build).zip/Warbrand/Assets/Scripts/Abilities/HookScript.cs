﻿using UnityEngine;
using System.Collections;

public class HookScript : MonoBehaviour
{
    [SerializeField]
    protected float RotationSpeed = 720;
    [SerializeField]
    protected float MaxRange = 30;

    [HideInInspector]
    public Player Owner;
    [HideInInspector]
    public Player HookedPlayer;
    [HideInInspector]
    public bool HitObject = false;
    [HideInInspector]
    public bool HitAPlayer = false;

    GameObject m_ParticleManager;
    LineRenderer m_LineRenderer;
    Rigidbody m_Rigidbody;

    private const string m_ParticleManagerTransform = "ParticleManager";

    void Start()
    {
        m_ParticleManager = GameObject.Find(m_ParticleManagerTransform);
        m_LineRenderer = GetComponent<LineRenderer>();

        m_Rigidbody = GetComponent<Rigidbody>();
    }

    public void SetOwner(Player owner)
    {
        Owner = owner;
        GetComponentInChildren<HookHitboxScript>().Owner = owner;
    }

    void Update()
    {
        if (HookedPlayer != null)
        {
            m_Rigidbody.velocity = Vector3.zero;
        }
        else
        {
            gameObject.transform.Rotate(Vector3.right * RotationSpeed * Time.deltaTime);
        }

        //make sure the hook hasn't reach it's max length
        if(Vector3.Distance(transform.position, Owner.transform.position) >= 30)
        {
            HitObject = true;
        }

        m_LineRenderer.SetPosition(0, ((Zeph)Owner).KusarigamaBlade.transform.position + ((Zeph)Owner).KusarigamaBlade.transform.up * 0.2f);
        m_LineRenderer.SetPosition(1, gameObject.transform.position + gameObject.transform.up * 0.2f);
        m_LineRenderer.material.mainTextureScale = new Vector2(Vector3.Distance(((Zeph)Owner).KusarigamaBlade.transform.position + ((Zeph)Owner).KusarigamaBlade.transform.up * 0.2f, gameObject.transform.position + gameObject.transform.up * 0.2f) * 5, 1);
    }

    //void OnTriggerEnter(Collider other)
    //{
    //    Player player = other.GetComponent<PlayerHitboxScript>().Owner;

    //    //if (other.GetComponent<PlayerHitboxScript>().Owner != null || other.GetComponentInParent<Player>() || other.GetComponentInChildren<Player>() && !HitAPlayer)
    //    if (other.transform.root.GetComponentInChildren<Player>() != null && !HitAPlayer)
    //    {
    //        //Debug.Log(other.name);
    //        HookedPlayer = player;

    //        HitAPlayer = true;
    //    }
    //}

    void OnCollisionEnter(Collision hit)
    {
        //HitObject = true;
        m_ParticleManager.GetComponent<ParticleManager>().SpawnHitEffect(hit.contacts[0].point, hit.contacts[0].normal);

        HitObject = true;
    }
}
