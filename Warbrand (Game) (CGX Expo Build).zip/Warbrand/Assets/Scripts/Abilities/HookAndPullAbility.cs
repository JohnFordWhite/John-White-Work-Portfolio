/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        HookAndPullAbility                                                             *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            October 20th, 2016                                                             *
 *                                                                                                 *
 * Ability that will pull an enemy to just infront of the player.                                  *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - October 20th, 2016                                          *
 * V 1.1 - Updated to work as a continuous ability (Jon Roffey) - October 21st, 2016               *
 * V 1.2 - Changed to work with collisions and transforms (John White) - October 30th, 2016        *
 * V 1.3 - Added aim assist (Jon Roffey) - December 7th, 2016                                      *
\***************************************************************************************************/

using System;
using System.Collections.Generic;
using UnityEngine;

public class HookAndPullAbility : Ability
{
    //
    // Public
    //
    public float HookCooldown = 8.5f;
    public float StunTime = 0.8f;
    public float m_WaitForAnimationTimer = 0.35f;

    //
    //Private
    //
    private GameObject m_HookPrefab;
    private GameObject m_Hook;
    private HookScript m_HookScript;
    private Rigidbody m_HookRigidBody;
    private Rigidbody m_HookedPlayerRigidBody = null;
    private Vector3 m_DirectionToEnemy;
    private List<Player> m_PlayersThatCanBeHit;
    private Player m_ClosestEnemy;
    private Player m_HookedPlayer = null;
    private float m_AimAssistSphereCastRadius = 2f;
    private float m_TimeHooked = 0f;
    private float m_MaxHookDist = 40f;
    private float m_HookThrowForce = 175f;
    private float m_PullSpeed = 50f;
    private float m_HookTimer = 0f;
    private float m_ChanceToPlayDialogue = 0.005f;

    //this boolean should only be set to true if the hook hit something other than a player and is now returning to the owner
    private bool m_HookFailed = false;
    private bool m_HookFailedDialoguePlayed = false;
    private bool m_HookSucceededDialoguePlayed = false;
    private int m_LayerMask;
    //private bool m_PlayerHit = false;


    public HookAndPullAbility(InputName aKey)
    {
        Key = aKey;
        IsContinuousAbility = true;

        m_LayerMask = ~((1 << LayerMask.NameToLayer("UnplacedObjects")) |
                        (1 << LayerMask.NameToLayer("WallCollider")) |
                        (1 << LayerMask.NameToLayer("Ignore Raycast")));

        m_HookPrefab = Resources.Load("Prefabs/Projectiles/Hook") as GameObject;

        HasAnimationTime = true;
        AnimatorString = "ThrowHook";
    }

    public override void OnStartAbility()
    {

        if (m_HookTimer <= 0)
        {
            AddAssist();

            bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
            if (playDialogue)
            {
                Debug.Log("here");

                DialogueManager.Instance.PlayDialogue(CharacterTypes.Zeph, DialogueContext.ZephThrowsHook, false, true);
            }
            Owner.AudioSourceAbility1.clip = Owner.GetComponent<Zeph>().HookThrowClip;
            Owner.AudioSourceAbility1.Play();

            ContinuousAbilityStarted = true;
            ContinuousAbilityInUse = true;
            m_TimeHooked = 0f;
            m_HookTimer = HookCooldown;

            //Initialize the hook position to be right in front of the player
            m_Hook = GameObject.Instantiate(m_HookPrefab, ((Zeph)Owner).KusarigamaBlade.transform.position, ((Zeph)Owner).KusarigamaBlade.transform.rotation) as GameObject;
            ((Zeph)Owner).KusarigamaBlade.SetActive(false);
            //Vector3 hookRotation = m_Hook.transform.rotation.eulerAngles;
            //hookRotation.z = -90;
            //m_Hook.transform.eulerAngles = hookRotation;
            m_HookScript = m_Hook.GetComponent<HookScript>();
            m_HookScript.SetOwner(Owner);
            m_HookRigidBody = m_Hook.GetComponent<Rigidbody>();

            //Apply force to the hook
            m_HookRigidBody.AddForce(m_DirectionToEnemy.normalized * m_HookThrowForce * m_HookRigidBody.mass, ForceMode.Impulse);
        }
    }

    public override void OnContinueAbility()
    {
        //Hook reached it's max range without hitting anything :(
        if (m_HookScript.HookedPlayer == null && Vector3.Distance(m_Hook.transform.position, Owner.transform.position  + Vector3.up) >= m_MaxHookDist)
        {
            m_HookFailed = true;
            m_HookRigidBody.velocity = Vector3.zero;
        }

        //Check the hook script to see if it hit an object before hooking a player
        if (m_HookScript.HookedPlayer == null && m_HookScript.HitObject == true)
        {
            //Debug.Log("Hook Failed, no player hit");
            m_HookFailed = true;
            m_HookRigidBody.velocity = Vector3.zero;
        }

        //The hook is returning to zeph
        if (m_HookFailed == true)
        {
            if(!m_HookFailedDialoguePlayed)
            {
                bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
                if (playDialogue)
                {
                    Debug.Log("here");

                    DialogueManager.Instance.PlayDialogue(CharacterTypes.Zeph, DialogueContext.ZephMissThrownAttack, false, true);
                    m_HookFailedDialoguePlayed = true;
                }
            }

            Owner.PlayerAnimator.SetTrigger("ReturnHook");

            Vector3 pullDirection = (Owner.transform.position + Vector3.up) - m_Hook.transform.position;
            pullDirection.Normalize();
            pullDirection *= m_PullSpeed;

            m_Hook.gameObject.transform.position += pullDirection * Time.fixedDeltaTime;

            //If the hook has been returned close enough, end the ability
            if (Vector3.Distance(Owner.PlayerCamera.transform.position, m_Hook.transform.position) < 2)
            {
                ContinuousAbilityInUse = false;
            }
        }

        //Hook didn't hit a player and is coming back to Zeph
        if (m_HookScript.HookedPlayer != null && m_HookFailed == false)
        {
            Owner.PlayerAnimator.SetTrigger("ReturnHook");

            HandleHookerHookeeDied();

            if (m_HookScript != null)
            {
                m_HookedPlayer = m_HookScript.HookedPlayer;
                m_HookedPlayerRigidBody = m_HookedPlayer.GetComponent<Rigidbody>();
            }
        }

        //Another player is being hooked
        if (m_HookedPlayer != null && m_HookedPlayerRigidBody != null)
        {
            HandleHookerHookeeDied();

            m_HookedPlayer.AbilityBlockingMovement = true;
            m_HookedPlayer.AbilityBlockingRotation = true;
            m_HookedPlayerRigidBody.velocity = Vector3.zero;
        }

        //The hook hit another player
        if (m_HookedPlayer != null)
        {
            HandleHookerHookeeDied();

            if(!m_HookSucceededDialoguePlayed)
            {
                bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
                if (playDialogue)
                {
                    DialogueManager.Instance.PlayDialogue(CharacterTypes.Zeph, DialogueContext.ZephPullOpponent, false, true);
                    m_HookSucceededDialoguePlayed = true;
                }
            }

            m_WaitForAnimationTimer -= Time.deltaTime;

            //Rotate the other player to face zeph
            Vector3 ownerPosition = Owner.transform.position;
            ownerPosition.y = m_HookedPlayer.transform.position.y;
            Quaternion rot = Quaternion.LookRotation(ownerPosition - m_HookedPlayer.transform.position);
            m_HookedPlayer.transform.rotation = Quaternion.Slerp(m_HookedPlayer.transform.rotation, rot, Time.deltaTime * 10);

            if (m_WaitForAnimationTimer <= 0)
            {
                Zeph zeph = Owner.GetComponent<Zeph>();

                if (Owner.AudioSourceAbility1.clip == zeph.HookThrowClip)
                {
                    Owner.AudioSourceAbility1.Stop();
                    Owner.AudioSourceAbility1.clip = zeph.HookReturnClip;
                }
                if (!Owner.AudioSourceAbility1.isPlaying)
                    Owner.AudioSourceAbility1.Play();

                //While the enemy is hooked, pull towards player
                //TODO: Do a linecast to make sure the hooked player isn't about move through a wall

                Vector3 pullDirection = (Owner.PlayerCamera.transform.position + (Vector3.up * 0.5f)) - (m_HookedPlayer.transform.position + Vector3.up);
                pullDirection.Normalize();
                pullDirection *= m_PullSpeed;

                m_HookedPlayer.transform.position += pullDirection * Time.fixedDeltaTime;
                m_Hook.gameObject.transform.position = m_HookedPlayer.transform.position + Vector3.up;
                //TODO:I know this is bad, but it will do for now
                if (!m_HookedPlayer.GetComponent<Health>().IsInvincible)
                    m_HookedPlayer.Stun(Time.deltaTime * 1.1f);
                //m_Hook.gameObject.transform.position += pullDirection * Time.fixedDeltaTime;


                //If the enemy has been pulled close enough, or if the enemy has been pulled for more than 2 seconds, end the pull
                if (Vector3.Distance(Owner.transform.position, m_HookedPlayer.transform.position) < 1.5 || m_TimeHooked > 2.0f)
                {
                    //If the enemy is close to, and above or below the player, make the enemy have the same Y as the player
                    if (Mathf.Abs(Owner.transform.position.y - m_HookedPlayer.transform.position.y) > 0.5f && Vector3.Distance(Owner.transform.position, m_HookedPlayer.transform.position) < 1.5)
                        m_HookedPlayer.transform.position = new Vector3(m_HookedPlayer.transform.position.x, Owner.transform.position.y + 0.5f, m_HookedPlayer.transform.position.z);

                    ContinuousAbilityInUse = false;
                }
            }
        }
    }

    void HandleHookerHookeeDied()
    {
        if(m_HookedPlayer!=null)
        {
            Health health = m_HookedPlayer.GetComponent<Health>();

            if (health != null)
            {
                if(health.IsDead)
                {
                    ContinuousAbilityInUse = false;
                }
            }
        }

        if (Owner.Health.IsDead)
        {
            m_HookedPlayer.Stun(StunTime);
            m_HookedPlayer.AbilityBlockingMovement = false;
            m_HookedPlayer.AbilityBlockingRotation = false;
            m_HookedPlayer = null;
            ContinuousAbilityInUse = false;
            m_HookScript.HitAPlayer = false;
            m_HookScript = null;
            m_HookFailedDialoguePlayed = false;
            m_HookSucceededDialoguePlayed = false;
        }
    }

    public override void OnEndAbility()
    {
        if (m_HookedPlayer != null)
        {
            m_HookedPlayer.Stun(StunTime);
            m_HookedPlayer.AbilityBlockingMovement = false;
            m_HookedPlayer.AbilityBlockingRotation = false;
        }
        ((Zeph)Owner).KusarigamaBlade.SetActive(true);

        ContinuousAbilityStarted = false;
        ContinuousAbilityInUse = false;
        GameObject.Destroy(m_Hook);

        if (m_HookScript != null)
        {
            m_HookScript.HitAPlayer = false;
            m_HookScript = null;
        }

        m_HookRigidBody = null;
        m_HookedPlayer = null;
        m_HookedPlayerRigidBody = null;
        m_WaitForAnimationTimer = 0.35f;
        m_HookFailed = false;
        m_HookFailedDialoguePlayed = false;
        m_HookSucceededDialoguePlayed = false;
    }

    void AddAssist()
    {
        //m_PlayerHit = false;
        m_PlayersThatCanBeHit = new List<Player>();
        m_ClosestEnemy = null;
        m_PlayersThatCanBeHit.Clear();

        //Set direction to enemy to players forward, so if no enemy is closeby, just shoot straight
        m_DirectionToEnemy = Owner.PlayerCamera.transform.forward;

        //Spherecast infront of the player and check for only other players, m_SphereCastRadius is the variable to adjust to change the amount of assist(lul)
        RaycastHit[] hits = Physics.SphereCastAll(Owner.transform.position, m_AimAssistSphereCastRadius, Owner.transform.forward, Mathf.Infinity, m_LayerMask, QueryTriggerInteraction.Collide);
        for (int i = 0; i < hits.Length; i++)
        {
            RaycastHit hitInArray = hits[i];


            if (hitInArray.transform.GetComponent<PlayerHitboxScript>() != null)
            {
                if (hitInArray.transform.GetComponent<PlayerHitboxScript>().Owner != Owner)
                {
                    //If a player was hit, add them to a list
                    m_PlayersThatCanBeHit.Add(hitInArray.transform.GetComponent<PlayerHitboxScript>().Owner);
                }
            }
        }

        float angleToEnemy = float.MaxValue;

        //If there were any players hit, check the angle between where the player is looking, and the enemy
        //If there is more than one enemy in the list, set the one that has the lowest angle to m_ClosestEnemy, since that's the closest one to where the player is aiming
        if (m_PlayersThatCanBeHit.Count > 0)
        {
            for (int i = 0; i < m_PlayersThatCanBeHit.Count; i++)
            {
                Player ObjectInList = m_PlayersThatCanBeHit[i];

                m_DirectionToEnemy = ObjectInList.transform.position - Owner.transform.position;

                if (Vector3.Angle(Owner.PlayerCamera.transform.forward, m_DirectionToEnemy) < angleToEnemy)
                {
                    angleToEnemy = Vector3.Angle(Owner.PlayerCamera.transform.forward, m_DirectionToEnemy);
                    //Debug.Log(angleToEnemy);
                    m_ClosestEnemy = ObjectInList;
                }
            }
        }

        //If there is an enemy, raycast to it, to make sure you can't hit through a wall
        if (m_ClosestEnemy != null)
        {
            RaycastHit hit;
            if (Physics.Raycast(Owner.transform.position, m_DirectionToEnemy, out hit, Mathf.Infinity))
            {
                //m_PlayerHit = true;
            }
        }
    }

    public override void UpdateAbility(float aFixedDelta)
    {
        m_HookTimer -= aFixedDelta;

        m_TimeHooked += Time.deltaTime;

        //Do UI stuff
        if (Owner.IsAI)
            return;

        Owner.AbilityUICooldowns.Ability1Info.UseCooldown = m_HookTimer / HookCooldown;
        Owner.AbilityUICooldowns.Ability1Info.Usable = CanUseAbility();
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_HookTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_HookTimer <= 0 && !ContinuousAbilityStarted)
            return true;
        return false;
    }
}