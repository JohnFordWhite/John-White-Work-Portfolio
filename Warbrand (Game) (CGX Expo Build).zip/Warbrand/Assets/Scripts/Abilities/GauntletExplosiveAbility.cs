/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        GauntletExplosiveAbility                                                       *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 16th, 2016                                                             *
 *                                                                                                 *
 * This will spawn a grenade from leeroy's gauntlet that will travel at a medium speed. Once the   *
 * grenade touches the ground or another player, it will explode. Each use will consume a charge.  *
 * There will be a max of 3 charges. The player will gain another charge every 8 seconds           *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 16th, 2016                                          *
 *                                                                                                 *
\***************************************************************************************************/

using System;
using UnityEngine;

public class GauntletExplosiveAbility : Ability
{
	//
	// Public
	//
    public int MaxCharges = 3;
    public float ChargeRegenCooldown = 6.0f;
    public float UseCooldown = 0.5f;

    //
    //Private
    //
    private int m_CurrentCharges;
    private float m_ChargeRegenTimer;
    private float m_UseCooldownTimer;
    private GameObject m_ExplosiveGrenadePrefab;
    private GameObject m_ExplosiveGrenade;
    private const string m_GauntletExplosive = "GauntletExplosive";

    private const string m_ExplosionGrenadeResource = "Prefabs/Projectiles/ExplosiveGrenade";

    public GauntletExplosiveAbility(InputName aKey)
    {
        Key = aKey;
        m_CurrentCharges = MaxCharges;
        m_ChargeRegenTimer = 0.0f;
        m_UseCooldownTimer = 0.0f;
        m_ExplosiveGrenadePrefab = Resources.Load(m_ExplosionGrenadeResource) as GameObject;
        AnimatorString = m_GauntletExplosive;
        HasAnimationTime = true;

    }

    public override void SetOwner(Player owner)
    {
        Owner = owner;
        m_ExplosiveGrenadePrefab.GetComponent<ExplosiveGrenadeScript>().Owner = this.Owner;
        if (!Owner.GameInput.IsAI)
        {
            Owner.AbilityUICooldowns.Ability2Info.HasCharges = true;
            Owner.AbilityUICooldowns.Ability2Info.MaxCharges = MaxCharges;
        }
    }

    public override void OnStartAbility ()
	{
        if(m_CurrentCharges > 0 && m_UseCooldownTimer <= 0)
        {
            m_CurrentCharges--;
            m_UseCooldownTimer = UseCooldown;

            //Fire the explosive
            m_ExplosiveGrenade = GameObject.Instantiate(m_ExplosiveGrenadePrefab, Owner.PlayerCamera.transform.position, Owner.PlayerCamera.transform.rotation) as GameObject;

            ExplosiveGrenadeScript grenade = m_ExplosiveGrenade.GetComponent<ExplosiveGrenadeScript>();

            grenade.Owner = Owner;
            grenade.Init();

            Owner.AudioSourceAbility2.Play();
        }
	}

	public override void OnContinueAbility ()
	{
        
	}

	public override void OnEndAbility ()
	{
        
	}

    //Occurs every frame
    public override void UpdateAbility(float aFixedDelta)
    {
        m_UseCooldownTimer -= aFixedDelta;
        m_ChargeRegenTimer -= aFixedDelta;

        if (m_CurrentCharges >= MaxCharges)
        {
            m_ChargeRegenTimer = ChargeRegenCooldown;
            if(Owner.AbilityUICooldowns)
                Owner.AbilityUICooldowns.Ability2Info.ChargeCooldown = 1;
        }
        else
        {
            if (Owner.AbilityUICooldowns)
                Owner.AbilityUICooldowns.Ability2Info.ChargeCooldown = m_ChargeRegenTimer / ChargeRegenCooldown;
        }

        if(m_ChargeRegenTimer <= 0)
        {
            m_ChargeRegenTimer = ChargeRegenCooldown;
            if(m_CurrentCharges < MaxCharges)
            {
                m_CurrentCharges++;
                //Debug.Log("charge gained");
            }
        }


        //Do UI stuff
        if (Owner.IsAI)
            return;

        Owner.AbilityUICooldowns.Ability2Info.ChargesLeft = m_CurrentCharges;
        Owner.AbilityUICooldowns.Ability2Info.UseCooldown = m_UseCooldownTimer / UseCooldown;
        if (m_CurrentCharges > 0 && m_UseCooldownTimer <= 0)
        {
            Owner.AbilityUICooldowns.Ability2Info.Usable = true;
        }
        else
        {
            Owner.AbilityUICooldowns.Ability2Info.Usable = false;

        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_CurrentCharges = MaxCharges;
        m_UseCooldownTimer = 0;
        m_ChargeRegenTimer = 0;
    }

    public override bool CanUseAbility()
    {
        if (m_CurrentCharges > 0 && m_UseCooldownTimer <= 0)
            return true;
        return false;
    }
}