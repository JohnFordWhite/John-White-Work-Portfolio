﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ChargedHealingAbility                                                          *
 * FileExtension:   .cs                                                                            *
 * Author:          Evan Campbell                                                                  *
 * Date:            October 26th, 2016                                                             *
 *                                                                                                 *
 * A healing ability. The player cannot move or perform any actions while performing               *
 * this ability. The ability button must be held to activate it. Healing amount starts             *
 * off slowly at first and gets faster over time.                                                  *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Evan Campbell) - October 26th, 2016                                       *
\***************************************************************************************************/


using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System;

public class ChargedHealingAbility : Ability
{
    public ParticleSystem HealingParticle;

    public Material HealingEffectMaterial;
    public CanvasRenderer HealingEffectCanvasRenderer;
    public GameObject HealingParticleEmitterPrefab;
    public Health PlayerHealth;
    public bool AbilityInterrupted = false;

    // Keep these values low!
    // Play around with these values to get an amount of total health recovered
    // that feels right.
    public float HealingExponentialValue = 1.75f;
    public float BaseHealthRecovery = 0.025f;

    public bool IsHealing { get { return m_IsHealing; } }
    public bool IsOverheated { get { return m_IsOverheated; } }

    private float CooldownTime = 10.0f;

    private bool m_IsHealing;
    private bool m_IsOverheated;
    private bool m_HealingEndClipPlayed = false;
    private bool m_HealingInteruptDialoguePlayed = false;
    private float m_CooldownTime = 11.0f;
    private float m_AccumulatedTime = 0.0f;
    [SerializeField]
    private float m_HealDistance = 10.0f;
    private float m_HealthHealed = 0.0f;
    private float m_ChanceToPlayDialogue = 0.1f;

    private List<Player> m_AllPlayers;

    private BasicMovementScript m_Movement = null;

    private AudioClip m_HealingClip;
    private AudioClip m_HealEndClip;

    private HealingImageEffectScript m_HealingEffectScript;

    private Paige m_Paige;

    public ChargedHealingAbility(InputName aKey)
    {
        Key = aKey;

        AbilityBlocksMovement = true;
        AbilityBlocksRotation = false;
        AbilityBlocksOtherAbilities = true;

        m_AllPlayers = Information.AllPlayers;

        HasAnimationTime = true;
        AnimatorString = "ChargedHealing";
    }

    public override void SetOwner(Player owner)
    {
        base.SetOwner(owner);
        m_HealingEffectScript = Owner.FirstPersonModelCamera.GetComponent<HealingImageEffectScript>();

        m_Paige = Owner.GetComponent<Paige>();
    }

    public override void OnStartAbility()
    {
        if (m_HealingClip == null)
            m_HealingClip = m_Paige.HealChargingClip;
        if (m_HealEndClip == null)
            m_HealEndClip = m_Paige.HealEndClip;

        m_HealthHealed = 0;

        AbilityInterrupted = false;

        if (m_Movement == null)
        {
            m_Movement = Owner.BasicMovementScript;
        }

        // Can only start the ability if the ability is not in use and not overheated.
        if (m_IsOverheated == false && m_IsHealing == false)
        {
            m_AccumulatedTime = 1;
            m_HealingEndClipPlayed = false;
            
            // Also, the player must be grounded.
            if (m_Movement != null && m_Movement.IsGrounded)
            {
                if (HealingParticle != null && HealingParticle.gameObject.activeSelf == false)
                {
                    HealingParticle.gameObject.SetActive(true);
                    m_HealingEffectScript.ResetTimer();
                }

                Owner.AudioSourceAbility2.clip = m_HealingClip;
                Owner.AudioSourceAbility2.Play();

                m_IsHealing = true;

                // Prevent movement
                //m_Movement.enabled = false;
                //Debug.Log(m_Movement.enabled);

                // Block inputs
                BlockInput();

                // Get rid of any residual velocity.
                Owner.RigidBody.velocity = Vector3.zero;

                if (!HealingParticle.isPlaying)
                    HealingParticle.Play();
            }
        }
    }

    public override void OnContinueAbility()
    {
        if ((m_IsOverheated == true && m_IsHealing == true) || AbilityInterrupted == true)
        {
            OnEndAbility();
        }

    }

    public override void OnEndAbility()
    {
        Owner.PlayerAnimator.SetBool("Healing", false);


        m_HealingInteruptDialoguePlayed = false;

        if (!m_HealingEndClipPlayed)
        {
            Owner.AudioSourceAbility2.Stop();
            Owner.AudioSourceAbility2.PlayOneShot(m_HealEndClip, 0.75f);
            m_HealingEndClipPlayed = true;

            if (!m_HealingInteruptDialoguePlayed && AbilityInterrupted)
            {
                bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayDialogue;
                if (playDialogue)
                {
                    DialogueManager.Instance.PlayDialogue(CharacterTypes.Paige, DialogueContext.PaigeHealingInterupt, false, true);
                    m_HealingInteruptDialoguePlayed = true;
                }
            }

        }

        m_IsHealing = false;
        m_IsOverheated = true;

        AbilityInterrupted = false;

        //if (m_Movement != null)
        //    m_Movement.enabled = true;

        UnblockInput();

        if (HealingParticle.isPlaying)
            HealingParticle.Stop();

        //if (m_HealthHealed > 0.0f)
        //    Debug.Log("Paige Healing Ability - Total Health Healed: " + m_HealthHealed);

        if (HealingParticle != null && HealingParticle.gameObject.activeSelf == true)
        {
            HealingParticle.gameObject.SetActive(false);
        }
    }

    public override void UpdateAbility(float aDeltaTime)
    {
        if (m_IsHealing)
        {
            if (m_IsOverheated == false)
            {
                m_AccumulatedTime += aDeltaTime;

                if (m_AccumulatedTime > m_CooldownTime)
                {
                    m_IsOverheated = true;

                    OnEndAbility();
                }
            }
        }
        // Recharge healing time
        else
        {
            m_AccumulatedTime -= aDeltaTime;
            if (m_AccumulatedTime <= 0)
            {
                m_AccumulatedTime = 0.0f;
                m_IsOverheated = false;
            }
        }

        if (m_IsHealing)
        {
            // Use y = x ^ 2 / b to get health
            // Where y is the amount of health to heal this frame
            // x is the accumulated time
            // m is the exponential value
            // b is the max health

            float amountToHeal = Mathf.Pow(m_AccumulatedTime, HealingExponentialValue) / PlayerHealth.MaxHealth;


            m_HealthHealed += amountToHeal;
            PlayerHealth.Heal(amountToHeal);
            m_HealingEffectScript.ResetTimer();

            //Heal nearby allies
            for(int i = 0; i < m_AllPlayers.Count; i++)
            {
                if(m_AllPlayers[i] != Owner && m_AllPlayers[i].TeamIndex == Owner.TeamIndex)
                {
                    if(Vector3.Distance(m_AllPlayers[i].transform.position, Owner.transform.position) <= m_HealDistance)
                    {
                        m_AllPlayers[i].Health.Heal(amountToHeal);
                        if (!m_AllPlayers[i].IsAI)
                        {
                            m_AllPlayers[i].FirstPersonModelCamera.GetComponent<HealingImageEffectScript>().ResetTimer();
                        }
                    }
                }
            }

        }

        if (Owner.IsAI)
            return;

        float cooldown = m_AccumulatedTime / m_CooldownTime;
        Owner.AbilityUICooldowns.Ability2Info.UseCooldown = cooldown;

        if (m_IsOverheated == false && m_IsHealing == false)
        {
            Owner.AbilityUICooldowns.Ability2Info.Usable = true;
        }
        else
        {
            Owner.AbilityUICooldowns.Ability2Info.Usable = false;
        }
    }

    public override void ResetAbility()
    {
        OnEndAbility();
        m_IsOverheated = false;
        m_AccumulatedTime = 0;
    }

    public override bool CanUseAbility()
    {
        if (!m_IsHealing && !m_IsOverheated)
            return true;
        return false;
    }
}
