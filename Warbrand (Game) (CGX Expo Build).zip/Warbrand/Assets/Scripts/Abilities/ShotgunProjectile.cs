﻿using UnityEngine;
using System.Collections;

public class ShotgunProjectile : MonoBehaviour
{
    //
    //Public
    //
    [HideInInspector]
    public Vector3 SpawnPosition;
    [HideInInspector]
    public Vector3 PreviousPosition;
    [HideInInspector]
    public float Velocity;
    [HideInInspector]
    public float MaxDistance;
    [HideInInspector]
    public float BaseDamage;
    [HideInInspector]
    public Player Owner;

    [HideInInspector]
    public Rigidbody RigidBody;

    public GameObject ShotgunHitEffectPrefab;
    public GameObject BulletHolePrefab;

    //
    //Private
    //
    private AudioClip m_HitClip;
    private int m_LayerMask;
    private const string m_ShotgunHitClipString = "Audio/SoundFX/shotgun_hit (1)";

    private const string m_BulletHoleResource = "Prefabs/Decals/BulletHole";

    private const string m_WallsMask = "Walls";
    private const string m_FloorMask = "Floor";
    private const string m_ShieldMask = "Shield";

    void Start()
    {
        RigidBody = GetComponent<Rigidbody>();

        BulletHolePrefab = Resources.Load(m_BulletHoleResource) as GameObject;

        m_HitClip = Resources.Load(m_ShotgunHitClipString) as AudioClip;

        m_LayerMask = ~((1 << LayerMask.NameToLayer("UnplacedObjects")) |
            (1 << LayerMask.NameToLayer("Ignore Raycast")) |
            (1 << LayerMask.NameToLayer("WallCollider")) |
            (1 << LayerMask.NameToLayer("Ragdoll")) |
            (1 << Owner.gameObject.layer));
    }

    public void Init(Player aOwner, Vector3 aSpawnPosition, float aVelocity)
    {
        Owner = aOwner;
        transform.position = aSpawnPosition;
        SpawnPosition = aSpawnPosition;
        PreviousPosition = SpawnPosition;
        Velocity = aVelocity;
    }
    
    void FixedUpdate()
    {
        // Store previous position
        PreviousPosition = transform.position;

        // Move
        Vector3 velocityThisFrame = transform.forward * Velocity * Time.fixedDeltaTime;
        transform.position += velocityThisFrame;

        // Deactivate after it is too far from starting position
        if (Vector3.Distance(transform.position, SpawnPosition) > MaxDistance)
        {
            gameObject.SetActive(false);
            return;
        }

        RaycastHit hitInfo;

        // Raycast from previous position to new position. If it hits an object, deactivate this object.
        if (Physics.Linecast(PreviousPosition, transform.position, out hitInfo, m_LayerMask, QueryTriggerInteraction.Collide))
        {
            ParticleSystem[] particleSystems = null;

            if (ShotgunHitEffectPrefab != null)
            {
                ShotgunHitEffectPrefab.transform.position = hitInfo.point;
                ShotgunHitEffectPrefab.transform.rotation = Quaternion.LookRotation(hitInfo.normal);

                particleSystems = ShotgunHitEffectPrefab.GetComponentsInChildren<ParticleSystem>();
            }

            if (particleSystems != null)
            {
                for (int i = 0; i < particleSystems.Length; i++)
                {
                    particleSystems[i].Play();
                }
            }

            if (hitInfo.transform.gameObject.layer == LayerMask.NameToLayer(m_WallsMask) || hitInfo.transform.gameObject.layer == LayerMask.NameToLayer(m_FloorMask))
            {
                GameObject InstancedObjectContainer = InputManager.CM.GetInstancedObjectContainer();
                GameObject bulletHole = Instantiate(BulletHolePrefab, hitInfo.point + (hitInfo.normal * 0.01f), Quaternion.LookRotation(hitInfo.normal)) as GameObject;
                bulletHole.transform.SetParent(InstancedObjectContainer.transform);
            }

            Health healthScript = null;

            Player player = null;
            if (hitInfo.collider.GetComponent<PlayerHitboxScript>() != null)
                player = hitInfo.collider.GetComponent<PlayerHitboxScript>().Owner;

            if(player != null)
            {
                healthScript = player.GetComponent<Health>();
            }
            else
            {
                healthScript = hitInfo.collider.GetComponent<Health>();
            }

            if (healthScript != null)
            {
                if(!Owner.IsAI)
                {
                    Owner.AudioSourceMainAttack.PlayOneShot(m_HitClip, 0.15f);
                }

                DamageEnemy(healthScript.GetComponent<Health>(), hitInfo.collider, hitInfo.point);
            }

            if(LayerMask.LayerToName(hitInfo.collider.gameObject.layer) == m_ShieldMask)
            {
                hitInfo.collider.gameObject.GetComponent<PlasmaShaderHitboxScript>().ManualHit(hitInfo.point);
            }

            if (!hitInfo.collider.isTrigger)
                gameObject.SetActive(false);
            return;
        }
    }

    void DamageEnemy(Health aHealth, Collider collider, Vector3 hitPos)
    {
        if (aHealth != null)
        {
            float damageDealt = BaseDamage;

            // Get the bullet distance from its start position.
            // The amount of damage done will be more the closer to the
            // start position it was, and less the farther away it was.
            float distance = Vector3.Distance(transform.position, SpawnPosition);
            if (distance < MaxDistance)
            {
                // Percentage of Base Damage based on distance from start point
                float damagePercent = Mathf.Clamp(-0.35f * (1f / (1f + Mathf.Pow(0.325f, 0.5f * distance - 3f))) + 1.269f, 0f, 1f);
                damageDealt = damagePercent * BaseDamage;
            }
            else
            {
                damageDealt = 0.0f;
            }

            if (aHealth.Damage(Owner, Owner.gameObject, damageDealt, DeathType.Physics) && collider.GetComponent<PlayerHitboxScript>() != null)
            {
                //apply physics to ragdoll
                collider.GetComponent<PlayerHitboxScript>().AddForce(transform.forward * 10, hitPos);
            }
        }
    }

}
