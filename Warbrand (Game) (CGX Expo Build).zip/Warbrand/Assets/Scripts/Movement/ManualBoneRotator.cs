﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ManualBoneRotator                                                              *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            March 26th, 2017                                                               *
 *                                                                                                 *
 * This class handles manual bone rotations, which need to happen after animations have been       *
 * applied. Currently has only RotateOnDamage, but other manual bone rotation code will end up     *
 * here.                                                                                           *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - March 26th, 2017                                            *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;

public class ManualBoneRotator : MonoBehaviour
{
    public enum DamageRotationDirection
    {
        Back,
        Left,
        Right,
        Center,
        None
    }

    public Transform m_LowerSpine;

    private DamageRotationDirection m_RotationDir = DamageRotationDirection.None;
    private float m_RotSpeed = 4;
    private float m_PosRotAmount = 20;
    private float m_NegRotAmount = 340;
    private float m_AlmostEqualsBuffer = 10;
    private float m_RotateFromDamageTimer = 0.5f;
    private Vector3 m_StartRot;
    private Vector3 m_TempRotAfterLerp = Vector3.zero;
    private bool m_RotatedRight = false;
    private bool m_RotatedLeft = false;
    private bool m_RotatedBack = false;

    private bool m_RotatingSpine = false;

    void Start()
    {

    }
    
    void Update()
    {
        if (m_RotateFromDamageTimer < 0.5f)
        {
            m_RotateFromDamageTimer += Time.deltaTime;
        }
    }

    void LateUpdate()
    {
        if (m_RotatingSpine)
        {
            RotateOnDamage();
        }
    }

    public void HandleRotationOnDamage()
    {
        if (m_RotateFromDamageTimer >= 0.5f && m_LowerSpine != null)
        {
            m_RotatingSpine = true;
            m_RotateFromDamageTimer = 0;

            m_StartRot = m_LowerSpine.localEulerAngles;

            int randRotNum = Random.Range(0, 3);
            m_RotationDir = (DamageRotationDirection)randRotNum;
        }
    }

    void RotateOnDamage()
    {
        //TODO: This should be cleaned up later....like, after R4 lul (JR)
        Vector3 currentRot = m_TempRotAfterLerp;

        switch (m_RotationDir)
        {
            case DamageRotationDirection.Back:
                m_RotatedBack = true;
                currentRot.z += m_RotSpeed;

                m_LowerSpine.localEulerAngles = currentRot;

                m_TempRotAfterLerp = m_LowerSpine.localEulerAngles;

                if (m_TempRotAfterLerp.z > m_PosRotAmount)
                {
                    m_RotationDir = DamageRotationDirection.Center;
                }

                break;
            case DamageRotationDirection.Left:
                m_RotatedLeft = true;
                currentRot.y += m_RotSpeed;

                m_LowerSpine.localEulerAngles = currentRot;

                m_TempRotAfterLerp = m_LowerSpine.localEulerAngles;

                if (m_TempRotAfterLerp.y > m_PosRotAmount)
                {
                    m_RotationDir = DamageRotationDirection.Center;
                }
                break;
            case DamageRotationDirection.Right:
                m_RotatedRight = true;
                currentRot.y -= m_RotSpeed;

                m_LowerSpine.localEulerAngles = currentRot;

                m_TempRotAfterLerp = m_LowerSpine.localEulerAngles;

                if (m_TempRotAfterLerp.y < m_NegRotAmount)
                {
                    m_RotationDir = DamageRotationDirection.Center;
                }
                break;
            case DamageRotationDirection.Center:

                if (m_RotatedBack)
                {
                    currentRot.z -= m_RotSpeed;

                    if (MathUtils.AlmostEquals(m_TempRotAfterLerp.z, m_StartRot.z, m_AlmostEqualsBuffer))
                    {
                        m_RotatedBack = false;
                        m_LowerSpine.localEulerAngles = new Vector3(m_LowerSpine.localEulerAngles.x, m_LowerSpine.localEulerAngles.y, m_StartRot.z);
                        m_RotationDir = DamageRotationDirection.None;

                    }
                }
                else if (m_RotatedLeft)
                {
                    currentRot.y -= m_RotSpeed;

                    if (MathUtils.AlmostEquals(m_TempRotAfterLerp.y, m_StartRot.y, m_AlmostEqualsBuffer))
                    {
                        m_RotatedLeft = false;
                        m_LowerSpine.localEulerAngles = new Vector3(m_LowerSpine.localEulerAngles.x, m_StartRot.y, m_LowerSpine.localEulerAngles.z);
                        m_RotationDir = DamageRotationDirection.None;

                    }
                }
                else if (m_RotatedRight)
                {
                    currentRot.y += m_RotSpeed;

                    if (MathUtils.AlmostEquals(m_TempRotAfterLerp.y, m_StartRot.y, m_AlmostEqualsBuffer))
                    {
                        m_RotatedRight = false;
                        m_LowerSpine.localEulerAngles = new Vector3(m_LowerSpine.localEulerAngles.x, m_StartRot.y, m_LowerSpine.localEulerAngles.z);
                        m_RotationDir = DamageRotationDirection.None;
                    }
                }

                m_LowerSpine.localEulerAngles = currentRot;

                m_TempRotAfterLerp = m_LowerSpine.localEulerAngles;

                break;
            case DamageRotationDirection.None:
                m_TempRotAfterLerp = Vector3.zero;
                m_RotatingSpine = false;

                break;
            default:
                break;
        }
    }
}
