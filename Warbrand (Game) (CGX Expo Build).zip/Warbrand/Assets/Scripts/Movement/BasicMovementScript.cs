﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        BasicMovementScript                                                            *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            October 7th, 2016                                                              *
 *                                                                                                 *
 * This file should be attached to a GameObject that needs to move. It holds simple Newtonian      *
 * physics options to play around with.                                                            *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - October 7th, 2016                                       *
 * V 1.1 - Switched input from Unity's InputManager to Ruthless Fusion Games InputManager          *
 *         (Evan Campbell) - October 10th, 2016                                                    *
\***************************************************************************************************/

using System;
using UnityEngine;
using System.Collections.Generic;

[RequireComponent(typeof(Rigidbody))]
public class BasicMovementScript : MonoBehaviour
{

    //
    // Public
    //
    private float WalkAcceleration = 80.0f;
    private float AirAcceleration = 20f;
    private float MaxVelocity = 7.5f;
    [HideInInspector]
    public bool CanJump = true;
    [HideInInspector]
    public ClampedInt NumberOfJumps = new ClampedInt(1, 0, 1);
    public float SlowSpeedBooster = 5f; // If the speed is lower than this, the player will start off at a higher speed
    public float JumpPower = 12.0f;
    public float StoppingPower = 60.0f;

    [HideInInspector]
    public bool IsStunned = false;

    [HideInInspector]
    public Vector3 Velocity { get { return m_RigidBody.velocity; } }
    [HideInInspector]
    public bool IsGrounded
    {
        get { return m_IsGrounded; }
        private set { m_IsGrounded = value; }
    }
    [HideInInspector]
    public GameInputComponent GameInput { get { return m_Input; } set { m_Input = value; } }

    //
    // Private
    //

    private const string m_VerticalString = "Vertical";
    private const string m_HorizontalString = "Horizontal";
    private const string m_JumpingString = "Jumping";
    private const string m_FallString = "Fall";
    private const string m_GroundedString = "Grounded";

    private const string m_UnplacedObjectsMask = "UnplacedObjects";
    private const string m_QuarkCameraMask = "QuarkCamera";
    private const string m_RagdollMask = "Ragdoll";
    private const string m_ShieldMask = "Shield";
    private const string m_WallsMask = "Walls";

    private Animator m_Animator;
    private int m_VerticalHash = Animator.StringToHash(m_VerticalString);
    private int m_HorizontalHash = Animator.StringToHash(m_HorizontalString);
    private int m_JumpHash = Animator.StringToHash(m_JumpingString);
    private int m_FallingHash = Animator.StringToHash(m_FallString);
    private int m_GroundedHash = Animator.StringToHash(m_GroundedString);
    private Vector3 m_LastInput;

    //For use in case the player is slowed by another player's ability. e.g. Quark's electric wall
    //1 is equivalent to 100% move speed
    private List<float> m_MovementSpeedModifiers;
    private float m_MovementSpeedPercent = 1;
    private AudioSource m_FootstepAudioSource;
    private Rigidbody m_RigidBody;
    private Player m_Player;
    //private float m_CurrentTargetSpeed = 8f;
    private GameInputComponent m_Input;
    private bool m_OverrideAirControls;
    private bool m_JustJumped = false;
    private bool m_IsGrounded = false;
    private bool m_WasPreviouslyGrounded = false;
    private bool m_AffectedByOutsideForce = false;
    private Vector3 m_GroundNormal = Vector3.zero;
    private int m_LayerMask;
    private bool m_Initializing = true;

    public void OverrideAirControls(bool aOverride) { m_OverrideAirControls = aOverride; }

    void Start()
    {
        m_Player = GetComponent<Player>();
        m_FootstepAudioSource = m_Player.AudioSourceFootstep;
        m_RigidBody = m_Player.RigidBody;

        m_MovementSpeedModifiers = new List<float>();
        m_MovementSpeedModifiers.Capacity = 5;
        for(int i = 0; i < m_MovementSpeedModifiers.Capacity; i++)
        {
            m_MovementSpeedModifiers.Add(0.0f);
        }

        m_Animator = GetComponent<Animator>();
    }
    
    void FixedUpdate()
    {
        if (m_Initializing)
        {
            m_Initializing = false;
            m_LayerMask = ~((1 << gameObject.layer) |
                (1 << LayerMask.NameToLayer(m_UnplacedObjectsMask)) |
                (1 << LayerMask.NameToLayer(m_QuarkCameraMask)) |
                (1 << LayerMask.NameToLayer(m_RagdollMask)) |
                (1 << LayerMask.NameToLayer(m_ShieldMask)) |
                (1 << LayerMask.NameToLayer(m_WallsMask)));
        }
        // Check to see if we're grounded
        CheckGround();

        // If we're on the ground, restore the number of jumps
        if (IsGrounded)
            NumberOfJumps.Value = NumberOfJumps.MaximumValue;

        // If the player is not stunned, move normally
        if (m_Player.StunTime <= 0.0f && m_Player.AbilityBlockingMovement == false)
        {
            bool isJumping = false;
            m_Animator.SetBool(m_JumpHash, false);

            if (GameInput != null)
            {
                if ((GameInput.GetInput(InputName.Jump, InputType.ButtonPressed, false) > 0f || GameInput.GetInput(InputName.Jump, InputType.ButtonHeld, false) > 0f) && NumberOfJumps.Value > 0 && CanJump && !IsStunned)
                {
                    isJumping = true;
                    m_Animator.SetBool(m_JumpHash, true);
                    NumberOfJumps.Value--;
                }
                UpdateMovement(GetMoveDirection(), isJumping);
            }

        }
        // If the player is stunned, have the player stop and prevent movement/jump input.
        else
            UpdateMovement(Vector3.zero, false);

#if UNITY_EDITOR
            //DrawDebug();
#endif
    }

    private void DrawDebug()
    {
        Color forwardColour = Color.green;
        Color velocityColour = Color.yellow;

#if UNITY_EDITOR
        // Draw Forward
        DebugManager.DrawLine(transform.position, transform.position + transform.forward * 10f, forwardColour, Developmer.AllDevelopmers);

        // Draw Velocity
        DebugManager.DrawLine(transform.position, transform.position + m_RigidBody.velocity, velocityColour, Developmer.AllDevelopmers);
#endif
    }

    void UpdateMovement(Vector3 aMovementDirection, bool aJumping)
    {
        // Get the current velocity and remove the y value for simplicities sake
        Vector3 velocity = m_RigidBody.velocity;
        float originalY = velocity.y;
        velocity.y = 0f;

        if (IsGrounded || m_OverrideAirControls)
        {
            // If we're not moving, reduce velocity
            if (aMovementDirection == Vector3.zero)
                velocity = Vector3.Lerp(velocity, Vector3.zero, Time.fixedDeltaTime * StoppingPower);
            // If we're too slow, speed up at a quicker rate
            else if (velocity.sqrMagnitude < SlowSpeedBooster * SlowSpeedBooster)
                velocity += aMovementDirection * 3f * Time.fixedDeltaTime * WalkAcceleration;
            // If we are moving in the same direction than the velocity, move normally
            else if (Vector3.Dot(velocity, aMovementDirection) > 0.0f)
                velocity += aMovementDirection * Time.fixedDeltaTime * WalkAcceleration;
            // If we are not moving in the same direction than the velocity, apply more force to stop
            else
            {
                if (Vector3.Dot(aMovementDirection, velocity + aMovementDirection * 2f * Time.fixedDeltaTime * WalkAcceleration) > 0)
                    velocity += aMovementDirection * 2f * Time.fixedDeltaTime * WalkAcceleration;
                else
                    velocity = Vector3.zero;
            }

            // float velocityMagnitude = Vector3.Magnitude(velocity);
        }
        else
        {
            aMovementDirection.y = 0;
            velocity += aMovementDirection * Time.fixedDeltaTime * AirAcceleration;
        }

        velocity = Vector3.ClampMagnitude(velocity, MaxVelocity * m_MovementSpeedPercent);

        float deliberateYMovement = velocity.y;

        if(m_JustJumped)
        {
            deliberateYMovement = 0;
        }

        // Return the y value of the velocty
        velocity.y = originalY + deliberateYMovement;

        //If the player didn't jump, make sure their y velocity is only what we want it to be
        if (IsGrounded && !m_JustJumped)
        {
            velocity.y = deliberateYMovement;
        }

        //If the player is jumping or falling off a ledge, set their y velocity to 0
        if (aJumping || (!IsGrounded && m_WasPreviouslyGrounded && !m_JustJumped))
        {
            velocity.y = 0;
            m_Animator.SetBool(m_FallingHash, true);
        }

        // Give the rigid body its velocity back
        m_RigidBody.velocity = velocity;

        if (aJumping)
        {
            m_RigidBody.AddForce(Vector3.up * JumpPower, ForceMode.Impulse);
            m_JustJumped = true;
            //move the player up a little bit so that it can't instantly fail the grounded check
            transform.Translate(Vector3.up * 0.06f);
        }

        if(m_RigidBody.velocity.y < 0)
        {
            m_JustJumped = false;
        }
        m_WasPreviouslyGrounded = IsGrounded;
        m_AffectedByOutsideForce = false;

        //Debug.Log(m_RigidBody.velocity);
    }

    private Vector3 GetMoveDirection()
    {
        Vector3 input;
        if (!IsStunned)
            input = new Vector3(GameInput.GetInput(InputName.Horizontal, InputType.ButtonHeld, false), 0, GameInput.GetInput(InputName.Vertical, InputType.ButtonHeld, false));
        else
            input = Vector3.zero;
        Vector3 dir = input;
        dir = transform.TransformDirection(dir);

        m_Animator.SetFloat(m_VerticalHash, input.z);
        m_Animator.SetFloat(m_HorizontalHash, input.x);

        //Use cross product to find a direction that is perpendicular to the player's orientation and the ground normal
        Vector3 orthagonalToPlayerAndSurface = Vector3.Cross(m_GroundNormal, transform.forward);
        orthagonalToPlayerAndSurface.Normalize();

        //Use cross product to find a direction that is perpendicular to the direction we just got and the ground normal
        //This should return a direction along the surface.
        Vector3 directionAlongNormal = Vector3.Cross(orthagonalToPlayerAndSurface, m_GroundNormal);
        directionAlongNormal.Normalize();

        //The x and z are normalized, but the y is independant of them
        dir = dir.normalized;
        dir.y = (directionAlongNormal.y * input.z) + (orthagonalToPlayerAndSurface.y * input.x);

        //// Make sure that the y direction isn't taken into account for speed
        //dir.y = 0;

        //if(dir.z!=0f || dir.x!=0)
        //{
        //    if(IsGrounded)
        //    {
        //        if(!m_FootstepAudioSource.isPlaying)
        //        {
        //            m_FootstepAudioSource.pitch = UnityEngine.Random.Range(0.85f, 1.0f);
        //            m_FootstepAudioSource.volume = UnityEngine.Random.Range(0.4f, 0.7f);

        //            m_FootstepAudioSource.Play();
        //        }
        //    }
        //}

        // Return it
        return dir;
    }

    public void PlayFootstepSound()
    {
        if (!m_FootstepAudioSource.isPlaying)
        {
            m_FootstepAudioSource.pitch = UnityEngine.Random.Range(0.85f, 1.0f);
            m_FootstepAudioSource.volume = UnityEngine.Random.Range(0.4f, 0.7f);

            m_FootstepAudioSource.Play();
        }
    }


    public void CheckGround()
    {
        // RECODE: Implement Tags into this, make sure that the game object we're hitting actually is ground
        //bool wasPreviouslyGrounded = IsGrounded;

        //do a longer raycast if the player is above a ramp. This should improve ramp movement and minimize bugs
        float raycastLength = 0.7f + 1.5f * (1 - m_GroundNormal.y);

        Vector3 sphereCastPosition = transform.position + new Vector3(0.0f, 0.80f, 0.0f);

        if(m_JustJumped)
        {
            raycastLength = 0.05f;
        }
        RaycastHit hit;
        if (Physics.SphereCast(sphereCastPosition, 0.20f, -Vector3.up, out hit, raycastLength, m_LayerMask, QueryTriggerInteraction.Ignore) && !m_AffectedByOutsideForce)
        {
            //Make sure the sphere-cast doesn't just hit the player
            if (hit.collider.gameObject != gameObject)
            {
                float newYPos = Mathf.Lerp(transform.position.y, hit.point.y, 0.5f);
                //Debug.Log(newYPos);
                Vector3 pos = transform.position;
                pos.y = newYPos;
                transform.position = pos;

                IsGrounded = true;
                m_Animator.SetBool(m_GroundedHash, true);
                m_Animator.SetBool(m_FallingHash, false);
                m_RigidBody.useGravity = false;
                m_JustJumped = false;
                m_GroundNormal = hit.normal;
            }
        }
        else
        {
            IsGrounded = false;
            m_Animator.SetBool(m_GroundedHash, false);
            m_RigidBody.useGravity = true;
        }
    }

    public void AddMovementSpeedModifier(float modifier)
    {
        AddRemoveModifier.AddModifier(ref m_MovementSpeedModifiers, modifier);
        AddRemoveModifier.UpdateModifierPercent(ref m_MovementSpeedModifiers, ref m_MovementSpeedPercent);
    }

    public void RemoveMovementSpeedModifier(float modifier)
    {
        AddRemoveModifier.RemoveModifier(ref m_MovementSpeedModifiers, modifier);
        AddRemoveModifier.UpdateModifierPercent(ref m_MovementSpeedModifiers, ref m_MovementSpeedPercent);
    }

    public void AffectedByOutsideForce()
    {
        IsGrounded = false;
        m_AffectedByOutsideForce = true;
        m_JustJumped = true;
    }
}