﻿using UnityEngine;
using System.Collections;

public class BaseRagdollInfo : MonoBehaviour
{
    //TODO: replace these gameobjects with rigidbodies so using getcomponent isn't necessary
    public GameObject MarinePelvis;
    public GameObject MarineLLegThigh;
    public GameObject MarineLLegCalf1;
    public GameObject MarineLLegCalf2;
    public GameObject MarineLLegCalf3;
    public GameObject MarineLLegAnkle;
    public GameObject MarineLLegToe;
    public GameObject MarineRThigh;
    public GameObject MarineRCalf1;
    public GameObject MarineRCalf2;
    public GameObject MarineRCalf3;
    public GameObject MarineRAnkle;
    public GameObject MarineRToe;
    public GameObject MarineSpine1;
    public GameObject MarineSpine2;
    public GameObject MarineSpine3;
    public GameObject MarineRibcage;
    public GameObject MarineLArmCollarbone;
    public GameObject MarineLArmUpperarm;
    public GameObject MarineLArmForearm1;
    public GameObject MarineLArmForearm2;
    public GameObject MarineLArmForearm3;
    public GameObject MarineLArmPalm;
    public GameObject MarineNeck1;
    public GameObject MarineNeck2;
    public GameObject MarineHead;
    public GameObject MarineRCollarbone;
    public GameObject MarineRUpperarm;
    public GameObject MarineRForearm1;
    public GameObject MarineRForearm2;
    public GameObject MarineRForearm3;
    public GameObject MarineRPalm;

	void Start ()
    {
	
	}
	
	void Update ()
    {
	
	}

    public virtual void SetBoneInfo(BaseRagdollInfo info)
    {
        MarinePelvis.transform.position = info.MarinePelvis.transform.position;
        MarinePelvis.transform.rotation = info.MarinePelvis.transform.rotation;

        MarineLLegThigh.transform.position = info.MarineLLegThigh.transform.position;
        MarineLLegThigh.transform.rotation = info.MarineLLegThigh.transform.rotation;

        MarineLLegCalf1.transform.position = info.MarineLLegCalf1.transform.position;
        MarineLLegCalf1.transform.rotation = info.MarineLLegCalf1.transform.rotation;

        MarineLLegCalf2.transform.position = info.MarineLLegCalf2.transform.position;
        MarineLLegCalf2.transform.rotation = info.MarineLLegCalf2.transform.rotation;

        MarineLLegCalf3.transform.position = info.MarineLLegCalf3.transform.position;
        MarineLLegCalf3.transform.rotation = info.MarineLLegCalf3.transform.rotation;

        MarineLLegAnkle.transform.position = info.MarineLLegAnkle.transform.position;
        MarineLLegAnkle.transform.rotation = info.MarineLLegAnkle.transform.rotation;

        MarineLLegToe.transform.position = info.MarineLLegToe.transform.position;
        MarineLLegToe.transform.rotation = info.MarineLLegToe.transform.rotation;

        MarineRThigh.transform.position = info.MarineRThigh.transform.position;
        MarineRThigh.transform.rotation = info.MarineRThigh.transform.rotation;

        MarineRCalf1.transform.position = info.MarineRCalf1.transform.position;
        MarineRCalf1.transform.rotation = info.MarineRCalf1.transform.rotation;

        MarineRCalf2.transform.position = info.MarineRCalf2.transform.position;
        MarineRCalf2.transform.rotation = info.MarineRCalf2.transform.rotation;

        MarineRCalf3.transform.position = info.MarineRCalf3.transform.position;
        MarineRCalf3.transform.rotation = info.MarineRCalf3.transform.rotation;

        MarineRAnkle.transform.position = info.MarineRAnkle.transform.position;
        MarineRAnkle.transform.rotation = info.MarineRAnkle.transform.rotation;

        MarineRToe.transform.position = info.MarineRToe.transform.position;
        MarineRToe.transform.rotation = info.MarineRToe.transform.rotation;

        MarineSpine1.transform.position = info.MarineSpine1.transform.position;
        MarineSpine1.transform.rotation = info.MarineSpine1.transform.rotation;

        MarineSpine2.transform.position = info.MarineSpine2.transform.position;
        MarineSpine2.transform.rotation = info.MarineSpine2.transform.rotation;

        MarineSpine3.transform.position = info.MarineSpine3.transform.position;
        MarineSpine3.transform.rotation = info.MarineSpine3.transform.rotation;

        MarineRibcage.transform.position = info.MarineRibcage.transform.position;
        MarineRibcage.transform.rotation = info.MarineRibcage.transform.rotation;

        MarineLArmCollarbone.transform.position = info.MarineLArmCollarbone.transform.position;
        MarineLArmCollarbone.transform.rotation = info.MarineLArmCollarbone.transform.rotation;

        MarineLArmUpperarm.transform.position = info.MarineLArmUpperarm.transform.position;
        MarineLArmUpperarm.transform.rotation = info.MarineLArmUpperarm.transform.rotation;

        MarineLArmForearm1.transform.position = info.MarineLArmForearm1.transform.position;
        MarineLArmForearm1.transform.rotation = info.MarineLArmForearm1.transform.rotation;

        MarineLArmForearm2.transform.position = info.MarineLArmForearm2.transform.position;
        MarineLArmForearm2.transform.rotation = info.MarineLArmForearm2.transform.rotation;

        MarineLArmForearm3.transform.position = info.MarineLArmForearm3.transform.position;
        MarineLArmForearm3.transform.rotation = info.MarineLArmForearm3.transform.rotation;

        MarineLArmPalm.transform.position = info.MarineLArmPalm.transform.position;
        MarineLArmPalm.transform.rotation = info.MarineLArmPalm.transform.rotation;

        MarineNeck1.transform.position = info.MarineNeck1.transform.position;
        MarineNeck1.transform.rotation = info.MarineNeck1.transform.rotation;

        MarineNeck2.transform.position = info.MarineNeck2.transform.position;
        MarineNeck2.transform.rotation = info.MarineNeck2.transform.rotation;

        MarineHead.transform.position = info.MarineHead.transform.position;
        MarineHead.transform.rotation = info.MarineHead.transform.rotation;

        MarineRCollarbone.transform.position = info.MarineRCollarbone.transform.position;
        MarineRCollarbone.transform.rotation = info.MarineRCollarbone.transform.rotation;

        MarineRUpperarm.transform.position = info.MarineRUpperarm.transform.position;
        MarineRUpperarm.transform.rotation = info.MarineRUpperarm.transform.rotation;

        MarineRForearm1.transform.position = info.MarineRForearm1.transform.position;
        MarineRForearm1.transform.rotation = info.MarineRForearm1.transform.rotation;

        MarineRForearm2.transform.position = info.MarineRForearm2.transform.position;
        MarineRForearm2.transform.rotation = info.MarineRForearm2.transform.rotation;

        MarineRForearm3.transform.position = info.MarineRForearm3.transform.position;
        MarineRForearm3.transform.rotation = info.MarineRForearm3.transform.rotation;

        MarineRPalm.transform.position = info.MarineRPalm.transform.position;
        MarineRPalm.transform.rotation = info.MarineRPalm.transform.rotation;
    }

    //Pass in a player's ragdoll info. This will parse their hitboxes and see if there are forces to be applied to this ragdoll
    public void ApplyForces(BaseRagdollInfo info)
    {
        PlayerHitboxScript hitboxScript;

        hitboxScript = info.MarinePelvis.GetComponent<PlayerHitboxScript>();
        if(hitboxScript.ForceApplied)
        {
            MarinePelvis.GetComponent<Rigidbody>().AddForceAtPosition(hitboxScript.ForceDirection, hitboxScript.ForceLocation, ForceMode.Impulse);
            hitboxScript.ClearForce();
        }

        hitboxScript = info.MarineLLegThigh.GetComponent<PlayerHitboxScript>();
        if (hitboxScript.ForceApplied)
        {
            MarineLLegThigh.GetComponent<Rigidbody>().AddForceAtPosition(hitboxScript.ForceDirection, hitboxScript.ForceLocation, ForceMode.Impulse);
            hitboxScript.ClearForce();
        }

        hitboxScript = info.MarineLLegCalf1.GetComponent<PlayerHitboxScript>();
        if (hitboxScript.ForceApplied)
        {
            MarineLLegCalf1.GetComponent<Rigidbody>().AddForceAtPosition(hitboxScript.ForceDirection, hitboxScript.ForceLocation, ForceMode.Impulse);
            hitboxScript.ClearForce();
        }

        hitboxScript = info.MarineRThigh.GetComponent<PlayerHitboxScript>();
        if (hitboxScript.ForceApplied)
        {
            MarineRThigh.GetComponent<Rigidbody>().AddForceAtPosition(hitboxScript.ForceDirection, hitboxScript.ForceLocation, ForceMode.Impulse);
            hitboxScript.ClearForce();
        }

        hitboxScript = info.MarineRCalf1.GetComponent<PlayerHitboxScript>();
        if (hitboxScript.ForceApplied)
        {
            MarineRCalf1.GetComponent<Rigidbody>().AddForceAtPosition(hitboxScript.ForceDirection, hitboxScript.ForceLocation, ForceMode.Impulse);
            hitboxScript.ClearForce();
        }

        hitboxScript = info.MarineSpine2.GetComponent<PlayerHitboxScript>();
        if (hitboxScript.ForceApplied)
        {
            MarineSpine2.GetComponent<Rigidbody>().AddForceAtPosition(hitboxScript.ForceDirection, hitboxScript.ForceLocation, ForceMode.Impulse);
            hitboxScript.ClearForce();
        }

        hitboxScript = info.MarineLArmUpperarm.GetComponent<PlayerHitboxScript>();
        if (hitboxScript.ForceApplied)
        {
            MarineLArmUpperarm.GetComponent<Rigidbody>().AddForceAtPosition(hitboxScript.ForceDirection, hitboxScript.ForceLocation, ForceMode.Impulse);
            hitboxScript.ClearForce();
        }

        hitboxScript = info.MarineLArmForearm1.GetComponent<PlayerHitboxScript>();
        if (hitboxScript.ForceApplied)
        {
            MarineLArmForearm1.GetComponent<Rigidbody>().AddForceAtPosition(hitboxScript.ForceDirection, hitboxScript.ForceLocation, ForceMode.Impulse);
            hitboxScript.ClearForce();
        }

        hitboxScript = info.MarineHead.GetComponent<PlayerHitboxScript>();
        if (hitboxScript.ForceApplied)
        {
            MarineHead.GetComponent<Rigidbody>().AddForceAtPosition(hitboxScript.ForceDirection, hitboxScript.ForceLocation, ForceMode.Impulse);
            hitboxScript.ClearForce();
        }

        hitboxScript = info.MarineRUpperarm.GetComponent<PlayerHitboxScript>();
        if (hitboxScript.ForceApplied)
        {
            MarineRUpperarm.GetComponent<Rigidbody>().AddForceAtPosition(hitboxScript.ForceDirection, hitboxScript.ForceLocation, ForceMode.Impulse);
            hitboxScript.ClearForce();
        }

        hitboxScript = info.MarineRForearm1.GetComponent<PlayerHitboxScript>();
        if (hitboxScript.ForceApplied)
        {
            MarineRForearm1.GetComponent<Rigidbody>().AddForceAtPosition(hitboxScript.ForceDirection, hitboxScript.ForceLocation, ForceMode.Impulse);
            hitboxScript.ClearForce();
        }
    }
}
