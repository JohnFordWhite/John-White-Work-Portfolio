﻿using UnityEngine;
using System.Collections;

public class LeeroyRagdollInfo : BaseRagdollInfo
{
	void Start ()
    {
	
	}
	
	void Update ()
    {
	
	}

    public override void SetBoneInfo(BaseRagdollInfo info)
    {
        base.SetBoneInfo(info);
    }
}
