﻿using UnityEngine;
using System.Collections;

public class QuarkRagdollInfo : BaseRagdollInfo
{
    public GameObject BaseFrame;

    public override void SetBoneInfo(BaseRagdollInfo info)
    {
        base.SetBoneInfo(info);

        QuarkRagdollInfo boneInfo = info as QuarkRagdollInfo;

        BaseFrame.transform.position = boneInfo.BaseFrame.transform.position;
        BaseFrame.transform.rotation = boneInfo.BaseFrame.transform.rotation;
    }
}
