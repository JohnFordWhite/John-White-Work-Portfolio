﻿using UnityEngine;
using System.Collections;

public class PaigeRagdollInfo : BaseRagdollInfo
{
    public GameObject MarineRibcageBone001;
    public GameObject MarineRibcageBone002;
    public GameObject GunFrame;

    public override void SetBoneInfo(BaseRagdollInfo info)
    {
        base.SetBoneInfo(info);

        PaigeRagdollInfo boneInfo = info as PaigeRagdollInfo;

        MarineRibcageBone001.transform.position = boneInfo.MarineRibcageBone001.transform.position;
        MarineRibcageBone001.transform.rotation = boneInfo.MarineRibcageBone001.transform.rotation;

        MarineRibcageBone002.transform.position = boneInfo.MarineRibcageBone002.transform.position;
        MarineRibcageBone002.transform.rotation = boneInfo.MarineRibcageBone002.transform.rotation;

        GunFrame.transform.position = boneInfo.GunFrame.transform.position;
        GunFrame.transform.rotation = boneInfo.GunFrame.transform.rotation;
    }
}
