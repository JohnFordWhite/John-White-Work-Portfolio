﻿using UnityEngine;
using System.Collections;

public class ZephRagdollInfo : BaseRagdollInfo
{
    public GameObject KusarigamaGripPoint;

    public override void SetBoneInfo(BaseRagdollInfo info)
    {
        base.SetBoneInfo(info);

        ZephRagdollInfo boneInfo = info as ZephRagdollInfo;

        KusarigamaGripPoint.transform.position = boneInfo.KusarigamaGripPoint.transform.position;
        KusarigamaGripPoint.transform.rotation = boneInfo.KusarigamaGripPoint.transform.rotation;
    }
}
