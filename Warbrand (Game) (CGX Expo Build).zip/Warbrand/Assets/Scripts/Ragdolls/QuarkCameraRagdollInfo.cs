﻿using UnityEngine;
using System.Collections;

public class QuarkCameraRagdollInfo : MonoBehaviour
{
    [SerializeField]
    private float ExplosionForce = 2;
    public GameObject CameraParticleSystems;

    public GameObject Body;
    public GameObject Camera;

	public void SetBoneInfo(QuarkCameraRagdollInfo info)
    {
        Body.transform.position = info.Body.transform.position;
        Body.transform.rotation = info.Body.transform.rotation;
        Body.GetComponent<Rigidbody>().AddForce((Body.transform.position - CameraParticleSystems.transform.position).normalized * ExplosionForce, ForceMode.Impulse);

        Camera.transform.position = info.Camera.transform.position;
        Camera.transform.rotation = info.Camera.transform.rotation;
        Camera.GetComponent<Rigidbody>().AddForce((Camera.transform.position - CameraParticleSystems.transform.position).normalized * ExplosionForce, ForceMode.Impulse);
    }
}
