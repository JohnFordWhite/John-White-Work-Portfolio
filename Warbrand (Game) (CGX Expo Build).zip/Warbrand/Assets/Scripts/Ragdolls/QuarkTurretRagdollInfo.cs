﻿using UnityEngine;
using System.Collections;

public class QuarkTurretRagdollInfo : MonoBehaviour
{
    [SerializeField]
    private float ExplosionForce = 5;
    public GameObject TurretParticleSystems;

    public GameObject Base;
    public GameObject Stand;
    public GameObject TurretHead;
    void Start ()
    {
    }
	
	void Update ()
    {
    }

    public void SetBoneInfo(QuarkTurretRagdollInfo info)
    {
        Base.transform.position = info.Base.transform.position;
        Base.transform.rotation = info.Base.transform.rotation;
        Base.GetComponent<Rigidbody>().AddForce((Base.transform.position - TurretParticleSystems.transform.position).normalized * ExplosionForce, ForceMode.Impulse);

        Stand.transform.position = info.Stand.transform.position;
        Stand.transform.rotation = info.Stand.transform.rotation;
        Stand.GetComponent<Rigidbody>().AddForce((Stand.transform.position - TurretParticleSystems.transform.position).normalized * ExplosionForce, ForceMode.Impulse);

        TurretHead.transform.position = info.TurretHead.transform.position;
        TurretHead.transform.rotation = info.TurretHead.transform.rotation;
        TurretHead.GetComponent<Rigidbody>().AddForce((TurretHead.transform.position - TurretParticleSystems.transform.position).normalized * ExplosionForce, ForceMode.Impulse);
    }
}
