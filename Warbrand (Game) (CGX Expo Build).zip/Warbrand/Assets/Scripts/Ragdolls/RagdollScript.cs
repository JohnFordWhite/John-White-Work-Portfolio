﻿using UnityEngine;
using System.Collections;

public class RagdollScript : MonoBehaviour
{
    public float DespawnTime = 10.0f;
    public float MassMultiplier = 1.0f;

    private float m_DespawnTimer;

	void Start ()
    {
        m_DespawnTimer = DespawnTime;

        Rigidbody[] rigidbodies = GetComponentsInChildren<Rigidbody>();
        for(int i = 0; i < rigidbodies.Length; i++)
        {
            rigidbodies[i].mass = rigidbodies[i].mass * MassMultiplier;
        }
	}
	
	void Update ()
    {
        m_DespawnTimer -= Time.deltaTime;
        
        if(m_DespawnTimer <= 0)
        {
            GameObject.Destroy(gameObject);
        }
	}
}
