﻿using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SplashScreenScript : GameMenu
{
    public string[] ButtonsThatCanSkip;
    public Graphic[] FadeImages;
    public float TimeSpentFading = 0.5f;
    public float TimeShowingImages = 1.0f;

    private float m_CurrentTime = 0f;

    private const string m_MainMenuSceneName = "MainMenuScene";

    private int m_CurrentImageShowing;

    protected override void Start()
    {
        base.Start();
        
        for (int i = 0; i < FadeImages.Length; i++)
        {
            Graphic image = FadeImages[i];

            image.gameObject.SetActive(false);
        }

        m_CurrentImageShowing = -1;
        IncrementImages();
    }

	protected override void Update()
    {
        m_CurrentTime += Time.deltaTime;

        float alpha = 0f;

        if (EnableInputs == true && IsSubmitButtonPressed())
        {
            EnableInputs = false;
            GoToNextScene();
            return;
        }

        // Fading In
        if (m_CurrentTime < TimeSpentFading)
        {
            alpha = Mathf.Lerp(0f, 1f, m_CurrentTime / TimeSpentFading);
        }

        // Showing
        else if (m_CurrentTime - TimeSpentFading < TimeShowingImages)
        {
            alpha = 1f;
        }

        // Fading Out
        else if (m_CurrentTime - (TimeSpentFading + TimeShowingImages) < TimeSpentFading)
        {
            alpha = Mathf.Lerp(1f, 0f, (m_CurrentTime - (TimeSpentFading + TimeShowingImages)) / TimeSpentFading);
        }
        else
            IncrementImages();

        // Update the opacity on the current image.
        if (m_CurrentImageShowing >= 0 && m_CurrentImageShowing < FadeImages.Length)
        {
            Graphic im = FadeImages[m_CurrentImageShowing];
            Color col = im.color;
            col.a = alpha;
            im.color = col;
        }
	}

    void IncrementImages()
    {
        m_CurrentImageShowing++;

        // We have shown all of the images at this point
        if (m_CurrentImageShowing >= FadeImages.Length)
        {
            // Swap Scenes
            GoToNextScene();
        }
        else
        {
            m_CurrentTime = 0.0f;

            // Hide the previous image and show the next image.
            if (m_CurrentImageShowing - 1 >= 0)
            {
                FadeImages[m_CurrentImageShowing - 1].gameObject.SetActive(false);
            }
            FadeImages[m_CurrentImageShowing].gameObject.SetActive(true);
        }
    }

    void GoToNextScene()
    {
        //LoadingScreen.Instance.LoadScreenSceneSwitch(m_MainMenuSceneName, LoadSceneMode.Single, true);
        SceneManager.LoadScene(m_MainMenuSceneName);
    }
}
