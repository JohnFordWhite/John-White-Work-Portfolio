﻿using UnityEngine;
using System.Collections;

public class MainMenuCameraPivot : MonoBehaviour
{
    public float Speed = 0.1f;
	
	void Update ()
    {
        transform.Rotate(0f, Speed * Time.deltaTime, 0f);
	}
}
