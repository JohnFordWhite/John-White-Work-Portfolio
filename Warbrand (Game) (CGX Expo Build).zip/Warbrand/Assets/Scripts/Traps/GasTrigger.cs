﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        GasTrigger                                                                     *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            November 25th, 2016                                                            *
 *                                                                                                 *
 * Handles gas trap.                                                                               *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - November 25th, 2016                                         *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GasTrigger : MonoBehaviour
{
    //
    //Public
    //
    public bool m_GasActivated = false;
    public float GasTimer = 20f;
    public float TimeToNextGasCheck = 20f;
    public float ChanceToActivateOnCheck = 0.5f;

    //
    //Private
    //
    private Renderer m_GasTriggerRenderer;
    private ParticleSystem m_GasTrapParticleSys;
    private float m_GasActivatedTimer = 0f;
    private float m_GasActivatedDuration = 10f;
    private float m_GasDamage = 0.1f;
    private float m_WarningTime;
    private AudioSource m_AudioSource;
    private NavMeshObstacle m_Obstacle;
    private List<Player> m_PlayersHit = null;

    private WaitForSeconds WarningTimeWait = null;

    void Start()
    {
        m_GasTriggerRenderer = GetComponent<Renderer>();
        m_GasTriggerRenderer.material.color = Color.green;
        m_GasTrapParticleSys = GetComponentInChildren<ParticleSystem>();
        m_GasTrapParticleSys.Stop();
        m_AudioSource = GetComponent<AudioSource>();
        m_WarningTime = m_AudioSource.clip.length;

        m_PlayersHit = new List<Player>();
        m_PlayersHit.Capacity = Information.AllPlayers.Count;
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }

        WarningTimeWait = new WaitForSeconds(m_WarningTime);
        m_Obstacle = GetComponent<NavMeshObstacle>();
    }

    void Update()
    {
        GasTimer -= Time.deltaTime;
        m_Obstacle.enabled = m_GasActivated;

        if (GasTimer <= 0 && !m_GasActivated)
        {
            bool activateGas = UnityEngine.Random.value < ChanceToActivateOnCheck;

            if (activateGas)
            {
                StartCoroutine(WarnThenActivateGas());
            }

            GasTimer = TimeToNextGasCheck;
        }

        if(m_GasActivated)
        {
            for (int i = 0; i < m_PlayersHit.Count; i++)
            {
                m_PlayersHit[i] = null;
            }
            if(!m_GasTrapParticleSys.isPlaying)
                m_GasTrapParticleSys.Play();

            m_GasActivatedTimer -= Time.deltaTime;

            if (m_GasActivatedTimer <= 0)
            {
                m_GasTriggerRenderer.material.color = Color.green;
                m_GasActivated = false;
                m_GasActivatedTimer = m_GasActivatedDuration;
                return;
            }
        }
        else
        {
            m_GasTrapParticleSys.Stop();
        }
    }

    IEnumerator WarnThenActivateGas()
    {
        AudioUtils.SetVolumeByDistance(gameObject, false);
        m_AudioSource.Play();

        m_GasTriggerRenderer.material.color = Color.yellow;

        yield return WarningTimeWait;

        m_GasTriggerRenderer.material.color = Color.red;

        m_GasActivated = true;

    }

    void OnTriggerStay(Collider other)
    {
        Player player = null;

        PlayerHitboxScript hitbox = other.GetComponent<PlayerHitboxScript>();

        if (hitbox != null)
            player = hitbox.Owner;

        if (player != null)
        {
            if(!m_PlayersHit.Contains(player))
            {
                m_PlayersHit.Add(player);

                PoisonGasImageEffectScript poison = player.FirstPersonModelCamera.GetComponent<PoisonGasImageEffectScript>();

                if (m_GasActivated)
                {
                    player.Health.Damage(null, gameObject, m_GasDamage, DeathType.PoisonGas, false);

                    if (!player.IsAI)
                    {
                        poison.enabled = true;
                        poison.Poisoned = true;
                    }
                }
                else if (!player.IsAI)
                {
                    poison.Poisoned = false;
                }
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        Player player = null;

        PlayerHitboxScript hitbox = other.GetComponent<PlayerHitboxScript>();

        if (hitbox != null)
            player = hitbox.Owner;

        if(player != null && !player.IsAI)
        {
            player.FirstPersonModelCamera.GetComponent<PoisonGasImageEffectScript>().Poisoned = false;
        }
    }
}
