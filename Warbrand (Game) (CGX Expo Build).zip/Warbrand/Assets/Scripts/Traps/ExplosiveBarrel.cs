﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ExplosiveBarrel                                                                *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            November 25th, 2016                                                            *
 *                                                                                                 *
 * Handles explosive barrels                                                                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - November 25th, 2016                                         *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityStandardAssets.Effects;

public class ExplosiveBarrel : MonoBehaviour
{
    //
    //Public
    //
    public GameObject BarrelParticleSystems;
    public bool HasExploded = false;
    public float BarrelDestroyTime = 3.5f;
    private float RespawnTime = 20.0f;
    public float Radius = 7.5f;
    public float ExplosiveBarrelDamage = 50.0f;
    [HideInInspector]
    public Player Exploder = null;

    //
    //Private
    //
    private int m_LayerMask;
    private Health m_BarrelHealthComponent;
    private AudioSource m_AudioSource;
    private float m_DestroyBarrelTimer = 3.5f;
    private float m_RespawnTimer = 20.0f;
    private Vector3 m_InitialPosition;
    private Quaternion m_InitialRotation;
    private ParticleSystem[] m_Particles;
    private MeshRenderer[] m_Renderers;
    private List<Player> m_PlayersHit = null;

    private Rigidbody m_RigidBody;
    private BoxCollider m_BoxCollider;

    public ExplosionPhysicsForce ExplosionPhysicsForce
    {
        get
        {
            if (m_ExplosionPhysicsForce == null && BarrelParticleSystems != null)
            {
                m_ExplosionPhysicsForce = BarrelParticleSystems.GetComponent<ExplosionPhysicsForce>();
            }
            return m_ExplosionPhysicsForce;
        }
    }
    protected ExplosionPhysicsForce m_ExplosionPhysicsForce;

    void Start()
    {
        m_BarrelHealthComponent = GetComponent<Health>();
        m_AudioSource = GetComponent<AudioSource>();

        m_RigidBody = GetComponent<Rigidbody>();
        m_BoxCollider = GetComponent<BoxCollider>();

        m_DestroyBarrelTimer = BarrelDestroyTime;
        m_RespawnTimer = RespawnTime;

        m_InitialPosition = transform.position;
        m_InitialRotation = transform.rotation;

        m_Particles = BarrelParticleSystems.GetComponentsInChildren<ParticleSystem>();
        m_Renderers = GetComponentsInChildren<MeshRenderer>();

        m_PlayersHit = new List<Player>();
        m_PlayersHit.Capacity = Information.AllPlayers.Count;
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }

        m_LayerMask = ~((1 << LayerMask.NameToLayer("UnplacedObjects")) |
                        (1 << LayerMask.NameToLayer("WallCollider")) |
                        (1 << LayerMask.NameToLayer("Ignore Raycast")));

        for (int i = 0; i < m_Particles.Length; i++)
        {
            m_Particles[i].Stop();
            m_Particles[i].gameObject.SetActive(false);
        }
    }
    
    void Update()
    {
        if (m_BarrelHealthComponent.IsDead)
        {
            for(int i = 0; i < m_Renderers.Length; i++)
            {
                m_Renderers[i].enabled = false;
            }
            m_BoxCollider.enabled = false;
            if(!HasExploded)
                Explode();

            m_DestroyBarrelTimer -= Time.deltaTime;

            if (m_DestroyBarrelTimer <= 0)
            {
                Disable();
            }
        }
        //if (m_RigidBody.velocity != Vector3.zero)
        //{
        //    m_BarrelHealthComponent.Damage(null, gameObject, 0.05f);
        //}
    }

    void Disable()
    {
        if(m_Particles[0].isPlaying)
        {
            for (int i = 0; i < m_Particles.Length; i++)
            {
                m_Particles[i].Stop();
                m_Particles[i].gameObject.SetActive(false);
            }
        }

        m_BoxCollider.enabled = false;
        for (int i = 0; i < m_Renderers.Length; i++)
        {
            m_Renderers[i].enabled = false;
        }

        m_RespawnTimer -= Time.deltaTime;

        if(m_RespawnTimer <= 0)
        {
            Respawn();
        }
    }

    void Respawn()
    {
        m_BarrelHealthComponent.CurrentHealth = m_BarrelHealthComponent.MaxHealth;
        m_BoxCollider.enabled = true;
        for (int i = 0; i < m_Renderers.Length; i++)
        {
            m_Renderers[i].enabled = true;
        }
        m_RigidBody.velocity = Vector3.zero;
        transform.position = m_InitialPosition;
        transform.rotation = m_InitialRotation;
        m_DestroyBarrelTimer = BarrelDestroyTime;
        m_RespawnTimer = RespawnTime;
        HasExploded = false;
        m_RigidBody.isKinematic = false;
        Exploder = null;
    }

    void Explode()
    {
        m_AudioSource.pitch = UnityEngine.Random.Range(0.7f, 1f);
        m_AudioSource.volume = UnityEngine.Random.Range(0.5f, 0.7f);
        m_AudioSource.Play();
        GetComponent<Rigidbody>().isKinematic = true;

        if (!m_Particles[0].isPlaying)
        {
            for (int i = 0; i < m_Particles.Length; i++)
            {
                m_Particles[i].gameObject.SetActive(true);
                m_Particles[i].Play();
            }
            ExplosionPhysicsForce.Explode();
        }

        HandleExplosionDamage();
        HasExploded = true;
    }

    void HandleExplosionDamage()
    {
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, Radius, m_LayerMask, QueryTriggerInteraction.Collide);
        
        for (int i = 0; i < hitColliders.Length; i++)
        {
            Collider collider = hitColliders[i];

            Player player = null;

            PlayerHitboxScript hitbox = collider.GetComponent<PlayerHitboxScript>();

            if (hitbox != null)
                player = hitbox.Owner;

            Health colliderHealth = null;

            if (player != null)
            {
                if(!m_PlayersHit.Contains(player))
                {
                    colliderHealth = player.Health;
                    m_PlayersHit.Add(player);
                }
                else if (player.Health.IsDead && hitbox != null)
                {
                    ApplyPhysics(collider);
                }
            }
            else
            {
                colliderHealth = collider.gameObject.GetComponent<Health>();
            }

            if (colliderHealth != null)
            {
                float damagePerDistance = ExplosiveBarrelDamage / Radius;
                float distanceFromExplosion = Vector3.Distance(collider.gameObject.transform.position, transform.position);
                float damageToDeal = ExplosiveBarrelDamage - (distanceFromExplosion * damagePerDistance);

                //make sure the explosion can't heal the player
                if (damageToDeal > 0)
                {
                    if (colliderHealth.Damage(Exploder, gameObject, damageToDeal, DeathType.Physics, false, true) && hitbox != null)
                    {
                        ApplyPhysics(collider);
                    }
                }
            }
        }

        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }
    }

    void ApplyPhysics(Collider collider)
    {
        Vector3 direction = collider.transform.position - transform.position;
        direction = direction.normalized;
        float forceAmount = 25;
        float forcePerDistance = forceAmount / Radius;
        float distanceFromExplosion = Vector3.Distance(collider.gameObject.transform.position, transform.position);
        float forceToApply = forceAmount - (distanceFromExplosion * forcePerDistance);
        collider.GetComponent<PlayerHitboxScript>().AddForce(direction * forceToApply, collider.transform.position);
    }
}