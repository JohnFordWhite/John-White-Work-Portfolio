﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ShockBarrel                                                                    *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            November 25th, 2016                                                            *
 *                                                                                                 *
 * Handles shock barrels                                                                           *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - November 25th, 2016                                         *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ShockBarrel : MonoBehaviour
{
    //
    //Public
    //
    public GameObject BarrelParticleSystems;
    public bool HasExploded = false;
    public float BarrelDestroyTime = 3.5f;
    public float Radius = 7.5f;
    public float m_ShockBarrelDamage = 10.0f;
    [HideInInspector]
    public Player Exploder;

    //
    //Private
    //
    private Health m_BarrelHealthComponent;
    private AudioSource m_AudioSource;
    private bool SoundEffectHasPlayed = false;
    private float m_DestroyBarrelTimer;
    private float m_RespawnTimer;
    private float RespawnTime = 20.0f;

    private List<Player> m_PlayersHit = null;

    private int m_LayerMask;
    private BoxCollider m_BoxCollider;
    private Rigidbody m_Rigidbody;
    private Vector3 m_InitialPosition;
    private Quaternion m_InitialRotation;
    private ParticleSystem[] m_Particles;
    private MeshRenderer[] m_Renderers;
    private bool m_Disabled = false;

    void Start()
    {
        m_BarrelHealthComponent = GetComponent<Health>();
        m_AudioSource = GetComponent<AudioSource>();

        m_RespawnTimer = RespawnTime;
        m_DestroyBarrelTimer = BarrelDestroyTime;

        m_BoxCollider = GetComponent<BoxCollider>();
        m_Rigidbody = GetComponent<Rigidbody>();

        m_InitialPosition = transform.position;
        m_InitialRotation = transform.rotation;

        m_Particles = BarrelParticleSystems.GetComponentsInChildren<ParticleSystem>();
        m_Renderers = GetComponentsInChildren<MeshRenderer>();

        m_PlayersHit = new List<Player>();
        m_PlayersHit.Capacity = Information.AllPlayers.Count;
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }

        m_LayerMask = ~((1 << LayerMask.NameToLayer("UnplacedObjects")) |
                        (1 << LayerMask.NameToLayer("WallCollider")) |
                        (1 << LayerMask.NameToLayer("Ignore Raycast")));

        for (int i = 0; i < m_Particles.Length; i++)
        {
            m_Particles[i].Stop();
            m_Particles[i].gameObject.SetActive(false);
        }
    }

    void Update()
    {
        if (m_BarrelHealthComponent.IsDead)
        {
            for (int i = 0; i < m_Renderers.Length; i++)
            {
                m_Renderers[i].enabled = false;
            }
            m_BoxCollider.enabled = false;

            if(!m_Disabled)
            {
                Explode();
            }

            m_DestroyBarrelTimer -= Time.deltaTime;

            if (m_DestroyBarrelTimer <= 0 && !m_AudioSource.isPlaying)
            {
                Disable();
            }
        }
        //if (m_Rigidbody.velocity != Vector3.zero)
        //{
        //    m_BarrelHealthComponent.Damage(null, gameObject, 0.05f);
        //}
    }

    void Disable()
    {
        if(m_Disabled == false)
        {
            for (int i = 0; i < m_Particles.Length; i++)
            {
                m_Particles[i].Stop();
                m_Particles[i].gameObject.SetActive(false);
            }

            m_BoxCollider.enabled = false;
            for (int i = 0; i < m_Renderers.Length; i++)
            {
                m_Renderers[i].enabled = false;
            }
            m_Disabled = true;
        }
        
        m_RespawnTimer -= Time.deltaTime;

        if (m_RespawnTimer <= 0)
        {
            Respawn();
        }
    }

    void Respawn()
    {
        m_BoxCollider.enabled = true;
        for (int i = 0; i < m_Renderers.Length; i++)
        {
            m_Renderers[i].enabled = true;
        }
        m_Rigidbody.velocity = Vector3.zero;
        transform.position = m_InitialPosition;
        transform.rotation = m_InitialRotation;
        m_BarrelHealthComponent.CurrentHealth = m_BarrelHealthComponent.MaxHealth;
        HasExploded = false;
        m_Disabled = false;
        m_DestroyBarrelTimer = BarrelDestroyTime;
        m_RespawnTimer = RespawnTime;
        m_Rigidbody.isKinematic = false;
        SoundEffectHasPlayed = false;
    }

    void Explode()
    {
        if(!m_AudioSource.isPlaying && !SoundEffectHasPlayed)
        {
            m_AudioSource.pitch = UnityEngine.Random.Range(0.7f, 1f);
            m_AudioSource.volume = UnityEngine.Random.Range(0.5f, 0.7f);
            m_AudioSource.Play();
            SoundEffectHasPlayed = true;
        }

        if (m_Rigidbody.isKinematic == false)
            m_Rigidbody.isKinematic = true;

        if (!m_Particles[0].isPlaying)
        {
            for (int i = 0; i < m_Particles.Length; i++)
            {
                m_Particles[i].Play();
                m_Particles[i].gameObject.SetActive(true);
            }
        }

        HandleShockDamage();
        HasExploded = true;
    }

    void HandleShockDamage()
    {
        float damageToDeal = m_ShockBarrelDamage * Time.deltaTime;

        //make sure the explosion can't heal the players
        if (damageToDeal > 0)
        {
            Collider[] hitColliders = Physics.OverlapSphere(transform.position, Radius, m_LayerMask, QueryTriggerInteraction.Collide);
            
            for (int i = 0; i < hitColliders.Length; i++)
            {
                Collider collider = hitColliders[i];

                Player player = null;

                PlayerHitboxScript hitbox = collider.GetComponent<PlayerHitboxScript>();

                if (hitbox != null)
                    player = hitbox.Owner;

                Health colliderHealth = null;

                if(player != null)
                {
                    if(!m_PlayersHit.Contains(player))
                    {
                        colliderHealth = player.Health;
                        m_PlayersHit.Add(player);
                    }
                    
                }
                else
                {
                    colliderHealth = collider.gameObject.GetComponent<Health>();
                }

                if (colliderHealth != null)
                {
                    // float distanceFromExplosion = Vector3.Distance(collider.gameObject.transform.position, transform.position);

                    colliderHealth.Damage(Exploder, gameObject, damageToDeal, DeathType.None, false, true);
                }
            }

            for (int i = 0; i < m_PlayersHit.Count; i++)
            {
                m_PlayersHit[i] = null;
            }
        }
    }
}