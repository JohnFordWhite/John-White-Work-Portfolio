﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        SpikeTrap                                                                      *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            November 23rd, 2016                                                            *
 *                                                                                                 *
 * Moves the spikes and damages players                                                            *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - November 23rd, 2016                                         *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SpikeTrap : MonoBehaviour
{

    //
    //Public
    //
    public GameObject DownPos;
    public GameObject UpPos;
    public GameObject Platform;
    private AudioSource m_AudioSource;
    public float ActivateTimer = 0.0f;
    public bool PlayerOnSpikeTrap;
    public bool Raising = false;

    [SerializeField]
    private float CooldownTime = 1.0f;
    [SerializeField]
    private float m_CooldownTimer = 1.0f;

    //
    //Private
    //
    private float m_Damage = 20f;
    private float m_ImpulseForceAmount = 35;
    private float m_WaitTimeBeforeActivation = 0.5f;
    private List<Player> m_PlayersHit = null;

    private const string m_PlayerString = "Player";

    void Start()
    {
        PlayerOnSpikeTrap = false;
        transform.position = DownPos.transform.position;
        m_AudioSource = transform.parent.GetComponent<AudioSource>();

        m_PlayersHit = new List<Player>();
        m_PlayersHit.Capacity = Information.AllPlayers.Count;
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }
    }
    
    void Update()
    {
        m_CooldownTimer -= Time.deltaTime;

        if (PlayerOnSpikeTrap && m_CooldownTimer <= 0.0f)
            ActivateTimer += Time.deltaTime;
    }

    void FixedUpdate()
    {
        //If a player walked over the trap, and a short time has passed, begin raising it
        if (ActivateTimer >= m_WaitTimeBeforeActivation && Raising == false)
        {
            for (int i = 0; i < m_PlayersHit.Count; i++)
            {
                m_PlayersHit[i] = null;
            }

            m_CooldownTimer = 1.0f;
            Raising = true;
        }

        if (Raising)
        {
            if(!m_AudioSource.isPlaying)
                m_AudioSource.Play();

            transform.position = Vector3.Lerp(transform.position, UpPos.transform.position, 13f * Time.deltaTime);
            if(Vector3.Distance(transform.position,UpPos.transform.position)<0.1f)
            {
                ActivateTimer = 0.0f;
                PlayerOnSpikeTrap = false;
                Raising = false;
            }
        }
        else
        {
            transform.position = Vector3.Lerp(transform.position, DownPos.transform.position, 7f * Time.deltaTime);
        }
    }

    public void AcvivateSpikes()
    {
        PlayerOnSpikeTrap = true;
    }

    void OnTriggerEnter(Collider other)
    {
        Player player = null;

        PlayerHitboxScript hitbox = other.GetComponent<PlayerHitboxScript>();

        if (hitbox != null)
            player = hitbox.Owner;

        if (player != null && Raising == true)
        {
            if(!m_PlayersHit.Contains(player))
            {
                m_PlayersHit.Add(player);
                float randomDamageModifier = UnityEngine.Random.Range(-3, 3);

                m_Damage += randomDamageModifier;

                if (m_Damage % 2 == 0)
                    m_Damage += 1;

                player.Health.Damage(null, gameObject, m_Damage, DeathType.Spikes, false);
            }
        }
    }
}
