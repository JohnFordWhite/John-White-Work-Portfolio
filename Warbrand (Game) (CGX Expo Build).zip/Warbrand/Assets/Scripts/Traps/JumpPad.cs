﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        JumpPad                                                                        *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            November 24th, 2016                                                            *
 *                                                                                                 *
 * Handles jump pad.                                                                               *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - November 24th, 2016                                         *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;

public class JumpPad : MonoBehaviour
{
    //
    //Public
    //
    public float Force = 25f;

    //
    //Private
    //
    private ParticleSystem m_ParticleSystem;
    private AudioSource m_AudioSource;
    private bool m_PadJustUsed = false;
    private float m_JumpPadParticleTimer = 2f;
    private float m_JumpPadUseTimer;

    void Start()
    {
        m_ParticleSystem = GetComponentInChildren<ParticleSystem>();
        m_ParticleSystem.Stop();

        m_AudioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        if(m_PadJustUsed)
        {
            transform.Rotate(new Vector3(0, 1, 0), 25);
            m_JumpPadParticleTimer -= Time.deltaTime;
            m_ParticleSystem.Play();

            if(m_JumpPadParticleTimer<=0)
            {
                m_ParticleSystem.Stop();
                m_PadJustUsed = false;
            }
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (m_PadJustUsed)
            return;

        Player player = null;

        PlayerHitboxScript hitbox = other.GetComponent<PlayerHitboxScript>();

        if (hitbox != null)
            player = hitbox.Owner;

        if (player != null)
        {
            if (player.BasicMovementScript != null)
            {
                player.BasicMovementScript.AffectedByOutsideForce();
            }

            m_AudioSource.PlayOneShot(m_AudioSource.clip);

            player.RigidBody.velocity = Vector3.zero;

            player.RigidBody.AddForce(Vector3.up * Force, ForceMode.VelocityChange);

            m_PadJustUsed = true;
            m_JumpPadParticleTimer = 2f;

            if(player.IsAI)
            {
                player.GetComponent<AICharacter>().SetBouncePadReaction();
            }
        }
    }
}
