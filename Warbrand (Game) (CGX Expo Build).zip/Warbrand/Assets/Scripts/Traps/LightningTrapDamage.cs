﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        LightningTrapDamage                                                            *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            November 24th, 2016                                                            *
 *                                                                                                 *
 * Handles damage to health when lighting is active                                                *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - November 24th, 2016                                         *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LightningTrapDamage : MonoBehaviour
{
    private List<Player> m_PlayersHit = null;

    void Start()
    {
        m_PlayersHit = new List<Player>();
        m_PlayersHit.Capacity = Information.AllPlayers.Count;
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }
    }

    void Update()
    {
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }
    }

    void OnTriggerStay(Collider other)
    {
        Player player = null;

        PlayerHitboxScript hitbox = other.GetComponent<PlayerHitboxScript>();

        if (hitbox != null)
            player = hitbox.Owner;

        if (player != null)
        {
            if(!m_PlayersHit.Contains(player))
            {
                m_PlayersHit.Add(player);

                LightningBolt bolt = GetComponentInChildren<LightningBolt>();

                if (bolt != null)
                {
                    if(bolt.gameObject.activeSelf == true)
                    {
                        player.Health.Damage(null, transform.gameObject, 2f, DeathType.None, false);
                    }
                }
            }
        }
    }
}