﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        FanTrap                                                                        *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            November 25th, 2016                                                            *
 *                                                                                                 *
 * Handles pulling players in to the fan and applying damage to them.                              *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - November 25th, 2016                                         *
 * V 1.1 - Rewrote file for clarity (Jon Roffey) - November 25th, 2016                             *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class FanTrap : MonoBehaviour
{

    //
    //Public
    //
    public enum FanState
    {
        Off,
        WarmingUp,
        Running
    }

    public FanState CurrentFanState = FanState.Off;

    public AudioClip FanStartClip;
    public AudioClip FanRunningClip;
    public GameObject SpinnyPart;
    public ParticleSystem Particles;

    //
    //Private
    //
    private AudioSource m_AudioSource;
    private Vector3 m_FanPosition = Vector3.zero;
    private Vector3 m_RaycastPoint = Vector3.zero;
    private Vector3 m_RotateAroundY = new Vector3(0, 1, 0);
    private float m_FanDamage = 5f;
    private float m_TimeBetweenActivations = 30f;
    private float m_RunningTime = 10f;
    private float m_Angle = 720f;
    private float m_WarmupTime;
    private float m_tParam = 0;
    private float m_WarmUpFanAngle;
    private List<Player> m_PlayersHit = null;

    private const string m_RaycastPointTransform = "RaycastPoint";

    void Start()
    {
        m_FanPosition = transform.position;
        m_RaycastPoint = transform.FindChild(m_RaycastPointTransform).transform.position;
        m_AudioSource = GetComponent<AudioSource>();
        m_WarmupTime = FanStartClip.length;

        m_PlayersHit = new List<Player>();
        m_PlayersHit.Capacity = Information.AllPlayers.Count;
        for (int i = 0; i < m_PlayersHit.Count; i++)
        {
            m_PlayersHit[i] = null;
        }
        Particles.Stop();
    }

    void Update()
    {
        switch (CurrentFanState)
        {
            case FanState.Off:
                if(Particles.isPlaying)
                {
                    Particles.Stop();
                }
                m_TimeBetweenActivations -= Time.deltaTime;

                if (m_TimeBetweenActivations <= 0)
                {
                    CurrentFanState = FanState.WarmingUp;
                    m_AudioSource.clip = FanStartClip;
                    m_AudioSource.loop = false;
                    m_TimeBetweenActivations = 30f;
                }

                break;
            case FanState.WarmingUp:

                AudioUtils.SetVolumeByDistance(gameObject, false);

                if(!m_AudioSource.isPlaying)
                {
                    m_AudioSource.Play();
                }

                m_WarmupTime -= Time.deltaTime;

                if (m_WarmupTime <= 0)
                {
                    CurrentFanState = FanState.Running;
                    m_AudioSource.clip = FanRunningClip;
                    m_AudioSource.loop = true;
                    m_WarmupTime = FanStartClip.length;
                    m_tParam = 0;
                }

                if (m_tParam < 1)
                {
                    m_tParam += Time.deltaTime * 0.3f;
                    m_WarmUpFanAngle = Mathf.Lerp(0, m_Angle, m_tParam);
                }

                SpinnyPart.transform.Rotate(m_RotateAroundY, m_WarmUpFanAngle * Time.deltaTime);

                break;
            case FanState.Running:

                if(Particles.isStopped)
                {
                    Particles.Play();
                }

                for (int i = 0; i < m_PlayersHit.Count; i++)
                {
                    m_PlayersHit[i] = null;
                }

                if (!m_AudioSource.isPlaying)
                {
                    m_AudioSource.Play();
                }

                SpinnyPart.transform.Rotate(m_RotateAroundY, m_Angle * Time.deltaTime);

                m_RunningTime -= Time.deltaTime;

                AudioUtils.SetVolumeByDistance(gameObject, true);

                if (m_RunningTime <= 0)
                {
                    CurrentFanState = FanState.Off;
                    m_RunningTime = 10f;
                    StartCoroutine(AudioUtils.FadeOut(m_AudioSource, 1f, 0.3f));
                }

                break;
            default:
                break;
        }
    }

    void OnTriggerStay(Collider other)
    {
        PlayerHitboxScript hitbox = other.GetComponent<PlayerHitboxScript>();

        if (hitbox != null && CurrentFanState == FanState.Running)
        {
            Player player = hitbox.Owner;

            if(!m_PlayersHit.Contains(player))
            {
                m_PlayersHit.Add(player);
                Vector3 directionToFan = m_FanPosition - other.transform.position;

                RaycastHit hit;

                if (Physics.Raycast(m_RaycastPoint, -directionToFan, out hit, 50f))
                {
                    float distanceFromFan = Vector3.Distance(m_FanPosition, other.transform.position);

                    float force = distanceFromFan / 65f;

                    if (distanceFromFan <= 10f)
                        force = 0.5f;

                    if (distanceFromFan <= 2f)
                    {
                        force = 10f;

                        player.Health.Damage(null, gameObject, m_FanDamage);
                    }

                    player.BasicMovementScript.AffectedByOutsideForce();
                    player.RigidBody.AddForce(directionToFan * force, ForceMode.Impulse);
                }
            }
        }
    }
}