﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        SpikeTrigger                                                                   *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            November 23rd, 2016                                                            *
 *                                                                                                 *
 * Triggers the spike trap                                                                         *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - November 23rd, 2016                                         *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;

public class SpikeTrigger : MonoBehaviour
{

    //
    //Private
    //
    private GameObject m_SpikePrefab;
    private SpikeTrap m_Spikes;

    private const string m_PlayerString = "Player";

    void Start()
    {
        m_SpikePrefab = transform.parent.gameObject;
        m_Spikes = m_SpikePrefab.transform.GetComponentInChildren<SpikeTrap>();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<PlayerHitboxScript>())
        {
            if (!m_Spikes.PlayerOnSpikeTrap && !m_Spikes.Raising)
            {
                m_Spikes.AcvivateSpikes();
            }
        }
    }
}
