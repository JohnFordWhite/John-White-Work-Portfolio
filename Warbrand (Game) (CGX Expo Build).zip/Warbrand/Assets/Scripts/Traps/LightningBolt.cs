﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        LightningBolt                                                                  *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            November 24th, 2016                                                            *
 *                                                                                                 *
 * Randomizes the positions of the lightning bolt line renderers                                   *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - November 24th, 2016                                         *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;

public class LightningBolt : MonoBehaviour
{
    //
    //Public
    //
    public Color Colour = Color.white;
    
    //
    //Private
    //
    private LineRenderer m_LineRenderer;
    private float m_MaxZ = 10f;
    private int m_NumSegments = 6;
    private float m_PosRange = 0.5f;
    private NavMeshObstacle m_NavMeshObstacle;

    void Start()
    {
        m_LineRenderer = GetComponent<LineRenderer>();
        m_LineRenderer.SetVertexCount(m_NumSegments);
        RandomizePath();
    }

    void Update()
    {
        Colour.a -= 9f * Time.deltaTime;

        m_LineRenderer.SetColors(Colour, Colour);
        if (Colour.a <= 0f)
        {
            gameObject.SetActive(false);
            if(m_NavMeshObstacle != null)
                m_NavMeshObstacle.enabled = false;
        }
    }

    public void RandomizePath()
    {
        if (m_LineRenderer != null)
        {
            for (int i = 1; i < m_NumSegments - 1; i++)
            {
                float z = ((float)i) * (m_MaxZ) / (float)(m_NumSegments - 1);
                m_LineRenderer.SetPosition(i, new Vector3(Random.Range(m_PosRange, -m_PosRange), Random.Range(m_PosRange, -m_PosRange), z));
            }
            m_LineRenderer.SetPosition(0, new Vector3(0f, 0f, 0f));
            m_LineRenderer.SetPosition(m_NumSegments - 1, new Vector3(0f, 0f, 10f));
        }
    }

    public void SetNavMeshObstacle(NavMeshObstacle aNavMeshObstacle)
    {
        m_NavMeshObstacle = aNavMeshObstacle;
    }
}