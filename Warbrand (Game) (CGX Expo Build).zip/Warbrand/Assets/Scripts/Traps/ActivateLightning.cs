﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System;

public class ActivateLightning : MonoBehaviour
{
    //
    //Public
    //
    public LightningBolt LightningBoltPrefab;
    public List<GameObject> m_LightningBoltPool = new List<GameObject>();
    public bool RandomActivation = true;
    public bool TimedActivation = true;
    public Vector3 BoltScale = new Vector3(1, 1, 1);
    public NavMeshObstacle NavMeshObstacle;
    //
    //Private
    //
    private AudioSource m_AudioSource;
    private float m_SpawnLightningTimer = 3f;
    private float m_TimeToSpawnBolts = 0.5f;
    private int m_BoltPoolSize = 9;

    private const string m_LightningBoltPoolTransform = "Lightning Bolt Pool";

    void Start()
    {
        m_AudioSource = transform.parent.GetComponent<AudioSource>();

        GameObject lightningBoltHolder = new GameObject(m_LightningBoltPoolTransform);
        lightningBoltHolder.transform.parent = transform;
        for (int i = 0; i < m_BoltPoolSize; i++)
        {
            LightningBolt prefabInstance = Instantiate(LightningBoltPrefab, this.transform.position, transform.rotation) as LightningBolt;
            prefabInstance.transform.localScale = BoltScale;
            prefabInstance.transform.parent = lightningBoltHolder.transform;
            m_LightningBoltPool.Add(prefabInstance.gameObject);
        }
    }

    void Update()
    {
        //TODO: Stop the lightning from playing when paused. This only stops the audio.
        if (InputManager.CM.CurrentGameState == GameState.PauseGame)
        {
            for (int i = 0; i < m_LightningBoltPool.Count; i++)
            {
                m_LightningBoltPool[i].SetActive(false);
            }

            //if (m_AudioSource.isPlaying)
            //{
            //    m_AudioSource.Stop();
            //}

            //return;
        }

        GameObject[] bolts = new GameObject[m_LightningBoltPool.Count];
        m_LightningBoltPool.CopyTo(bolts);

        if (Array.TrueForAll(bolts, CheckIfTrue))
        {
            if(!m_AudioSource.isPlaying)
            {
                AudioUtils.SetVolumeByDistance(transform.parent.gameObject, true);
                m_AudioSource.pitch = UnityEngine.Random.Range(0.8f, 1f);
                m_AudioSource.Play();
            }
        }
        else
        {
            m_AudioSource.Stop();
            //StartCoroutine(AudioUtils.FadeOut(m_AudioSource, 1f, 0.3f));
        }
        
        m_SpawnLightningTimer -= Time.deltaTime;

        if(TimedActivation)
        {
            if (m_SpawnLightningTimer < 0f)
            {
                StartCoroutine(SpawnBolts());
                m_SpawnLightningTimer = 3f;
            }
        }

        if(RandomActivation)
        {
            int randomNum = UnityEngine.Random.Range(1, 50);
            if (randomNum == 1)
            {
                for (int i = 0; i < m_LightningBoltPool.Count; i++)
                {
                    LightningBolt bolt = m_LightningBoltPool[i].GetComponent<LightningBolt>();

                    m_LightningBoltPool[i].SetActive(true);
                    bolt.Colour.a = 1f;
                    bolt.RandomizePath();
                    if (NavMeshObstacle != null)
                    {
                        NavMeshObstacle.enabled = true;
                        bolt.SetNavMeshObstacle(NavMeshObstacle);
                    }
                }
            }
        }

        if(!TimedActivation && !RandomActivation)
        {
            for (int i = 0; i < m_LightningBoltPool.Count; i++)
            {
                LightningBolt bolt = m_LightningBoltPool[i].GetComponent<LightningBolt>();

                m_LightningBoltPool[i].SetActive(true);
                bolt.Colour.a = 1f;
                bolt.RandomizePath();
                if (NavMeshObstacle != null)
                {
                    NavMeshObstacle.enabled = true;
                    bolt.SetNavMeshObstacle(NavMeshObstacle);
                }
            }
        }
    }

    IEnumerator SpawnBolts()
    {
        while (m_TimeToSpawnBolts>0)
        {
            m_TimeToSpawnBolts -= Time.deltaTime;
            for (int i = 0; i < m_LightningBoltPool.Count; i++)
            {
                LightningBolt bolt = m_LightningBoltPool[i].GetComponent<LightningBolt>();

                m_LightningBoltPool[i].SetActive(true);
                bolt.Colour.a = 1f;
                bolt.RandomizePath();
                if(NavMeshObstacle != null)
                {
                    NavMeshObstacle.enabled = true;
                    bolt.SetNavMeshObstacle(NavMeshObstacle);
                }
            }

            yield return null;
        }
        m_TimeToSpawnBolts = 0.5f;
    }
    bool CheckIfTrue(GameObject aLightningBolt)
    {
        bool state = false;
        state = aLightningBolt.activeSelf;
        return state;
    }
}
