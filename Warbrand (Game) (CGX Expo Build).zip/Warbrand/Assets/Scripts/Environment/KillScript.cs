﻿using UnityEngine;
using System.Collections;

public class KillScript : MonoBehaviour
{
   void OnTriggerStay(Collider other)
    {
        Player player = null;

        if (other.GetComponent<PlayerHitboxScript>() != null)
            player = other.GetComponent<PlayerHitboxScript>().Owner;

        if (player != null)
        {
            player.gameObject.GetComponent<Health>().Kill();
        }
    }
}
