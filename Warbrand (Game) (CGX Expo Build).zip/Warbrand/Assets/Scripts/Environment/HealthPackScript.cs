﻿using UnityEngine;
using System.Collections;

public class HealthPackScript : MonoBehaviour
{
    public float HealAmount = 50.0f;
    public float RespawnTime = 30.0f;
    public bool Enabled { get; private set; }

    private GameObject m_HealthKitModel;
    private float m_RespawnTimer;
    private float m_RotationSpeed = 40.0f;

    private const string m_ModelTransform = "Model";

	// Use this for initialization
	void Start ()
    {
        Enabled = true;
        m_HealthKitModel = transform.Find(m_ModelTransform).gameObject;
        m_RespawnTimer = RespawnTime;
	}
	
	// Update is called once per frame
	void Update ()
    {
        //Is the health kit respawning?
	    if(Enabled == false)
        {
            m_RespawnTimer -= Time.fixedDeltaTime;

            if(m_RespawnTimer <= 0)
            {
                m_RespawnTimer = RespawnTime;
                m_HealthKitModel.SetActive(true);
                Enabled = true;
            }
        }
        else
        {
            m_HealthKitModel.transform.Rotate(new Vector3(0, m_RotationSpeed * Time.fixedDeltaTime, 0));
        }
	}

    void OnTriggerEnter(Collider other)
    {
        Player player = null;

        if (other.GetComponent<PlayerHitboxScript>() != null)
            player = other.GetComponent<PlayerHitboxScript>().Owner;

        if(player != null)
        {
            Health health = player.gameObject.GetComponent<Health>();
            if (Enabled && health != null)
            {
                if (health.CurrentHealth < health.MaxHealth)
                {
                    m_HealthKitModel.SetActive(false);
                    health.Heal(HealAmount);
                    Enabled = false;
                }
            }
        }
    }
}
