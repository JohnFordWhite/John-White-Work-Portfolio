﻿using UnityEngine;
using System.Collections;

public class BillboardScript : MonoBehaviour
{
    public float TimeOffset = 0;
    public float OscillationHeight = 0.25f;
    public float OscillationSpeed = 2.0f;
    private Vector3 m_InitialPosition;

	void Start ()
    {
        m_InitialPosition = transform.position;
	}
	
	void Update ()
    {
        float offset = Mathf.Cos(Time.realtimeSinceStartup * OscillationSpeed + TimeOffset) * OscillationHeight;
        Vector3 pos = m_InitialPosition;
        pos.y += offset;
        transform.position = pos;
	}
}
