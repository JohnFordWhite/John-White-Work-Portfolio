﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        BulletHole                                                                     *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            January 15th, 2017                                                             *
 *                                                                                                 *
 * Randomizes the bullethole material attached to this gameobject, and deletes the gameobject      *
 *  after a time.                                                                                  *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - January 15th, 2017                                          *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;

public class BulletHole : MonoBehaviour
{
    //
    //Private
    //
    private Renderer m_Renderer;
    //private Color m_FadeColor;
    private float m_WaitBeforeFadeTimer = 10f;
    private float m_NotInViewTimer = 2f;
    private float m_Alpha = 1.0f;

    private const string m_BulletHoleResource = "Materials/Decals/BulletHole";
    private const string m_MaterialString = "Material";

    void Start()
    {
        m_Renderer = GetComponentInChildren<Renderer>();
        //m_FadeColor = m_Renderer.material.color;
        int randHoleTexture = UnityEngine.Random.Range(1, 5);

        float randomTime = (float)UnityEngine.Random.Range(1, 30);
        randomTime /= 10.0f;
        m_WaitBeforeFadeTimer += randomTime;

        // TODO: Pre-cache all resource strings.

        Material newMat = Resources.Load(m_BulletHoleResource + randHoleTexture + m_MaterialString, typeof(Material)) as Material;
        m_Renderer.material = newMat;
    }
    
    void Update()
    {
        if(!m_Renderer.isVisible)
        {
            m_NotInViewTimer -= Time.deltaTime;
            if (m_NotInViewTimer <= 0f)
                Destroy(gameObject);
        }
        m_WaitBeforeFadeTimer -= Time.deltaTime;

        if (m_WaitBeforeFadeTimer <= 0)
        {
            m_Alpha -= 0.01f;
            //m_FadeColor.a -= 0.01f;
            //m_Renderer.material.color = m_FadeColor;
        }
        if (m_Alpha <= 0)
            Destroy(gameObject);
        //if (m_FadeColor.a <= 0)
        //    Destroy(gameObject);
    }
}
