﻿using UnityEngine;
using System.Collections.Generic;
using System;

public class QuarkAICharacter : AICharacter
{
    public class QuarkAIOptionWeights
    {
        public float WanderWeight = 1f;
        public float AttackWeight = 1f;
        public float EscapeWeight = 1f;
        public float AttackTurret = 1f;
    }
    //
    // Public
    //
    public QuarkAIOptionWeights OptionWeights = new QuarkAIOptionWeights();

    protected Quark Quark;

    //
    // Private
    //
    private Vector3 m_AreaToHide = Vector3.zero;
    private bool AreaSetUp = false;
    private float m_CameraToSetUp = 5f;
    
    protected override void Start()
    {
        base.Start();

        Quark = GetComponent<Quark>();
        NavMeshArea = NavMeshAreaInformation.GetAreaForCharacter(CharacterTypes.Quark);
    }

    private const float TOO_CLOSE_DISTANCE = 5f;
    protected override void Update()
    {
        base.Update();

        NavMeshArea = NavMeshAreaInformation.GetAreaForCharacter(CharacterTypes.Quark);

        UpdateTurrets();

        // If we don't have a current behaviour, or our behaviour is done, choose a new one
        if (AIBehaviour == null)
            SelectOption();
        else if (AIBehaviour.Reset)
            SelectOption();

        else if (AIBehaviour.GetBehaviourName() != AIString.QuarkPlaceTurretBehaviour && Quark.m_PlaceTurret.PlacingTurret)
            AIBehaviour = new QuarkPlaceTurretAIBehaviour(this.gameObject, AIBehaviour);


        // Act
        else
        {
            AIBehaviour.Act();
            if (AIBehaviour != null)
                AIBehaviour.DebugDraw();
        }

        for (int i = 0; i < EnemyList.Count; i++)
        {
            Enemies enemy = EnemyList[i];

            if (!(enemy.CanSee))
                continue;

            if (IsLookingAtPoint(enemy.Object.transform.position + Vector3.up, 25f) && Vector3.Distance(transform.position, enemy.Object.transform.position + Vector3.up) < TOO_CLOSE_DISTANCE)
                GameInput.SetInput(InputName.Movement, 1f);
            else if (IsLookingAtPoint(enemy.Object.transform.position + Vector3.up, 25f) && Vector3.Distance(transform.position, enemy.Object.transform.position + Vector3.up) < DamageBeamScript.BeamLength)
                GameInput.SetInput(InputName.Attack1, 1f);
        }

        if (Quark.m_PlaceCamera.CamerasPlaced < 2)
        {
            m_CameraToSetUp -= Time.deltaTime;

            if(m_CameraToSetUp <= 0f)
            {
                m_CameraToSetUp = 5f;
                GameInput.SetInput(InputName.Ability3, 1f);
            }
        }
    }

    protected override void SelectOption()
    {
        AIGoals currentGoal = GetGoals()[0];

        GameModeType currentGameMode = InputManager.CM.GameModeManager.CurrentGameMode.GetGameModeType();
        switch (currentGameMode)
        {
            case GameModeType.KingOfTheHillGameMode:
                if (currentGoal != AIGoals.KeepMyselfAlive)
                {
                    AIBehaviour = new QuarkKingOfTheHillBehaviour(gameObject);
                    return;
                }
                break;
            case GameModeType.TerritoriesGameMode:
                if (currentGoal != AIGoals.KeepMyselfAlive)
                {
                    AIBehaviour = new QuarkTerritoriesBehaviour(gameObject);
                    return;
                }
                break;
        }


        float[] weights = new float[(int)(QuarkAICharacterOptions.MAX_QUARK_AI_CHARACTER_OPTIONS)];

        // Calculate all of the weights
        for (int i = 0; i < weights.Length; i++)
        {
            QuarkAICharacterOptions option = (QuarkAICharacterOptions)(i);
            float weight = float.MinValue;

            switch (option)
            {
                case QuarkAICharacterOptions.Wander:
                    if (currentGoal == AIGoals.LookForEnemies)
                        weight = 1f * OptionWeights.WanderWeight;
                    break;
                case QuarkAICharacterOptions.Attack:
                    if (currentGoal == AIGoals.KillEnemies)
                        weight = 1f * OptionWeights.AttackWeight;
                    break;
                case QuarkAICharacterOptions.Escape:
                    if (currentGoal == AIGoals.KeepMyselfAlive)
                        weight = 1f * OptionWeights.EscapeWeight;
                    break;
                case QuarkAICharacterOptions.AttackTurret:
                    {
                        if (currentGoal == AIGoals.KillTurret)
                            weight = OptionWeights.AttackTurret;
                    }
                    break;
                default:
                case QuarkAICharacterOptions.Null:
                case QuarkAICharacterOptions.MAX_QUARK_AI_CHARACTER_OPTIONS:
                    break;
            }
            
            weights[i] = weight;
        }
        // End Calculating all the weights

        // Calculate value needed for being too low for contention (so we don't select anything stupid)
        float maxValue = float.MinValue;
        for (int weightIndex = 0; weightIndex < weights.Length; weightIndex++)
        {
            float weight = weights[weightIndex];

            if (weight > maxValue)
                maxValue = weight;
        }
        float cutOffPercentage = 0.2f; // Hard coded value, change as needed

        // Create the Dictionary to do the weighted random
        Dictionary<QuarkAICharacterOptions, float> options = new Dictionary<QuarkAICharacterOptions, float>();
        for (int i = 0; i < weights.Length; i++)
        {
            // Make sure we don't add anything that's too low on there
            if (weights[i] > maxValue * cutOffPercentage)
                options.Add((QuarkAICharacterOptions)(i), weights[i]);
        }

        // Set the current option
        if (options.Count != 0)
        {
            QuarkAICharacterOptions paigeOption = MathUtils.WeightedRandom<QuarkAICharacterOptions>(options);
            switch (paigeOption)
            {
                case QuarkAICharacterOptions.Wander:
                    AIBehaviour = new QuarkWanderAIBehaviour(gameObject);
                    break;
                case QuarkAICharacterOptions.Attack:
                    AIBehaviour = new QuarkAttackAIBehaviour(gameObject);
                    break;
                case QuarkAICharacterOptions.Escape:
                    AIBehaviour = new AIFindHealthBehaviour(gameObject);
                    break;
                case QuarkAICharacterOptions.AttackTurret:
                    AIBehaviour = new QuarkDestroyTurretAIBehaviour(gameObject);
                    break;
                default:
#if UNITY_EDITOR
                    DebugManager.LogError("AI Quark could not decide what to do!", Developmer.AllDevelopmers);
#endif
                    AIBehaviour = null;
                    break;
            }
        }
    }

    private List<TurretAISight> m_Turrets = new List<TurretAISight>();
    void UpdateTurrets()
    {
        bool turretRemoved = false;
        for(int i = 0; i < m_Turrets.Count; i++)
        {
            if(m_Turrets[i].Turret == null)
            {
                turretRemoved = true;
                m_Turrets.RemoveAt(i);
                i = -1;
            }
        }

        if (turretRemoved)
        {
            QuarkAIBehaviour behaviour = AIBehaviour as QuarkAIBehaviour;
            if (behaviour != null)
                behaviour.TurretsDirty = true;
        }

        for (int i = 0; i < m_Turrets.Count; i++)
        {
            TurretAISight turret = m_Turrets[i];

            turret.TimeSincePlaced += Time.deltaTime;
        }
    }

    public TurretAISight[] TurretDetails { get { return m_Turrets.ToArray(); } }

    public TurretAISight GetMostRecentTurret()
    {
        TurretAISight sight = null;
        for (int i = 0; i < m_Turrets.Count; i++)
        {
            TurretAISight turret = m_Turrets[i];

            if(sight == null)
            {
                sight = turret;
                continue;
            }

            if (turret.TimeSincePlaced < sight.TimeSincePlaced)
                sight = turret;
        }

        if (sight == null)
            return null;
        return sight;
    }

    public void AddTurret(GameObject aTurret)
    {
        if (aTurret == null)
            return;

        m_Turrets.Add(new TurretAISight(aTurret));

        QuarkAIBehaviour behaviour = AIBehaviour as QuarkAIBehaviour;
        if (behaviour != null)
            behaviour.TurretsDirty = true;
    }

    public void NotifyTurretDestroyed(GameObject aTurret)
    {
        for (int i = 0; i < m_Turrets.Count; i++)
        {
            if (m_Turrets[i].Turret == aTurret)
            {
                m_Turrets.RemoveAt(i);
                i = -1;
            }
        }
    }
}

public class TurretAISight
{
    public TurretAISight(GameObject aTurret) { Turret = aTurret; }
    public GameObject Turret;
    public float TimeSincePlaced = 0f;
}