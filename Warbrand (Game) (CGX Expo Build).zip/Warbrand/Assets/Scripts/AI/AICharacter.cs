﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using UnityEngine.SceneManagement;

public enum AIGoals
{
    // Lowest Goal should be at the top
    LookForEnemies,
    KillEnemies,
    KillTurret,
    KingOfTheHill,
    Territories,
    Juggernaut,
    KeepMyselfAlive,
    MAX_AI_GOALS
}

public abstract class AICharacter : MonoBehaviour
{
    // A class for just AI - to keep track of enemies, where their last known position and direction was, and how long ago we saw them
    public class Enemies
    {
        public Enemies(GameObject aObject)
        {
            Object = aObject;
            if (Object != null)
            {
                Player = Object.GetComponent<Player>();
                Health = Object.GetComponent<Health>();
                MovementScript = Object.GetComponent<BasicMovementScript>();
            }
        }
        public GameObject Object = null;
        public Player Player = null;
        public Health Health = null;
        public BasicMovementScript MovementScript = null;
        public bool CanSee = false;
        public Vector3 LastPosition = Vector3.zero;
        public Vector3 LastDirection = Vector3.zero;
        public float TimeSinceLastSeen = float.MaxValue / 2;

        public void SetCanSee()
        {
            if (CanSee)
                return;

            CanSee = true;
            //LastPosition = Object.transform.position;
            //LastDirection = Object.gameObject.GetComponent<BasicMovementScript>().Velocity;
            TimeSinceLastSeen = 0f;
        }

        public void SetCantSee()
        {
            if (!CanSee)
                return;

            CanSee = false;
            //LastPosition = Object.transform.position;
            //LastDirection = Object.gameObject.GetComponent<BasicMovementScript>().Velocity;
            TimeSinceLastSeen = 0f;
        }
    }

    //
    // Public
    //

    // All of our enemies
    public List<Enemies> EnemyList = new List<Enemies>();

    // Our first person camera
    public Camera CharactersFirstPersonCamera;

    // Our input
    public AiInput GameInput;

    // A function to set our AIBehaviour. Only AI Behaviours use Coroutines, so we stop all 
    // coroutines when swapping between the behaviours so that there aren't Coroutines lasting
    // between Behaviours
    public AIBehaviour AIBehaviour
    {
        get { return m_AIBehaviour; }
        set
        {
            m_AIBehaviour = value;
            StopAllCoroutines();
        }
    }

    public string BehaviourIdentifier = string.Empty;
    public Color DebugColour = Color.clear;
    //
    // Protected
    //
    protected BasicMovementScript m_Movement;
    protected GameModeManager m_GameModeManager;
    protected Rigidbody m_Rigidbody;
    protected Health m_Health;
    protected Player m_Player;
    public int NavMeshArea { get; protected set; }
    public NavMeshAgent Agent { get; protected set; }

    //
    // Private
    //
    private AIBehaviour m_AIBehaviour = null;
    private const float HEALTH_PERCENT_WORRY = 0.25f;
    private const float SENSITIVITY = 250f;

    protected virtual void Start ()
    {
        // Get different components
        m_Player = GetComponent<Player>();
        m_Movement = GetComponent<BasicMovementScript>();
        m_GameModeManager = InputManager.CM.GameModeManager;
        GameInput = (AiInput)(m_Player.GameInput.Input);
        m_Rigidbody = GetComponent<Rigidbody>();
        m_Health = GetComponent<Health>();

        List<GameInputComponent> AllPlayerObjects = InputManager.CM.Players;
        for (int i = 0; i < AllPlayerObjects.Count; i++)
        {
            //Player player = InputManager.CM.Players[i].GetComponentInChildren<Player>(true);
            Player player = AllPlayerObjects[i].Input.Character;

            if (player.gameObject == this.gameObject)
                continue;

            if (m_Player.TeamIndex != player.TeamIndex)
            {
                EnemyList.Add(new Enemies(player.gameObject));
            }
        }

        var cameras = GetComponentsInChildren<FirstPersonCamera>();
        for(int i = 0; i < cameras.Length; i++)
        {
            cameras[i].XMouseSensitivity = SENSITIVITY;
            cameras[i].YMouseSensitivity = SENSITIVITY;
        }

        StartCoroutine(AddNavMeshAgent());
    }
	
	protected virtual void Update ()
    {
        if (m_Health.IsDead)
        {
            m_AIBehaviour = null;
            return;
        }

        if (Agent != null)
        {
            Agent.areaMask = NavMeshArea;
            NavMeshHit hit;

            float radius = 1f;
            while (!NavMesh.SamplePosition(transform.position, out hit, radius, NavMeshArea))
            {
                radius *= 10f;
                if (radius >= 10000f)
                    DebugManager.LogError(gameObject + " unable to find closest NavMesh!", Developmer.Nathan);
            }

            // Keep track of our current position
            // Then move the agent
            // Then move us back to our current position
            Vector3 pos = transform.position;
            Agent.Warp(hit.position);
            transform.position = pos;
        }

        if (m_AIBehaviour != null)
        {
            BehaviourIdentifier = m_AIBehaviour.GetBehaviourName();
            DebugColour = m_AIBehaviour.DebugColour;
        }
        else
        {
            BehaviourIdentifier = string.Empty;
            DebugColour = Color.clear;
        }

        // Take a look for enemies, update our list
        UpdateEnemyList();
        CheckIfCanSeeEnemies();

        // Make sure we don't spin (this is an issue for some reason)
        m_Rigidbody.angularVelocity = Vector3.zero;

        // Reset the inputs so that we're not constantly using them without explicitly saying
        // we want to use them this frame.
        SetLeftAnalogStick(Vector2.zero);
        SetRightAnalogStick(Vector2.zero);
        GameInput.SetAllInputs(0f);

        Debug.DrawLine(transform.position + Vector3.up, transform.position + transform.forward * 50 + Vector3.up, DebugColour);
    }
    
    private const string m_GameSceneString = "GameScene";
    private IEnumerator AddNavMeshAgent()
    {
        while (SceneManager.GetActiveScene().name != m_GameSceneString)
        {
            // Returning null will make it wait 1 frame
            yield return null;
        }

        Agent = gameObject.AddComponent<NavMeshAgent>();

        Agent.speed = 0f;
        Agent.updatePosition = false;
        Agent.updateRotation = false;
        Agent.acceleration = 0f;
        Agent.angularSpeed = 0f;
        Agent.autoTraverseOffMeshLink = false;
        Agent.radius = 0.75f;
    }

    // Get an AIEnemy information given a GameObject
    public Enemies GetEnemyForObject(GameObject aObj)
    {
        for (int i = 0; i < EnemyList.Count; i++)
        {
            Enemies enemy = EnemyList[i];

            if (enemy.Object == aObj)
                return enemy;
        }
        return null;
    }

    // Get what the AI's current goals are
    public List<AIGoals> GetGoals()
    {
        List<AIGoals> goals = new List<AIGoals>();

        // If we're below 50% health, we want to start taking care of ourselves
        if (m_Health.HealthPercentage < HEALTH_PERCENT_WORRY)
            goals.Add(AIGoals.KeepMyselfAlive);

        // For objective type game modes, add Objective goals.
        if (m_GameModeManager.CurrentGameMode != null)
        {
            if (m_GameModeManager.CurrentGameMode.GetGameModeType() == GameModeType.KingOfTheHillGameMode)
                goals.Add(AIGoals.KingOfTheHill);

            if (m_GameModeManager.CurrentGameMode.GetGameModeType() == GameModeType.TerritoriesGameMode)
                goals.Add(AIGoals.Territories);

            if (m_GameModeManager.CurrentGameMode.GetGameModeType() == GameModeType.KingOfTheHillGameMode)
                goals.Add(AIGoals.Juggernaut);
        }

        TurretScript[] turrets = Information.AllTurrets.ToArray();
        for (int i = 0; i < turrets.Length; i++)
        {
            if (turrets[i].Owner.TeamIndex == m_Player.TeamIndex)
                continue;
            if (turrets[i].IsActivated == false)
                continue;

            if (CanSeeObject(turrets[i].gameObject))
            {
                goals.Add(AIGoals.KillTurret);
                break;
            }
        }

        // If we can see at least one enemy, we can go kill them
        if (CanSeeAtLeastOneEnemy)
            goals.Add(AIGoals.KillEnemies);

        // If there are no valid options for the above, we can always look around for more
        goals.Add(AIGoals.LookForEnemies);

        // We should never hit this. Error Checking
        if (goals.Count == 0)
        {
#if UNITY_EDITOR
            DebugManager.LogError(this.gameObject + " was unable to log any goals.", Developmer.Nathan);
#endif
        }

        return goals;
    }

    // Each AI will take a look at its own goals and implement a version of this function, given
    // what their character can actually do.
    protected abstract void SelectOption();

    // Can we see an enemy?
    public bool CanSeeAtLeastOneEnemy { get { return (GetViewableEnemies().Count > 0); } }

    // Check all the enemies and if we can see them, then update the list
    void CheckIfCanSeeEnemies()
    {
        // Check every enemy
        for (int i = 0; i < EnemyList.Count; i++)
        {
            Enemies enemy = EnemyList[i];

            if(enemy.Object == null)
            {
#if UNITY_EDITOR
                DebugManager.LogError("Enemy is null!", Developmer.Nathan);
#endif
                EnemyList.Remove(enemy);
                CheckIfCanSeeEnemies();
                return;
            }
            // Can we see the enemy? This does not take into account raycasting
            bool canSeePlayer = Information.AICanSeeObject(this.gameObject, enemy.Object);

            // If we're in smoke screen, we can't see any other players
            if (m_Player.IsAffectedBySmokeScreen)
                canSeePlayer = false;

            // If the enemy is in smoke screen that's not ours, we can't see them
            if (enemy.Player.IsAffectedBySmokeScreen)
            {
                if(!(enemy.Player.OnlyAffectedByMySmokeScreen(m_Player)))
                {
                    canSeePlayer = false;
                }
            }

            // If they are on our camera, raycast to them to ensure we can actually see them
            if(canSeePlayer)
            {
                Vector3 enemyRaycastPoint = enemy.Object.transform.position + Vector3.up;

                RaycastHit[] hits = 
                    Physics.RaycastAll(CharactersFirstPersonCamera.transform.position,
                                       enemyRaycastPoint - CharactersFirstPersonCamera.transform.position,
                                       Vector3.Distance(CharactersFirstPersonCamera.transform.position, enemyRaycastPoint));

                // If we hit something that is not ourselves, or the enemy, we want to 
                // set seeing the enemy to false
                for (int hitIndex = 0; hitIndex < hits.Length; hitIndex++)
                {
                    RaycastHit hit = hits[hitIndex];

                    if (hit.transform.gameObject == gameObject)
                        continue;

                    if (hit.transform.gameObject == enemy.Object)
                        continue;

                    if (hit.collider.isTrigger)
                        continue;

                    canSeePlayer = false;
                    break;
                }
            }

            // Can't see player
            if (!canSeePlayer)
                enemy.SetCantSee();

            // Can now see player
            else
                enemy.SetCanSee();
        }
    }

    // Update the enemy information
    void UpdateEnemyList()
    {
        // For every enemy
        for (int i = 0; i < EnemyList.Count; i++)
        {
            Enemies enemy = EnemyList[i];

            if (enemy == null || enemy.Player == null || enemy.Player.gameObject.activeSelf == false)
                continue;

            // Can see enemy
            if(enemy.CanSee)
            {
                // Update their position and their direction, since we can see them
                if (MathUtils.AlmostEquals(enemy.Object.transform.position, new Vector3(5000f, 5000f, 5000f), 10f))
                    continue;
                enemy.LastPosition = enemy.Object.transform.position;
                enemy.LastDirection = enemy.MovementScript.Velocity;
            }

            // Can't see enemy
            else
            {
                // Increment the time since we last saw them
                enemy.TimeSinceLastSeen += Time.deltaTime;
            }
        }
    }

    // Get a list of all our enemies we can actually see
    public List<Enemies> GetViewableEnemies(bool aIncludeRecentlySeenEnemies = false)
    {
        List<Enemies> objs = new List<Enemies>();
        
        for (int i = 0; i < EnemyList.Count; i++)
        {
            Enemies enemy = EnemyList[i];

            if (enemy == null || enemy.Player == null || enemy.Player.gameObject.activeSelf == false)
                continue;
            if (enemy.Health.IsDead)
                continue;
            if (enemy.CanSee)
                objs.Add(enemy);
            else if (enemy.TimeSinceLastSeen < 1f)
                objs.Add(enemy);
        }

        return objs;
    }

    // Get the one viewable enemy that's the closest to our current position
    public Enemies GetClosestViewableEnemy(bool aIncludeRecentlySeenEnemies = false)
    {
        // If we can't see anything, return null
        if (!CanSeeAtLeastOneEnemy)
            return null;

        Enemies obj = null;
        float closestDistance = float.MaxValue;
        List<Enemies> ViewableEnemies = GetViewableEnemies(aIncludeRecentlySeenEnemies);
        
        for (int i = 0; i < ViewableEnemies.Count; i++)
        {
            Enemies enemy = ViewableEnemies[i];

            if (enemy.Health.IsDead)
                continue;

            if (Vector3.Distance(transform.position, enemy.Object.transform.position) < closestDistance)
            {
                closestDistance = Vector3.Distance(transform.position, enemy.Object.transform.position);
                obj = enemy;
            }
        }

        return obj;
    }

    // Get a random viewable enemy
    public Enemies GetRandomViewableEnemy()
    {
        return GetViewableEnemies()[UnityEngine.Random.Range(0, GetViewableEnemies().Count)];
    }

    // Get all enemies objects
    public Enemies[] GetAllEnemies()
    {
        return EnemyList.ToArray();
    }

    // Set the left analog stick to move towards a target, taking into account our
    // current forward direction
    public void MoveTowardsTarget(Vector3 aTarget)
    {
        MoveTowardsTarget(aTarget, Vector3.zero);
    }

    // Set the left analog stick to move towards a moving target, taking into account 
    // our current forward direction
    public void MoveTowardsTarget(Vector3 aTarget, Vector3 aObjectForward)
    {
        // Track just a little bit. Will probably include an object speed here at some point
        aTarget += aObjectForward;
        
        // The difference between our and the targets position
        Vector3 difference = new Vector3(aTarget.x - transform.position.x, 0f, aTarget.z - transform.position.z);

        if(difference.sqrMagnitude < 1f)
        {
            SetLeftAnalogStick(Vector2.zero);
            return;
        }

        // The angle between us
        float yawAngle = Mathf.Atan2(difference.z, difference.x) * Mathf.Rad2Deg;

        // Our local rotation, clamped to -180 - 180
        float localRot = transform.eulerAngles.y;
        if (localRot > 180)
            localRot -= 360;

        // Take our local rotation into account
        yawAngle += localRot - 90;
        
        // The angle has been known to have fucky numbers. This fixes it
        while (yawAngle < 0) yawAngle += 360;

        // Readd the 90 we took away earlier
        yawAngle += 90f;

        // Calculate the angle to set the sticks
        Vector2 currentMovement = new Vector2(Mathf.Cos(yawAngle * Mathf.Deg2Rad), Mathf.Sin(yawAngle * Mathf.Deg2Rad));
        
        // Set the sticks
        SetLeftAnalogStick(currentMovement);
    }

    public bool CanSeeObject(GameObject aObject)
    {
        Enemies enemy = GetEnemyForObject(aObject);

        if (enemy == null)
        {
            // Can we see the enemy? This does not take into account raycasting
            bool canSeeObject = Information.AICanSeeObject(this.gameObject, aObject);

            // If we're in smoke screen, we can't see any other players
            if (m_Player.IsAffectedBySmokeScreen)
                canSeeObject = false;

            // If the enemy is in smoke screen that's not ours, we can't see them
            if (canSeeObject)
            {
                TurretScript turret = aObject.GetComponent<TurretScript>();
                if (turret != null)
                {
                    if (turret.IsInSmoke)
                        canSeeObject = false;
                }
            }

            // If they are on our camera, raycast to them to ensure we can actually see them
            if (canSeeObject)
            {
                Vector3 enemyRaycastPoint = aObject.transform.position + Vector3.up;

                RaycastHit[] hits =
                    Physics.RaycastAll(CharactersFirstPersonCamera.transform.position,
                                       enemyRaycastPoint - CharactersFirstPersonCamera.transform.position,
                                       Vector3.Distance(CharactersFirstPersonCamera.transform.position, enemyRaycastPoint));

                // If we hit something that is not ourselves, or the enemy, we want to 
                // set seeing the enemy to false
                for (int hitIndex = 0; hitIndex < hits.Length; hitIndex++)
                {
                    RaycastHit hit = hits[hitIndex];

                    if (hit.transform.gameObject == gameObject)
                        continue;

                    if (hit.transform.gameObject == aObject)
                        continue;

                    if (hit.collider.isTrigger)
                        continue;

                    canSeeObject = false;
                    break;
                }
            }

            return canSeeObject;
        }

        return enemy.CanSee;
    }

    // Look towards a position
    public void LookTowardsTarget(Vector3 aTarget, float aSafety = 2.5f)
    {
        // A bit of error checking, just to reduce twitchiness
        float angle = Vector3.Angle(transform.forward, MathUtils.DirectionVector(transform.position, aTarget));
        if (angle < aSafety)
        {
            SetRightAnalogStick(Vector2.zero);
            return;
        }

        // The Vector2 to input
        Vector2 input;
        {
            // Most of this code is the same as the above function
            Vector3 difference = new Vector3(aTarget.x - transform.position.x, 0f, aTarget.z - transform.position.z);
            float yawAngle = Mathf.Atan2(difference.z, difference.x) * Mathf.Rad2Deg;

            float localRot = transform.eulerAngles.y;
            if (localRot > 180)
                localRot -= 360;

            yawAngle += localRot - 90;

            while (yawAngle < 0) yawAngle += 360;

            float yawDirection = 1;

            if (yawAngle < 180)
                yawDirection = -1;

            Vector3 cameraForward = m_Player.FirstPersonPlayerCamera.transform.forward;
            Vector3 targetForward = (aTarget - transform.position).normalized;

            float pitchDirection = Mathf.Sign(targetForward.y - cameraForward.y);

            input = new Vector2(yawDirection, pitchDirection);
            Vector3 newForward;
            {
                FirstPersonCamera camera = m_Player.FirstPersonPlayerCamera.GetComponent<FirstPersonCamera>();
                Vector3 eulerAngles = m_Player.FirstPersonPlayerCamera.transform.forward;
                eulerAngles.x -= input.y * camera.XMouseSensitivity * Time.smoothDeltaTime;
                eulerAngles.y += input.x * camera.YMouseSensitivity * Time.smoothDeltaTime;
                newForward = (Quaternion.Euler(eulerAngles)) * Vector3.forward;
            }

            float otDot = Vector3.Dot(cameraForward, targetForward);
            float onDot = Vector3.Dot(cameraForward, newForward);

            if(otDot < onDot)
            {
                input *= onDot - otDot;
            }
        }
        
        SetRightAnalogStick(input);
    }

    public void LookForward()
    {
        LookTowardsTarget(transform.position + transform.forward);
    }

    public void Look45DegreesDown()
    {
        Vector3 Forward2D = transform.forward;
        Forward2D.y = 0;
        Forward2D.Normalize();

        Vector3 point = transform.position + Forward2D;
        point.y -= 1f;
        LookTowardsTarget(point);
    }
       

    public void SetLeftAnalogStick(Vector2 aInput)
    {
        // Make sure we don't input some fucky numbers
        if(aInput.magnitude > 1f)
            aInput.Normalize();
        GameInput.SetInput(InputName.Horizontal, aInput.x);
        GameInput.SetInput(InputName.Vertical, aInput.y);
    }

    public void SetRightAnalogStick(Vector2 aInput)
    {
        // Make sure we don't input some fucky numbers
        if(aInput.magnitude > 1f)
            aInput.Normalize();
        
        GameInput.SetInput(InputName.LookHorizontal, aInput.x);
        GameInput.SetInput(InputName.LookVertical, aInput.y);
    }

    // Helper function - will find the closest point to us on a sphere with a radius
    // of aRadius around a given point
    public Vector3 GetClosestPositionToTargetGivenRadius(Vector3 aTarget, float aRadius)
    {
        Vector3 dir = transform.position - aTarget;
        return aTarget + (dir.normalized * aRadius);
    }

    public static Vector3 GetClosestPositionToTargetGivenRadius(Vector3 aStartingPosition, Vector3 aTarget, float aRadius)
    {
        Vector3 dir = aStartingPosition - aTarget;
        return aTarget + (dir.normalized * aRadius);
    }

    // Helper function - same as above, except y will always equal our current y. Useful
    // if we want to look straight forward.
    public Vector3 GetClosestPositionToTargetGivenRadius2D(Vector3 aTarget, float aRadius)
    {
        Vector3 pos = GetClosestPositionToTargetGivenRadius(aTarget, aRadius);
        pos.y = transform.position.y;
        return pos;
    }

    public Vector3 GetClosestPositionToTargetGivenRadius2D(Vector3 aStartingPosition, Vector3 aTarget, float aRadius)
    {
        Vector3 pos = GetClosestPositionToTargetGivenRadius(aStartingPosition, aTarget, aRadius);
        pos.y = aStartingPosition.y;
        return pos;
    }

    // Are we looking at a specific point? aAngle represents a little forgiveness (we'll never 
    // be looking DIRECTLY at something
    public bool IsLookingAtPoint(Vector3 aPoint, float aAngle = 15f)
    {
        bool isValid = (Vector3.Angle(m_Player.PlayerCamera.transform.forward, (aPoint - transform.position).normalized) < aAngle);
        
        return isValid;
    }

    public void SetSmokeScreenReaction()
    {
        switch (m_Player.Character)
        {
            case CharacterTypes.Paige:
                m_AIBehaviour = new PaigeSmokeScreenReactionBehaviour(this.gameObject);
                break;
            case CharacterTypes.Quark:
                break;
            case CharacterTypes.Leeroy:
                break;
            case CharacterTypes.Zeph:
                break;
            case CharacterTypes.MAX_CHARACTER_TYPES:
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Unsupported Character Type: " + m_Player.Character.ToString(), Developmer.AllDevelopmers);
#endif
                break;
        }
    }

    public void SetAdhesiveReaction()
    {
        switch (m_Player.Character)
        {
            case CharacterTypes.Paige:
                m_AIBehaviour = new PaigeAdhesiveReactionBehaviour(this.gameObject);
                break;
            case CharacterTypes.Quark:
                break;
            case CharacterTypes.Leeroy:
                break;
            case CharacterTypes.Zeph:
                break;
            case CharacterTypes.MAX_CHARACTER_TYPES:
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Unsupported Character Type: " + m_Player.Character.ToString(), Developmer.Nathan);
#endif
                break;
        }
    }

    public void SetDamageReaction(GameObject aAttackingObject)
    {
        switch (m_Player.Character)
        {
            case CharacterTypes.Paige:
                m_AIBehaviour = new PaigeTakeDamageReactionBehaviour(this.gameObject, m_AIBehaviour, aAttackingObject);
                break;
            case CharacterTypes.Quark:
                break;
            case CharacterTypes.Leeroy:
                break;
            case CharacterTypes.Zeph:
                m_AIBehaviour = new ZephTakeDamageReactionBehaviour(this.gameObject, m_AIBehaviour, aAttackingObject);
                break;
            case CharacterTypes.MAX_CHARACTER_TYPES:
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Unsupported Character Type: " + m_Player.Character.ToString(), Developmer.AllDevelopmers);
#endif
                break;
        }
    }

    public void SetBouncePadReaction()
    {
        m_AIBehaviour = new AIBounceBehaviour(this.gameObject, m_AIBehaviour);
    }
}