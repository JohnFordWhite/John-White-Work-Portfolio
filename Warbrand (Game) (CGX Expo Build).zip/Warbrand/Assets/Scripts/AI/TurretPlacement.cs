﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TurretPlacement :MonoBehaviour
{
    private static Collider[] m_Colliders;

    void Start()
    {
        m_Colliders = GetComponentsInChildren<Collider>();
    }

    public static Vector3 GetClosestPoint(Vector3 aPoint)
    {
        Vector3[] closestPoints = new Vector3[m_Colliders.Length];
        for(int i = 0; i < m_Colliders.Length; i++)
        {
            closestPoints[i] = m_Colliders[i].bounds.ClosestPoint(aPoint);
        }
        int closestIndex = -1;
        float closestDistance = float.MaxValue;

        for(int i = 0; i < closestPoints.Length; i++)
        {
            float distance = Vector3.Distance(aPoint, closestPoints[i]);
            if (distance < closestDistance)
            {
                closestIndex = i;
                closestDistance = distance;
            }
        }

        return closestPoints[closestIndex];
    }
}