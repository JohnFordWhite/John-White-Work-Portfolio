﻿using UnityEngine;
using System.Collections.Generic;

public class AIWanderPathfinding : MonoBehaviour
{
    public Transform BounceLandingLocationsParent;
    private static Transform[] m_Positions;
    private static Transform[] m_BounceLandingLocations;

    void Awake()
    {
        m_Positions = GetComponentsInChildren<Transform>();
        NavMeshAreaInformation.Setup();

        m_BounceLandingLocations = BounceLandingLocationsParent.GetComponentsInChildren<Transform>();
    }

    void Start()
    {
        OffMeshLink[] objs = GameObject.FindObjectsOfType<OffMeshLink>();
        for (int i = 0; i < objs.Length; i++)
        {
            GameObject obj = objs[i].startTransform.gameObject;
            obj.transform.position = MathUtils.GetClosestPointOnNavMesh(obj.transform.position);
            obj = objs[i].endTransform.gameObject;
            obj.transform.position = MathUtils.GetClosestPointOnNavMesh(obj.transform.position);
        }
    }

    public static Vector3 GetRandomPoint()
    {
        return m_Positions[Random.Range(0, m_Positions.Length)].position;
    }

    public static Vector3 GetRandomLandingLocation()
    {
        return m_BounceLandingLocations[Random.Range(0, m_Positions.Length)].position;
    }
}

public static class NavMeshAreaInformation
{
    private static Dictionary<string, int> m_Areas;

    public static void Setup()
    {
        m_Areas = new Dictionary<string, int>();
        Add(WALKABLE);
        Add(JUMP);
        Add(DROP);
        Add(JETPACK);
        Add(TELEPORT);
        Add(POUNCE);
    }

    private static void Add(string aName)
    {
        m_Areas.Add(aName, 1 << NavMesh.GetAreaFromName(aName));
    }

    private const string WALKABLE = "Walkable";
    private const string JUMP = "Jump";
    private const string DROP = "Drop";
    private const string JETPACK = "Jetpack";
    private const string POUNCE = "Pounce";
    private const string TELEPORT = "Teleport";
    public static OffMeshLinkType GetTypeForID(int ID)
    {
        ID = 1 << ID;

        foreach(var a in m_Areas)
        {
            if(a.Value == ID)
            {
                if (a.Key == JUMP)
                    return OffMeshLinkType.Jump;
                if (a.Key == DROP)
                    return OffMeshLinkType.Drop;
                if (a.Key == JETPACK)
                    return OffMeshLinkType.Jetpack;
                if (a.Key == POUNCE)
                    return OffMeshLinkType.Pounce;
                if (a.Key == TELEPORT)
                    return OffMeshLinkType.Teleport;
            }
        }

        return OffMeshLinkType.Drop;
    }

    public static int GetAreaForCharacter(CharacterTypes aCharacter, bool aIncludeMovement = true)
    {
        switch (aCharacter)
        {
            case CharacterTypes.Paige:
                return GetArea(WALKABLE) | GetArea(JUMP) | GetArea(DROP) | ((aIncludeMovement) ? GetArea(JETPACK) : 0);
            case CharacterTypes.Quark:
                return GetArea(WALKABLE) | GetArea(JUMP) | GetArea(DROP);
            case CharacterTypes.Leeroy:
                return GetArea(WALKABLE) | GetArea(JUMP) | GetArea(DROP) | ((aIncludeMovement) ? GetArea(POUNCE) : 0);
            case CharacterTypes.Zeph:
                return GetArea(WALKABLE) | GetArea(JUMP) | GetArea(DROP) | ((aIncludeMovement) ? GetArea(TELEPORT) : 0);
        }

        return 0;
    }

    private static int GetArea(string aName)
    {
        if(m_Areas.ContainsKey(aName))
            return m_Areas[aName];
        return -1;
    }
}