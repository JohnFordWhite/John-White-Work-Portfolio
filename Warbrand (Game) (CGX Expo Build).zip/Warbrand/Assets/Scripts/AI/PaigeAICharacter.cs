﻿using UnityEngine;
using System.Collections.Generic;
using System;

public class PaigeAICharacter : AICharacter
{
    // All of Paige's options, and how likely she is to choose each option
    [Serializable]
    public class PaigeAIOptionWeights
    {
        public float AllOutAttackWeight = 1f;
        public float CautiousAttackWeight = 1f;
        public float HealWeight = 1f;
        public float WanderWeight = 1f;

        public float KingOfTheHillWeight = 1f;
        public float TerritoriesWeight = 1f;
        public float JuggernautWeight = 1f;
        public float AttackTurret = 1f;
    }

    //
    // Public
    //
    [SerializeField] public PaigeAIOptionWeights OptionWeights = new PaigeAIOptionWeights();
    public float MaxYVelocity = 10f;
    public Paige Paige { get { return m_Paige; } }

    //
    // Private
    //
    private Paige m_Paige;

    protected override void Start()
    {
        base.Start();
        m_Paige = GetComponent<Paige>();
        NavMeshArea = NavMeshAreaInformation.GetAreaForCharacter(CharacterTypes.Paige);
    }

    private float m_MinimumAttackDistance = 30f;
    protected override void Update()
    {
        base.Update();

        bool includeMovementAbility = (m_Paige.JetpackAbility.PercentFuelRemaining > 0.75f);
        NavMeshArea = NavMeshAreaInformation.GetAreaForCharacter(CharacterTypes.Paige, includeMovementAbility);

        // If we don't have a current behaviour, or our behaviour is done, choose a new one
        if (AIBehaviour == null)
            SelectOption();
        else if (AIBehaviour.Reset)
            SelectOption();

        // If we have a behaviour, tell it to do stuff!
        else
        {
            AIBehaviour.Act();
            if (AIBehaviour != null)
                AIBehaviour.DebugDraw();
        }

        for (int i = 0; i < EnemyList.Count; i++)
        {
            Enemies enemy = EnemyList[i];

            if (!(enemy.CanSee))
                continue;

            if (IsLookingAtPoint(enemy.Object.transform.position + Vector3.up, 25f) && Vector3.Distance(transform.position, enemy.Object.transform.position + Vector3.up) < m_MinimumAttackDistance)
                GameInput.SetInput(InputName.Attack1, 1f);
        }
    }

    // This is where decision making takes place
    override protected void SelectOption()
    {
        AIGoals currentGoal = GetGoals()[0];

        GameModeType currentGameMode = InputManager.CM.GameModeManager.CurrentGameMode.GetGameModeType();
        switch (currentGameMode)
        {
            case GameModeType.KingOfTheHillGameMode:
                if (currentGoal != AIGoals.KeepMyselfAlive)
                {
                    AIBehaviour = new PaigeKingOfTheHillBehaviour(gameObject);
                    return;
                }
                break;
            case GameModeType.TerritoriesGameMode:
                if (currentGoal != AIGoals.KeepMyselfAlive)
                {
                    //AIBehaviour = new LeeroyTerritoriesBehaviour(gameObject);
                    return;
                }
                break;
        }
        // Boy is this function confusing. Just ask me for help. I can't explain it via typing -Nathan
        float[] weights = new float[(int)(PaigeAICharacterOptions.MAX_PAIGE_AI_CHARACTER_OPTIONS)];

        // Calculate all of the weights
        for (int i = 0; i < weights.Length; i++)
        {
            PaigeAICharacterOptions option = (PaigeAICharacterOptions)(i);
            float weight = float.MinValue;

            // Any weight that is set to MinValue will disqualified from consideration
            switch (option)
            {
                case PaigeAICharacterOptions.KingOfTheHill:
                    if (currentGoal == AIGoals.KingOfTheHill)
                        weight = 1f * OptionWeights.KingOfTheHillWeight;
                    break;
                //
                case PaigeAICharacterOptions.Wander:
                    if (!(m_Paige.JetpackAbility.CanUseAbility()))
                        break;
                    if (currentGoal == AIGoals.KillEnemies)
                        break;
                    weight = 1f * OptionWeights.WanderWeight;
                    break;

                //
                case PaigeAICharacterOptions.AllOutAttack:
                    if (currentGoal != AIGoals.KillEnemies)
                        break;
                    weight = 1f * OptionWeights.AllOutAttackWeight;
                    break;

                //
                case PaigeAICharacterOptions.CautiousAttack:
                    if(GetGoals().Contains(AIGoals.KillEnemies))
                    {
                        weight = 1f * OptionWeights.CautiousAttackWeight;
                        if (currentGoal == AIGoals.KeepMyselfAlive)
                            weight /= 2f;
                    }
                    break;

                //
                case PaigeAICharacterOptions.Heal:
                    if (currentGoal != AIGoals.KeepMyselfAlive)
                        break;

                    weight = 1f * OptionWeights.HealWeight;
                    break;

                case PaigeAICharacterOptions.AttackTurret:
                    {
                        if (currentGoal == AIGoals.KillTurret)
                            weight = OptionWeights.AttackTurret;
                    }
                    break;

                // Other things, don't want to bother with these
                default:
                case PaigeAICharacterOptions.Null:
                case PaigeAICharacterOptions.MAX_PAIGE_AI_CHARACTER_OPTIONS:
                    weight = float.MinValue;
                    break;
            }

            weights[i] = weight;
        }
        // End Calculating all the weights

        // Calculate value needed for being too low for contention (so we don't select anything stupid)
        float maxValue = float.MinValue;
        for (int weightIndex = 0; weightIndex < weights.Length; weightIndex++)
        {
            float weight = weights[weightIndex];

            if (weight > maxValue)
                maxValue = weight;
        }
        float cutOffPercentage = 0.2f; // Hard coded value, change as needed

        // Create the Dictionary to do the weighted random
        Dictionary<PaigeAICharacterOptions, float> options = new Dictionary<PaigeAICharacterOptions, float>();
        for (int i = 0; i < weights.Length; i++)
        {
            // Make sure we don't add anything that's too low on there
            if (weights[i] > maxValue * cutOffPercentage)
                options.Add((PaigeAICharacterOptions)(i), weights[i]);
        }

        // Set the current option
        if (options.Count != 0)
        {
            PaigeAICharacterOptions paigeOption = MathUtils.WeightedRandom<PaigeAICharacterOptions>(options);
            switch (paigeOption)
            {
                case PaigeAICharacterOptions.KingOfTheHill:
                    AIBehaviour = new PaigeKingOfTheHillBehaviour(gameObject);
                    break;
                case PaigeAICharacterOptions.Wander:
                    AIBehaviour = new PaigeWanderAIBehaviour(gameObject);
                    break;
                case PaigeAICharacterOptions.AllOutAttack:
                    AIBehaviour = new PaigeAllOutAttackBehaviour(gameObject);
                    break;
                case PaigeAICharacterOptions.CautiousAttack:
                    AIBehaviour = new PaigeCautiousAttackBehaviour(gameObject);
                    break;
                case PaigeAICharacterOptions.Heal:
                    AIBehaviour = new PaigeHealBehaviour(gameObject);
                    break;
                case PaigeAICharacterOptions.AttackTurret:
                    AIBehaviour = new PaigeDestroyTurretAIBehaviour(gameObject);
                    break;
                default:
                    AIBehaviour = null;
                    break;
            }
        }
    }
}