﻿using UnityEngine;
using System.Collections.Generic;
using System;

public class ZephAICharacter : AICharacter
{
    [Serializable]
    public class ZephAIOptionWeights
    {
        public float WanderWeight = 1f;
        public float AllOutAttackWeight = 1f;
        public float PullOpponent = 1f;
        public float ThrowSmokeScreen = 1f;
        public float PoisonDart = 1f;
        public float AttackTurret = 1f;
    }
    //
    // Public
    //
    [SerializeField]
    public ZephAIOptionWeights OptionWeights = new ZephAIOptionWeights();

    protected Zeph Zeph;

    //
    // Private
    //

    protected override void Start()
    {
        base.Start();

        Zeph = GetComponent<Zeph>();
        NavMeshArea = NavMeshAreaInformation.GetAreaForCharacter(CharacterTypes.Zeph);
    }

    private float m_MinimumAttackDistance = 30f;
    protected override void Update()
    {
        base.Update();

        bool includeMovementAbility = Zeph.TeleportAbility.CanUseAbility();
        NavMeshArea = NavMeshAreaInformation.GetAreaForCharacter(CharacterTypes.Zeph, includeMovementAbility);

        // If we don't have a current behaviour, or our behaviour is done, choose a new one
        if (AIBehaviour == null)
            SelectOption();
        else if (AIBehaviour.Reset)
            SelectOption();

        // If we have a behaviour, tell it to do stuff!
        else
        {
            AIBehaviour.Act();
            if (AIBehaviour != null)
                AIBehaviour.DebugDraw();
        }

        for (int i = 0; i < EnemyList.Count; i++)
        {
            Enemies enemy = EnemyList[i];

            if (!(enemy.CanSee))
                continue;

            if (IsLookingAtPoint(enemy.Object.transform.position + Vector3.up, 25f) &&
                Vector3.Distance(transform.position, enemy.Object.transform.position + Vector3.up) < m_MinimumAttackDistance &&
                Zeph.PoisonDartAbility.CanUseAbility())
            {
                GameInput.SetInput(InputName.Ability3, 1f);
            }
        }
    }

    protected override void SelectOption()
    {
        AIGoals currentGoal = GetGoals()[0];

        GameModeType currentGameMode = InputManager.CM.GameModeManager.CurrentGameMode.GetGameModeType();
        switch (currentGameMode)
        {
            case GameModeType.KingOfTheHillGameMode:
                if (currentGoal != AIGoals.KeepMyselfAlive)
                {
                    AIBehaviour = new ZephKingOfTheHillBehaviour(gameObject);
                    return;
                }
                break;
            case GameModeType.TerritoriesGameMode:
                if (currentGoal != AIGoals.KeepMyselfAlive)
                {
                    AIBehaviour = new ZephTerritoriesBehaviour(gameObject);
                    return;
                }
                break;
        }


        float[] weights = new float[(int)(ZephAICharacterOptions.MAX_ZEPH_AI_CHARACTER_OPTIONS)];

        // Calculate all of the weights
        for (int i = 0; i < weights.Length; i++)
        {
            if (currentGoal == AIGoals.KeepMyselfAlive)
                currentGoal = GetGoals()[1];

            ZephAICharacterOptions option = (ZephAICharacterOptions)(i);
            float weight = float.MinValue;

            switch (option)
            {
                case ZephAICharacterOptions.Wander:
                    {
                        if (currentGoal == AIGoals.LookForEnemies)
                            weight = 1f * OptionWeights.WanderWeight;
                    }
                    break;
                case ZephAICharacterOptions.AllOutAttack:
                    {
                        if (currentGoal == AIGoals.KillEnemies)
                            weight = 1f * OptionWeights.AllOutAttackWeight;
                    }
                    break;
                case ZephAICharacterOptions.ThrowSmokeScreen:
                    {
                        if (currentGoal != AIGoals.KillEnemies)
                            break;

                        if (Zeph.SmokeGrenadeAbility.CanUseAbility() == false)
                            break;
                        // Will be at least one
                        GameObject closestEnemy = null;
                        int maxNumber = 0;
                        List<Enemies> ViewableEnemies = GetViewableEnemies();
                        
                        for (int enemyIndex = 0; enemyIndex < ViewableEnemies.Count; enemyIndex++)
                        {
                            Enemies e = ViewableEnemies[enemyIndex];

                            int num = MathUtils.GetPlayersCloseToGameObject(e.Object, 10f, true, new Player[] { m_Player }).Length;

                            if(num > maxNumber)
                            {
                                closestEnemy = e.Object;
                                maxNumber = num;
                            }
                        }

                        if (closestEnemy == null)
                            break;

                        weight = 0.75f * maxNumber * OptionWeights.ThrowSmokeScreen;
                    }
                    break;
                case ZephAICharacterOptions.AttackTurret:
                    {
                        if (currentGoal == AIGoals.KillTurret)
                            weight = OptionWeights.AttackTurret;
                    }
                    break;
            }

            weights[i] = weight;
        }
        // End Calculating all the weights

        // Calculate value needed for being too low for contention (so we don't select anything stupid)
        float maxValue = float.MinValue;
        for (int weightIndex = 0; weightIndex < weights.Length; weightIndex++)
        {
            float weight = weights[weightIndex];

            if (weight > maxValue)
                maxValue = weight;
        }
        float cutOffPercentage = 0.2f; // Hard coded value, change as needed

        // Create the Dictionary to do the weighted random
        Dictionary<ZephAICharacterOptions, float> options = new Dictionary<ZephAICharacterOptions, float>();
        for (int i = 0; i < weights.Length; i++)
        {
            // Make sure we don't add anything that's too low on there
            if (weights[i] > maxValue * cutOffPercentage && weights[i] > 0f)
                options.Add((ZephAICharacterOptions)(i), weights[i]);
        }

        // Set the current option
        if (options.Count != 0)
        {
            ZephAICharacterOptions paigeOption = MathUtils.WeightedRandom<ZephAICharacterOptions>(options);
            switch (paigeOption)
            {
                case ZephAICharacterOptions.Wander:
                    AIBehaviour = new ZephWanderAIBehaviour(gameObject);
                    break;
                case ZephAICharacterOptions.AllOutAttack:
                    AIBehaviour = new ZephAllOutAttackAIBehaviour(gameObject);
                    break;
                case ZephAICharacterOptions.ThrowSmokeScreen:
                    AIBehaviour = new ZephSmokeScreenAIBehaviour(gameObject);
                    break;
                case ZephAICharacterOptions.AttackTurret:
                    AIBehaviour = new ZephDestroyTurretAIBehaviour(gameObject);
                    break;
                default:
#if UNITY_EDITOR
                    DebugManager.LogError("Zeph couldn't decide what to do!", Developmer.Nathan);
#endif
                    AIBehaviour = null;
                    break;
            }
        }
        else
        {
            AIBehaviour = new AIFindHealthBehaviour(gameObject);
        }
    }
}
