﻿using UnityEngine;
using System.Collections.Generic;
using System;

public class LeeroyAICharacter : AICharacter
{
    public class LeeroyAIOptionWeights
    {
        public float WanderWeight = 1f;
        public float AllOutAttackWeight = 1f;
        public float ClapStunWeight = 1f;
        public float GrenadeWeight = 1f;
        public float LeeroidRageWeight = 1f;

        public float KingOfTheHillWeight = 1f;
        public float TerritoriesWeight = 1f;
        public float JuggernautWeight = 1f;
        public float AttackTurret = 1f;
    }
    //
    // Public
    //
    public LeeroyAIOptionWeights OptionWeights = new LeeroyAIOptionWeights();
    public float FarDistance = 7.5f;
    public float RadiusOfSmokeScreen = 5f;

    protected Leeroy Leeroy;

    protected override void Start()
    {
        base.Start();

        Leeroy = GetComponent<Leeroy>();
        NavMeshArea = NavMeshAreaInformation.GetAreaForCharacter(CharacterTypes.Leeroy);
    }

    protected override void Update()
    {
        base.Update();

        bool includeMovementAbility = Leeroy.GauntletJumpAbility.CanUseAbility();
        NavMeshArea = NavMeshAreaInformation.GetAreaForCharacter(CharacterTypes.Leeroy, includeMovementAbility);

        // If we don't have a current behaviour, or our behaviour is done, choose a new one
        if (AIBehaviour == null)
            SelectOption();
        else if (AIBehaviour.Reset)
            SelectOption();

        // Act
        else
        {
            AIBehaviour.Act();
            if (AIBehaviour != null)
                AIBehaviour.DebugDraw();
        }
    }

    protected override void SelectOption()
    {
        AIGoals currentGoal = GetGoals()[0];

        GameModeType currentGameMode = InputManager.CM.GameModeManager.CurrentGameMode.GetGameModeType();
        switch (currentGameMode)
        {
            case GameModeType.KingOfTheHillGameMode:
                if(currentGoal != AIGoals.KeepMyselfAlive)
                {
                    AIBehaviour = new LeeroyKingOfTheHillBehaviour(gameObject);
                    return;
                }
                break;
            case GameModeType.TerritoriesGameMode:
                if (currentGoal != AIGoals.KeepMyselfAlive)
                {
                    AIBehaviour = new LeeroyTerritoriesBehaviour(gameObject);
                    return;
                }
                break;
        }

        float[] weights = new float[(int)(LeeroyAICharacterOptions.MAX_LEEROY_AI_CHARACTER_OPTIONS)];

        // Calculate all of the weights
        for (int i = 0; i < weights.Length; i++)
        {
            if (currentGoal == AIGoals.KeepMyselfAlive)
                currentGoal = GetGoals()[1];

            LeeroyAICharacterOptions option = (LeeroyAICharacterOptions)(i);
            float weight = float.MinValue;

            switch (option)
            {
                case LeeroyAICharacterOptions.KingOfTheHill:
                    if (currentGoal == AIGoals.KingOfTheHill)
                        weight = 1f * OptionWeights.KingOfTheHillWeight;
                    break;
                case LeeroyAICharacterOptions.Wander:
                    if (currentGoal == AIGoals.LookForEnemies)
                        weight = 1f * OptionWeights.WanderWeight;
                    break;
                case LeeroyAICharacterOptions.AllOutAttack:
                    if (currentGoal == AIGoals.KillEnemies)
                        weight = 1f * OptionWeights.AllOutAttackWeight;
                    break;
                case LeeroyAICharacterOptions.Grenade:
                    if (currentGoal != AIGoals.KillEnemies)
                        break;
                    
                    if (!(Leeroy.GauntletExplosiveAbility.CanUseAbility()))
                        break;
                    {
                        int maxNumber = 0;
                        {
                            // Will be at least one
                            GameObject closestEnemy = null;
                            
                            List<Enemies> ViewableEnemies = GetViewableEnemies();
                            for (int enemyIndex = 0; enemyIndex < ViewableEnemies.Count; enemyIndex++)
                            {
                                AICharacter.Enemies e = ViewableEnemies[enemyIndex];

                                int num = MathUtils.GetPlayersCloseToGameObject(e.Object, 10f, true, new Player[] { m_Player }).Length;

                                if (num > maxNumber)
                                {
                                    closestEnemy = e.Object;
                                    maxNumber = num;
                                }
                            }

                            if (closestEnemy == null)
                                break;
                        }

                        if (maxNumber > 1)
                            weight = maxNumber * 0.5f * OptionWeights.GrenadeWeight;
                        else
                        {
                            float dist = Vector3.Distance(transform.position, GetClosestViewableEnemy().Object.Position());

                            if (dist > 25f)
                                break;

                            weight = 1.43f * (Mathf.Pow(1.03f, dist)) - 1f;
                        }
                    }
                    break;
                case LeeroyAICharacterOptions.LeeroidRage:
                    if (currentGoal != AIGoals.KillEnemies)
                        break;
                    if (!(Leeroy.InjectionAbility.CanUseAbility()))
                        break;
                    {
                        int viewableEnemies = GetViewableEnemies().Count;
                        float health = m_Health.HealthPercentage;

                        weight = ((Mathf.Sqrt(-health + 100) / 10f) * 0.5f * viewableEnemies) * OptionWeights.LeeroidRageWeight;
                    }
                    break;
                case LeeroyAICharacterOptions.AttackTurret:
                    {
                        if (currentGoal == AIGoals.KillTurret)
                            weight = OptionWeights.AttackTurret;
                    }
                    break;
            }

            weights[i] = weight;
        }
        // End Calculating all the weights

        // Calculate value needed for being too low for contention (so we don't select anything stupid)
        float maxValue = float.MinValue;
        for (int weightIndex = 0; weightIndex < weights.Length; weightIndex++)
        {
            float weight = weights[weightIndex];

            if (weight > maxValue)
                maxValue = weight;
        }
        float cutOffPercentage = 0.2f; // Hard coded value, change as needed

        // Create the Dictionary to do the weighted random
        Dictionary<LeeroyAICharacterOptions, float> options = new Dictionary<LeeroyAICharacterOptions, float>();
        for (int i = 0; i < weights.Length; i++)
        {
            // Make sure we don't add anything that's too low on there
            if (weights[i] > maxValue * cutOffPercentage)
                options.Add((LeeroyAICharacterOptions)(i), weights[i]);
        }

        // Set the current option
        if (options.Count != 0)
        {
            LeeroyAICharacterOptions leeroyOption = MathUtils.WeightedRandom<LeeroyAICharacterOptions>(options);
            switch (leeroyOption)
            {
                case LeeroyAICharacterOptions.KingOfTheHill:
                    AIBehaviour = new LeeroyKingOfTheHillBehaviour(gameObject);
                    break;
                case LeeroyAICharacterOptions.Wander:
                    AIBehaviour = new LeeroyWanderAIBehaviour(gameObject);
                    break;
                case LeeroyAICharacterOptions.AllOutAttack:
                    AIBehaviour = new LeeroyAllOutAttackBehaviour(gameObject);
                    break;
                case LeeroyAICharacterOptions.LeeroidRage:
                    AIBehaviour = new LeeroyLeeroidRageAIBehaviour(gameObject);
                    break;
                case LeeroyAICharacterOptions.Grenade:
                    AIBehaviour = new LeeroyGrenadeAIBehaviour(gameObject);
                    break;
                case LeeroyAICharacterOptions.AttackTurret:
                    AIBehaviour = new LeeroyDestroyTurretAIBehaviour(gameObject);
                    break;
                default:
#if UNITY_EDITOR
                    DebugManager.LogError("AI Leeroy could not decide what to do!", Developmer.AllDevelopmers);
#endif
                    AIBehaviour = null;
                    break;
            }
        }
    }
}
