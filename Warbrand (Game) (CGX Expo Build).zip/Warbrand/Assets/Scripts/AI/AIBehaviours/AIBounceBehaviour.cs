﻿using UnityEngine;
using System.Collections;
using System;

public class AIBounceBehaviour : AIBehaviour
{
    private AIBehaviour m_ToReturnTo = null;
    private Vector3 m_LandingLocation;

    public AIBounceBehaviour(GameObject aOwner, AIBehaviour aToReturnTo) : base(aOwner)
    {
        m_ToReturnTo = aToReturnTo;
        m_LandingLocation = AIWanderPathfinding.GetRandomLandingLocation(); 
    }

    public override void Act()
    {
        m_AICharacter.MoveTowardsTarget(m_LandingLocation);
        m_AICharacter.LookTowardsTarget(m_LandingLocation);

        if (MathUtils.AIVector3Distance(Position, m_LandingLocation, 2f, 5f) || m_Player.GetComponent<BasicMovementScript>().IsGrounded)
        {
            SetAIBehaviour(m_ToReturnTo);
            m_ToReturnTo.HasStartedCooroutine = false;
        }
    }

    public override void DebugDraw()
    {
        base.DebugDraw();
    }

    public override string GetBehaviourName()
    {
        return AIString.BounceBehaviour;
    }
}