﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class ZephEscapeAIBehaviour : ZephAIBehaviour
{
    public ZephEscapeAIBehaviour(GameObject aOwner) : base(aOwner) { }

    private Vector3 m_EscapePoint;
    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;

    public override void Act()
    {
        if (m_Nodes == null)
        {
            if(m_AICharacter.CanSeeAtLeastOneEnemy)
            {
                m_Nodes = CalculatePath(AIWanderPathfinding.GetRandomPoint());
                m_NodeIndex = 0;
            }
            else
            {
                ClearAIBehaviour();
                return;
            }
        }

        FollowNodes(ref m_Nodes, ref m_NodeIndex, 1f, true);

        if (m_Zeph.SmokeGrenadeAbility.CanUseAbility())
            m_Input.SetInput(InputName.Ability2, 1f);

        if (m_Nodes == null)
            return;

        if(m_Nodes.Length <= m_NodeIndex)
        {
            m_Nodes = null;
        }

        else if (m_AICharacter.IsLookingAtPoint(m_Nodes[m_NodeIndex]) &&
            Vector3.Distance(Position, m_Nodes[m_NodeIndex]) > TeleportAbility.TeleportDistance &&
            m_Zeph.TeleportAbility.CanUseAbility())
        {
            m_Input.SetInput(InputName.Movement, 1f);
        }
    }

    public override void DebugDraw()
    {
        base.DebugDraw();

        if (m_Nodes == null)
            return;

        if (m_NodeIndex >= m_Nodes.Length)
            return;

        Debug.DrawLine(m_Nodes[m_NodeIndex], m_Nodes[m_NodeIndex] + Vector3.up * 50, DebugColour);
        for (int i = 0; i < m_Nodes.Length - 1; i++)
        {
            Debug.DrawLine(m_Nodes[i], m_Nodes[i + 1], DebugColour);
        }
    }

    public override string GetBehaviourName()
    {
        return AIString.ZephEscapeBehaviour;
    }
}