﻿using UnityEngine;
using System.Collections;
using System;

public class ZephWanderAIBehaviour : ZephAIBehaviour
{
    public ZephWanderAIBehaviour(GameObject aOwner) : base(aOwner) { }
    private int m_NodeIndex = 0;
    private Vector3[] m_Nodes = null;

    private float[] m_RadiusToCheck = { 2.5f, 7.5f };
    private int m_NumberOfChecks = 0;

    public override void Act()
    {
        if (m_AICharacter.CanSeeAtLeastOneEnemy)
        {
            ClearAIBehaviour();
            return;
        }

        if (CheckForRecentlySeenEnemies())
            return;

        if (m_Nodes == null)
        {
            Vector3 point = AIWanderPathfinding.GetRandomPoint();
            m_Nodes = CalculatePath(point);
            m_NodeIndex = 0;
        }

        FollowNodes(ref m_Nodes, ref m_NodeIndex, 1, true);

        if (m_Nodes != null && m_NodeIndex >= m_Nodes.Length)
            m_Nodes = null;
    }

    public override void DebugDraw()
    {
        base.DebugDraw();
    }

    private float m_DirtyTime = 1.5f;
    bool CheckForRecentlySeenEnemies()
    {
        for (int i = 0; i < m_AICharacter.EnemyList.Count; i++)
        {
            AICharacter.Enemies enemy = m_AICharacter.EnemyList[i];

            if (enemy.TimeSinceLastSeen < m_DirtyTime)
            {
                SetSearchBehaviour(enemy);
                return true;
            }
        }
        return false;
    }

    public override string GetBehaviourName()
    {
        return AIString.ZephWanderBehaviour;
    }
}