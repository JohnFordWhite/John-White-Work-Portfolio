﻿using UnityEngine;
using System.Collections;
using System;

public class ZephTakeDamageReactionBehaviour : ZephAIBehaviour
{
    private AIBehaviour m_BehaviourToReturnTo;
    private GameObject m_AttackingObject;

    public ZephTakeDamageReactionBehaviour(GameObject aObject, AIBehaviour aBehaviour, GameObject aAttackingObject) : base(aObject)
    {
        m_BehaviourToReturnTo = aBehaviour;
        m_AttackingObject = aAttackingObject;
    }

    public override void Act()
    {
        AICharacter.Enemies enemy = m_AICharacter.GetEnemyForObject(m_AttackingObject);

        if (enemy == null)
        {
#if UNITY_EDITOR
            DebugManager.LogError("Zeph AI Cannot Find Enemy", Developmer.AllDevelopmers);
#endif
            ClearAIBehaviour();
            return;
        }

        enemy.LastPosition = m_AttackingObject.transform.position;
        enemy.LastDirection = m_AttackingObject.GetComponent<Rigidbody>().velocity;
        enemy.TimeSinceLastSeen = 0f;

        if (m_BehaviourToReturnTo == null)
            SetSearchBehaviour(enemy);
        else if (m_BehaviourToReturnTo.GetBehaviourName() == AIString.ZephWanderBehaviour)
            SetSearchBehaviour(enemy);
        else if (m_BehaviourToReturnTo.GetBehaviourName() == AIString.ZephAllOutAttackBehaviour ||
                 m_BehaviourToReturnTo.GetBehaviourName() == AIString.ZephSmokeScreenBehaviour)
        {
            if (m_AICharacter.GetGoals()[0] == AIGoals.KeepMyselfAlive)
                SetEscapeBehaviour(enemy.Object);
            else
            {
                SetAIBehaviour(m_BehaviourToReturnTo);
                m_BehaviourToReturnTo.Act();
            }
        }
        else
        {
            SetAIBehaviour(m_BehaviourToReturnTo);
            m_BehaviourToReturnTo.Act();
        }
    }

    public override string GetBehaviourName()
    {
        return AIString.ZephTakeDamageReactionBehaviour;
    }
}