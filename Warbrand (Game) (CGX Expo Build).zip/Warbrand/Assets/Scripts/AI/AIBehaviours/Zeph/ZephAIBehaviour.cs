﻿using UnityEngine;
using System.Collections;

public enum ZephAICharacterOptions
{
    Null,
    Wander,
    AllOutAttack,
    ThrowSmokeScreen,
    AttackTurret,

    // Max
    MAX_ZEPH_AI_CHARACTER_OPTIONS
}

public abstract class ZephAIBehaviour : AIBehaviour
{
    public ZephAIBehaviour(GameObject aPlayer) : base(aPlayer) { }
}