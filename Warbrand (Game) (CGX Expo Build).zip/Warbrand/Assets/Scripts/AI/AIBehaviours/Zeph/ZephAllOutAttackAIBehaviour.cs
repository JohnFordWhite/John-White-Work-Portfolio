﻿using UnityEngine;
using System.Collections;

public class ZephAllOutAttackAIBehaviour : ZephAIBehaviour
{
    public ZephAllOutAttackAIBehaviour(GameObject aPlayer) : base(aPlayer) { }

    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;
    private GameObject m_Target = null;
    private float m_CloseEnoughToNode = 0.25f;

    // If our distance to the target is less than this amount, we'll start attacking.
    private float m_ApproachCloseEnoughDistance = 1f;
    private float m_AttackDistance = 3f;

    public override void Act()
    {
        // Start a cooroutine if we need to which will recheck our nodes at an average human reaction time
        if (!HasStartedCooroutine)
        {
            m_Player.StartCoroutine(CheckNodes());
            HasStartedCooroutine = true;
        }

        // If we have no nodes to travel to, lets find some nodes
        if (m_Nodes == null)
        {
            AICharacter.Enemies closestEnemy = m_AICharacter.GetClosestViewableEnemy();
            if (closestEnemy != null)
            {
                m_Nodes = CalculatePath(MathUtils.GetClosestPointOnNavMesh(m_AICharacter.GetClosestPositionToTargetGivenRadius(closestEnemy.Object.transform.position, m_ApproachCloseEnoughDistance * 0.9f)));
                m_NodeIndex = 0;
                m_Target = closestEnemy.Object;
            }
        }

        // If there is no viewable enemy, we have no target, and therefor can't attack
        if (m_Target == null)
        {
            ClearAIBehaviour();
            return;
        }
        if(m_Target.GetComponent<Health>().IsDead)
        {
            ClearAIBehaviour();
            return;
        }

        if (!(m_AICharacter.CanSeeObject(m_Target)))
            m_Nodes = null;

        // At this point, we have a target, but there's no path to them. We should just try to take a look around for them
        if (m_Nodes == null)
        {
            SetSearchBehaviour(m_AICharacter.GetEnemyForObject(m_Target));
            return;
        }

        // We have nodes, we have a target. Follow the nodes
        FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);
        m_AICharacter.LookTowardsTarget(m_Target.Position());

        // If we've finished the path, clear the nodes
        if (m_Nodes != null && m_NodeIndex >= m_Nodes.Length)
            ClearNodes();

        // If we're far enough away, we should teleport closer
        if (m_Nodes != null)
        {
            if (m_AICharacter.CanSeeObject(m_Target))
            {
                m_AICharacter.LookTowardsTarget(m_Target.Position());

                // Some debug stuff because weird shit's happening, yo
                bool isLookingAtPoint = m_AICharacter.IsLookingAtPoint(m_Target.Position(), 10f);
                bool canUseHook = m_Zeph.HookAbility.CanUseAbility();
                
                if (isLookingAtPoint)
                {
                    if (canUseHook)
                    {
                        m_Input.SetInput(InputName.Ability1, 1f - m_Input.GetInput(InputName.Ability1));
                    }

                    // Literally do not ask. Don't ask what this does. Don't do it
                    // Ask Jimmy before you ask me
                    bool isTrue = true;
                    if (isTrue)
                        isTrue = false;
                }
            }
            else if (Vector3.Distance(Position, m_Nodes[m_NodeIndex]) > TeleportAbility.TeleportDistance * 1.25f && m_Zeph.TeleportAbility.CanUseAbility())
            {
               // Debug.Log("Here");
                m_Input.SetInput(InputName.Movement, 1f);
               // Debug.Log("Here");
            }
        }

        // We're close enough to the player
        if (MathUtils.AIVector3Distance(m_Player.transform.position, m_Target.transform.position, m_AttackDistance, 5f))
        {
            if (m_AICharacter.IsLookingAtPoint(m_Target.Position(), 10f))
                m_Input.SetInput(InputName.Attack1, 1f);
        }
    }

    public override void DebugDraw()
    {
        base.DebugDraw();

        if (m_Nodes == null)
            return;

        if (m_NodeIndex >= m_Nodes.Length)
            return;

        Debug.DrawLine(m_Nodes[m_NodeIndex], m_Nodes[m_NodeIndex] + Vector3.up * 50, DebugColour);
        for (int i = 0; i < m_Nodes.Length - 1; i++)
        {
            Debug.DrawLine(m_Nodes[i], m_Nodes[i + 1], DebugColour);
        }
    }

    private void ClearNodes()
    {
        m_Nodes = null;
        m_NodeIndex = 0;
    }

    IEnumerator CheckNodes()
    {
        for (;;)
        {
            yield return new WaitForSeconds(0.2f);
            ClearNodes();
        }
    }

    public override string GetBehaviourName()
    {
        return AIString.ZephAllOutAttackBehaviour;
    }
}
