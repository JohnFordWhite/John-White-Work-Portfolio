﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ZephTerritoriesBehaviour : ZephAIBehaviour
{
    public ZephTerritoriesBehaviour(GameObject aOwner) : base(aOwner)
    {
        List<GameObject> objs = new List<GameObject>(Information.AllTerritories);

        for (int i = 0; i < objs.Count; i++)
        {
            if (objs[i].GetComponent<TerritoryObjective>().m_TerritoryOwnerTeam == m_Player.TeamIndex)
            {
                objs.RemoveAt(i--);
            }
        }

        if (objs.Count > 0)
            m_CurrentTerritory = objs[UnityEngine.Random.Range(0, objs.Count)].GetComponent<TerritoryObjective>();
        else
            SetAIBehaviour(new LeeroyWanderAIBehaviour(m_Player.gameObject));
    }

    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;

    private TerritoryObjective m_CurrentTerritory = null;

    private const float m_CloseEnoughToNode = 1f;
    private const float m_ApproachCloseEnoughToAttackDistance = 3f;

    public override void Act()
    {
        if (m_CurrentTerritory == null)
        {
            ClearAIBehaviour();
            return;
        }
        if (m_CurrentTerritory.m_TerritoryOwnerTeam == m_Player.TeamIndex)
        {
            ClearAIBehaviour();
            return;
        }

        // Start a cooroutine if we need to which will recheck our nodes at an average human reaction time
        if (!HasStartedCooroutine)
        {
            m_Player.StartCoroutine(CheckNodes());
            HasStartedCooroutine = true;
        }

        if (m_AICharacter.GetGoals()[0] == AIGoals.KeepMyselfAlive)
        {
            SetSearchForHealthBehaviour();
            return;
        }

        if (m_CurrentTerritory.IsPlayerInsideObjective(m_Player.gameObject))
            DefendFunction();
        else
            ApproachFunction();

        // We're close enough to our current enemy - attack

        foreach (var enemy in m_AICharacter.GetViewableEnemies())
        {
            if (MathUtils.AIVector3Distance(m_Player.transform.position, enemy.LastPosition, m_ApproachCloseEnoughToAttackDistance, 5f))
            {
                if (m_AICharacter.IsLookingAtPoint(enemy.LastPosition, 10f))
                    m_Input.SetInput(InputName.Attack1, 1f);
            }
        }
    }

    private void ApproachFunction()
    {
        bool canSeeEnemy = m_AICharacter.CanSeeAtLeastOneEnemy;
        bool canSeeHill = true;

        if (m_Nodes == null)
        {
            m_Nodes = CalculatePath(m_CurrentTerritory.PointAtGround);
            m_NodeIndex = 0;
        }

        RaycastHit[] hits = Physics.RaycastAll(Position, MathUtils.DirectionVector(Position, m_CurrentTerritory.PointAtGround + Vector3.up), Vector3.Distance(Position, m_CurrentTerritory.PointAtGround + Vector3.up));

        for (int i = 0; i < hits.Length; i++)
        {
            if (hits[i].collider.isTrigger)
                continue;
            if (hits[i].transform.GetComponent<PlayerHitboxScript>() != null)
                continue;
            if (hits[i].transform.GetComponent<TurretScript>() != null)
                continue;

            canSeeHill = false;
        }
        if (canSeeHill && m_CurrentTerritory.PlayersInsideTerritory.Count > 0)
        {
            FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);
            m_AICharacter.LookTowardsTarget(m_CurrentTerritory.PlayersInsideTerritory[0].transform.position);
            if (m_AICharacter.IsLookingAtPoint(m_CurrentTerritory.PlayersInsideTerritory[0].transform.position))
                m_Input.SetInput(InputName.Ability1, 1f);
        }
        else if (canSeeEnemy)
        {
            FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);
            m_AICharacter.LookTowardsTarget(m_AICharacter.GetClosestViewableEnemy().LastPosition);
        }
        else
        {
            FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, true);
        }
    }

    private bool m_CanSeeEnemy = false;
    private void DefendFunction()
    {
        bool isOtherPlayerInHill = false;
        Player[] otherPlayers = m_CurrentTerritory.PlayersInsideTerritory.ToArray();
        for (int i = 0; i < otherPlayers.Length; i++)
        {
            if (otherPlayers[i].TeamIndex == m_Player.TeamIndex)
                continue;

            isOtherPlayerInHill = true;
        }

        GameObject closestEnemy = null;
        {
            var enemy = m_AICharacter.GetClosestViewableEnemy(true);
            if (enemy != null)
                closestEnemy = enemy.Object;

            if (closestEnemy != null && !m_CanSeeEnemy)
            {
                m_Nodes = null;
                m_CanSeeEnemy = true;
            }
        }

        if (closestEnemy == null)
            SearchHill();
        else if (m_CurrentTerritory.IsPlayerInsideObjective(closestEnemy))
        {
            if (m_Nodes == null)
            {
                m_Nodes = CalculatePath(closestEnemy.Position());
                m_NodeIndex = 0;
            }

            FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);
            m_AICharacter.LookTowardsTarget(closestEnemy.Position());

            if (m_AICharacter.IsLookingAtPoint(closestEnemy.Position()) && m_Zeph.SmokeGrenadeAbility.CanUseAbility())
                m_Input.SetInput(InputName.Ability2, 1f);
        }
        else if (!isOtherPlayerInHill)
        {
            if (m_Nodes == null)
            {
                m_Nodes = CalculatePath(m_AICharacter.GetClosestPositionToTargetGivenRadius2D(m_CurrentTerritory.GetComponent<Collider>().bounds.ClosestPoint(closestEnemy.transform.position), 5f));
                m_NodeIndex = 0;
            }

            FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);
            m_AICharacter.LookTowardsTarget(closestEnemy.Position());
        }
        else
            SearchHill();
    }

    private void SearchHill()
    {
        m_CanSeeEnemy = false;
        if (m_Nodes == null)
        {
            m_Nodes = CalculatePath(m_CurrentTerritory.PointAtGround);
            m_NodeIndex = 0;
        }

        FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);
        m_AICharacter.SetRightAnalogStick(Vector2.right);
    }

    public override void DebugDraw()
    {
        base.DebugDraw();
    }

    public override string GetBehaviourName()
    {
        return AIString.ZephKingOfTheHillBehaviour;
    }

    IEnumerator CheckNodes()
    {
        for (;;)
        {
            yield return new WaitForSeconds(0.2f);
            m_Nodes = null;
            m_NodeIndex = 0;
        }
    }
}