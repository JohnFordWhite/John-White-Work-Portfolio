﻿using UnityEngine;
using System.Collections;
using System;

public enum OffMeshLinkType
{
    Jump,
    Drop,
    Jetpack,
    Pounce,
    Teleport
}

public class AITraverseOffMeshLink : AIBehaviour
{
    private AIBehaviour m_ToReturnTo;
    private Vector3 m_StartPosition;
    private Vector3 m_EndPosition;
    private OffMeshLinkType m_OffMeshLinkType;

    public AITraverseOffMeshLink(GameObject aOwner, OffMeshLinkData aOffMeshLinkData, AIBehaviour aBehaviourToReturnTo, OffMeshLinkType aOffMeshLinkType) : base(aOwner)
    {
        m_StartPosition = aOffMeshLinkData.startPos;
        m_EndPosition = aOffMeshLinkData.endPos;
        m_ToReturnTo = aBehaviourToReturnTo;
        m_OffMeshLinkType = aOffMeshLinkType;
    }

    public AITraverseOffMeshLink(GameObject aOwner, Vector3 aStartPosition, Vector3 aEndPosition, AIBehaviour aBehaviourToReturnTo, OffMeshLinkType aOffMeshLinkType) : base(aOwner)
    {
        m_StartPosition = aStartPosition;
        m_EndPosition = aEndPosition;
        m_ToReturnTo = aBehaviourToReturnTo;
        m_OffMeshLinkType = aOffMeshLinkType;
    }

    private const float PAIGE_RISE_AMOUNT = 5f;
    private bool m_LeeroyHasCalledCooroutine = false;
    public override void Act()
    {
        switch (m_OffMeshLinkType)
        {
            case OffMeshLinkType.Jump:
                {
                    m_AICharacter.MoveTowardsTarget(m_EndPosition);
                    m_AICharacter.LookTowardsTarget(m_EndPosition);

                    if (MathUtils.AIVector3Distance(Position, m_EndPosition, 2f, 25f))
                        Return();
                    else
                        m_Input.SetInput(InputName.Jump, 1f - m_Input.GetInput(InputName.Jump));
                }
                break;
            case OffMeshLinkType.Drop:
                {
                    m_AICharacter.MoveTowardsTarget(m_EndPosition);
                    m_AICharacter.LookTowardsTarget(m_EndPosition);

                    if (MathUtils.AIVector3Distance(Position, m_EndPosition, 2f, 25f))
                        Return();
                }
                break;
            case OffMeshLinkType.Jetpack:
                {
                    if (!(m_Paige.CanUseMovementAbility))
                    {
                        ClearAIBehaviour();
                        return;
                    }

                    if(Position.y < m_EndPosition.y)
                    {
                        m_AICharacter.SetLeftAnalogStick(Vector2.zero);
                        m_Input.SetInput(InputName.Movement, 1f);
                    }
                    else
                    {
                        bool descend = (Vector2.Distance(Position.xz(), m_EndPosition.xz()) < Mathf.Abs(Position.y - m_EndPosition.y)) ? true : false;

                        if(Position.y < m_EndPosition.y + PAIGE_RISE_AMOUNT && !descend)
                        {
                            m_Input.SetInput(InputName.Movement, 1f);
                        }

                        m_AICharacter.MoveTowardsTarget(m_EndPosition);
                        m_AICharacter.LookTowardsTarget(m_EndPosition);
                    }

                    if (MathUtils.AIVector3Distance(Position, m_EndPosition, 2f, 25f))
                        Return();
                }
                break;
            case OffMeshLinkType.Pounce:
                {
                    if (!m_LeeroyHasCalledCooroutine)
                    {
                        if (!(m_Leeroy.CanUseMovementAbility))
                        {
                            ClearAIBehaviour();
                            return;
                        }

                        m_AICharacter.LookTowardsTarget(m_EndPosition);

                        if (m_AICharacter.IsLookingAtPoint(m_EndPosition, 10f))
                        {
                            m_Input.SetInput(InputName.Movement, 1f);
                            m_AICharacter.StartCoroutine(LeeroyCheckGroundCooroutine());
                        }
                    }
                    else
                    {
                        m_Input.SetInput(InputName.Movement, 1f);
                        m_AICharacter.MoveTowardsTarget(m_EndPosition);
                        m_AICharacter.LookTowardsTarget(m_EndPosition);
                    }
                }
                break;
            case OffMeshLinkType.Teleport:
                {

                }
                break;
            default:
                break;
        }
        
    }

    IEnumerator LeeroyCheckGroundCooroutine()
    {
        m_LeeroyHasCalledCooroutine = true;
        yield return new WaitForSeconds(0.75f);

        bool done = false;
        while(!done)
        {
            if(m_Player.GetComponent<BasicMovementScript>().IsGrounded)
            {
                done = true;
                Return();
            }
            yield return null;
        }
    }

    void Return()
    {
        SetAIBehaviour(m_ToReturnTo);
        m_ToReturnTo.HasStartedCooroutine = false;
    }

    public override void DebugDraw()
    {
        base.DebugDraw();

        switch (m_OffMeshLinkType)
        {
            case OffMeshLinkType.Drop:
                break;
            case OffMeshLinkType.Jetpack:
                break;
            case OffMeshLinkType.Pounce:
                Debug.DrawLine(Position, Position + MathUtils.DirectionVector(Position, m_EndPosition) * 5f, DebugColour);
                break;
            case OffMeshLinkType.Teleport:
                break;
            default:
                break;
        }

        m_ToReturnTo.DebugDraw();
    }

    public override string GetBehaviourName()
    {
        return AIString.TraverseOffMeshLink + " - " + m_ToReturnTo.GetBehaviourName();
    }
}