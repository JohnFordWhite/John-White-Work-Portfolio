﻿using UnityEngine;
using System.Collections;

public enum LeeroyAICharacterOptions
{
    Null,
    Wander,
    AllOutAttack,
    Grenade,
    LeeroidRage,

    KingOfTheHill,
    Territories,
    Juggernaut,
    AttackTurret,

    // Max
    MAX_LEEROY_AI_CHARACTER_OPTIONS
}

public abstract class LeeroyAIBehaviour : AIBehaviour
{
    public LeeroyAIBehaviour(GameObject aPlayer) : base(aPlayer) { }
}