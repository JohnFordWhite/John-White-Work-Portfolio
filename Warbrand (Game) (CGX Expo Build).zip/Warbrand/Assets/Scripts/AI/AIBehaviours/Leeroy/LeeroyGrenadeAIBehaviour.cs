using UnityEngine;
using System.Collections;
using System;

public class LeeroyGrenadeAIBehaviour : LeeroyAIBehaviour
{
    public LeeroyGrenadeAIBehaviour(GameObject aPlayer) : base(aPlayer)
    {
    }
    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;

    private Vector3 m_TargetPosition = Vector3.zero;
    
    private bool m_CanSeeTargetPosition = false;

    public const float MAX_DISTANCE = 31.855f;

    public override void Act()
    {
        if (!HasStartedCooroutine)
            m_AICharacter.StartCoroutine(FindTargetPositionCooroutine());

        if (m_TargetPosition == Vector3.zero)
            FindTargetPosition();

        if (m_Nodes == null)
        {
            m_Nodes = CalculatePath(m_TargetPosition);
            m_NodeIndex = 0;
        }

        FollowNodes(ref m_Nodes, ref m_NodeIndex, 1f);

        if (m_Nodes != null && m_NodeIndex >= m_Nodes.Length)
            m_Nodes = null;

        if (m_CanSeeTargetPosition && Vector3.Distance(Position, m_TargetPosition) < MAX_DISTANCE)
            Throw ();
    }

    private void Throw()
    {
        // Hard coded values are derived from Physics Kinematic equations
        float distance = Vector3.Distance(Position, m_TargetPosition);
        float angle = Mathf.Asin(0.015696f * distance);
        float h = 0.318552497f * Mathf.Sin(angle * Mathf.Deg2Rad);

        Vector3 halfwayPoint = Position + new Vector3(m_AICharacter.transform.forward.x, 0, m_AICharacter.transform.forward.z) * (distance * 0.5f) + Vector3.up * h;
        RaycastHit[] hits = Physics.RaycastAll(Position, MathUtils.DirectionVector(Position, halfwayPoint), Vector3.Distance(Position, halfwayPoint));
        bool pathClear = true;
        foreach (var hit in hits)
        {
            if (hit.transform.GetComponent<PlayerHitboxScript>() || hit.transform.GetComponent<TurretScript>())
                continue;
            if (hit.collider.isTrigger)
                continue;
            pathClear = false;
            break;
        }

        if (pathClear)
        {
            LookTowardsAngle(angle);
            if(IsLookingTowardsAngle(angle))
            {
                m_Input.SetInput(InputName.Ability2, 1f);
                ClearAIBehaviour();
            }
        }
        else
        {
            LookTowardsAngle(10f);
            if (IsLookingTowardsAngle(10f))
            {
                m_Input.SetInput(InputName.Ability2, 1f);
                ClearAIBehaviour();
            }
        }
           
    }

    public override void DebugDraw()
    {
        base.DebugDraw();

        Debug.DrawLine(m_AICharacter.transform.position, m_TargetPosition, DebugColour);

        if(m_Nodes != null)
        {
            for (int i = 0; i < m_Nodes.Length - 1; i++)
                Debug.DrawLine(m_Nodes[i], m_Nodes[i + 1], DebugColour);
        }
    }

    IEnumerator FindTargetPositionCooroutine()
    {
        HasStartedCooroutine = true;
        while (true)
        {
            FindTargetPosition();
            yield return new WaitForSeconds(2f);
        }
    }

    void FindTargetPosition()
    {
        m_CanSeeTargetPosition = true;
        RaycastHit[] hits = Physics.RaycastAll(Position, MathUtils.DirectionVector(Position, m_TargetPosition), Vector3.Distance(Position, m_TargetPosition));
        foreach (var hit in hits)
        {
            if (hit.transform.GetComponent<PlayerHitboxScript>() || hit.transform.GetComponent<TurretScript>())
                continue;
            if (hit.collider.isTrigger)
                continue;
            m_CanSeeTargetPosition = false;
            break;
        }

        if (m_CanSeeTargetPosition)
        {
            Player[] closePlayers = null;
            { // Variable Scope Control
                GameObject closestEnemy = null;
                int maxNumber = 0;

                for (int i = 0; i < m_AICharacter.EnemyList.Count; i++)
                {
                    AICharacter.Enemies e = m_AICharacter.EnemyList[i];
                    if (!(e.CanSee))
                        continue;
                    Player[] players = MathUtils.GetPlayersCloseToGameObject(e.Object, 10f, true, new Player[] { m_Player });
                    int num = players.Length;

                    if (num > maxNumber)
                    {
                        closestEnemy = e.Object;
                        maxNumber = num;
                        closePlayers = players;
                    }
                }

                if (closestEnemy == null)
                {
                    ClearAIBehaviour();
                }
            } // End Variable Scope Control

            if (closePlayers == null)
            {
                ClearAIBehaviour();
                return;
            }

            Vector3[] points = new Vector3[closePlayers.Length];
            for (int i = 0; i < closePlayers.Length; i++)
                points[i] = closePlayers[i].transform.position;
            m_TargetPosition = MathUtils.Average(points) + Vector3.up;
        }
    }

    public override string GetBehaviourName()
    {
        return AIString.LeeroyGrenadeBehaviour;
    }
}