﻿using UnityEngine;
using System.Collections;

public class LeeroyDestroyTurretAIBehaviour : LeeroyAIBehaviour
{
    private TurretScript m_Turret;
    public LeeroyDestroyTurretAIBehaviour(GameObject aOwner) : base(aOwner)
    {
        TurretScript[] turrets = Information.AllTurrets.ToArray();
        for (int i = 0; i < turrets.Length; i++)
        {
            if (turrets[i].Owner.TeamIndex == m_Player.TeamIndex)
                continue;

            if (m_AICharacter.CanSeeObject(turrets[i].gameObject))
            {
                m_Turret = turrets[i];
                break;
            }
        }
    }
    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;

    private const float CLOSE_DISTANCE = 1f;

    public override void Act()
    {
        if (m_Nodes == null)
        {
            m_Nodes = CalculatePath(m_AICharacter.GetClosestPositionToTargetGivenRadius2D(m_Turret.transform.position, CLOSE_DISTANCE));
            m_NodeIndex = 0;
        }
        
        FollowNodes(ref m_Nodes, ref m_NodeIndex, 1f, false);
        m_AICharacter.LookTowardsTarget(m_Turret.transform.position);

        if (m_NodeIndex >= m_Nodes.Length)
            m_Nodes = null;

        if (m_AICharacter.IsLookingAtPoint(m_Turret.transform.position))
            m_Input.SetInput(InputName.Attack1, 1f - m_Input.GetInput(InputName.Attack1));

        if (m_Turret.GetComponent<Health>().IsDead)
            ClearAIBehaviour();
    }

    public override void DebugDraw()
    {
        base.DebugDraw();

        if (m_Nodes != null)
        {
            for (int i = 0; i < m_Nodes.Length - 1; i++)
            {
                Debug.DrawLine(m_Nodes[i], m_Nodes[i + 1], DebugColour);
            }
        }

        if (m_Turret != null)
            Debug.DrawLine(Position, m_Turret.transform.position);
    }

    public override string GetBehaviourName()
    {
        return AIString.LeeroyDestroyTurretBehaviour;
    }
}