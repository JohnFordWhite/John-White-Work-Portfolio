using UnityEngine;
using System.Collections;
using System;

public class LeeroyLeeroidRageAIBehaviour : LeeroyAIBehaviour
{
    public LeeroyLeeroidRageAIBehaviour(GameObject aPlayer) : base(aPlayer)
    {
    }

    public override void Act()
    {
        m_Input.SetInput(InputName.Ability3, 1f);
        ClearAIBehaviour();
    }

    public override void DebugDraw()
    {
        base.DebugDraw();
    }

    public override string GetBehaviourName()
    {
        return AIString.LeeroyLeeroidRageBehaviour;
    }
}