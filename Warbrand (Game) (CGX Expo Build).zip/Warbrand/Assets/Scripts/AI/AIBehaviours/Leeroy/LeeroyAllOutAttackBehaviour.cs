﻿using UnityEngine;
using System.Collections;
using System;

public class LeeroyAllOutAttackBehaviour : LeeroyAIBehaviour
{
    public LeeroyAllOutAttackBehaviour(GameObject aPlayer) : base(aPlayer) { }

    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;
    private GameObject m_Target = null;
    private float m_CloseEnoughToNode = 1f;

    // If our distance to the target is less than this amount, we'll start attacking.
    private float m_ApproachCloseEnoughDistance = 3f;

    public override void Act()
    {
        // Start a cooroutine if we need to which will recheck our nodes at an average human reaction time
        if (!HasStartedCooroutine)
        {
            m_Player.StartCoroutine(CheckNodes());
            HasStartedCooroutine = true;
        }

        if(m_Leeroy.InjectionAbility.CanUseAbility())
            m_Input.SetInput(InputName.Ability3, 1f - m_Input.GetInput(InputName.Ability3));

        // If we have no nodes to travel to, lets find some nodes
        if (m_Nodes == null)
        {
            AICharacter.Enemies closestEnemy = m_AICharacter.GetClosestViewableEnemy();
            if (closestEnemy != null)
            {
                m_Nodes = CalculatePath(MathUtils.GetClosestPointOnNavMesh(closestEnemy.Object.transform.position));
                m_NodeIndex = 0;
                m_Target = closestEnemy.Object;
            }
        }

        // If we're in the air, something has gone wrong. Stop moving until we're grounded again
        if (!(m_Player.GetComponent<BasicMovementScript>().IsGrounded))
        {
            ClearNodes();
            return;
        }

        // If there is no viewable enemy, we have no target, and therefor can't attack
        if (m_Target == null && m_Target.GetComponent<Health>().IsDead)
        {
            ClearAIBehaviour();
            return;
        }

        // At this point, we have a target, but there's no path to them. We should just try to take a look around for them
        if (m_Nodes == null)
        {
            SetSearchBehaviour(m_AICharacter.GetEnemyForObject(m_Target));
            return;
        }

        // We have nodes, we have a target. Follow the nodes
        FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);
        m_AICharacter.LookTowardsTarget(m_Target.Position());

        // If we've finished the path, clear the nodes
        if (m_Nodes != null && m_NodeIndex >= m_Nodes.Length)
            ClearNodes();

        // We're close enough to our current node - attack
        if (MathUtils.AIVector3Distance(m_Player.transform.position, m_Target.transform.position, m_ApproachCloseEnoughDistance, 5f))
        {
            if (m_AICharacter.IsLookingAtPoint(m_Target.Position()))
                m_Input.SetInput(InputName.Attack1, 1f - m_Input.GetInput(InputName.Attack1));
        }
    }

    public override void DebugDraw()
    {
        base.DebugDraw();
    }

    private void ClearNodes()
    {
        m_Nodes = null;
        m_NodeIndex = 0;
    }

    IEnumerator CheckNodes()
    {
        for (;;)
        {
            yield return new WaitForSeconds(0.2f);
            ClearNodes();
        }
    }

    public override string GetBehaviourName()
    {
        return AIString.LeeroyAllOutAttackBehaviour;
    }
}