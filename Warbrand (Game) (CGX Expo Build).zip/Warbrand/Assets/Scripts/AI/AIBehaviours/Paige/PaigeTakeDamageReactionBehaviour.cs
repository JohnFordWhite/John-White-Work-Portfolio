﻿using UnityEngine;
using System.Collections;
using System;

public class PaigeTakeDamageReactionBehaviour : PaigeAIBehaviour
{
    private AIBehaviour m_BehaviourToReturnTo;
    private GameObject m_AttackingObject;

    public PaigeTakeDamageReactionBehaviour(GameObject aObject, AIBehaviour aBehaviour, GameObject aAttackingObject) : base(aObject)
    {
        m_BehaviourToReturnTo = aBehaviour;
        m_AttackingObject = aAttackingObject;
    }

    public override void Act()
    {
        AICharacter.Enemies enemy = m_AICharacter.GetEnemyForObject(m_AttackingObject);

        if(enemy == null)
        {
#if UNITY_EDITOR
            DebugManager.LogError("Paige AI Cannot Find Enemy", Developmer.AllDevelopmers);
#endif
            ClearAIBehaviour();
            return;
        }

        enemy.LastPosition = m_AttackingObject.transform.position;
        enemy.LastDirection = m_AttackingObject.GetComponent<Rigidbody>().velocity;
        enemy.TimeSinceLastSeen = 0f;

        if (m_BehaviourToReturnTo == null)
            SetSearchBehaviour(enemy);
        else if (m_BehaviourToReturnTo.GetBehaviourName() == AIString.PaigeHealBehaviour)
            SetEscapeBehaviour(enemy.Object);
        else if (m_BehaviourToReturnTo.GetBehaviourName() == AIString.PaigeWanderBehaviour)
            SetSearchBehaviour(enemy);
        else
        {
            SetAIBehaviour(m_BehaviourToReturnTo);
            m_BehaviourToReturnTo.Act();
        }
    }
    
    public override string GetBehaviourName()
    {
        return AIString.PaigeTakeDamageReactionBehaviour;
    }
}
