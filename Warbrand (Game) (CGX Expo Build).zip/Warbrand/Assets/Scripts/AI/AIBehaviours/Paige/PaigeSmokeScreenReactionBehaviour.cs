﻿using UnityEngine;
using System.Collections;
using System;

public class PaigeSmokeScreenReactionBehaviour : PaigeAIBehaviour
{
    public PaigeSmokeScreenReactionBehaviour(GameObject aOwner) : base(aOwner) { }

    public override void Act()
    {
        m_AICharacter.SetLeftAnalogStick(Vector2.down);
        m_Input.SetInput(InputName.Movement, 1f);

        if (!(m_Player.IsAffectedBySmokeScreen))
            ClearAIBehaviour();
    }

    public override string GetBehaviourName()
    {
        return AIString.PaigeSmokeScreenReactionBehaviour;
    }
}