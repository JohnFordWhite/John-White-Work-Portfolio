﻿using UnityEngine;
using System.Collections;
using System;

public class PaigeCautiousAttackBehaviour : PaigeAIBehaviour
{
    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;
    private GameObject m_Target = null;
    public PaigeCautiousAttackBehaviour(GameObject aPlayer) : base(aPlayer) { }

    private float m_TooCloseDistance = 10f;
    private float m_CloseEnoughDistance = 15f;

    public override void Act()
    {
        if(m_Target != null)
        {
            if (!(m_AICharacter.CanSeeObject(m_Target)))
            {
                ClearAIBehaviour();
                return;
            }
            if(m_Target.GetComponent<Health>().IsDead)
            {
                ClearAIBehaviour();
                return;
            }
        }

        if(!(m_AICharacter.CanSeeAtLeastOneEnemy))
        {
            ClearAIBehaviour();
            return;
        }

        if (m_Target == null)
        {
            m_Target = m_AICharacter.GetClosestViewableEnemy().Object;

            if (m_Target == null)
            {
                ClearAIBehaviour();
                return;
            }
        }

        if (m_Target)
        {
            if (MathUtils.AIVector3Distance(m_Player.transform.position, m_Target.Position(), m_TooCloseDistance, m_TooCloseDistance))
            {
                SetEscapeBehaviour(m_Target);
            }
        }

        if (m_Nodes == null)
        {
            m_Nodes = CalculatePath(m_AICharacter.GetClosestPositionToTargetGivenRadius(m_Target.transform.position + m_Target.GetComponent<Rigidbody>().velocity, m_CloseEnoughDistance));
            m_NodeIndex = 0;

            if (m_Nodes.Length < 2)
                SetEscapeBehaviour(m_AICharacter.GetClosestViewableEnemy().Object);
        }
        FollowNodes(ref m_Nodes, ref m_NodeIndex, 1, false);
        m_AICharacter.LookTowardsTarget(m_Target.transform.position);

        if(m_Nodes != null && m_Nodes.Length <= m_NodeIndex)
        {
            m_Nodes = null;
            m_NodeIndex = 0;
        }
    }

    public override void DebugDraw()
    {
        base.DebugDraw();
        if (m_Nodes == null)
            return;

        if (m_NodeIndex >= m_Nodes.Length)
            return;

        Debug.DrawLine(m_Nodes[m_NodeIndex], m_Nodes[m_NodeIndex] + Vector3.up * 50, DebugColour);
        for (int i = 0; i < m_Nodes.Length - 1; i++)
        {
            Debug.DrawLine(m_Nodes[i], m_Nodes[i + 1], DebugColour);
        }
    }
    public override string GetBehaviourName()
    {
        return AIString.PaigeCautiousAttackBehaviour;
    }
}
