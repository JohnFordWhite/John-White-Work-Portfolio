﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class PaigeKingOfTheHillBehaviour : PaigeAIBehaviour
{
    public PaigeKingOfTheHillBehaviour(GameObject aOwner) : base(aOwner) { }

    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;

    private const float m_CloseEnoughToNode = 1f;
    private const float m_ApproachCloseEnoughToAttackDistance = 15f;
    private const float m_TooClosePanicDistance = 5f;

    private HillObjective m_CurrentHill = null;

    public override void Act()
    {
        // Start a cooroutine if we need to which will recheck our nodes at an average human reaction time
        if (!HasStartedCooroutine)
        {
            m_Player.StartCoroutine(CheckNodes());
            HasStartedCooroutine = true;
        }

        if (m_AICharacter.GetGoals()[0] == AIGoals.KeepMyselfAlive)
        {
            SetSearchForHealthBehaviour();
            return;
        }

        HillObjective hill = Information.ActiveHill.GetComponent<HillObjective>();
        if (m_CurrentHill != hill)
        {
            m_CurrentHill = hill;
            m_Nodes = null;
        }

        if (m_CurrentHill == null)
            return;

        if (m_CurrentHill.IsPlayerInsideObjective(m_Player.gameObject) && !m_IsFlying)
            DefendFunction();
        else
            ApproachFunction();
    }

    private bool m_IsFlying = false;
    private bool m_CanSeeHill = true;
    private void ApproachFunction()
    {
        m_CanSeeHill = true;
        {
            RaycastHit[] hits = Physics.RaycastAll(Position,
                                                   MathUtils.DirectionVector(Position, m_CurrentHill.PointAtGround + Vector3.up),
                                                   Vector3.Distance(Position, m_CurrentHill.PointAtGround + Vector3.up));
            for (int i = 0; i < hits.Length; i++)
            {
                RaycastHit hit = hits[i];

                if (hit.collider.isTrigger)
                    continue;
                if (hit.transform.GetComponent<PlayerHitboxScript>())
                    continue;
                if (hit.transform.GetComponent<TurretScript>())
                    continue;

                m_CanSeeHill = false;
            }
        }

        if (m_CanSeeHill)
        {
            Vector3? point = null;
            {
                List<Player> players = m_CurrentHill.PlayersInsideHill;
                for (int i = 0; i < players.Count; i++)
                {
                    if (players[i].TeamIndex == m_Player.TeamIndex)
                    {
                        players.RemoveAt(i);
                        i--;
                    }
                }

                if (players.Count > 0)
                {
                    Vector3[] points = new Vector3[players.Count];
                    for (int i = 0; i < players.Count; i++)
                        points[i] = players[i].transform.position;
                    point = MathUtils.Average(points);
                }
            }

            if(point.HasValue)
            {
                if(!(m_Paige.GroundPoundAbility.ContinuousAbilityStarted))
                    m_IsFlying = true;

                if (m_Nodes == null)
                {
                    m_Nodes = CalculatePath(point.Value);
                    m_NodeIndex = 0;
                }

                FollowNodes(ref m_Nodes, ref m_NodeIndex, 1f, false);
                m_AICharacter.LookTowardsTarget(m_CurrentHill.PointAtGround);

                if (m_Nodes != null && m_NodeIndex >= m_Nodes.Length)
                    m_Nodes = null;

                bool highEnough = true;
                {
                    RaycastHit[] hits = Physics.RaycastAll(Position, Vector3.down, GroundPoundAbility.MinimumHeight * 1.1f, -1, QueryTriggerInteraction.Ignore);
                    for (int i = 0; i < hits.Length; i++)
                    {
                        if (hits[i].transform.GetComponent<PlayerHitboxScript>())
                            continue;
                        if (hits[i].transform.GetComponent<TurretScript>())
                            continue;

                        highEnough = false;
                    }
                }

                if (!highEnough)
                    m_Input.SetInput(InputName.Movement, 1f);

                if(MathUtils.AIVector3Distance(Position, point.Value, 2f, GroundPoundAbility.MinimumHeight * 5f) && m_Paige.GroundPoundAbility.CanUseAbility())
                {
                    m_Input.SetInput(InputName.Ability3, 1f);
                    m_IsFlying = false;
                }
            }
            else
            {
                if (m_Nodes == null)
                {
                    m_Nodes = CalculatePath(m_CurrentHill.PointAtGround);
                    m_NodeIndex = 0;
                }

                FollowNodes(ref m_Nodes, ref m_NodeIndex, 1f, true);
                m_IsFlying = false;
            }
        }
        else
        {
            if (m_Nodes == null)
            {
                m_Nodes = CalculatePath(m_CurrentHill.PointAtGround);
                m_NodeIndex = 0;
            }

            FollowNodes(ref m_Nodes, ref m_NodeIndex, 1f, true);
            m_IsFlying = false;
        }
    }

    private bool m_CanSeeEnemy = false;
    private void DefendFunction()
    {
        bool isOtherPlayerInHill = false;
        Player[] otherPlayers = m_CurrentHill.PlayersInsideHill.ToArray();
        for (int i = 0; i < otherPlayers.Length; i++)
        {
            if (otherPlayers[i].TeamIndex == m_Player.TeamIndex)
                continue;

            isOtherPlayerInHill = true;
        }
        
        GameObject closestEnemy = null;
        {
            var enemy = m_AICharacter.GetClosestViewableEnemy(true);
            if (enemy != null)
                closestEnemy = enemy.Object;

            if (closestEnemy != null && !m_CanSeeEnemy)
            {
                m_Nodes = null;
                m_CanSeeEnemy = true;
            }
        }

        if (closestEnemy != null)
        {
            if (Vector3.Distance(Position, closestEnemy.Position()) < m_TooClosePanicDistance)
                isOtherPlayerInHill = true;
        }

        if (closestEnemy == null && !isOtherPlayerInHill)
            SearchHill();
        else if (!isOtherPlayerInHill)
        {
            m_Input.SetInput(InputName.Ability2, 1f);
            m_AICharacter.LookTowardsTarget(closestEnemy.Position());
        }
        else if (closestEnemy != null && m_CurrentHill.IsPlayerInsideObjective(closestEnemy))
        {
            if (m_Nodes == null)
            {
                float distance = Vector3.Distance(Position, closestEnemy.Position());
                if(distance < m_TooClosePanicDistance)
                {
                    Vector3 pos = m_AICharacter.GetClosestPositionToTargetGivenRadius2D(closestEnemy.Position(), m_TooClosePanicDistance);
                    m_Nodes = CalculatePath(pos);
                    m_NodeIndex = 0;

                    m_Input.SetInput(InputName.Jump, 1f);
                }
                else if(distance > m_ApproachCloseEnoughToAttackDistance)
                {
                    Vector3 pos = m_AICharacter.GetClosestPositionToTargetGivenRadius2D(closestEnemy.Position(), m_ApproachCloseEnoughToAttackDistance);
                    m_Nodes = CalculatePath(pos);
                    m_NodeIndex = 0;
                }
            }

            if(m_Nodes != null)
                FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);
            m_AICharacter.LookTowardsTarget(closestEnemy.Position());
        }
        else
            SearchHill();
    }

    private void SearchHill()
    {
        m_CanSeeEnemy = false;
        if (m_Nodes == null)
        {
            m_Nodes = CalculatePath(m_CurrentHill.PointAtGround);
            m_NodeIndex = 0;
        }

        FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);
        m_AICharacter.SetRightAnalogStick(Vector2.right);
    }

    public override void DebugDraw()
    {
        base.DebugDraw();
    }

    public override string GetBehaviourName()
    {
        return AIString.PaigeKingOfTheHillBehaviour;
    }

    IEnumerator CheckNodes()
    {
        for (;;)
        {
            yield return new WaitForSeconds(0.2f);
            m_Nodes = null;
            m_NodeIndex = 0;
        }
    }
}
