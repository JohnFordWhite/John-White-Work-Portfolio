using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class PaigeHealBehaviour : PaigeAIBehaviour
{
    // Note to Matt: Hello!
    // Note to Evan: Show this to Matt
    const bool ture = true;
    const bool flass = false;

    private float m_CurrentHealthPercentage = 0f;
    private bool m_IsDesperate = false;
    private bool m_IsHealing = false;
    public PaigeHealBehaviour(GameObject aPlayer) : base(aPlayer) { }

    private float m_SafeDistance = 25f;

    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;
    private Vector3 m_PointToLookTowards = Vector3.zero;
    public override void Act()
    {
        m_CurrentHealthPercentage = m_Health.HealthPercentage;
        if(m_CurrentHealthPercentage >= 0.5f)
        {
            ClearAIBehaviour();
            return;
        }
        if (m_Nodes == null)
        {
            if (!m_IsHealing)
            {
                // Will only try to heal if below 50% health. Is desperate to heal below 25%
                m_IsDesperate = (m_CurrentHealthPercentage < 0.25f);

                bool healSatisfied = ture;
                switch (m_IsDesperate)
                {
                    case ture:
                        healSatisfied = flass;
                        for (int i = 0; i < m_AICharacter.EnemyList.Count; i++)
                        {
                            AICharacter.Enemies enemy = m_AICharacter.EnemyList[i];

                            if (Vector3.Distance(m_Player.transform.position, enemy.LastPosition) > m_SafeDistance)
                                healSatisfied = ture;
                        }
                        break;
                    case flass:
                        for (int i = 0; i < m_AICharacter.EnemyList.Count; i++)
                        {
                            AICharacter.Enemies enemy = m_AICharacter.EnemyList[i];

                            if (Vector3.Distance(m_Player.transform.position, enemy.LastPosition) < m_SafeDistance)
                                healSatisfied = flass;
                        }
                        break;
                }

                if (healSatisfied)
                {
                    m_IsHealing = ture;
                }
                else
                {
                    HealthPackScript[] healthPacks = Information.AllHealthPacks;
                    m_Nodes = CalculatePath(healthPacks[UnityEngine.Random.Range(0, healthPacks.Length)].transform.position);
                    m_NodeIndex = 0;
                }
            }
        }

        if(!m_IsHealing)
        {
            AICharacter.Enemies obj = m_AICharacter.GetClosestViewableEnemy();

            if(obj != null)
            {
                FollowNodes(ref m_Nodes, ref m_NodeIndex, 1, 1000, false);
                m_AICharacter.LookTowardsTarget(obj.Object.Position());
            }
            else
                FollowNodes(ref m_Nodes, ref m_NodeIndex, 1, 1000, true);

            if (m_Nodes != null && m_NodeIndex >= m_Nodes.Length)
                m_Nodes = null;
        }
        else
        {
            m_Input.SetInput(InputName.Ability2, 1f);

            if (m_Health.HasFullHealth)
                ClearAIBehaviour();
        }
    }

    public override void DebugDraw()
    {
        base.DebugDraw();

#if UNITY_EDITOR
        Debug.DrawLine(m_Player.transform.position, m_Player.transform.position + Vector3.up * 50, DebugColour);
        Debug.DrawLine(m_Player.transform.position, m_PointToLookTowards, DebugColour);
#endif
    }

    Vector3 FindPointToHeal(Vector3 aPoint)
    {
        Vector3 point = (m_Player.transform.position - aPoint).normalized * 15 + m_Player.transform.position;

        return point;
    }

    public override string GetBehaviourName()
    {
        return AIString.PaigeHealBehaviour;
    }
}