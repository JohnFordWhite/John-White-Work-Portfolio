﻿using UnityEngine;
using System.Collections;
using System;

public class PaigeEscapeCharacterBehaviour : PaigeAIBehaviour
{
    private GameObject m_ToEscape;
    public PaigeEscapeCharacterBehaviour(GameObject aOwner, GameObject aCharacterToEscapeFrom) : base(aOwner) { m_ToEscape = aCharacterToEscapeFrom; }

    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;

    private float m_SatisfyingDistance = 20f;

    public override void Act()
    {
        if (!(m_AICharacter.CanSeeAtLeastOneEnemy))
        {
            SetSearchForHealthBehaviour();
            return;
        }

        if (m_Nodes == null)
        {
            HealthPackScript[] healthPacks = Information.AllHealthPacks;
            m_Nodes = CalculatePath(healthPacks[UnityEngine.Random.Range(0, healthPacks.Length)].transform.position);
            m_NodeIndex = 0;
        }

        FollowNodes(ref m_Nodes, ref m_NodeIndex, 1, false);

        if (m_Nodes != null)
        {
            if (m_Nodes.Length <= m_NodeIndex)
            {
                m_Nodes = null;
                m_NodeIndex = 0;
            }
            else
                m_AICharacter.LookTowardsTarget(Position - MathUtils.DirectionVector(Position, m_Nodes[m_NodeIndex]));
        }

        if (m_Player.GetComponent<Paige>().TMNThrowable.CanUseAbility())
            m_Input.SetInput(InputName.Ability1, 1f);

        if (m_AICharacter.IsLookingAtPoint(m_ToEscape.Position()))
            m_Input.SetInput(InputName.Attack1, 1f);

        if (!(MathUtils.AIVector3Distance(m_Player.transform.position, m_ToEscape.Position(), m_SatisfyingDistance, m_SatisfyingDistance)))
            ClearAIBehaviour();
    }

    public override void DebugDraw()
    {
        base.DebugDraw();

        if (m_Nodes == null) return;
        for (int i = 0; i < m_Nodes.Length - 1; i++)
            Debug.DrawLine(m_Nodes[i], m_Nodes[i + 1], DebugColour);
    }

    public override string GetBehaviourName()
    {
        return AIString.PaigeEscapeCharacterBehaviour;
    }
}
