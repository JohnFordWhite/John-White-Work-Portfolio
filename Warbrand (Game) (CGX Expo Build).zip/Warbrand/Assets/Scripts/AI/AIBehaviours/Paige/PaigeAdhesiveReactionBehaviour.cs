﻿using UnityEngine;
using System.Collections;
using System;

public class PaigeAdhesiveReactionBehaviour : PaigeAIBehaviour
{
    public PaigeAdhesiveReactionBehaviour(GameObject aObject) : base(aObject) { }
    
    public override void Act()
    {
        //m_AICharacter.SetLeftAnalogStick(m_Agent.nextPosition - m_Player.transform.position);

        //if (!(Information.IsPlayerInAdhesive(m_Player)))
        if ((Information.IsPlayerInAdhesive(m_Player)))
            ClearAIBehaviour();
    }

    public override void DebugDraw()
    {
        base.DebugDraw();
    }

    public override string GetBehaviourName()
    {
        return AIString.PaigeAdhesiveReactionBehaviour;
    }
}
