using UnityEngine;
using System.Collections;
using System;

public enum PaigeAICharacterOptions
{
    Null,
    Wander,
    AllOutAttack,
    CautiousAttack,
    Heal,
    AttackTurret,

    KingOfTheHill,

    // Max //
    MAX_PAIGE_AI_CHARACTER_OPTIONS
}

public abstract class PaigeAIBehaviour : AIBehaviour
{
    public PaigeAIBehaviour(GameObject aPlayer) : base(aPlayer) { }
}