﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class PaigeAllOutAttackBehaviour : PaigeAIBehaviour
{
    public PaigeAllOutAttackBehaviour(GameObject aPlayer) : base(aPlayer) { }

    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;
    private GameObject m_Target = null;
    private float m_CloseEnoughToNode = 1f;

    private enum AllOutAttackState
    {
        // Approach the enemy
        Approach,

        // Try to catch the enemy in adhesive
        AdhesiveThrow,

        // Use the adhesive as a barrier between you and another enemy
        AdhesiveKite,

        // Simply go in close and kill
        Fire,

        // Ground pound many people
        GroundPound
    }
    private AllOutAttackState m_CurrentState = AllOutAttackState.Approach;
    public override void Act()
    {
        if(m_Health.HealthPercentage <= 0.5f)
        {
            ClearAIBehaviour();
            return;
        }

        if (m_Target != null && m_Target.GetComponent<Health>().IsDead)
        {
            ClearAIBehaviour();
            return;
        }

        // Start a cooroutine if we need to which will recheck our nodes at an average human reaction time
        if (!HasStartedCooroutine)
        {
            m_Player.StartCoroutine(CheckNodes());
            HasStartedCooroutine = true;
        }
        
        // Act based on our current state
        switch (m_CurrentState)
        {
            case AllOutAttackState.Approach:
                ApproachFunction();
                break;
            case AllOutAttackState.AdhesiveThrow:
                AdhesiveFunction();
                break;
            case AllOutAttackState.AdhesiveKite:
                AdhesiveKiteFunction();
                break;
            case AllOutAttackState.Fire:
                FireFunction();
                break;
            case AllOutAttackState.GroundPound:
                GroundPoundFunction();
                break;
        }
    }

    // If our distance to the target is less than this amount, we'll start attacking.
    private float m_ApproachCloseEnoughDistance = 15f;
    private void ApproachFunction()
    {
        // If we have no nodes to travel to, lets find some nodes
        if (m_Nodes == null)
        {
            AICharacter.Enemies closestEnemy = m_AICharacter.GetClosestViewableEnemy();
            if (closestEnemy != null)
            {
                m_Nodes = CalculatePath(MathUtils.GetClosestPointOnNavMesh(m_AICharacter.GetClosestPositionToTargetGivenRadius(closestEnemy.Object.transform.position, m_ApproachCloseEnoughDistance * 0.9f)));
                m_NodeIndex = 0;
                m_Target = closestEnemy.Object;
            }
        }

        // If we're in the air, something has gone wrong. Stop moving until we're grounded again
        if (!(m_Player.GetComponent<BasicMovementScript>().IsGrounded))
        {
            ClearNodes();
            return;
        }

        // If there is no viewable enemy, we have no target, and therefor can't attack
        if (m_Target == null)
        {
            ClearAIBehaviour();
            return;
        }

        // At this point, we have a target, but there's no path to them. We should just try to take a look around for them
        if (m_Nodes == null)
        {
            SetSearchBehaviour(m_AICharacter.GetEnemyForObject(m_Target));
            return;
        }

        // We have nodes, we have a target. Follow the nodes
        FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, true);

        // If we've finished the path, clear the nodes
        if (m_Nodes != null && m_NodeIndex >= m_Nodes.Length)
            ClearNodes();

        // We're close enough to our current node - figure out something to do now
        if (MathUtils.AIVector3Distance(m_Player.transform.position, m_Target.transform.position, m_ApproachCloseEnoughDistance, 5f))
        {
            PaigeAICharacter paigeAI = (PaigeAICharacter)(m_AICharacter);

            // If there is at least one more person close to our target, we want to ground pound them
            if(MathUtils.GetPlayersCloseToGameObject(m_Target, 6.5f, false, new Player[] { m_Player }).Length > 1)
            {
                m_CurrentState = AllOutAttackState.GroundPound;
            }

            // Otherwise, if we can throw our adhesive, we should do that
            else if (paigeAI.Paige.JetpackAbility.TimeRemaining >= m_AdhesiveTimeToFly && paigeAI.Paige.TMNThrowable.CanUseAbility())
            {
                m_CurrentState = AllOutAttackState.AdhesiveThrow;
                m_AdhesiveCurrentTimer = 0f;
                m_HasThrownAdhesive = false;
            }

            // Otherwise, let's just chase them and attack
            else
            {
                m_CurrentState = AllOutAttackState.Fire;
            }
        }
    }

    private float m_AdhesiveCurrentTimer = 0f;
    private const float m_AdhesiveTimeToFly = 0.75f; // This number was taken from players time flying to throw adhesive
    private bool m_HasThrownAdhesive = false;
    private void AdhesiveFunction()
    {
        if (!(m_Paige.JetpackAbility.CanUseAbility()))
        {
            ClearAIBehaviour();
            return;
        }

        // We want to throw from a high ground, so start flying
        m_Input.SetInput(InputName.Movement, 1f);
        m_AdhesiveCurrentTimer += Time.deltaTime;

        // Move towards the proper area, and proper area
        m_AICharacter.MoveTowardsTarget(m_AICharacter.GetClosestPositionToTargetGivenRadius2D(m_Target.transform.position, 7.5f));
        m_AICharacter.LookTowardsTarget(m_Target.transform.position + Vector3.up * 0.75f);

        // If we've been flying for long enough, throw the adhesive
        if (m_AdhesiveCurrentTimer > m_AdhesiveTimeToFly && !m_HasThrownAdhesive)
        {
            m_Input.SetInput(InputName.Ability1, 1f);
            m_HasThrownAdhesive = true;
        }

        // If we've thrown our adhesive
        if (m_HasThrownAdhesive)
        {
            // Get the adhesive object
            TMNThrowableFunctionality adhesive = Information.GetAdhesiveForOwner(m_Player.GetComponent<Paige>());

            // If we can find it
            if (adhesive != null)
            {
                // Get the players affected, and see if the target is one of those players
                List<Player> playersAffected = adhesive.PlayersAffected;
                bool targetInAdhesive = playersAffected.Contains(m_Target.GetComponent<Player>());

                // If they are in the adhesive, let's ground pound them
                if (targetInAdhesive)
                {
                    m_CurrentState = AllOutAttackState.GroundPound;
                }

                // Otherwise, we'll decide whether we want to kite around the adhesive or just chase
                else
                {
                    // If the adhesive is closer to us than the target
                    if (Vector3.Distance(m_Player.transform.position, adhesive.transform.position) < Vector3.Distance(m_Player.transform.position, m_Target.transform.position))
                        m_CurrentState = AllOutAttackState.AdhesiveKite;
                    else
                        m_CurrentState = AllOutAttackState.Fire;
                }
            }
            else
            {
                ClearAIBehaviour();
            }
        }
    }

    private TMNThrowableFunctionality m_Adhesive = null;
    private float m_AdhesiveRadius = 6.5f;
    void AdhesiveKiteFunction()
    {
        // If the adhesive is null, let's look for it
        if (m_Adhesive == null)
        {
            m_Adhesive = Information.GetAdhesiveForOwner(m_Player.GetComponent<Paige>());

            // If the adhesive doesn't exist, we can't kite
            if (m_Adhesive == null)
            {
                ClearAIBehaviour();
                return;
            }
        }

        // Let's find the point on the other side of the adhesive
        Vector3 dir = m_Target.transform.position - m_Adhesive.transform.position;
        m_AICharacter.MoveTowardsTarget(m_Adhesive.transform.position - dir.normalized * m_AdhesiveRadius);
        m_AICharacter.LookTowardsTarget(m_Target.transform.position);

        // If the target is too far, we want to approach the target
        if (Vector3.Distance(m_Player.transform.position, m_Target.transform.position) > m_AdhesiveRadius * 2)
            m_CurrentState = AllOutAttackState.Approach;

        if (!(m_AICharacter.GetEnemyForObject(m_Target).CanSee))
        {
            ClearAIBehaviour();
            return;
        }
    }

    private float m_ChaseDownDistance = 5f;
    void FireFunction()
    {
        // If we have no nodes to travel to, lets find some nodes
        if (m_Nodes == null)
        {
            if (m_Target == null)
            {
                m_Target = m_AICharacter.GetClosestViewableEnemy().Object;

                if (m_Target == null)
                {
                    ClearAIBehaviour();
                    return;
                }
            }
            m_Nodes = CalculatePath(m_AICharacter.GetClosestPositionToTargetGivenRadius(m_Target.transform.position + m_Target.GetComponent<Rigidbody>().velocity, m_ChaseDownDistance));
            m_NodeIndex = 0;
        }

        // Now we have nodes. Follow them
        FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);

        // Always look at the target
        m_AICharacter.LookTowardsTarget(m_Target.transform.position);

        // If we can use our adhesive, then let's reset our current behaviour
        PaigeAICharacter paigeAI = (PaigeAICharacter)(m_AICharacter);
        if (paigeAI.Paige.TMNThrowable.CanUseAbility())
            ClearAIBehaviour();

        if(!(m_AICharacter.GetEnemyForObject(m_Target).CanSee))
        {
            ClearAIBehaviour();
            return;
        }
    }

    void GroundPoundFunction()
    {
        // If we can't use the jetpack or the ground pound, we shouldn't be here
        if (!(m_Paige.JetpackAbility.CanUseAbility()) || !(m_Paige.GroundPoundAbility.CanAIUseAbility()))
            ClearAIBehaviour();

        // Calculate point to travel too ( HACK: fairly low cost so we can do this every frame. If the game starts running low, we can change this)
        Vector3 point = Vector3.zero;
        {
            // This gets the average between the players that are all in range of a ground pound
            Player[] playersInRange = MathUtils.GetPlayersCloseToGameObject(m_Target, 6.5f, true);
            Vector3[] points = new Vector3[playersInRange.Length];
            for (int i = 0; i < playersInRange.Length; i++)
                points[i] = playersInRange[i].transform.position;
            point = MathUtils.Average(points);
        }

        // Place the point above the players
        point.y += 8f;

        RaycastHit[] hits = Physics.RaycastAll(Position, MathUtils.DirectionVector(Position, point), Vector3.Distance(Position, point));
        for (int i = 0; i < hits.Length; i++)
        {
            RaycastHit hit = hits[i];

            if (hit.transform.GetComponent<Collider>())
            {
                if (hit.transform.GetComponent<Collider>().isTrigger)
                    continue;
            }
            if (hit.transform.parent.GetComponent<PlayerHitboxScript>())
                continue;

            m_CurrentState = AllOutAttackState.Fire;
            return;
        }

        // Move towards the point (doesn't take into account y position)
        m_AICharacter.MoveTowardsTarget(point);

        // If we are currently grounded, then let's jump to get off the ground
        if (m_Player.GetComponent<BasicMovementScript>().IsGrounded)
            m_Input.SetInput(InputName.Jump, 1f);

        // If we are not high enough, jetpack
        if(m_Player.transform.position.y < point.y)
            m_Input.SetInput(InputName.Movement, 1f);
        
        // If we're close enough to the point, then use our ability
        if (Vector2.Distance(m_Player.transform.position.xz(), point.xz()) < 0.5f)
        {
            m_Input.SetInput(InputName.Ability3, 1f);
            m_CurrentState = AllOutAttackState.Fire;
        }

    }

    public override void DebugDraw()
    {
        base.DebugDraw();

        if (m_Nodes == null)
            return;

        if (m_NodeIndex >= m_Nodes.Length)
            return;

        Debug.DrawLine(m_Nodes[m_NodeIndex], m_Nodes[m_NodeIndex] + Vector3.up * 50, DebugColour);
        for (int i = 0; i < m_Nodes.Length - 1; i++)
        {
            Debug.DrawLine(m_Nodes[i], m_Nodes[i + 1], DebugColour);
        }
    }

    private void ClearNodes()
    {
        m_Nodes = null;
        m_NodeIndex = 0;
    }

    IEnumerator CheckNodes()
    {
        for (;;)
        {
            yield return new WaitForSeconds(0.2f);
            ClearNodes();
        }
    }

    public override string GetBehaviourName()
    {
        return AIString.PaigeAllOutAttackBehaviour + ": " + m_CurrentState.ToString();
    }
}