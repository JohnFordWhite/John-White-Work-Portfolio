﻿using UnityEngine;
using System;

public class QuarkEscapeAIBehaviour : QuarkAIBehaviour
{
    public QuarkEscapeAIBehaviour(GameObject aPlayer) : base(aPlayer) { }

    public override void Act()
    {
        throw new NotImplementedException();
    }

    public override void DebugDraw()
    {
        base.DebugDraw();
    }

    public override string GetBehaviourName()
    {
        return AIString.QuarkEscapeBehaviour;
    }
}
