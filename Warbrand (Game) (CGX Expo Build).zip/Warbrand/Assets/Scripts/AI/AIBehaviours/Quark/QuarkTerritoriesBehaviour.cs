﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class QuarkTerritoriesBehaviour : QuarkAIBehaviour
{
    public QuarkTerritoriesBehaviour(GameObject aOwner) : base(aOwner)
    {
        List<GameObject> objs = new List<GameObject>(Information.AllTerritories);

        for (int i = 0; i < objs.Count; i++)
        {
            if (objs[i].GetComponent<TerritoryObjective>().m_TerritoryOwnerTeam == m_Player.TeamIndex)
            {
                objs.RemoveAt(i--);
            }
        }

        if (objs.Count > 0)
            m_CurrentTerritory = objs[UnityEngine.Random.Range(0, objs.Count)].GetComponent<TerritoryObjective>();
        else
            SetAIBehaviour(new LeeroyWanderAIBehaviour(m_Player.gameObject));
    }

    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;

    private TerritoryObjective m_CurrentTerritory = null;

    private const float m_CloseEnoughToNode = 1f;
    private const float m_ApproachCloseEnoughToAttackDistance = 15f;
    private const float m_TooClosePanicDistance = 5f;

    public override void Act()
    {
        if (m_CurrentTerritory == null)
        {
            ClearAIBehaviour();
            return;
        }
        if (m_CurrentTerritory.m_TerritoryOwnerTeam == m_Player.TeamIndex)
        {
            ClearAIBehaviour();
            return;
        }

        // Start a cooroutine if we need to which will recheck our nodes at an average human reaction time
        if (!HasStartedCooroutine)
        {
            m_Player.StartCoroutine(CheckNodes());
            HasStartedCooroutine = true;
        }

        if (m_AICharacter.GetGoals()[0] == AIGoals.KeepMyselfAlive)
        {
            SetSearchForHealthBehaviour();
            return;
        }

        if (m_CurrentTerritory.IsPlayerInsideObjective(m_Player.gameObject))
            DefendFunction();
        else
            ApproachFunction();
    }

    private bool m_HasPlaceTurretOutsideHill = false;
    private bool m_CanSeeHill = true;
    private void ApproachFunction()
    {
        m_CanSeeHill = true;
        {
            RaycastHit[] hits = Physics.RaycastAll(Position,
                                                   MathUtils.DirectionVector(Position, m_CurrentTerritory.PointAtGround + Vector3.up),
                                                   Vector3.Distance(Position, m_CurrentTerritory.PointAtGround + Vector3.up));
            for (int i = 0; i < hits.Length; i++)
            {
                RaycastHit hit = hits[i];

                if (hit.collider.isTrigger)
                    continue;
                if (hit.transform.GetComponent<PlayerHitboxScript>())
                    continue;
                if (hit.transform.GetComponent<TurretScript>())
                    continue;

                m_CanSeeHill = false;
            }
        }

        if (m_CanSeeHill)
        {
            if (!m_HasPlaceTurretOutsideHill)
            {
                m_HasPlaceTurretOutsideHill = true;
                SetPlaceTurretBehaviour();

                m_Nodes = CalculatePath(m_CurrentTerritory.PointAtGround);
                m_NodeIndex = 0;
            }

            if (m_Nodes == null)
            {
                m_Nodes = CalculatePath(m_CurrentTerritory.PointAtGround);
                m_NodeIndex = 0;
            }

            FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, true);
        }
        else
        {
            m_HasPlaceTurretOutsideHill = false;
            bool canSeeEnemy = m_AICharacter.CanSeeAtLeastOneEnemy;

            if (m_Nodes == null)
            {
                m_Nodes = CalculatePath(m_CurrentTerritory.PointAtGround);
                m_NodeIndex = 0;
            }

            if (canSeeEnemy)
            {
                FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);
                m_AICharacter.LookTowardsTarget(m_AICharacter.GetClosestViewableEnemy().LastPosition);
            }
            else
            {
                FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, true);
            }
        }
    }

    private Vector3? m_PointToPlace = null;
    private int m_NumberOfTurretsPlacedInHill;
    private readonly float[] TURRET_DISTANCE_FROM_CENTER = { 2.5f, 7.5f };
    private bool m_CanSeeEnemy = false;
    private void DefendFunction()
    {
        m_HasPlaceTurretOutsideHill = false;

        bool isOtherPlayerInHill = false;
        Player[] otherPlayers = m_CurrentTerritory.PlayersInsideTerritory.ToArray();
        for (int i = 0; i < otherPlayers.Length; i++)
        {
            if (otherPlayers[i].TeamIndex == m_Player.TeamIndex)
                continue;

            isOtherPlayerInHill = true;
        }

        GameObject closestEnemy = null;
        {
            var enemy = m_AICharacter.GetClosestViewableEnemy(true);
            if (enemy != null)
                closestEnemy = enemy.Object;

            if (closestEnemy != null && !m_CanSeeEnemy)
            {
                m_Nodes = null;
                m_CanSeeEnemy = true;
            }
        }

        if (isOtherPlayerInHill)
        {
            if (closestEnemy != null)
            {
                if (m_CurrentTerritory.IsPlayerInsideObjective(closestEnemy))
                {
                    m_AICharacter.MoveTowardsTarget(m_AICharacter.GetClosestPositionToTargetGivenRadius2D(closestEnemy.Position(), 5f));
                    m_AICharacter.LookTowardsTarget(closestEnemy.Position());
                }
                else
                    SearchHill();
            }
            else
                SearchHill();
        }
        else
        {
            m_NumberOfTurretsPlacedInHill = 0;
            TurretScript[] myTurrets = Information.GetTurretsForOwner(m_Quark);
            for (int i = 0; i < myTurrets.Length; i++)
            {
                if (m_CurrentTerritory.IsPlayerInsideObjective(myTurrets[i].gameObject))
                    m_NumberOfTurretsPlacedInHill++;
            }

            if (m_NumberOfTurretsPlacedInHill < 2)
            {
                if (m_PointToPlace == null)
                {
                    Vector3 addedPoint = UnityEngine.Random.insideUnitSphere;
                    addedPoint.y = 0;
                    m_PointToPlace = m_CurrentTerritory.PointAtGround + addedPoint.normalized * UnityEngine.Random.Range(TURRET_DISTANCE_FROM_CENTER[0], TURRET_DISTANCE_FROM_CENTER[1]);
                }

                m_AICharacter.MoveTowardsTarget(m_PointToPlace.Value);
                if (MathUtils.AIVector3Distance(Position, m_PointToPlace.Value, m_CloseEnoughToNode, m_CloseEnoughToNode * 5))
                {
                    m_PointToPlace = null;
                    SetPlaceTurretBehaviour();
                }
            }
            else
            {
                SearchHill();
            }
        }
    }

    private void SearchHill()
    {
        m_CanSeeEnemy = false;
        if (m_Nodes == null)
        {
            m_Nodes = CalculatePath(m_CurrentTerritory.PointAtGround);
            m_NodeIndex = 0;
        }

        FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, false);
        m_AICharacter.SetRightAnalogStick(Vector2.right);
    }

    public override void DebugDraw()
    {
        base.DebugDraw();
    }

    public override string GetBehaviourName()
    {
        return AIString.QuarkTerritoriesBehaviour;
    }

    IEnumerator CheckNodes()
    {
        for (;;)
        {
            yield return new WaitForSeconds(0.2f);
            m_Nodes = null;
            m_NodeIndex = 0;
        }
    }
}