﻿using UnityEngine;
using System.Collections;
using System;
#if UNITY_EDITOR
using UnityEditor;
#endif
public class QuarkPlaceTurretAIBehaviour : QuarkAIBehaviour
{
    private AIBehaviour m_ToReturnTo;
    public QuarkPlaceTurretAIBehaviour(GameObject aOwner, AIBehaviour aToReturnTo) : base(aOwner) { m_ToReturnTo = aToReturnTo; }
    private Vector3? m_PositionToPlace = null;

    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;

    private bool m_HasPlaced = false;

    public override void Act()
    {
        if(!HasStartedCooroutine)
        {
            m_AICharacter.StartCoroutine(ChangePosition());
        }
        if(m_HasPlaced)
        {
            SetAIBehaviour(m_ToReturnTo);
            return;
        }

        if (m_PositionToPlace == null)
        {
            m_PositionToPlace = MathUtils.GetClosestPointOnNavMesh(TurretPlacement.GetClosestPoint(Position));

            TurretScript[] turrets = Information.GetTurretsForOwner(m_Quark);
            for(int i = 0; i < turrets.Length; i++)
            {
                if(Vector3.Distance(m_PositionToPlace.Value, turrets[i].transform.position) < 4f)
                {
                    m_PositionToPlace = MathUtils.GetClosestPointOnNavMesh(m_AICharacter.GetClosestPositionToTargetGivenRadius2D(m_PositionToPlace.Value, 6f));
                }
            }
        }
        if(m_PositionToPlace.HasValue)
            m_PositionToPlace = MathUtils.GetClosestPointOnNavMesh(m_PositionToPlace.Value);

        if (m_Nodes == null && m_PositionToPlace.HasValue)
        {
            m_Nodes = CalculatePath(m_PositionToPlace.Value);
            m_NodeIndex = 0;
        }

        FollowNodes(ref m_Nodes, ref m_NodeIndex, 1f, false);

        //m_AICharacter.MoveTowardsTarget(m_AICharacter.GetClosestPositionToTargetGivenRadius2D(MathUtils.GetClosestPointOnNavMesh(m_PositionToPlace.Value), 1f));
        m_AICharacter.LookTowardsTarget(m_PositionToPlace.Value);

        if (!(m_Quark.m_PlaceTurret.PlacingTurret) && !(MathUtils.AlmostEquals(m_Input.GetInput(InputName.Ability1), 1f)))
            m_Input.SetInput(InputName.Ability1, 1f);
        else
        {
            if (m_Quark.m_PlaceTurret.AI_CanPlace() && m_Quark.m_PlaceTurret.PlacingTurret)
            {
                m_Input.SetInput(InputName.Attack1, 1f);
                m_HasPlaced = true;
            }
        }
    }

    public override void DebugDraw()
    {
        base.DebugDraw();

        if (m_PositionToPlace != null)
        {
            Debug.DrawLine(Position, m_PositionToPlace.Value, DebugColour);
            Debug.DrawLine(m_PositionToPlace.Value, m_PositionToPlace.Value + Vector3.up * 50f, DebugColour);
        }
    }

    public override string GetBehaviourName()
    {
        return AIString.QuarkPlaceTurretBehaviour;
    }

    private const float TIME_TO_WAIT = 5f;
    private IEnumerator ChangePosition()
    {
        HasStartedCooroutine = true;
        while(true)
        {
            yield return new WaitForSeconds(TIME_TO_WAIT);
            m_PositionToPlace = null;
            m_Nodes = null;
            m_NodeIndex = 0;
        }
    }
}
