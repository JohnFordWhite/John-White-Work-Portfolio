﻿using UnityEngine;
using System;

public class QuarkAttackAIBehaviour : QuarkAIBehaviour
{
    public QuarkAttackAIBehaviour(GameObject aPlayer) : base(aPlayer) { }
    private State m_CurrentState = State.Start;

    public override void Act()
    {
        switch (m_CurrentState)
        {
            case State.Start:
                TurretAISight sight = (m_AICharacter as QuarkAICharacter).GetMostRecentTurret();

                if (sight != null)
                {
                    if (sight.TimeSincePlaced > 1f)
                        SetPlaceTurretBehaviour();
                }
                else
                    SetPlaceTurretBehaviour();
                m_CurrentState = State.Battle;
                break;
            case State.Battle:
                BattleFunction();
                break;
            default:
                break;
        }
    }

    public const float SafetyZone = 12.5f;
    GameObject closestTurret = null;
    void BattleFunction()
    {
        if (closestTurret == null)
        {
            TurretAISight sight = (m_AICharacter as QuarkAICharacter).GetMostRecentTurret();
            if (sight == null)
            {
                m_Input.SetInput(InputName.Attack1, 1f);
                ClearAIBehaviour();
                return;
            }
            else
                closestTurret = sight.Turret;

            // Either we didn't successfully place a turret down or it got destroyed immediately. Either way, fuck off
            if (closestTurret == null)
                ClearAIBehaviour();
        }

        // Must find this every frame because Quark is trying to actively defend his turret.
        AICharacter.Enemies target = m_AICharacter.GetClosestViewableEnemy(true);
        if(target == null)
        {
            ClearAIBehaviour();
            return;
        }
        
        m_AICharacter.LookTowardsTarget(target.Object.Position());

        // The Character is within the safety zone
        if (Vector3.Distance(Position, target.Object.Position()) < SafetyZone)
        {
            m_AICharacter.MoveTowardsTarget(m_AICharacter.GetClosestPositionToTargetGivenRadius2D(target.Object.Position(), DamageBeamScript.BeamLength * 0.9f));
        }
        else
        {
            m_AICharacter.MoveTowardsTarget(TurretPlacement.GetClosestPoint(m_AICharacter.GetClosestPositionToTargetGivenRadius2D(closestTurret.Position(), 5f)));
            if (Vector3.Distance(Position, closestTurret.Position()) < 5.5f && Vector3.Distance(Position, closestTurret.Position()) > 1f)
                SetAIBehaviour(new QuarkPlaceTurretAIBehaviour(m_Player.gameObject, new QuarkCampAIBehaviour(m_Player.gameObject)));
        }
    }

    public override void DebugDraw()
    {
        base.DebugDraw();

        AICharacter.Enemies target = m_AICharacter.GetClosestViewableEnemy(true);
        if (target == null)
            return;
        
        Debug.DrawLine(Position, target.Object.Position(), DebugColour);
    }

    public override string GetBehaviourName()
    {
        return AIString.QuarkAttackBehaviour;
    }

    public enum State
    {
        Start,
        Battle
    }
}