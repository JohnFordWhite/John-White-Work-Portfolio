﻿using UnityEngine;
using System.Collections;
using System;

public class QuarkCampAIBehaviour : QuarkAIBehaviour
{
    public QuarkCampAIBehaviour(GameObject aPlayer) : base(aPlayer) { }

    TurretAISight[] m_Sights;
    private int m_DirectionToTurn;
    private float m_TimeUntilTurn = 1f;
    private const float m_SafetyRadius = 7.5f;
    public override void Act()
    {
        m_Sights = (m_AICharacter as QuarkAICharacter).TurretDetails;

        if(m_Sights.Length < 2)
        {
            ClearAIBehaviour();
            return;
        }

        Vector3[] positions = new Vector3[m_Sights.Length];
        for (int i = 0; i < m_Sights.Length; i++)
            positions[i] = m_Sights[i].Turret.Position();

        Vector3 safetyPosition = positions.Average();

        if (!(m_AICharacter.CanSeeAtLeastOneEnemy))
        {
            m_AICharacter.MoveTowardsTarget(safetyPosition);

            m_TimeUntilTurn -= Time.deltaTime;
            if (m_TimeUntilTurn <= 0f)
            {
                m_TimeUntilTurn = 1f;
                m_DirectionToTurn = (UnityEngine.Random.Range(0, 2) == 1) ? 1 : -1;
            }

            m_AICharacter.SetRightAnalogStick(new Vector2(m_DirectionToTurn, 0f));
        }
        else
        {
            AICharacter.Enemies target = m_AICharacter.GetClosestViewableEnemy();
            m_AICharacter.LookTowardsTarget(target.Object.Position());
            if (Vector3.Distance(safetyPosition, target.Object.Position()) < m_SafetyRadius + DamageBeamScript.BeamLength * 0.9f)
            {
                m_AICharacter.MoveTowardsTarget(m_AICharacter.GetClosestPositionToTargetGivenRadius2D(target.Object.Position(), DamageBeamScript.BeamLength * 0.9f));
                if (Vector3.Distance(Position, target.Object.Position()) < DamageBeamScript.BeamLength)
                    m_Input.SetInput(InputName.Attack1, 1f);
            }
            else
                m_AICharacter.MoveTowardsTarget(safetyPosition);
        }
    }

    public override void DebugDraw()
    {
        base.DebugDraw();
    }

    public override string GetBehaviourName()
    {
        return AIString.QuarkCampBehaviour;
    }
}
