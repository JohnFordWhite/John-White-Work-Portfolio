﻿using UnityEngine;
using System.Collections;

public enum QuarkAICharacterOptions
{
    Null,
    Wander,
    Attack,
    Escape,
    AttackTurret,

    MAX_QUARK_AI_CHARACTER_OPTIONS
}

public abstract class QuarkAIBehaviour : AIBehaviour
{
    public bool TurretsDirty = false;
    public QuarkAIBehaviour(GameObject aPlayer) : base(aPlayer) { }

    public void SetPlaceTurretBehaviour()
    {
        SetAIBehaviour(new QuarkPlaceTurretAIBehaviour(m_AICharacter.gameObject, this));
    }
}