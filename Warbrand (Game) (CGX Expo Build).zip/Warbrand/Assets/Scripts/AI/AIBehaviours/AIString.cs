﻿using UnityEngine;
using System.Collections;

public static class AIString
{
    public const string PaigeAdhesiveReactionBehaviour = "Paige Adhesive Reaction Behaviour";
    public const string PaigeAllOutAttackBehaviour = "Paige All Out Attack Behaviour";
    public const string PaigeCautiousAttackBehaviour = "Paige Cautious Attack Behaviour";
    public const string PaigeEscapeCharacterBehaviour = "Paige Escape Character Behaviour";
    public const string PaigeHealBehaviour = "Paige Heal Behaviour";
    public const string PaigeSmokeScreenReactionBehaviour = "Paige Smoke Screen Reaction Behaviour";
    public const string PaigeTakeDamageReactionBehaviour = "Paige Take Damage Reaction Behaviour";
    public const string PaigeWanderBehaviour = "Paige Wander Behaviour";
    public const string PaigeKingOfTheHillBehaviour = "Paige King Of The Hill Behaviour";
    public const string PaigeTerritoriesBehaviour = "Paige Territories Behaviour";
    public const string PaigeDestroyTurretBehaviour = "Paige Destroy Turret Behaviour";

    public const string SearchBehaviour = "Generic Search Behaviour";
    public const string CloseSearchBehaviour = "Generic Close Search Behaviour";
    public const string FindHealthBehaviour = "Generic Find Health Behaviour";
    public const string BounceBehaviour = "Generic Bounce Behaviour";

    public const string LeeroyWanderBehaviour = "Leeroy Wander Behaviour";
    public const string LeeroyAllOutAttackBehaviour = "Leeroy All Out Attack Behaviour";
    public const string LeeroyLeeroidRageBehaviour = "Leeroy Leeroid Rage Behaviour";
    public const string LeeroyGrenadeBehaviour = "Leeroy Grenade Behaviour";
    public const string LeeroyKingOfTheHillBehaviour = "Leeroy King of the Hill Behaviour";
    public const string LeeroyTerritoriesBehaviour = "Leeroy Territories Behaviour";
    public const string LeeroyDestroyTurretBehaviour = "Leeroy Destroy Turret Behaviour";

    public const string ZephWanderBehaviour = "Zeph Wander Behaviour";
    public const string ZephAllOutAttackBehaviour = "Zeph All Out Attack Behaviour";
    public const string ZephTakeDamageReactionBehaviour = "Zeph Take Damage Reaction Behaviour";
    public const string ZephEscapeBehaviour = "Zeph Escape Behaviour";
    public const string ZephSmokeScreenBehaviour = "Zeph Smoke Screen Behaviour";
    public const string ZephKingOfTheHillBehaviour = "Zeph King of the Hill Behaviour";
    public const string ZephTerritoriesBehaviour = "Zeph Territories Behaviour";
    public const string ZephDestroyTurretBehaviour = "Zeph Destroy Turret Behaviour";

    public const string QuarkWanderBehaviour = "Quark Wander Behaviour";
    public const string QuarkAttackBehaviour = "Quark Attack Behaviour";
    public const string QuarkEscapeBehaviour = "Quark Escape Behaviour";

    public const string QuarkPlaceTurretBehaviour = "Quark Place Turret Behaviour";
    public const string QuarkCampBehaviour = "Quark Camp Behaviour";
    public const string QuarkKingOfTheHillBehaviour = "Quark King Of The Hill Behaviour";
    public const string QuarkTerritoriesBehaviour = "Quark Territories Behaviour";
    public const string QuarkDestroyTurretBehaviour = "Quark Destroy Turret Behaviour";

    public const string TraverseOffMeshLink = "Traverse Off Mesh Link";
}