using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public abstract class AIBehaviour
{
    protected Player m_Player = null;
    protected AICharacter m_AICharacter = null;
    protected AiInput m_Input = null;
    protected Health m_Health = null;

    protected Paige m_Paige { get { return (Paige)(m_Player); } }
    protected Zeph m_Zeph { get { return (Zeph)(m_Player); } }
    protected Leeroy m_Leeroy { get { return (Leeroy)(m_Player); } }
    protected Quark m_Quark { get { return (Quark)(m_Player); } }
    protected Vector3 Position { get { return m_Player.transform.position; } }
    protected Vector3 Forward { get { return m_Player.transform.forward; } }
    protected Vector3 Left { get { return -(m_Player.transform.right); } }

    public Color DebugColour { get; private set; }

    public abstract string GetBehaviourName();

    private const string m_GameSceneString = "GameScene";

    public bool HasStartedCooroutine = false;

    public AIBehaviour(GameObject aPlayer)
    {
        m_Player = aPlayer.GetComponent<Player>();
        m_AICharacter = aPlayer.GetComponent<AICharacter>();
        m_Input = m_AICharacter.GameInput;
        m_Health = aPlayer.GetComponent<Health>();

        m_AICharacter.StartCoroutine(ResetAfterTime());
        DebugColour = BaseGameMode.TeamColors[m_Player.TeamIndex];
    }

    public abstract void Act();

    public bool Reset { get; protected set; }

    public virtual void DebugDraw() { }

    public void SetAIBehaviour(AIBehaviour aAIBehaviour)
    {
        m_AICharacter.AIBehaviour = aAIBehaviour;
    }

    public void ClearAIBehaviour()
    {
        SetAIBehaviour(null);
    }

    public void SetSearchForHealthBehaviour()
    {
        SetAIBehaviour(new AIFindHealthBehaviour(m_Player.gameObject));
    }

    public void SetSearchBehaviour(AICharacter.Enemies aEnemy)
    {
        SetAIBehaviour(new AISearchBehaviour(m_Player.gameObject, aEnemy));
    }
    
    public void SetEscapeBehaviour(GameObject aCharacterToEscapeFrom)
    {
        switch (m_Player.Character)
        {
            case CharacterTypes.Paige:
                SetAIBehaviour(new PaigeEscapeCharacterBehaviour(m_Player.gameObject, aCharacterToEscapeFrom));
                break;
            case CharacterTypes.Quark:
                //SetAIBehaviour(new QuarkEscapeAIBehaviour(m_Player.gameObject, aCharacterToEscapeFrom));
                break;
            case CharacterTypes.Leeroy:
                break;
            case CharacterTypes.Zeph:
                SetAIBehaviour(new ZephEscapeAIBehaviour(m_Player.gameObject));
                break;
        }
    }

    public void SetDamageBehaviour(GameObject aAttackingObject)
    {
        m_AICharacter.SetDamageReaction(aAttackingObject);
    }

    protected Vector3[] CalculatePath(Vector3 aPoint)
    {
        if (SceneManager.GetActiveScene().name == m_GameSceneString)
        {
            //Vector3 startingPosition = Position;
            Vector3 endingPosition = aPoint;

            // Get the positions. Braces are for scope
            {
                NavMeshHit hit;
                //NavMesh.SamplePosition(Position, out hit, 1000f, -1);
                //startingPosition = hit.position;
                NavMesh.SamplePosition(aPoint, out hit, 1000f, -1);
                endingPosition = hit.position;
            }
            // End Scope

            NavMeshPath path = new NavMeshPath();
            if (float.IsInfinity(aPoint.x) || float.IsInfinity(aPoint.y) || float.IsInfinity(aPoint.z))
            {
#if UNITY_EDITOR
                DebugManager.LogError("Calculate Path is Infinity!", Developmer.AllDevelopmers);
#endif
                return null;
            }
            else
                m_AICharacter.Agent.CalculatePath(endingPosition, path);
                //NavMesh.CalculatePath(startingPosition, endingPosition, -1, path);

            if (path.corners.Length == 0)
            {
#if UNITY_EDITOR
                DebugManager.LogError("AI Couldn't find a path to " + aPoint + "!", Developmer.AllDevelopmers);
                DebugManager.DrawLine(Position, aPoint, Color.blue, 10f, Developmer.AllDevelopmers);
#endif
            }
            return path.corners;
        }
        else
            return null;
    }

    protected void FollowNodes(ref Vector3[] aNodes, ref int aNodeIndex, float aCloseEnoughDistance, bool aLookTowardsNodes = true)
    {
        FollowNodes(ref aNodes, ref aNodeIndex, aCloseEnoughDistance, aCloseEnoughDistance * 5f, aLookTowardsNodes);
    }

    protected void LookTowardsAngle(float angle)
    {
        Vector3 forward = (new Vector3(m_AICharacter.transform.forward.x, 0, m_AICharacter.transform.forward.z)).normalized + Position;
        forward.y += Mathf.Tan(angle * Mathf.Deg2Rad);
        m_AICharacter.LookTowardsTarget(forward);
    }

    protected bool IsLookingTowardsAngle(float angle)
    {
        Vector3 forward = (new Vector3(m_AICharacter.transform.forward.x, 0, m_AICharacter.transform.forward.z)).normalized + Position;
        forward.y += Mathf.Tan(angle * Mathf.Deg2Rad);
        return m_AICharacter.IsLookingAtPoint(forward);
    }

    protected void FollowNodes(ref Vector3[] aNodes, ref int aNodeIndex, float aCloseEnoughDistanceHorizontal, float aCloseEnoughDistanceVertical, bool aLookTowardsNodes = true)
    {
        if (aNodes == null)
            return;
        if (aNodeIndex >= aNodes.Length)
            return;

        m_AICharacter.MoveTowardsTarget(aNodes[aNodeIndex]);
        if (aLookTowardsNodes)
            m_AICharacter.LookTowardsTarget(aNodes[aNodeIndex]);

        if (MathUtils.AIVector3Distance(m_Player.transform.position, aNodes[aNodeIndex], aCloseEnoughDistanceHorizontal, aCloseEnoughDistanceVertical))
        {
            aNodeIndex++;

            if (aNodeIndex < aNodes.Length)
            {
                OffMeshLink[] links = Information.GetOffMeshLinksPlayerIsOn(m_Player);
                if (links != null && links.Length > 0)
                {
                    for (int i = 0; i < links.Length; i++)
                    {
                        if ( ((1 << links[i].area) & m_AICharacter.NavMeshArea) > 0)
                        {
                            if(MathUtils.AlmostEquals(aNodes[aNodeIndex], links[i].endTransform.position))
                                SetAIBehaviour(new AITraverseOffMeshLink(m_Player.gameObject, links[i].startTransform.position, links[i].endTransform.position, this, NavMeshAreaInformation.GetTypeForID(links[i].area)));
                        }
                    }
                }
            }
        }
        else if(MathUtils.AIVector3Distance(m_Player.transform.position, aNodes[aNodeIndex], aCloseEnoughDistanceHorizontal, aCloseEnoughDistanceVertical) && m_Player.GetComponent<BasicMovementScript>().IsGrounded)
        {
            ClearAIBehaviour();
        }
    }

    private float m_TimeToReset = 10f;
    protected IEnumerator ResetAfterTime()
    {
        yield return new WaitForSeconds(m_TimeToReset);
        ClearAIBehaviour();
    }
}