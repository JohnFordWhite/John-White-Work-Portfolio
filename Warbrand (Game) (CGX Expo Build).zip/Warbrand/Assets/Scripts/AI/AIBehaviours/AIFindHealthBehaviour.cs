﻿using UnityEngine;
using System.Collections;
using System;

public class AIFindHealthBehaviour : AIBehaviour
{
    public AIFindHealthBehaviour(GameObject aOwner) : base(aOwner) { }

    private Vector3[] m_Nodes = null;
    private int m_NodeIndex;
    private GameObject m_HealthPack;

    public override void Act()
    {
        if (m_Nodes == null)
            FindPack();

        if (m_Nodes.Length == 0)
            FindPack();

        if (m_AICharacter.CanSeeAtLeastOneEnemy)
        {
            FollowNodes(ref m_Nodes, ref m_NodeIndex, 1f, false);
            m_AICharacter.LookTowardsTarget(m_AICharacter.GetClosestViewableEnemy().LastPosition);
        }
        else
        {
            FollowNodes(ref m_Nodes, ref m_NodeIndex, 1f, true);
        }

        if (Vector3.Distance(Position, m_HealthPack.Position()) < 1f ||
            (m_AICharacter.CanSeeObject(m_HealthPack) && m_HealthPack.GetComponent<HealthPackScript>().enabled == false))
        {
            ClearAIBehaviour();
        }
    }

    void FindPack()
    {
        HealthPackScript[] healthPacks = Information.AllHealthPacks;
        m_HealthPack = healthPacks[UnityEngine.Random.Range(0, healthPacks.Length)].gameObject;
        m_Nodes = CalculatePath(m_HealthPack.Position());
        m_NodeIndex = 0;
    }

    public override void DebugDraw()
    {
        base.DebugDraw();

        if (m_Nodes != null)
        {
            for (int i = 0; i < m_Nodes.Length - 1; i++)
            {
                Debug.DrawLine(m_Nodes[i], m_Nodes[i + 1], DebugColour);
            }
        }
    }

    public override string GetBehaviourName()
    {
        return AIString.FindHealthBehaviour;
    }
}