﻿using UnityEngine;
using System.Collections;
using System;

public class AISearchBehaviour : AIBehaviour
{
    private AICharacter.Enemies m_Target;
    private Vector3[] m_Nodes = null;
    private int m_NodeIndex = 0;
    private float m_CloseEnoughToNode = 1f;

    bool m_HasReachedLastKnownLocation = false;
    public AISearchBehaviour(GameObject aPlayer, AICharacter.Enemies aTarget) : base(aPlayer)
    {
        m_Target = aTarget;
    }

    public override void Act()
    {
        if (m_AICharacter.CanSeeAtLeastOneEnemy)
        {
            ClearAIBehaviour();
            return;
        }

        if (m_Target.Object.GetComponent<Health>().IsDead)
        {
            ClearAIBehaviour();
            return;
        }

        if (!m_HasReachedLastKnownLocation)
        {
            if (m_Nodes == null)
            {
                m_Nodes = CalculatePath(MathUtils.GetClosestPointOnNavMesh(m_Target.LastPosition));
                m_NodeIndex = 0;
            }

            // Look at our target, move towards the node
            FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, true);

            if (m_Nodes != null)
            {
                if (m_NodeIndex >= m_Nodes.Length)
                {
                    m_Nodes = null;
                    m_NodeIndex = 0;
                    m_HasReachedLastKnownLocation = true;
                }
            }
        }
        else
        {
            if (m_Nodes == null)
            {
                m_Nodes = CalculatePath(MathUtils.GetClosestPointOnNavMesh(m_Target.LastPosition + m_Target.LastDirection));
                m_NodeIndex = 0;
            }

            FollowNodes(ref m_Nodes, ref m_NodeIndex, m_CloseEnoughToNode, true);

            if (m_Nodes != null)
            {
                if (m_NodeIndex >= m_Nodes.Length)
                {
                    m_Nodes = null;
                    m_NodeIndex = 0;
                    ClearAIBehaviour();
                }
            }
        }
    }

    public override void DebugDraw()
    {
        base.DebugDraw();

        Debug.DrawLine(m_Player.transform.position, m_Target.LastPosition, DebugColour);
        Debug.DrawLine(m_Target.LastPosition, m_Target.LastPosition + m_Target.LastDirection * 5, DebugColour);
        if (m_Nodes == null)
            return;

        if (m_NodeIndex >= m_Nodes.Length)
            return;

        Debug.DrawLine(m_Nodes[m_NodeIndex], m_Nodes[m_NodeIndex] + Vector3.up * 50, DebugColour);
        for (int i = 0; i < m_Nodes.Length - 1; i++)
        {
            Debug.DrawLine(m_Nodes[i], m_Nodes[i + 1], DebugColour);
        }
    }

    public override string GetBehaviourName()
    {
        return AIString.SearchBehaviour;
    }
}
