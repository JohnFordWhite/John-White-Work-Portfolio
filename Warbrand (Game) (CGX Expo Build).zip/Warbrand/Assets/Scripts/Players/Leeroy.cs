/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Leeroy                                                                         *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            September 16th, 2016                                                           *
 *                                                                                                 *
 * This is meant to be placed on a prefab, used to define the actions of Leeroy.                   *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - September 16th, 2016                                    *
\***************************************************************************************************/

using UnityEngine;

public class Leeroy : Player
{
    //
    // Public
    //
    public LeeroyMeleeAbility LeeroyMeleeAbility;
    public GauntletJumpAbility GauntletJumpAbility;
    public ClapStunAbility ClapStunAbility;
    public GauntletExplosiveAbility GauntletExplosiveAbility;
    public InjectionAbility InjectionAbility;
    public LeeroyShieldAbility LeeroyShieldAbility;

    public GameObject Shield;

    //
    //Private
    //
    private const string m_LeeroyMeleeAbilityString = "LeeroyMeleeAbility";
    private const string m_LeeroyShieldAbilityString = "LeeroyShieldAbility";
    private const string m_ClapStunAbilityString = "ClapStunAbility";
    private const string m_GauntletExplosiveAbilityString = "GauntletExplosiveAbility";
    private const string m_InjectionAbilityString = "InjectionAbility";
    private const string m_GauntletJumpAbilityString = "GauntletJumpAbility";

    override protected void Start ()
    {
        base.Start();

        if (GameInput != null)
        {

            // TODO: Make it so that abilities take in their proper inputs
            Character = CharacterTypes.Leeroy;

            LeeroyMeleeAbility = new LeeroyMeleeAbility(InputName.Attack1);
            LeeroyMeleeAbility.SetOwner(this);
            Abilities.Add(LeeroyMeleeAbility);

            LeeroyShieldAbility = new LeeroyShieldAbility(InputName.Attack2);
            LeeroyShieldAbility.SetOwner(this);
            Abilities.Add(LeeroyShieldAbility);

            GauntletJumpAbility = new GauntletJumpAbility(InputName.Movement);
            GauntletJumpAbility.SetOwner(this);
            Abilities.Add(GauntletJumpAbility);

            //Abilities.Add(new ShieldAbility());

            ClapStunAbility = new ClapStunAbility(InputName.Ability1);
            ClapStunAbility.SetOwner(this);
            Abilities.Add(ClapStunAbility);

            GauntletExplosiveAbility = new GauntletExplosiveAbility(InputName.Ability2);
            GauntletExplosiveAbility.SetOwner(this);
            Abilities.Add(GauntletExplosiveAbility);

            InjectionAbility = new InjectionAbility(InputName.Ability3);
            InjectionAbility.SetOwner(this);
            Abilities.Add(InjectionAbility);
        }
    }

    protected override void FixedUpdate()
    {
        base.FixedUpdate();
    }
    public void TriggerOnStart(string aAbility)
    {
        switch (aAbility)
        {
            case m_LeeroyMeleeAbilityString:
                LeeroyMeleeAbility.ActivateOnStartPointReached = true;
                break;
            case m_LeeroyShieldAbilityString:
                LeeroyShieldAbility.ActivateOnStartPointReached = true;
                break;
            case m_GauntletJumpAbilityString:
                GauntletJumpAbility.ActivateOnStartPointReached = true;
                break;
            case m_ClapStunAbilityString:
                ClapStunAbility.ActivateOnStartPointReached = true;
                break;
            case m_GauntletExplosiveAbilityString:
                GauntletExplosiveAbility.ActivateOnStartPointReached = true;
                break;
            case m_InjectionAbilityString:
                InjectionAbility.ActivateOnStartPointReached = true;
                break;
            default:
                break;
        }

    }
}