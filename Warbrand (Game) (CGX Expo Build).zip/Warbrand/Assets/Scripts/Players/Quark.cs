/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Quark                                                                          *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            September 16th, 2016                                                           *
 *                                                                                                 *
 * This is meant to be placed on a prefab, used to define the actions of Quark.                    *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - September 16th, 2016                                    *
\***************************************************************************************************/

using UnityEngine;

public class Quark : Player
{
    //
    // Public
    //
    public AudioClip MainAttackDamageBeam;

    [HideInInspector]
    public bool PlacingObject = false;

    public BounceBackAbility m_BounceBackability;
    public DamageMultiToolAbility m_DamageMultiTool;
    public PlaceTurretAbility m_PlaceTurret;
    public PlaceQuarkTrapAbility m_PlaceTrap;
    public PlaceCameraAbility m_PlaceCamera;
    
    override protected void Start()
    {
        base.Start();

        if (GameInput != null)
        {

            // TODO: Make it so that abilities take in their proper inputs
            Character = CharacterTypes.Quark;

            m_DamageMultiTool = (new DamageMultiToolAbility(InputName.Attack1));
            m_DamageMultiTool.SetOwner(this);
            Abilities.Add(m_DamageMultiTool);

            m_BounceBackability = new BounceBackAbility(InputName.Movement);
            m_BounceBackability.SetOwner(this);
            Abilities.Add(m_BounceBackability);

            m_PlaceTurret = new PlaceTurretAbility(InputName.Ability1);
            m_PlaceTurret.SetOwner(this);
            Abilities.Add(m_PlaceTurret);

            //Abilities.Add(new ThrowableAbility(ElectricWallPrefab));
            m_PlaceTrap = new PlaceQuarkTrapAbility(InputName.Ability2);
            m_PlaceTrap.SetOwner(this);
            Abilities.Add(m_PlaceTrap);

            m_PlaceCamera = new PlaceCameraAbility(InputName.Ability3);
            m_PlaceCamera.SetOwner(this);
            Abilities.Add(m_PlaceCamera);
        }
    }

    protected override void FixedUpdate()
    {
        base.FixedUpdate();
    }
    public void TriggerOnStart(string aAbility)
    {
        switch (aAbility)
        {
            case "BeamAbility":
                m_DamageMultiTool.ActivateOnStartPointReached = true;
                break;
            case "BounceBackability":
                m_BounceBackability.ActivateOnStartPointReached = true;
                break;
            case "PlaceTurretAbility":
                m_PlaceTurret.ActivateOnStartPointReached = true;
                break;
            case "PlaceTrapAbility":
                m_PlaceTrap.ActivateOnStartPointReached = true;
                break;
            case "PlaceCameraAbility":
                m_PlaceCamera.ActivateOnStartPointReached = true;
                break;

            default:
                break;
        }
    }
}