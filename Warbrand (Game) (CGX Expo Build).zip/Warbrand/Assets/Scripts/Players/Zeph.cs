/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Zeph                                                                           *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            September 16th, 2016                                                           *
 *                                                                                                 *
 * This is meant to be placed on a prefab, used to define the actions of Zeph.                     *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Author) - Date                                                            *
 * V 1.1 - Changelog (Author) - Date                                                               *
\***************************************************************************************************/

using UnityEngine;

public class Zeph : Player
{
    //
    // Public
    //
    public GameObject PoisonDartPrefab;

    [Space(10)]
    public AudioClip HookThrowClip;
    public AudioClip HookReturnClip;

    [HideInInspector]
    public ZephMeleeAbility ZephMeleeAbility;
    [HideInInspector]
    public TeleportAbility TeleportAbility;
    [HideInInspector]
    public HookAndPullAbility HookAbility;
    [HideInInspector]
    public GauntletSmokeAbility SmokeGrenadeAbility;
    [HideInInspector]
    public PoisonDartAbility PoisonDartAbility;
    public GameObject KusarigamaBlade;

    override protected void Start()
    {
        base.Start();

        if (GameInput != null)
        {

            Character = CharacterTypes.Zeph;

            ZephMeleeAbility = new ZephMeleeAbility(InputName.Attack1);
            ZephMeleeAbility.SetOwner(this);
            Abilities.Add(ZephMeleeAbility);

            TeleportAbility = new TeleportAbility(InputName.Movement);
            TeleportAbility.SetOwner(this);
            Abilities.Add(TeleportAbility);

            HookAbility = new HookAndPullAbility(InputName.Ability1);
            HookAbility.SetOwner(this);
            Abilities.Add(HookAbility);

            SmokeGrenadeAbility = new GauntletSmokeAbility(InputName.Ability2);
            SmokeGrenadeAbility.SetOwner(this);
            Abilities.Add(SmokeGrenadeAbility);

            PoisonDartAbility = new PoisonDartAbility(InputName.Ability3);
            PoisonDartAbility.SetOwner(this);
            Abilities.Add(PoisonDartAbility);
            //Abilities.Add(new ThrowableAbility(PoisonDartPrefab));
        }
    }

    protected override void FixedUpdate()
    {
        base.FixedUpdate();

        //Debug.Log(PlayerAnimator.GetBool("ZephMelee"));
    }
    public void TriggerOnStart(string aAbility)
    {
        switch (aAbility)
        {
            case "ZephMeleeAbility":
                ZephMeleeAbility.ActivateOnStartPointReached = true;
                break;
            case "SmokeGrenadeAbility":
                SmokeGrenadeAbility.ActivateOnStartPointReached = true;
                break;
            case "PoisonDartAbility":
                PoisonDartAbility.ActivateOnStartPointReached = true;
                break;
            case "HookAndPullAbility":
                HookAbility.ActivateOnStartPointReached = true;
                break;

            default:
                break;
        }
    }
}