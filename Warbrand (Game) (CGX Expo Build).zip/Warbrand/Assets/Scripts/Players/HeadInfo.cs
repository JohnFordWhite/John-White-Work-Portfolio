﻿using UnityEngine;
using System.Collections;

public class HeadInfo : MonoBehaviour
{
    public Renderer Head;
    public Renderer TopTeeth;
    public Renderer BottomTeeth;
    public Renderer Tongue;
    public Renderer LeftEye;
    public Renderer RightEye;

    public Renderer AdditionalRenderer1;
    public Renderer AdditionalRenderer2;

    public Material InvisibleMaterial;


    private Material m_HeadMaterial;
    private Material m_TopTeethMaterial;
    private Material m_BottomTeethMaterial;
    private Material m_TongueMaterial;
    private Material m_LeftEyeMaterial;
    private Material m_RightEyeMaterial;

    private const string StringInvincibleProperty = "_Invincible";

    void Start ()
    {
        m_HeadMaterial = Head.material;
        m_TopTeethMaterial = TopTeeth.material;
        m_BottomTeethMaterial = BottomTeeth.material;
        m_TongueMaterial = Tongue.material;
        m_LeftEyeMaterial = LeftEye.material;
        m_RightEyeMaterial = RightEye.material;
    }
	
	void Update ()
    {
        //MakeInvisible();
	}

    public void MakeVisible()
    {
        var mats = Head.materials;
        mats[0] = m_HeadMaterial;
        mats[1] = m_HeadMaterial;
        Head.materials = mats;
        TopTeeth.material = m_TopTeethMaterial;
        BottomTeeth.material = m_BottomTeethMaterial;
        Tongue.material = m_TongueMaterial;
        LeftEye.material = m_LeftEyeMaterial;
        RightEye.material = m_RightEyeMaterial;
    }

    public void MakeInvisible()
    {
        var mats = Head.materials;
        mats[0] = InvisibleMaterial;
        Head.materials = mats;
        TopTeeth.material = InvisibleMaterial;
        BottomTeeth.material = InvisibleMaterial;
        Tongue.material = InvisibleMaterial;
        LeftEye.material = InvisibleMaterial;
        RightEye.material = InvisibleMaterial;
    }

    public void UpdateInvincibility(float invincible)
    {
        for(int i = 0; i < Head.materials.Length; i++)
        {
            Head.materials[i].SetFloat(StringInvincibleProperty, invincible);
            if(AdditionalRenderer1 != null)
            {
                AdditionalRenderer1.material.SetFloat(StringInvincibleProperty, invincible);
            }

            if (AdditionalRenderer2 != null)
            {
                AdditionalRenderer2.material.SetFloat(StringInvincibleProperty, invincible);
            }
        }
    }
}
