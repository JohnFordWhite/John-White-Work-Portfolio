﻿using UnityEngine;
using System.Collections;

public class PlayerHitboxScript : MonoBehaviour
{
    public Player Owner;

    [HideInInspector]
    public bool ForceApplied = false;
    [HideInInspector]
    public Vector3 ForceDirection = Vector3.zero;
    [HideInInspector]
    public Vector3 ForceLocation = Vector3.zero;

    public void AddForce(Vector3 direction, Vector3 location)
    {
        if(ForceApplied)
        {
            ForceDirection += direction;
        }
        else
        {
            ForceApplied = true;
            ForceDirection = direction;
            ForceLocation = location;
        }
    }
    
    public void ClearForce()
    {
        ForceApplied = false;
        ForceDirection = Vector3.zero;
        ForceLocation = Vector3.zero;
    }
}
