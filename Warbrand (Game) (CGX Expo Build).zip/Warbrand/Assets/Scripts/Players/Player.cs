/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Player                                                                         *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            September 16th, 2016                                                           *
 *                                                                                                 *
 * This is an abstract class, meant to be subclassed from four times, once for each character.     *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - September 16th, 2016                                    *
 * V 1.1 - Added Functionality for continuous, non-toggle abilities (Jon Roffey) - Oct 21st, 2016  *
\***************************************************************************************************/

using UnityEngine;
//using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using System;
using UnityEngine.UI;
using System.Collections;

public enum CharacterTypes
{
    Paige,
    Quark,
    Leeroy,
    Zeph,
    MAX_CHARACTER_TYPES
}

public enum CharacterStates
{
    Inactive,
    HumanControlled,
    AIController,
    MAX_CHARACTER_STATES
}

public abstract class Player : MonoBehaviour
{
    //
    // Public
    //
    public List<Ability> Abilities = new List<Ability>();
    public CharacterTypes Character;
    public Camera PlayerCamera;
    public Camera FirstPersonPlayerCamera;
    [HideInInspector]
    public Camera ThirdPersonPlayerCamera;
    public Camera XRayCamera;
    public Camera OutlineCamera;
    public Camera FirstPersonModelCamera;
    public Camera UICamera;
    public Canvas UICanvas;
    [HideInInspector]
    public GameInputComponent GameInput = null;
    //[HideInInspector]
    public Transform SpawnPoint;
    public RecieveDamageIndicator RecieveDamageIndicator;
    public Image HitmarkerImage;
    public Image CrosshairImage;
    public Color DefaultCrosshairColor = Color.grey;
    public Color EnemyCrosshairColor = Color.red;
    public Color AllyCrosshairColor = Color.green;
    public Transform ObjectiveIndicatorPosition;

    public HudButtonIconHelper MovementAbilityIcon;
    public HudButtonIconHelper Ability1Icon;
    public HudButtonIconHelper Ability2Icon;
    public HudButtonIconHelper Ability3Icon;

    public KillFeedPanel KillFeedPanel;

    [Space(10)]
    public AudioSource AudioSourceMovement;
    public AudioSource AudioSourceMainAttack;
    public AudioSource AudioSourceAbility1;
    public AudioSource AudioSourceAbility2;
    public AudioSource AudioSourceAbility3;
    public AudioSource AudioSourceReload;
    public AudioSource AudioSourceFootstep;


    public Animator PlayerAnimator
    {
        get
        {
            if (m_PlayerAnimator == null)
            {
                m_PlayerAnimator = GetComponent<Animator>();
            }
            return m_PlayerAnimator;
        }
    }
    protected Animator m_PlayerAnimator;

    public BasicMovementScript BasicMovementScript
    {
        get
        {
            if (m_BasicMovementScript == null)
            {
                m_BasicMovementScript = GetComponent<BasicMovementScript>();
            }
            return m_BasicMovementScript;
        }
    }
    protected BasicMovementScript m_BasicMovementScript;

    public Rigidbody RigidBody
    {
        get
        {
            if (m_RigidBody == null)
            {
                m_RigidBody = GetComponent<Rigidbody>();
            }
            return m_RigidBody;
        }
    }
    protected Rigidbody m_RigidBody;

    [Space(10)]
    [HideInInspector]
    public bool CanSeePlayer1XRay = false;
    [HideInInspector]
    public bool CanSeePlayer2XRay = false;
    [HideInInspector]
    public bool CanSeePlayer3XRay = false;
    [HideInInspector]
    public bool CanSeePlayer4XRay = false;
    [HideInInspector]
    public bool CanSeePlayer5XRay = false;
    [HideInInspector]
    public bool CanSeePlayer6XRay = false;
    [HideInInspector]
    public bool CanSeePlayer7XRay = false;
    [HideInInspector]
    public bool CanSeePlayer8XRay = false;

    [HideInInspector]
    public bool CanUseMovementAbility = true;

    [HideInInspector]
    public bool IsAffectedBySmokeScreen { get { return (m_SmokeScreens.Count > 0); } }

    [HideInInspector]
    public float TimeOutOfAdhesive = 0.0f;
    [HideInInspector]
    public bool IsInAdhesive = false;
    [HideInInspector]
    public DeathType deathType = DeathType.None;

    public AbilityUICooldownsScript AbilityUICooldowns;

    // If you have an ability that requires that the player cannot move or rotate,
    // have the ability set this to true during OnStartAbility and
    // set to false during OnEndAbility.
    // See ChargedHealingAbility, ChargedWallSlamAbility.
    [HideInInspector]
    public bool AbilityBlockingMovement = false;
    [HideInInspector]
    public bool AbilityBlockingRotation = false;

    // This ability blocks other abilities from being used. This should be set from inside an Ability script.
    // OnStartAbility, set BlockingAbility to that Ability if it is null.
    // OnEndAbility, if BlockingAbility is that Ability, set it to null.
    // See ChargedHealingAbility, ChargedWallSlamAbility.
    [HideInInspector]
    public Ability BlockingAbility = null;

    [HideInInspector]
    public float StunTime { get { return m_StunTime; } }
    [HideInInspector]
    public bool IsStunned = false;

    [HideInInspector]
    public bool IsPoisoned = false;

    [HideInInspector]
    public float AttackSpeedPercent = 1;

    public float PoisonDamagePerSecond = 4.0f;

    public float RespawnInvincibilityTime = 5.0f;

    public GameObject m_RagdollPrefab;

    [HideInInspector]
    public int KillCount = 0;

    [HideInInspector]
    public int DeathCount = 0;

    [HideInInspector]
    public float LastDeathTime = 0;

    [HideInInspector]
    public Health Health
    {
        get
        {
            if (m_Health == null)
            {
                m_Health = GetComponent<Health>();
            }

            return m_Health;
        }
    }
    protected Health m_Health = null;

    public HealthUIScript HealthUIScript
    {
        get
        {
            if (m_HealthUIScript == null)
            {
                m_HealthUIScript = UICanvas.GetComponentInChildren<HealthUIScript>();
            }
            return m_HealthUIScript;
        }
    }
    protected HealthUIScript m_HealthUIScript;

    public PersonalKillNotification PersonalKillNotification
    {
        get
        {
            if (m_PersonalKillNotification == null)
            {
                m_PersonalKillNotification = UICanvas.GetComponent<PersonalKillNotification>();
            }
            return m_PersonalKillNotification;
        }
    }
    protected PersonalKillNotification m_PersonalKillNotification;

    public bool IsDead
    {
        get
        {
            return Health.IsDead;
        }
    }

    [HideInInspector]
    public Renderer PlayerRenderer
    {
        get
        {
            if (m_Renderer == null)
            {
                m_Renderer = GetComponent<Renderer>();
            }

            return m_Renderer;
        }
    }
    protected Renderer m_Renderer = null;

    public CapsuleCollider CapsuleCollider
    {
        get
        {
            if (m_CapsuleCollider == null)
            {
                m_CapsuleCollider = GetComponent<CapsuleCollider>();
            }
            return m_CapsuleCollider;
        }
    }
    protected CapsuleCollider m_CapsuleCollider;

    public GameObject ObjectiveWaypoints
    {
        get
        {
            if (m_ObjectiveWaypoints == null)
            {
                m_ObjectiveWaypoints = UICanvas.transform.FindChild(StringObjectiveWaypoints).gameObject;
            }
            return m_ObjectiveWaypoints;
        }
    }
    protected GameObject m_ObjectiveWaypoints;
    private const string StringObjectiveWaypoints = "ObjectiveWaypoints";

    public GameObject AbilityIndicators
    {
        get
        {
            if (m_AbilityIndicators == null)
            {
                m_AbilityIndicators = UICanvas.transform.FindChild(StringAbilities).gameObject;
            }
            return m_AbilityIndicators;
        }
    }
    protected GameObject m_AbilityIndicators;
    private const string StringAbilities = "Abilities";

    public GameObject StunnedNotification
    {
        get
        {
            if (m_StunnedNotification == null)
            {
                m_StunnedNotification = UICanvas.transform.FindChild(StringStunnedNotification).gameObject;
            }
            return m_StunnedNotification;
        }
    }
    protected GameObject m_StunnedNotification;
    private const string StringStunnedNotification = "StunnedNotification";

    //public int TeamIndex = 0;
    public int TeamIndex
    {
        get
        {
            if (GameInput != null)
            {
                return GameInput.TeamIndex;
            }
            return -1;
        }
    }

    public int PlayerID
    {
        get
        {
            if (GameInput != null)
            {
                return GameInput.PlayerID;
            }
            return -1;
        }
    }

    //
    // Private
    //

    private Transform m_Spine1;
    private Transform m_Neck1;
    private Transform m_LeftArm;
    private Transform m_RightArm;

    private bool m_IsAI;
    private float m_StunTime;
    private float m_PoisonTime;
    private PoisonDartImageEffectScript m_PoisonEffect;

    public bool InitialSpawned
    {
        get
        {
            return m_InitialSpawned;
        }
    }
    private bool m_InitialSpawned = false;
    private float m_InvincibilityTimer = 0;

    // Used for Hitmarker opacity
    private float m_HitTargetTimeout;

    private List<float> m_AttackSpeedModifiers;
    private List<SmokeScript> m_SmokeScreens = new List<SmokeScript>();
    private Renderer[] m_Renderers;
    private Collider[] m_Colliders;

    private bool m_HasSpawnedRagdoll = false;
    private int m_CrosshairLayerMask = 0;
    private int m_StunnedHash = Animator.StringToHash(m_StunnedString);
    private Material m_CrosshairMaterialPrefab;
    private HeadInfo m_HeadInfo;
    private Player m_Poisoner;
    private float m_InvincibleEffectAlpha;
    private float m_InvincibleEffectTimer = 0;

    protected InvincibleImageEffectScript m_InvincibleImageEffect;

    //strings
    private const string m_XRayLayer1Name = "Player1Model";
    private const string m_XRayLayer2Name = "Player2Model";
    private const string m_XRayLayer3Name = "Player3Model";
    private const string m_XRayLayer4Name = "Player4Model";
    private const string m_XRayLayer5Name = "Player5Model";
    private const string m_XRayLayer6Name = "Player6Model";
    private const string m_XRayLayer7Name = "Player7Model";
    private const string m_XRayLayer8Name = "Player8Model";
    private const string m_RespawnTagString = "Respawn";
    private const string m_GameSceneString = "GameScene";
    private const string m_XRayColorUniformString = "_XRayColor";

    private const string m_LeeroyMeleeString = "LeeroyMelee";
    private const string m_LeeroyShieldString = "ShieldActive";
    private const string m_GauntletJump = "GauntletJump";
    private const string m_ClapStunString = "ClapStun";
    private const string m_GauntletExplosiveString = "GauntletExplosive";
    private const string m_InjectLeeroidRage = "InjectLeeroidRage";
    private const string m_EmptyStateString = "Empty";

    private const string m_StunnedString = "Stunned";

    private const string StringColourProperty = "_Colour";
    private const string StringInvincibleProperty = "_Invincible";
    private const string StringOutlineColourProperty = "_OutlineColor";
    private const string StringFadeToBlackPanelPath = "FadeToBlackPanel";

    private const string m_InvertedColourReticleResource = "Materials/ShaderMaterials/InvertedColourReticle";

    private const string m_Spine1String = "MarineSpine1";
    private const string m_Neck1String = "MarineNeck1";
    private const string m_LeftArmString = "MarineLArmUpperarm";
    private const string m_RightArmString = "MarineRUpperarm";

    protected virtual void Start()
    {
        if (transform.parent != null && transform.parent.parent != null)
            GameInput = transform.parent.parent.GetComponent<GameInputComponent>();

        m_PlayerAnimator = GetComponent<Animator>();

        m_Spine1 = transform.FindInChildren(m_Spine1String);
        m_Neck1 = transform.FindInChildren(m_Neck1String);
        m_LeftArm = transform.FindInChildren(m_LeftArmString);
        m_RightArm = transform.FindInChildren(m_RightArmString);

        m_HitTargetTimeout = 0.0f;

        m_AttackSpeedModifiers = new List<float>();
        m_AttackSpeedModifiers.Capacity = 5;
        for (int i = 0; i < m_AttackSpeedModifiers.Capacity; i++)
        {
            m_AttackSpeedModifiers.Add(0.0f);
        }

        if (GameInput != null)
        {
            //Determine which XRay layer to put the player in based on his ID
            int id = GameInput.PlayerID;

            AssignLayers(id);


            m_CrosshairLayerMask = ~((1 << gameObject.layer) |
                                    (1 << LayerMask.NameToLayer("UnplacedObjects")) |
                                    (1 << LayerMask.NameToLayer("WallCollider")) |
                                    (1 << LayerMask.NameToLayer("Ragdoll")) |
                                    (1 << LayerMask.NameToLayer("Shield")));
        }

        if (IsAI)
            return;

        AbilityUICooldowns = UICanvas.gameObject.GetComponentInChildren<AbilityUICooldownsScript>(true);

        m_PoisonEffect = FirstPersonModelCamera.GetComponent<PoisonDartImageEffectScript>();

        m_CrosshairMaterialPrefab = Resources.Load(m_InvertedColourReticleResource) as Material;
        CrosshairImage.material = MonoBehaviour.Instantiate(m_CrosshairMaterialPrefab);

        m_CapsuleCollider = GetComponent<CapsuleCollider>();
    }

    void Update()
    {
#if UNITY_EDITOR
        if (GameInput.GetInput(InputName.Test_Respawn, InputType.ButtonPressed, true) != 0.0f)
        {
            Health.Kill(false);
            return;
        }
#endif


        if(IsAffectedBySmokeScreen)
        {
            DialogueManager.Instance.PlayDialogue(Character, DialogueContext.InSmoke, false, true);
        }
        if(m_HeadInfo == null)
        {
            m_HeadInfo = GetComponent<HeadInfo>();
            m_HeadInfo.MakeVisible();
        }
        else
        {
            m_HeadInfo.MakeVisible();
        }

        if (GameInput != null)
        {
            if (m_InitialSpawned == false)
            {
                return;
                //SpawnPlayer();
                //m_InitialSpawned = true;

                ////if(GetSpawnPoint() != null)
                ////{
                ////    SpawnPoint = GetSpawnPoint();
                ////    SpawnPlayer();
                ////    m_InitialSpawned = true;
                ////} 
            }
            if (transform.parent == null)
                return;

            if (InputManager.CM.CurrentGameState == GameState.PlayGame)
            {
                CheckAbilities();
            }

            if (GameInput.IsAI == false)
            {
                //check if the player is aiming at ally, foe, or neither
                RaycastHit hitInfo;
                if (Physics.SphereCast(PlayerCamera.transform.position, 0.2f, PlayerCamera.transform.forward, out hitInfo, 100, m_CrosshairLayerMask, QueryTriggerInteraction.Ignore))
                {
                    Player otherPlayer = null;

                    PlayerHitboxScript hitbox = hitInfo.collider.GetComponent<PlayerHitboxScript>();

                    if (hitbox != null)
                        otherPlayer = hitbox.Owner;

                    if (otherPlayer != null && otherPlayer != this)
                    {
                        if (GameInput.TeamIndex == otherPlayer.GameInput.TeamIndex)
                        {
                            CrosshairImage.material.SetColor(StringColourProperty, AllyCrosshairColor);
                        }
                        else
                        {
                            CrosshairImage.material.SetColor(StringColourProperty, EnemyCrosshairColor);
                        }
                    }
                    else
                    {
                        CrosshairImage.material.SetColor(StringColourProperty, DefaultCrosshairColor);
                    }
                }
                else
                {
                    CrosshairImage.material.SetColor(StringColourProperty, DefaultCrosshairColor);
                }
            }
        }
    }
    void LateUpdate()
    {
        //NOTE: The rotations are strange because the bones were not rotated/exported for Unity from 3DS Max
        float Neck1RotationValue = -FirstPersonModelCamera.transform.eulerAngles.x;
        float Spine1RotationValue = -FirstPersonModelCamera.transform.eulerAngles.x;
        float LeftArmRotationValue = -FirstPersonModelCamera.transform.eulerAngles.x;
        float RightArmRotationValue = -FirstPersonModelCamera.transform.eulerAngles.x;

        //TODO: Adjust rotation of specific bones on a per character basis once they have their own animations -
        // e.g., Leeroy's right arm should mostly follow the camera, but left should not, because it looks strange -
        //but Paige will be holding a shotgun, and both of her arms will need to rotate with the camera

        //lock neck looking down
        if (Neck1RotationValue < -50 && Neck1RotationValue > -180)
            Neck1RotationValue = -50;

        //lock neck looking up
        if (Neck1RotationValue > -330 && Neck1RotationValue < -180)
            Neck1RotationValue = -330;

        //lock spine1 looking down
        if (Spine1RotationValue < -15 && Spine1RotationValue > -180)
            Spine1RotationValue = -15;

        //lock spine1 looking up
        if (Spine1RotationValue > -340 && Spine1RotationValue < -180)
            Spine1RotationValue = -340;

        //lock Larm looking down
        if (LeftArmRotationValue < -10 && LeftArmRotationValue > -180)
            LeftArmRotationValue = -10;

        //lock Larm looking up
        if (LeftArmRotationValue > -330 && LeftArmRotationValue < -180)
            LeftArmRotationValue = -330;

        //lock Rarm looking down
        if (RightArmRotationValue < -25 && RightArmRotationValue > -180)
            RightArmRotationValue = -25;

        //lock Rarm looking up
        if (RightArmRotationValue > -330 && RightArmRotationValue < -180)
            RightArmRotationValue = -330;

        switch (Character)
        {
            case CharacterTypes.Paige:
                //m_Neck1.localEulerAngles = new Vector3(m_Neck1.localEulerAngles.x, m_Neck1.localEulerAngles.y, Neck1RotationValue);
                break;
            case CharacterTypes.Quark:
                break;
            case CharacterTypes.Leeroy:
            case CharacterTypes.Zeph:
                m_RightArm.localEulerAngles = new Vector3(RightArmRotationValue, m_RightArm.localEulerAngles.y, m_RightArm.localEulerAngles.z);
                m_Neck1.localEulerAngles = new Vector3(m_Neck1.localEulerAngles.x, m_Neck1.localEulerAngles.y, Neck1RotationValue);
                break;
            default:
                break;
        }

        //m_Spine1.localEulerAngles = new Vector3(m_Spine1.localEulerAngles.x, m_Spine1.localEulerAngles.y, Spine1RotationValue);
        //m_Neck1.localEulerAngles = new Vector3(m_Neck1.localEulerAngles.x, m_Neck1.localEulerAngles.y, Neck1RotationValue);

        //m_LeftArm.localEulerAngles = new Vector3(-LeftArmRotationValue, m_LeftArm.localEulerAngles.y, m_LeftArm.localEulerAngles.z);
        //m_RightArm.localEulerAngles = new Vector3(RightArmRotationValue, m_RightArm.localEulerAngles.y, m_RightArm.localEulerAngles.z);
    }

    public void CheckAbilities()
    {
        for (int i = 0; i < Abilities.Count; i++)
        {
            Ability ability = Abilities[i];

            // If there is a blocking ability in use, and it is not this one, do not perform this ability (End the ability instead).
            // Also end the ability if the player is currently stunned.
            if (BlockingAbility != null && BlockingAbility != ability || IsStunned == true)
            {
                ability.OnEndAbility();
                ability.Toggled = false;
                continue;
            }

            // GameInput may not have been initialized in Start()
            if (GameInput == null)
            {
                GameInput = transform.parent.GetComponent<GameInputComponent>();
            }

            if (ability.Owner == null)
                ability.Owner = this;
            if (ability.IsToggle)
            {
                if (GameInput != null && GameInput.GetInput(ability.Key, InputType.ButtonPressed) != 0.0f)
                {
                    if (!ability.Toggled)
                    {
                        TriggerAbilityAnimations(ability);
                    }
                    else
                    {
                        ability.OnEndAbility();
                        ability.Toggled = false;
                    }
                    continue;
                }

                if (ability.Toggled)
                    ability.OnContinueAbility();
            }
            else if (ability.IsContinuousAbility)
            {
                if (!ability.ContinuousAbilityInUse)
                {
                    if (GameInput.GetInput(ability.Key, InputType.ButtonPressed) != 0.0f && !ability.ContinuousAbilityStarted)
                    {
                        TriggerAbilityAnimations(ability);
                    }
                }
                else
                {
                    ability.OnContinueAbility();

                    //Did the previous OnContinueAbility set ContinuousAbilityInUse to false?
                    if (!ability.ContinuousAbilityInUse)
                    {
                        ability.OnEndAbility();
                    }
                }
            }
            else
            {
                if (GameInput != null)
                {
                    if (GameInput.GetInput(ability.Key, InputType.ButtonPressed) != 0.0f)
                    {
                        TriggerAbilityAnimations(ability);
                    }
                    else if (GameInput.GetInput(ability.Key, InputType.ButtonReleased) != 0.0f)
                        ability.OnEndAbility();
                    else if (GameInput.GetInput(ability.Key) != 0.0f)
                        ability.OnContinueAbility();
                }
            }
        }
    }

    //TODO: put all of this logic in it's own ability
    public void TriggerAbilityAnimations(Ability aAbility)
    {
        if (m_PlayerAnimator.GetCurrentAnimatorStateInfo(1).IsName(m_EmptyStateString))
        {
            if (aAbility.HasAnimationTime)
            {
                switch (Character)
                {
                    case CharacterTypes.Paige:
                        switch (aAbility.AnimatorString)
                        {
                        case "Shotgun":
                                PlayerAnimator.SetTrigger("Shotgun");
                            break;
                        case "StartJetpack":
                                PlayerAnimator.SetTrigger("StartJetpack");
                            break;
                        case "ChargedHealing":
                                if (aAbility.CanUseAbility())
                                    PlayerAnimator.SetBool("Healing", true);
                            break;
                        case "TMNThrowable":
                                if (aAbility.CanUseAbility())
                                    PlayerAnimator.SetTrigger("TMNThrowable");
                                break;
                        case "GroundPound":
                                if (aAbility.CanUseAbility())
                                    PlayerAnimator.SetTrigger("GroundPound");
                                break;

                            default:
                                break;
                        }

                        break;
                    case CharacterTypes.Quark:
                        switch (aAbility.AnimatorString)
                        {
                            case "Beam":
                                PlayerAnimator.SetBool("Beam", true);
                                break;
                            case "BounceBack":
                                if (aAbility.CanUseAbility())
                                    PlayerAnimator.SetTrigger("BounceBack");
                                break;
                            case "PlaceTurret":
                                if (aAbility.CanUseAbility())
                                    PlayerAnimator.SetBool("PlacingTurret", true);
                                break;
                            case "PlaceTrap":
                                if (aAbility.CanUseAbility())
                                    PlayerAnimator.SetBool("PlacingTrap", true);
                                break;
                            case "ThrowCamera":
                                if (aAbility.CanUseAbility())
                                    PlayerAnimator.SetTrigger("ThrowCamera");
                                break;

                            default:
                                break;
                        }
                        break;
                    case CharacterTypes.Leeroy:
                        switch (aAbility.AnimatorString)
                        {
                            case m_LeeroyMeleeString:
                                PlayerAnimator.SetBool(m_LeeroyMeleeString,true);
                                break;
                            case m_LeeroyShieldString:
                                m_PlayerAnimator.SetBool(m_LeeroyShieldString, true);
                                break;
                            case m_GauntletJump:
                                if (aAbility.CanUseAbility())
                                    m_PlayerAnimator.SetTrigger(m_GauntletJump);
                                break;
                            case m_ClapStunString:
                                if (aAbility.CanUseAbility())
                                    m_PlayerAnimator.SetTrigger(m_ClapStunString);
                                break;
                            case m_GauntletExplosiveString:
                                if (aAbility.CanUseAbility())
                                    m_PlayerAnimator.SetTrigger(m_GauntletExplosiveString);
                                break;
                            case m_InjectLeeroidRage:
                                if (aAbility.CanUseAbility())
                                    m_PlayerAnimator.SetTrigger(m_InjectLeeroidRage);
                                break;

                            default:
                                break;
                        }
                        break;
                    case CharacterTypes.Zeph:
                        switch (aAbility.AnimatorString)
                        {
                            case "ZephMelee":
                                PlayerAnimator.SetBool("ZephMelee", true);
                                break;
                            case "ThrowHook":
                                if (aAbility.CanUseAbility())
                                    PlayerAnimator.SetTrigger("ThrowHook");
                                break;
                            case "SmokeGrenade":
                                if(aAbility.CanUseAbility())
                                    PlayerAnimator.SetTrigger("SmokeGrenade");
                                break;
                            case "PoisonDart":
                                if (aAbility.CanUseAbility())
                                    PlayerAnimator.SetTrigger("PoisonDart");
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        break;
                }

                SimpleCoroutine.Instance.StartCoroutine(WaitForAnimation(aAbility));
            }
            else
            {
                aAbility.OnStartAbility();
            }
        }
    }

    IEnumerator WaitForAnimation(Ability aAbility)
    {
        while (!aAbility.ActivateOnStartPointReached)
        {
            yield return null;
        }

        aAbility.OnStartAbility();

        if(aAbility.IsToggle)
            aAbility.Toggled = true;

        aAbility.ActivateOnStartPointReached = false;
    }

    public bool IsAI
    {
        get
        {
            if (GameInput == null && transform.parent != null && transform.parent.parent != null)
                GameInput = transform.parent.parent.GetComponent<GameInputComponent>();
            if (GameInput != null)
                return GameInput.IsAI;
            else
                return false;
        }
    }

    // TODO: Fix these when the bounding boxes are added
    public bool IsInside { get { return false; } }
    public bool IsOutside { get { return !IsInside; } }

    protected virtual void FixedUpdate()
    {
        // Hitmarker Opacity
        m_HitTargetTimeout -= Time.fixedDeltaTime;
        if (m_HitTargetTimeout < 0)
            m_HitTargetTimeout = 0.0f;
        if (HitmarkerImage != null)
        {
            Color hitmarkerColor = HitmarkerImage.color;
            hitmarkerColor.a = m_HitTargetTimeout;
            HitmarkerImage.color = hitmarkerColor;
        }

        // Stun timeout
        m_StunTime -= Time.fixedDeltaTime;
        if (m_StunTime < 0)
            m_StunTime = 0.0f;

        // Poison timeout
        m_PoisonTime -= Time.fixedDeltaTime;
        if (m_PoisonTime < 0)
        {
            m_PoisonTime = 0.0f;
        }
            

        if (!IsInAdhesive)
        {
            TimeOutOfAdhesive += Time.fixedDeltaTime;
        }
        else
        {
            TimeOutOfAdhesive = 0.0f;
        }

        m_InvincibilityTimer -= Time.fixedDeltaTime;
        if (m_InvincibilityTimer <= 0 && Health.IsInvincible == true)
            Health.IsInvincible = false;
        else if (m_InvincibilityTimer > 0 && Health.IsInvincible == false)
            Health.IsInvincible = true;

        if (m_InvincibleImageEffect == null)
            m_InvincibleImageEffect = FirstPersonModelCamera.GetComponent<InvincibleImageEffectScript>();

        //If the player is invincible, update their materials and their screen effect
        if (Health.IsInvincible)
        {
            m_InvincibleImageEffect.enabled = true;

            m_InvincibleEffectTimer += Time.fixedDeltaTime;
            m_InvincibleEffectAlpha = (Mathf.Sin(m_InvincibleEffectTimer * 5.6f) + 1.3f) / 2.0f;

            if (m_HeadInfo != null)
                m_HeadInfo.UpdateInvincibility(m_InvincibleEffectAlpha);

            m_InvincibleImageEffect.m_EffectAlpha = m_InvincibleEffectAlpha;
        }
        else
        {
            if (m_InvincibleEffectAlpha < 0.02)
            {
                m_InvincibleImageEffect.enabled = false;
            }
            else
            {
                m_InvincibleEffectTimer = 0;
                m_InvincibleEffectAlpha = Mathf.Lerp(m_InvincibleEffectAlpha, 0, 10 * Time.fixedDeltaTime);

                if (m_HeadInfo != null)
                    m_HeadInfo.UpdateInvincibility(m_InvincibleEffectAlpha);

                m_InvincibleImageEffect.m_EffectAlpha = m_InvincibleEffectAlpha;
            }
        }

        // Set up components
        if (m_BasicMovementScript == null)
            m_BasicMovementScript = GetComponent<BasicMovementScript>();

        // Handle stun
        if (IsStunned == true)
        {
            if (m_StunTime <= 0.0f && AbilityBlockingMovement == false)
            {
                if (m_BasicMovementScript != null)
                {
                    m_BasicMovementScript.IsStunned = true;
                }
                IsStunned = false;
                m_BasicMovementScript.IsStunned = false;
                m_PlayerAnimator.SetBool(m_StunnedHash, false);
            }
            else
            {
                if (m_BasicMovementScript != null || AbilityBlockingMovement == true)
                {
                    m_PlayerAnimator.SetBool(m_StunnedHash, false);
                    m_BasicMovementScript.IsStunned = false;
                }
            }
        }

        //Handle poison
        if (IsPoisoned == true)
        {
            if (m_PoisonTime > 0.0f)
            {
                if (!IsAI)
                    m_PoisonEffect.Poisoned = true;
                Health.Damage(m_Poisoner, null, PoisonDamagePerSecond * Time.fixedDeltaTime, DeathType.PoisonDart, false);
                AchievementsManager.IncrementFloat(this, Achievements.TimePoisoned, Time.fixedDeltaTime);
            }
            else
            {
                if (!IsAI)
                    m_PoisonEffect.Poisoned = false;
            }
        }

        // Update each ability
        for (int i = 0; i < Abilities.Count; i++)
        {
            Ability ability = Abilities[i];

            if (ability != null)
            {
                ability.UpdateAbility(Time.fixedDeltaTime);
            }
        }
    }

    public void Stun(float aStunTime)
    {
        if (Health.IsInvincible == false)
        {

            m_StunTime += aStunTime;

            IsStunned = true;

            m_PlayerAnimator.SetBool(m_StunnedHash, true);
        }

        //Debug.Log(this + " was stunned! Stun time remaining: " + m_StunTime);
    }

    public void Poison(float aPoisonTime, Player poisoner)
    {
        FirstPersonModelCamera.GetComponent<PoisonDartImageEffectScript>().enabled = true;
        m_PoisonTime += aPoisonTime;

        m_Poisoner = poisoner;

        IsPoisoned = true;
    }

    public Transform GetSpawnPoint()
    {
        if (InputManager.CM.CurrentGameState == GameState.PlayGame)
        {
            GameModeManager game = InputManager.CM.GameModeManager;
            if (game.CurrentGameMode != null)
            {
                GameObject spawnPoint = game.CurrentGameMode.GetSpawnPointForPlayer(this);

                if (spawnPoint != null)
                    return spawnPoint.transform;
            }
        }

        return null;
    }

    public void HitTarget()
    {
        m_HitTargetTimeout = 1.0f;
    }

    public void SpawnPlayer()
    {
        // Keep track of the last spawn point the player got for debugging purposes.
        SpawnPoint = GetSpawnPoint();

#if UNITY_EDITOR
        if (SpawnPoint != null)
        {
            // Handy debugging to draw a line in the direction of the spawn point from (0,0,0)
            DebugManager.DrawLine(Vector3.zero, SpawnPoint.position, Color.blue, 1.0f, Developmer.AllDevelopmers);
        }
#endif

        m_StunTime = 0;
        IsStunned = false;
        m_PoisonTime = 0;

        PoisonDartImageEffectScript poisonDart = FirstPersonModelCamera.GetComponent<PoisonDartImageEffectScript>();
        PoisonGasImageEffectScript poisonGas = FirstPersonModelCamera.GetComponent<PoisonGasImageEffectScript>();

        poisonDart.Poisoned = false;
        poisonGas.Poisoned = false;
        poisonDart.m_EffectAlpha = 0;
        poisonGas.m_EffectAlpha = 0;
        for (int i = 0; i < Abilities.Count; i++)
        {
            Abilities[i].ResetAbility();
        }
        m_InvincibilityTimer = RespawnInvincibilityTime;
        RigidBody.velocity = Vector3.zero;
        Health.CurrentHealth = Health.MaxHealth;


        // TODO: don't spawn the player at all if there is no spawn point.

        if (SpawnPoint != null)
        {
            transform.position = SpawnPoint.position;
            transform.rotation = SpawnPoint.rotation;
            FirstPersonPlayerCamera.transform.rotation = transform.rotation;
        }

        m_HasSpawnedRagdoll = false;

        m_InitialSpawned = true;
    }

    public void AddAttackSpeedModifier(float modifier)
    {
        AddRemoveModifier.AddModifier(ref m_AttackSpeedModifiers, modifier);
        AddRemoveModifier.UpdateModifierPercent(ref m_AttackSpeedModifiers, ref AttackSpeedPercent);
    }

    public void RemoveAttackSpeedModifier(float modifier)
    {
        AddRemoveModifier.RemoveModifier(ref m_AttackSpeedModifiers, modifier);
        AddRemoveModifier.UpdateModifierPercent(ref m_AttackSpeedModifiers, ref AttackSpeedPercent);
    }

    public void AddSmokeScreen(SmokeScript aSmoke)
    {
        if (!(m_SmokeScreens.Contains(aSmoke)))
            m_SmokeScreens.Add(aSmoke);
    }

    public void RemoveSmokeScreen(SmokeScript aSmoke)
    {
        while (m_SmokeScreens.Contains(aSmoke))
            m_SmokeScreens.Remove(aSmoke);
    }

    public bool OnlyAffectedByMySmokeScreen(Player aPlayer)
    {
        if (m_SmokeScreens.Count != 1)
            return false;

        if (m_SmokeScreens[0].Owner == aPlayer)
            return true;
        return false;
    }

    private void AssignLayers(int id)
    {
        m_Renderers = transform.GetComponentsInChildren<Renderer>();
        m_Colliders = transform.GetComponentsInChildren<Collider>();
        int length;

        switch (id)
        {
            case 1:
                gameObject.layer = LayerMask.NameToLayer(m_XRayLayer1Name);
                length = m_Renderers.Length;
                for (int i = 0; i < length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    if (renderer.gameObject.layer == 0)
                    {
                        renderer.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer1Name);
                    }
                }
                length = m_Colliders.Length;
                for (int i = 0; i < length; i++)
                {
                    Collider collider = m_Colliders[i];

                    if (collider.gameObject.layer == 0)
                    {
                        collider.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer1Name);
                    }
                }
                break;
            case 2:
                gameObject.layer = LayerMask.NameToLayer(m_XRayLayer2Name);
                length = m_Renderers.Length;
                for (int i = 0; i < length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    if (renderer.gameObject.layer == 0)
                    {
                        renderer.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer2Name);
                    }
                }
                length = m_Colliders.Length;
                for (int i = 0; i < length; i++)
                {
                    Collider collider = m_Colliders[i];

                    if (collider.gameObject.layer == 0)
                    {
                        collider.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer2Name);
                    }
                }
                break;
            case 3:
                gameObject.layer = LayerMask.NameToLayer(m_XRayLayer3Name);
                length = m_Renderers.Length;
                for (int i = 0; i < length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    if (renderer.gameObject.layer == 0)
                    {
                        renderer.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer3Name);
                    }
                }
                length = m_Colliders.Length;
                for (int i = 0; i < length; i++)
                {
                    Collider collider = m_Colliders[i];

                    if (collider.gameObject.layer == 0)
                    {
                        collider.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer3Name);
                    }
                }
                break;
            case 4:
                gameObject.layer = LayerMask.NameToLayer(m_XRayLayer4Name);
                length = m_Renderers.Length;
                for (int i = 0; i < length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    if (renderer.gameObject.layer == 0)
                    {
                        renderer.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer4Name);
                    }
                }
                length = m_Colliders.Length;
                for (int i = 0; i < length; i++)
                {
                    Collider collider = m_Colliders[i];

                    if (collider.gameObject.layer == 0)
                    {
                        collider.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer4Name);
                    }
                }
                break;
            case 5:
                gameObject.layer = LayerMask.NameToLayer(m_XRayLayer5Name);
                length = m_Renderers.Length;
                for (int i = 0; i < length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    if (renderer.gameObject.layer == 0)
                    {
                        renderer.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer5Name);
                    }
                }
                length = m_Colliders.Length;
                for (int i = 0; i < length; i++)
                {
                    Collider collider = m_Colliders[i];

                    if (collider.gameObject.layer == 0)
                    {
                        collider.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer5Name);
                    }
                }
                break;
            case 6:
                gameObject.layer = LayerMask.NameToLayer(m_XRayLayer6Name);
                length = m_Renderers.Length;
                for (int i = 0; i < length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    if (renderer.gameObject.layer == 0)
                    {
                        renderer.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer6Name);
                    }
                }
                length = m_Colliders.Length;
                for (int i = 0; i < length; i++)
                {
                    Collider collider = m_Colliders[i];

                    if (collider.gameObject.layer == 0)
                    {
                        collider.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer6Name);
                    }
                }
                break;
            case 7:
                gameObject.layer = LayerMask.NameToLayer(m_XRayLayer7Name);
                length = m_Renderers.Length;
                for (int i = 0; i < length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    if (renderer.gameObject.layer == 0)
                    {
                        renderer.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer7Name);
                    }
                }
                length = m_Colliders.Length;
                for (int i = 0; i < length; i++)
                {
                    Collider collider = m_Colliders[i];

                    if (collider.gameObject.layer == 0)
                    {
                        collider.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer7Name);
                    }
                }
                break;
            case 8:
                gameObject.layer = LayerMask.NameToLayer(m_XRayLayer8Name);
                length = m_Renderers.Length;
                for (int i = 0; i < length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    if (renderer.gameObject.layer == 0)
                    {
                        renderer.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer8Name);
                    }
                }
                length = m_Colliders.Length;
                for (int i = 0; i < length; i++)
                {
                    Collider collider = m_Colliders[i];

                    if (collider.gameObject.layer == 0)
                    {
                        collider.gameObject.layer = LayerMask.NameToLayer(m_XRayLayer8Name);
                    }
                }
                break;
        }

        for (int i = 0; i < m_Renderers.Length; i++)
        {
            Renderer renderer = m_Renderers[i];

            renderer.material.SetColor(StringOutlineColourProperty, BaseGameMode.TeamColors[TeamIndex]);
        }
    }

    public void ShowBlackScreen(bool aShow)
    {
        // Get fade to black panel and show/hide it.
        Transform blackScreen = UICanvas.transform.FindChild(StringFadeToBlackPanelPath);
        if (blackScreen != null)
        {
            blackScreen.gameObject.SetActive(aShow);

            // We want to hide some UI elements when the black screen is active.
            HealthUIScript.gameObject.SetActive(!aShow);
            CrosshairImage.gameObject.SetActive(!aShow);
            ObjectiveWaypoints.SetActive(!aShow);
            AbilityIndicators.SetActive(!aShow);
            StunnedNotification.SetActive(!aShow);
            HitmarkerImage.gameObject.SetActive(!aShow);
        }
        if (aShow == true)
        {

        }

    }

    public void SpawnRagdoll(Transform trans)
    {
        if (m_HasSpawnedRagdoll == false && m_RagdollPrefab != null)
        {
            GameObject ragdollObject = GameObject.Instantiate(m_RagdollPrefab, trans) as GameObject;
            BaseRagdollInfo ragdoll = ragdollObject.GetComponent<BaseRagdollInfo>();
            BaseRagdollInfo playerRagdoll = GetComponent<BaseRagdollInfo>();

            ragdollObject.transform.SetParent(null);
            ragdollObject.transform.position = trans.position;
            ragdollObject.transform.rotation = trans.rotation;
            ragdoll.SetBoneInfo(playerRagdoll);
            Vector3 playerVelocity = RigidBody.velocity;
            Rigidbody[] rigidBodies = ragdollObject.GetComponentsInChildren<Rigidbody>();
            for (int i = 0; i < rigidBodies.Length; i++)
            {
                rigidBodies[i].velocity = playerVelocity;
            }
            
            switch(deathType)
            {
                case DeathType.Physics:
                    ragdoll.ApplyForces(playerRagdoll);
                    break;
                case DeathType.Turret:
                    ragdoll.ApplyForces(playerRagdoll);
                    break;
            }
            
            m_HasSpawnedRagdoll = true;
        }

    }

    public void UpdateAbilityIconButtons()
    {
        if (GameInput.IsAI == false)
        {
            PlayerInput input = GameInput.Input as PlayerInput;

            MovementAbilityIcon.UpdateAbilityIconButton(input, InputName.Movement);
            Ability1Icon.UpdateAbilityIconButton(input, InputName.Ability1);
            Ability2Icon.UpdateAbilityIconButton(input, InputName.Ability2);
            Ability3Icon.UpdateAbilityIconButton(input, InputName.Ability3);
        }
    }

    public void LateStartGameCleanup()
    {
        m_InitialSpawned = false;

        StartCoroutine(HandleLateStartGameCleanup());
    }

    IEnumerator HandleLateStartGameCleanup()
    {
        yield return null;

        if (UICanvas != null)
        {
            Transform[] ignoreObjects =
            {
                KillFeedPanel.transform
            };

            InterfaceUtils.DisableLayoutComponentsFromCanvas(UICanvas.transform, ignoreObjects);
        }

        if (RecieveDamageIndicator != null)
        {
            if (IsAI == true)
            {
                RecieveDamageIndicator.enabled = false;
            }
            else
            {
                RecieveDamageIndicator.InitPool();
            }
        }
        
        if (IsAI == false)
        {
            UpdateAbilityIconButtons();
            ShowBlackScreen(false);

            ObjectiveWaypoint waypoint = UICanvas.GetComponentInChildren<ObjectiveWaypoint>();
            if (waypoint != null)
            {
                waypoint.Setup();
            }
        }

        SpawnPlayer();
    }

    //Allows xray replacement shader scripts of other players to modify this player's xray color before rendering
    public void ChangeXRayColor(Color col)
    {
        if (InputManager.CM.GameModeManager.CurrentGameMode.GameCondition != GameCondition.GameInProgress)
            return;

        if (m_Renderers != null)
        {
            for (int i = 0; i < m_Renderers.Length; i++)
            {
                m_Renderers[i].material.SetColor(m_XRayColorUniformString, col);
            }
        }
    }

    public void IgnoreCollision(Collider collider)
    {
        int length = m_Colliders.Length;
        for(int i = 0; i < length; i++)
        {
            Physics.IgnoreCollision(m_Colliders[i], collider);
        }
    }
}