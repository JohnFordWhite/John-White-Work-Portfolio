/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Paige                                                                          *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            September 16th, 2016                                                           *
 *                                                                                                 *
 * This is meant to be placed on a prefab, used to define the actions of Paige.                    *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - September 16th, 2016                                    *
\***************************************************************************************************/

using UnityEngine;
using UnityEngine.UI;

public class Paige : Player
{
    //
    // Public
    //
    [HideInInspector]
    public ParticleSystem HealingParticle;
    public ParticleSystem ShotgunMuzzleFlash;
    public CanvasRenderer HealingEffectRenderer;
    public GameObject TMNAdhesivePrefab;
    public GameObject ShotgunBulletPrefab;
    public GameObject SplatterPrefab;
    public float ShotgunBaseDamage = 10.0f;


    // Keep these values low!
    // Play around with these values to get an amount of total health recovered
    // that feels right. If you turn on CapHealingAbilityAmount, try to make sure
    // that the cap amount is very close to the total amount of health that is
    // healed over the HealingAbilityChargeTime.
    public float HealingAbilityExponentialValue = 1.95f;
    public float HealingAbilityBaseHealthRecovery = 0.025f;

    [Space(10)]
    public AudioClip HealChargingClip;
    public AudioClip HealEndClip;
    public AudioClip GroundPoundEndClip;

    [HideInInspector] public ShotgunAbility ShotgunAbility { get; private set;}
    [HideInInspector] public JetpackAbility JetpackAbility { get; private set; }
    [HideInInspector] public ChargedHealingAbility HealingAbility { get; private set; }
    [HideInInspector] public TMNThrowable TMNThrowable { get; private set; }
    [HideInInspector] public GroundPoundAbility GroundPoundAbility { get; private set; }

    private const string m_HealingEffectTransform = "Healing Effect";
    private const string m_HealingEffectOverlayTransform = "Healing Effect Overlay";
    private const string m_HealingParticleEmitterTransform = "HealingParticleEmitter";

    override protected void Start()
    {
        base.Start();

        if (GameInput != null)
        {

            Character = CharacterTypes.Paige;

            JetpackAbility = new JetpackAbility(InputName.Movement);
            JetpackAbility.SetOwner(this);
            Abilities.Add(JetpackAbility);

            ShotgunAbility = new ShotgunAbility(this, InputName.Attack1, ShotgunBulletPrefab);
            ShotgunAbility.BaseDamage = ShotgunBaseDamage;
            ShotgunAbility.SetOwner(this);
            Abilities.Add(ShotgunAbility);

            TMNThrowable = new TMNThrowable(InputName.Ability1, SplatterPrefab);
            TMNThrowable.SetOwner(this);
            Abilities.Add(TMNThrowable);

            HealingAbility = new ChargedHealingAbility(InputName.Ability2);
            HealingParticle = transform.FindChild(m_HealingParticleEmitterTransform).GetComponent<ParticleSystem>();
            HealingAbility.SetOwner(this);
            HealingAbility.PlayerHealth = GetComponent<Health>();
            HealingAbility.HealingExponentialValue = HealingAbilityExponentialValue;
            HealingAbility.BaseHealthRecovery = HealingAbilityBaseHealthRecovery;
            HealingAbility.HealingEffectCanvasRenderer = HealingEffectRenderer;
            HealingAbility.HealingParticle = HealingParticle;
            Abilities.Add(HealingAbility);

            if (HealingParticle.isPlaying)
                HealingParticle.Stop();

            GroundPoundAbility = new GroundPoundAbility(InputName.Ability3);
            GroundPoundAbility.SetOwner(this);
            Abilities.Add(GroundPoundAbility);
        }
    }

    protected override void FixedUpdate()
    {
        base.FixedUpdate();

        if (HealingParticle != null)
        {
            // Always make the particle emitter face up
            HealingParticle.transform.rotation = Quaternion.LookRotation(Vector3.up, Vector3.forward);
        }
    }

    // TODO: Implement this (Get GlidingAbility, return if it's flying or not)
    public bool IsFlying { get { return false; } }

    public void TriggerOnStart(string aAbility)
    {
        switch (aAbility)
        {
            case "ShotgunAbility":
                ShotgunAbility.ActivateOnStartPointReached = true;
                break;
            case "JetpackAbility":
                JetpackAbility.ActivateOnStartPointReached = true;
                break;
            case "ChargedHealingAbility":
                HealingAbility.ActivateOnStartPointReached = true;
                break;
            case "TMNThrowableAbility":
                TMNThrowable.ActivateOnStartPointReached = true;
                break;
            case "GroundPoundAbility":
                GroundPoundAbility.ActivateOnStartPointReached = true;
                break;

            default:
                break;
        }
    }
}