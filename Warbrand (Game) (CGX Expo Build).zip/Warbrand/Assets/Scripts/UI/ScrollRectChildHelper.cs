﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ScrollRectChildHelper : MonoBehaviour
{
    public ScrollRect ScrollRect;
    public int ChildIndex;
}
