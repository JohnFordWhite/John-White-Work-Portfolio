﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Collections;

public class RecieveDamageIndicator : MonoBehaviour
{
    private class DamageIndicator
    {
        public DamageIndicator(Vector3 aPos, GameObject aIndicatorPrefab, GameObject aParent, GameObject aOriginOfDamage)
        {
            Position = aPos;
            TimeAlive = 0f;
            Object = GameObject.Instantiate(aIndicatorPrefab, aParent.transform) as GameObject;
            Object.SetActive(false);
            Object.transform.localPosition = Vector3.zero;
            Object.transform.localRotation = Quaternion.identity;
            Object.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
            OriginOfDamage = aOriginOfDamage;

            Image = Object.GetComponent<Image>();

            SetAlpha(0.0f);
        }
        public GameObject Object;
        public Vector3 Position;
        public float TimeAlive;
        public GameObject OriginOfDamage;

        public Image Image;

        public void SetAlpha(float aAlpha)
        {
            Color colour = Image.color;
            colour.a = aAlpha;
            Image.color = colour;
        }

        public void Reset(Vector3 aPos, GameObject aOriginOfDamage)
        {
            TimeAlive = 0.0f;

            Position = aPos;
            OriginOfDamage = aOriginOfDamage;

            Object.SetActive(true);

            SetAlpha(1.0f);
        }
    }

    public float TimeFullAlpha = 1f;
    public float TimeFading = 2f;
    
    [SerializeField] private GameObject IndicatorPrefab;
    private Player m_Player;
    private List<DamageIndicator> m_Indicators = new List<DamageIndicator>();

    private const int POOL_SIZE = 10;

    public void AddIndicator(GameObject aOrigin)
    {
        for(int i = 0; i < m_Indicators.Count; i++)
        {
            // Make sure there's no duplicates so that we don't spawn tonnes of images
            if(m_Indicators[i].OriginOfDamage == aOrigin)
            {
                DisableIndicator(m_Indicators[i]);
                
                continue;
            }
        }

        DamageIndicator indicator = GetFirstInactive();

        if (indicator != null)
        {
            indicator.Reset(aOrigin.transform.position, aOrigin);
        }
    }

    public void InitPool()
    {
        if (m_Indicators == null)
        {
            m_Indicators = new List<DamageIndicator>();
        }

        for (int i = 0; i < POOL_SIZE; i++)
        {
            DamageIndicator indicator = new DamageIndicator(Vector3.zero, IndicatorPrefab, gameObject, null);
            
            m_Indicators.Add(indicator);
        }
    }

    DamageIndicator GetFirstInactive()
    {
        for (int i = 0; i < m_Indicators.Count; i++)
        {
            if (m_Indicators[i].Object.activeInHierarchy == false)
                return m_Indicators[i];
        }

        return null;
    }

	void Start ()
    {
        m_Player = transform.parent.parent.GetComponent<GameInputComponent>().Input.Character;
	}
	
	void Update ()
    {
        if (m_Player == null)
            return;

        for (int i = 0; i < m_Indicators.Count; i++)
        {
            var indicator = m_Indicators[i];

            if (indicator.Object.activeSelf == false)
                continue;

            indicator.TimeAlive += Time.deltaTime;

            if (indicator.TimeAlive < TimeFullAlpha) { }
            else if (indicator.TimeAlive < TimeFullAlpha + TimeFading)
            {
                Color colour = indicator.Image.color;
                colour.a = (1f / TimeFading) * (indicator.TimeAlive - (TimeFullAlpha + TimeFading));
                indicator.Image.color = colour;
            }
            else
            {
                DisableIndicator(indicator);
                continue;
            }
            
            Vector3 rot = indicator.Object.transform.localEulerAngles;
            
            bool toLeft = MathUtils.IsPointToLeft(m_Player.gameObject, indicator.Position);
            bool isInFront = (Vector3.Dot(m_Player.transform.forward, (indicator.Position - m_Player.transform.position).normalized) > 0);

            float angle = (1 - Mathf.Abs(Vector3.Dot(m_Player.transform.forward, (indicator.Position - m_Player.transform.position).normalized))) * 90;

            if (toLeft && isInFront)
                rot.z = angle;
            else if (toLeft && !isInFront)
                rot.z = 180f - angle;
            else if (!isInFront)
                rot.z = 180f + angle;
            else
                rot.z = 360f - angle;

            indicator.Object.transform.localEulerAngles = rot;
        }
	}

    public void ClearAllIndicators()
    {
        for (int i = m_Indicators.Count - 1; i >= 0; i--)
        {
            DamageIndicator indicator = m_Indicators[i];

            DisableIndicator(indicator);
        }
    }

    void DisableIndicator(DamageIndicator aIndicator)
    {
        aIndicator.SetAlpha(0.0f);

        aIndicator.Object.SetActive(false);
    }
}
