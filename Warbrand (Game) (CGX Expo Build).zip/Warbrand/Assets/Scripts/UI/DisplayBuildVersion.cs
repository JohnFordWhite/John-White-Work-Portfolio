﻿using UnityEngine;
using System.Collections;

public class DisplayBuildVersion : MonoBehaviour
{
    public const string BuildVersion = "Pre-Alpha Build";

    private static readonly Rect GuiBox = new Rect(5.0f, 0.0f, 100.0f, 20.0f);

	void OnGUI ()
    {
        GUI.Label(GuiBox, BuildVersion);
    }
}
