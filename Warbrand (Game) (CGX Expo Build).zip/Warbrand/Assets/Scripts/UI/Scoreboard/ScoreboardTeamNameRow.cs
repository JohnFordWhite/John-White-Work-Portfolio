﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ScoreboardTeamNameRow : MonoBehaviour
{
    public Text TeamPositionText;
    public Text TeamNameText;
    public Text TeamScoreText;

	// Use this for initialization
	void Start ()
    {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
	
	}

    public void SetPosition(int aPosition)
    {
        TeamPositionText.text = aPosition.ToString();
    }
}
