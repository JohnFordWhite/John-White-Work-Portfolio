﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class ScoreboardPlayerRow : MonoBehaviour, IComparable<ScoreboardPlayerRow>
{
    public int PlayerID = -1;

    public CharacterTypes Character = (CharacterTypes)0;

    public Text PlayerPositionText;
    public Text PlayerNameText;
    public Text PlayerCharacterText;
    public Text PlayerKillsText;
    public Text PlayerDeathsText;
    public Text PlayerScoreText;
    public GameObject PlayerTimeAlivePanel;
    public Text PlayerTimeAliveText;

    public int PlayerKills = 0;
    public int PlayerDeaths = 0;
    public float PlayerScore = 0.0f;
    public float PlayerTimeAlive = 0.0f;

    public bool Disqualified = false;

    protected int m_Position = -1;

    public void IncrementKillCount(int aAmount = 1, bool aIncrementScore = false)
    {

        PlayerKills += aAmount;
        PlayerKillsText.text = PlayerKills.ToString();

        if (aIncrementScore)
            IncrementScoreCount(aAmount);
    }

    public void IncrementDeathCount(int aAmount = 1, bool aIncrementScore = false)
    {
        PlayerDeaths += aAmount;
        PlayerDeathsText.text = PlayerDeaths.ToString();

       if (aIncrementScore)
            IncrementScoreCount((float)aAmount * -1.0f);
    }

    public void IncrementScoreCount(float aAmount = 1.0f, bool aUpdateTimeString = true)
    {
        PlayerScore += aAmount;

        if (aUpdateTimeString)
            PlayerScoreText.text = ((int)PlayerScore).ToString();
    }

    public void IncrementTimeAlive(float aAmount = 1.0f, bool aIncrementScore = false, bool aUpdateTimeString = false)
    {
        PlayerTimeAlive += aAmount;

        if (aIncrementScore)
            IncrementScoreCount(aAmount, aUpdateTimeString);

        if (aUpdateTimeString == true)
        {
            PlayerTimeAliveText.text = Scoreboard.FormatTimer(PlayerTimeAlive);
        }
    }

    public int CompareTo(ScoreboardPlayerRow other)
    {
        int returnValue = 0;

        // Compare by score
        if (PlayerScore > other.PlayerScore)
            returnValue = -1;
        else if (PlayerScore < other.PlayerScore)
            returnValue = 1;
        else
        {
            // Compare by time alive (Stock uses this)
            if (PlayerTimeAlive > other.PlayerTimeAlive)
                returnValue = -1;
            else if (PlayerTimeAlive < other.PlayerTimeAlive)
                returnValue = 1;
            else
            {
                // Compare by kills
                if (PlayerKills > other.PlayerKills)
                    returnValue = -1;
                else if (PlayerKills < other.PlayerKills)
                    returnValue = 1;
                else
                {
                    // Compare by deaths
                    if (PlayerDeaths < other.PlayerDeaths)
                        returnValue = -1;
                    else if (PlayerDeaths > other.PlayerDeaths)
                        returnValue = 1;
                }
            }
        }

        return returnValue;
    }

    public void SetPosition(int aPosition)
    {
        m_Position = aPosition;
        PlayerPositionText.text = aPosition.ToString();
    }

    public int GetPosition()
    {
        return m_Position;
    }
}
