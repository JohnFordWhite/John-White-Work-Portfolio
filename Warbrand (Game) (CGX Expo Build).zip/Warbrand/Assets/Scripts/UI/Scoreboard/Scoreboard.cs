﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using System;

public class Scoreboard : MonoBehaviour
{
    public enum ScoringMetric
    {
        Points,
        Lives
    }
    public ScoringMetric ScoreboardScoringMetric = ScoringMetric.Points;

    public bool EditorForceVisible = false;
    
    public float TimeLimit
    {
        get
        {
            return m_TimeLimit;
        }
        set
        {
            m_TimeLimit = value;
            if (m_TimeLimit <= 0)
            {
                SetTimeRemainingPanelActive(false);
            }
            else
            {
                SetTimeRemainingPanelActive(true);
            }
        }
    }

    protected float m_TimeLimit;

    public float ScoreLimit;

    // Prefabs
    public GameObject TeamPanelPrefab;
    public GameObject PlayerPanelPrefab;

    // UI Components of ScoreboardCanvas
    public Canvas ScoreboardCanvas;
    public GameObject BackgroundPanel;
    public GameObject ScoreboardPanel;
    public GameObject HeaderPanel;
    public Text ScoreboardTitleText;
    public GameObject TableHeaderPanel;
    public GameObject TeamListPanel;
    public Text HeaderScoreText;
    public GameObject AliveTimePanel;

    public GameObject FooterPanel;
    public GameObject ElapsedTimePanel;
    public Text ElapsedTimeText;
    public GameObject RemainingTimePanel;
    public Text RemainingTimeText;
    public GameObject ScoreLimitPanel;
    public Text ScoreLimitText;

    protected GameModeManager m_GameModeManager;
    protected bool m_ShowList = false;
    protected bool m_JustPressed = false;

    protected float m_ElapsedTime = -1;

    public const string StringFormatTimeHHMMSS = "{0:D2}:{1:D2}:{2:D2}";
    public const string StringElapsedTime = "Elapsed Time: ";
    public const string StringRemainingTime = "Remaining Time: ";

    private const string StringLives = "Lives";
    private const string StringScore = "Score";

    public static readonly Color DisqualifiedColor = new Color(0.35f, 0.35f, 0.35f, 1.0f);

    // This should not be called every frame.
    public static string FormatTimer(float aTime)
    {
        if (aTime < 0.0f)
        {
            aTime = 0.0f;
        }

        TimeSpan time = TimeSpan.FromSeconds(aTime);
        string formattedTimeString = string.Format(Scoreboard.StringFormatTimeHHMMSS,
            time.Hours,
            time.Minutes,
            time.Seconds
        );

        return formattedTimeString;
    }

    public List<ScoreboardTeamPanel> TeamPanels { get { return m_TeamPanels; } }
    protected List<ScoreboardTeamPanel> m_TeamPanels;

	// Use this for initialization
	void Awake ()
    {
        m_GameModeManager = InputManager.CM.GameModeManager;

        m_TeamPanels = new List<ScoreboardTeamPanel>();

        transform.SetAsLastSibling();
    }

    public void ClearScoreboardEntries()
    {
        // Remove all previous teams/players from the scoreboard.
        while (TeamListPanel.transform.childCount > 0)
        {
            GameObject child = TeamListPanel.transform.GetChild(0).gameObject;
            child.transform.SetParent(null, false);
            Destroy(child);
        }

        m_TeamPanels.Clear();
    }

    public void BuildScoreboard()
    {
        if (m_GameModeManager == null)
        {
            m_GameModeManager = InputManager.CM.GameModeManager;
        }

        // Set scoreboard title name to the name of the current game mode.
        ScoreboardTitleText.text = m_GameModeManager.CurrentGameMode.GameModeName();

        if (ScoreboardScoringMetric == ScoringMetric.Lives)
        {
            HeaderScoreText.text = StringLives;
        }
        else if (ScoreboardScoringMetric == ScoringMetric.Points)
        {
            HeaderScoreText.text = StringScore;
        }

        // Determine the number of teams and create the team panels.
        List<int> teamsList = new List<int>();
        for (int i = 0; i < InputManager.CM.Players.Count; i++)
        {
            GameInputComponent playerInput = InputManager.CM.Players[i];

            // Prevents creating duplicate teams
            if (teamsList.Contains(playerInput.TeamIndex) == false && playerInput.TeamIndex >= 0)
            {
                teamsList.Add(playerInput.TeamIndex);

                // Create the team panel prefab and add it to the scoreboard.
                GameObject teamPanel = Instantiate(TeamPanelPrefab);
                teamPanel.transform.SetParent(TeamListPanel.transform, false);

                // Set the team panel's color to the team color
                Image teamPanelImage = teamPanel.GetComponent<Image>();
                Color teamPanelColor = teamPanelImage.color;
                teamPanelColor = BaseGameMode.TeamColors[playerInput.TeamIndex];
                teamPanelColor.a = 1.0f;
                teamPanelImage.color = teamPanelColor;

                // Set the team panel's team ID
                ScoreboardTeamPanel scoreboardTeamPanel = teamPanel.GetComponent<ScoreboardTeamPanel>();
                m_TeamPanels.Add(scoreboardTeamPanel);
                scoreboardTeamPanel.TeamID = playerInput.TeamIndex;

                scoreboardTeamPanel.TeamHeaderPanel.TeamNameText.text = BaseGameMode.TeamNames[playerInput.TeamIndex];

                // Disable the team header panel if FFA game mode.
                if (m_GameModeManager.TeamsEnabled == false)
                {
                    scoreboardTeamPanel.TeamHeaderPanel.gameObject.SetActive(false);
                }
            }
        }

        // Teams sorted by TeamID
        m_TeamPanels.Sort(
            delegate (ScoreboardTeamPanel team1, ScoreboardTeamPanel team2)
            {
                int returnValue = 0;
                if (team1.TeamID < team2.TeamID)
                    returnValue = -1;
                else if (team1.TeamID > team2.TeamID)
                    returnValue = 1;
                return returnValue;
            });

        // Loop over all players and add them to the appropriate team panels.
        for (int i = 0; i < InputManager.CM.Players.Count; i++)
        {
            GameInputComponent input = InputManager.CM.Players[i];
            string playerName = input.PlayerName;
            
            // Need to find the team panel with this player's team ID. Cannot lookup by index,
            // as teams might not be inserted in order of team ids
            // For instance, the team indexes added might be (0, 2, 5, 6).
            for (int j = 0; j < m_TeamPanels.Count; j++)
            {
                ScoreboardTeamPanel teamPanel = m_TeamPanels[j];
                if (teamPanel.TeamID == input.TeamIndex)
                {
                    teamPanel.AddPlayerRow(input.PlayerID, playerName, input.Character, PlayerPanelPrefab);
                    break;
                }
            }
        }

        SortScoreboard();

        m_ElapsedTime = -1;
    }

	// Update is called once per frame
	void Update ()
    {
        m_ShowList = false;

        // Show list if holding tab/back while playing the game
        if (InputManager.CM.CurrentGameState == GameState.PlayGame)
        {
            for (int i = 0; i < InputManager.CM.Players.Count; i++)
            {
                GameInputComponent input = InputManager.CM.Players[i];

                if (input.IsAI == false)
                {
                    // If just pressed, we also want to update the scoreboard.
                    if (input.Input.GetInput(InputName.Menu_Scoreboard, InputType.ButtonPressed) != 0.0f)
                    {
                        m_JustPressed = true;
                        m_ShowList = true;
                        break;
                    }

                    // If held, just show it.
                    if (input.Input.GetInput(InputName.Menu_Scoreboard, InputType.ButtonHeld) != 0.0f)
                    {
                        m_ShowList = true;
                        break;
                    }
                }
            }

            // At the end of the match (In game scene after the last point), show scoreboard.
            if (m_GameModeManager.CurrentGameMode.GameCondition == GameCondition.GameCompleted)
            {
                m_ShowList = true;
            }
        }

        if (EditorForceVisible == true)
        {
            m_ShowList = true;
        }

        // HACK:
        // For some reason no matter what I do, the Team's score text will not update while the scoreboard is not visible.
        // - The individual player stat texts do update properly though. Can't figure out what is different between
        //   the individual player score text and the team score text or why they behave differently.
        // The best I can do for now is to record when a player just pressed down the button, and in the first frame when it is visible,
        // refresh the scoreboard to update the score text. There may be a slight flicker from the old value to the new value in this frame
        // as a result - e.g. when the scoreboard first appears, there may be a brief instant where the team score shows up as 0 and then
        // in the next frame it will get it's correct value. If the frame rate is high though this may not be noticeable.
        // The reason why not to refresh the scoreboard every frame it is visible instead is because it is not a fast operation.
        if (m_ShowList == true && m_JustPressed == true && ScoreboardCanvas.gameObject.activeSelf == true)
        {
            RefreshScoreboard();
            m_JustPressed = false;
        }

        if (ScoreboardCanvas.gameObject.activeSelf != m_ShowList)
        {
            ScoreboardCanvas.gameObject.SetActive(m_ShowList);
        }
    }

    public void SortScoreboard()
    {
        m_TeamPanels.Sort(
            delegate (ScoreboardTeamPanel team1, ScoreboardTeamPanel team2)
            {
                int returnVal = team1.CompareTo(team2);
                if (returnVal == 0)
                {
                    if (team1.TeamID < team2.TeamID)
                        returnVal = -1;
                    else if (team1.TeamID > team2.TeamID)
                        returnVal = 1;
                }
                return returnVal;
            });

        // Reorder the transform sibling order
        for (int i = 0; i < m_TeamPanels.Count; i++)
        {
            m_TeamPanels[i].transform.SetSiblingIndex(i);

            // Update the Position of each team
            if (i <= 0)
            {
                m_TeamPanels[i].SetPosition(1);
            }
            else
            {
                if (m_TeamPanels[i].CompareTo(m_TeamPanels[i - 1]) == 0)
                {
                    m_TeamPanels[i].SetPosition(m_TeamPanels[i - 1].GetPosition());
                }
                else
                {
                    m_TeamPanels[i].SetPosition(i + 1);
                }
            }

            // If we are in FFA game mode, need to set the position of the first player row.
            if (m_GameModeManager.TeamsEnabled == false)
            {
                m_TeamPanels[i].PlayersInTeam[0].SetPosition(m_TeamPanels[i].GetPosition());
            }
        }
    }

    public void ShowTimeAliveColumn(bool aShowColumn = true)
    {
        AliveTimePanel.SetActive(aShowColumn);

        for (int i = 0; i < TeamPanels.Count; i++)
        {
            TeamPanels[i].TeamTimeAlivePanel.SetActive(aShowColumn);

            ScoreboardPlayerRow[] playerRows = TeamPanels[i].PlayersInTeam;
            for (int j = 0; j < playerRows.Length; j++)
            {
                playerRows[j].PlayerTimeAlivePanel.SetActive(aShowColumn);
            }
        }
    }

    public void RefreshScoreboard()
    {
        for (int i = 0; i < TeamPanels.Count; i++)
        {
            TeamPanels[i].UpdateTeamScoreboard();
        }
    }

    public void SetupLivesScoring()
    {
        HeaderScoreText.text = StringLives;
        AliveTimePanel.SetActive(true);
        ScoreboardScoringMetric = ScoringMetric.Lives;

        for (int i = 0; i < TeamPanels.Count; i++)
        {
            TeamPanels[i].TeamTimeAlivePanel.SetActive(true);

            ScoreboardPlayerRow[] playerRows = TeamPanels[i].PlayersInTeam;

            for (int j = 0; j < playerRows.Length; j++)
            {
                playerRows[j].PlayerTimeAlivePanel.SetActive(true);
                playerRows[j].PlayerScore = ScoreLimit;
                playerRows[j].PlayerScoreText.text = ((int)ScoreLimit).ToString();
            }

            TeamPanels[i].UpdateTeamScoreboard();
        }

        if (TeamPanels.Count == InputManager.CM.Players.Count)
        {
            ScoreLimitText.text = "Last Player Standing";
        }
        else
        {
            ScoreLimitText.text = "Last Team Standing";
        }

        SortScoreboard();
    }

    public void MarkPlayerAsDisqualified(Player aPlayer)
    {
        for (int i = 0; i < TeamPanels.Count; i++)
        {
            if (aPlayer.TeamIndex == TeamPanels[i].TeamID)
            {
                bool atLeastOnePlayerStillPlaying = false;

                ScoreboardPlayerRow[] playerRows = TeamPanels[i].PlayersInTeam;

                for (int j = 0; j < playerRows.Length; j++)
                {
                    if (aPlayer.PlayerID == playerRows[j].PlayerID)
                    {
                        playerRows[j].Disqualified = true;
                        playerRows[j].PlayerPositionText.color = DisqualifiedColor;
                        playerRows[j].PlayerNameText.color = DisqualifiedColor;
                        playerRows[j].PlayerCharacterText.color = DisqualifiedColor;
                        playerRows[j].PlayerKillsText.color = DisqualifiedColor;
                        playerRows[j].PlayerDeathsText.color = DisqualifiedColor;
                        playerRows[j].PlayerScoreText.color = DisqualifiedColor;
                        playerRows[j].PlayerTimeAliveText.color = DisqualifiedColor;
                        break;
                    }

                    if (playerRows[j].Disqualified == false)
                    {
                        atLeastOnePlayerStillPlaying = true;
                    }
                }

                // If all players on this team have been eliminated, mark the team as disqualified.
                if (atLeastOnePlayerStillPlaying == false)
                {
                    TeamPanels[i].TeamHeaderPanel.TeamPositionText.color = DisqualifiedColor;
                    TeamPanels[i].TeamHeaderPanel.TeamNameText.color = DisqualifiedColor;
                    TeamPanels[i].TeamHeaderPanel.TeamScoreText.color = DisqualifiedColor;
                    TeamPanels[i].TeamTimeAliveText.color = DisqualifiedColor;
                }

                break;
            }
        }
    }

    public void SetupFooterPanel(float aScoreLimit, float aTimeLimit)
    {
        ScoreLimit = aScoreLimit;
        TimeLimit = aTimeLimit;

        ScoreLimitText.text = "First to " + ScoreLimit.ToString() + " points";

        UpdateTimers(0);
    }

    public void UpdateTimers(float aElapsedTime)
    {
        // We don't want to update the timer text every frame
        // since string formatting and setting UI text are slow operations.
        if (aElapsedTime >= m_ElapsedTime + 1.0f)
        {
            m_ElapsedTime = aElapsedTime;

            ElapsedTimeText.text = StringElapsedTime + FormatTimer(aElapsedTime);
            RemainingTimeText.text = StringRemainingTime + FormatTimer(TimeLimit - Mathf.Floor(aElapsedTime));
        }
    }

    public void SetTimeRemainingPanelActive(bool aActive)
    {
        RemainingTimePanel.SetActive(aActive);
    }
}