﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine.UI;

public class ScoreboardTeamPanel : MonoBehaviour, IComparable<ScoreboardTeamPanel>
{
    public ScoreboardTeamNameRow TeamHeaderPanel;
    public GameObject TeamListPanel;
    public GameObject TeamTimeAlivePanel;
    public Text TeamTimeAliveText;

    public int TeamKillCount = 0;
    public int TeamDeathCount = 0;
    public float TeamScoreCount = 0;
    public float TeamTimeAlive = 0;

    public int TeamID = -1;

    protected int m_Position = -1;

    public ScoreboardPlayerRow[] PlayersInTeam
    {
        get
        {
            return TeamListPanel.transform.GetComponentsInChildren<ScoreboardPlayerRow>();
        }
    }

	// Use this for initialization
	void Start ()
    {
        TeamHeaderPanel.TeamScoreText.text = "0";
        TeamTimeAliveText.text = Scoreboard.FormatTimer(0);
	}
	
	// Update is called once per frame
	void Update ()
    {

    }

    public void AddPlayerRow(int aPlayerID, string aPlayerName, CharacterTypes aCharacter, GameObject aPlayerPanelPrefab)
    {
        GameModeManager game = InputManager.CM.GameModeManager;

        GameObject playerPanel = Instantiate(aPlayerPanelPrefab);
        playerPanel.transform.SetParent(TeamListPanel.transform, false);

        ScoreboardPlayerRow player = playerPanel.GetComponent<ScoreboardPlayerRow>();
        player.PlayerID = aPlayerID;
        player.PlayerPositionText.text = "1";
        player.PlayerNameText.text = aPlayerName;
        player.Character = aCharacter;
        player.PlayerCharacterText.text = aCharacter.ToString();
        player.PlayerKillsText.text = "0";
        player.PlayerDeathsText.text = "0";
        player.PlayerScoreText.text = "0";
        player.PlayerTimeAliveText.text = Scoreboard.FormatTimer(0);

        // If there is a team game, we can hide the individual player positions.
        if (game.TeamsEnabled == true)
        {
            player.PlayerPositionText.gameObject.SetActive(false);
        }
    }

    public void UpdateTeamScoreboard()
    {
        int kills = 0;
        int deaths = 0;
        float score = 0;
        float timeAlive = 0;

        ScoreboardPlayerRow[] players = PlayersInTeam;
        for (int i = 0; i < players.Length; i++)
        {
            kills += players[i].PlayerKills;
            deaths += players[i].PlayerDeaths;
            score += (int)players[i].PlayerScore;
            if (i == 0)
            {
                timeAlive = players[i].PlayerTimeAlive;
            }
        }

        TeamKillCount = kills;
        TeamDeathCount = deaths;
        TeamScoreCount = score;
        TeamTimeAlive = timeAlive;

        TeamHeaderPanel.TeamScoreText.text = ((int)TeamScoreCount).ToString();
        TeamTimeAliveText.text = Scoreboard.FormatTimer(timeAlive);

        GameModeManager game = InputManager.CM.GameModeManager;

        // In a team match, we want to sort the players within the team.
        if (game.TeamsEnabled == true)
        {
            SortPlayersInTeam();
        }
    }

    public int CompareTo(ScoreboardTeamPanel other)
    {
        int returnValue = 0;

        // Compare by score
        if (TeamScoreCount > other.TeamScoreCount)
            returnValue = -1;
        else if (TeamScoreCount < other.TeamScoreCount)
            returnValue = 1;
        else
        {
            // Compare by time alive (Stock uses this)
            if (TeamTimeAlive > other.TeamTimeAlive)
                returnValue = -1;
            else if (TeamTimeAlive < other.TeamTimeAlive)
                returnValue = 1;
            else
            {
                // Compare by kills
                if (TeamKillCount > other.TeamKillCount)
                    returnValue = -1;
                else if (TeamKillCount < other.TeamKillCount)
                    returnValue = 1;
                else
                {
                    // Compare by deaths
                    if (TeamDeathCount < other.TeamDeathCount)
                        returnValue = -1;
                    else if (TeamDeathCount > other.TeamDeathCount)
                        returnValue = 1;
                }
            }
        }

        return returnValue;
    }

    public void SetPosition(int aPosition)
    {
        m_Position = aPosition;
        TeamHeaderPanel.SetPosition(aPosition);
    }

    public int GetPosition()
    {
        return m_Position;
    }

    public void SortPlayersInTeam()
    {
        List<ScoreboardPlayerRow> players = new List<ScoreboardPlayerRow>(PlayersInTeam);

        players.Sort(
            delegate (ScoreboardPlayerRow player1, ScoreboardPlayerRow player2)
            {
                int returnVal = player1.CompareTo(player2);
                if (returnVal == 0)
                {
                    if (player1.PlayerID < player2.PlayerID)
                        returnVal = -1;
                    else if (player1.PlayerID > player2.PlayerID)
                        returnVal = 1;
                }
                return returnVal;
            });

        // Need to reset the transform child sibling order
        for (int i = 0; i < players.Count; i++)
        {
            players[i].transform.SetSiblingIndex(i);
        }
    }
}
