﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.EventSystems;

public class EditControlItemScript : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{

    //
    // Public
    //
    public EditControlScript ParentMenu;
    public Image BackgroundImage;

    public Sprite SelectedSprite;
    public Sprite UnselectedSprite;
    public Sprite ConfiguringSprite;

    //public Color SelectedColor = Color.white;
    //public Color UnselectedColor = Color.grey;
    //public Color ConfiguringColor = Color.green;
    public InputName ActionToMap;

    public GameObject TopConfigurationPanel;
    public Text ActionNameLabel;
    public Text ActionMappingLabel;
    public Button PositiveInputButton;
    public Button NegativeInputButton;
    public Toggle InvertAxisToggle;

    public GameObject BottomConfigurationPanel;
    public Text AxisDeadzoneText;
    public Slider AxisDeadzoneSlider;
    public Text SensitivityText;
    public Slider SensitivitySlider;

    public int ButtonIndex;

    //
    // Private
    //
    bool m_CursorOver;
    bool m_EditAxisDeadzoneExternally;
    bool m_EditSensitivityExternally;

	// Use this for initialization
	void Start ()
    {
        //BackgroundImage.color = UnselectedColor;
        BackgroundImage.sprite = UnselectedSprite;
        m_EditAxisDeadzoneExternally = false;
        m_EditSensitivityExternally = false;
	}
	
	// Update is called once per frame
	void Update ()
    {
        
	}

    public void Select(bool aSelected)
    {
        if (aSelected)
        {
            //BackgroundImage.color = SelectedColor;
            BackgroundImage.sprite = SelectedSprite;
        }
        else
        {
            //BackgroundImage.color = UnselectedColor;
            BackgroundImage.sprite = UnselectedSprite;
        }
    }

    public void Configure(bool configuring)
    {
        StartCoroutine(HandleConfigure(configuring));
    }

    IEnumerator HandleConfigure(bool configuring)
    {
        yield return null;

        if (configuring)
        {
            //BackgroundImage.color = ConfiguringColor;
            BackgroundImage.sprite = ConfiguringSprite;
        }
        else
        {
            //BackgroundImage.color = SelectedColor;
            BackgroundImage.sprite = SelectedSprite;
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        // If this is a gamepad player, ignore this.
        PlayerInput input = (PlayerInput)ParentMenu.PlayerObject.Input;
        if (input.Device == InputDevice.Keyboard)
        {
            m_CursorOver = true;
            Select(m_CursorOver);
            ParentMenu.SetSelectedIndex(ButtonIndex, false);
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        // If this is a gamepad player, ignore this.
        PlayerInput input = (PlayerInput)ParentMenu.PlayerObject.Input;
        if (input.Device == InputDevice.Keyboard)
        {
            m_CursorOver = false;
        }
    }

    public void SetNegativeButtonEnabled(bool aEnabled)
    {
        NegativeInputButton.enabled = aEnabled;
        NegativeInputButton.gameObject.SetActive(aEnabled);
    }

    public void SetAxisToggleEnabled(bool aEnabled)
    {
        InvertAxisToggle.enabled = aEnabled;
        InvertAxisToggle.gameObject.SetActive(aEnabled);
    }

    public void PositiveButtonClicked()
    {
        if (ParentMenu.IsConfiguring == false)
        {
            ParentMenu.StartConfiguring(ButtonIndex, ActionToMap, 1.0f);
        }
    }

    public void NegativeButtonClicked()
    {
        if (ParentMenu.IsConfiguring == false)
        {
            ParentMenu.StartConfiguring(ButtonIndex, ActionToMap, -1.0f);
        }
    }

    public void InvertAxisClicked(bool on)
    {
        if (ParentMenu.IsConfiguring == false)
        {
            ParentMenu.SetAxisInverted(ButtonIndex, ActionToMap, on);
        }
        else
        {
            // Just set it unchecked if there is no menu parent
            InvertAxisToggle.isOn = false;
        }
    }

    public void AxisDeadzoneSliderChanged()
    {
        if (m_EditAxisDeadzoneExternally == false)
        {
            UpdatePlayerAxisDeadzone(AxisDeadzoneSlider.value);
        }
        m_EditAxisDeadzoneExternally = false;
    }

    public void SetAxisDeadzone(float aDeadzone)
    {
        m_EditAxisDeadzoneExternally = true;
        AxisDeadzoneSlider.value = aDeadzone;
        
        UpdatePlayerAxisDeadzone(aDeadzone);
    }

    private void UpdatePlayerAxisDeadzone(float aDeadzone)
    {
        PlayerInput playerInput = (PlayerInput)ParentMenu.PlayerObject.Input;
        if (playerInput.CurrentConfiguration.InputMap[(int)ActionToMap] is AxisInputMapping)
        {
            // The deadzone passed in is between 0 and NumSliderTicks. Normalize it to a 0-1 value.
            float normalized = aDeadzone / (float)EditControlScript.NumSliderTicks;

            // Need to convert it to a value between DefaultControls MinDeadzone and MaxDeadzone and apply this value to the controller.
            float lerpedValue = Mathf.Lerp(DefaultControls.MIN_AXIS_DEADZONE, DefaultControls.MAX_AXIS_DEADZONE, normalized);

            ((AxisInputMapping)playerInput.CurrentConfiguration.InputMap[(int)ActionToMap]).AxisDeadZone = lerpedValue;
            ParentMenu.SliderChanged();
        }

        AxisDeadzoneText.text = "Axis Deadzone: " + aDeadzone.ToString();
    }

    public void SensitivitySliderChanged()
    {
        if (m_EditSensitivityExternally == false)
        {
            UpdatePlayerSensitivity(SensitivitySlider.value);
        }
        m_EditSensitivityExternally = false;
    }

    public void SetSensitivity(float aSensitivity)
    {
        m_EditSensitivityExternally = true;
        SensitivitySlider.value = aSensitivity;

        UpdatePlayerSensitivity(aSensitivity);
    }

    private void UpdatePlayerSensitivity(float aSensitivity)
    {
        // The deadzone passed in is between 0 and NumSliderTicks. Normalize it to a 0-1 value.
        float normalized = aSensitivity / (float)EditControlScript.NumSliderTicks;

        // Need to convert it to a value between DefaultControls MinSensitivity and MaxSensitivity and apply this value to the controller.
        float lerpedValue = Mathf.Lerp(DefaultControls.MIN_AXIS_SENSITIVITY, DefaultControls.MAX_AXIS_SENSITIVITY, normalized);

        PlayerInput playerInput = (PlayerInput)ParentMenu.PlayerObject.Input;
        playerInput.CurrentConfiguration.InputMap[(int)ActionToMap].SensitivityModifier = lerpedValue;

        SensitivityText.text = "Sensitivity: " + aSensitivity.ToString();

        ParentMenu.SliderChanged();
    }
}
