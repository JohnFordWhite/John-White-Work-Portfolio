﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class InputFieldScript : MonoBehaviour
{
    public Button NextNavigableInput;

    private InputField m_InputField;

    private float m_TimeBetweenNavigation;
    private float m_FocusTime;
    private bool m_IsFocused;

    public int PlayerIndex;

    private const string m_MenuVerticalInput = "Menu_Vertical";
    private const string m_MenuAltVerticalInput = "Menu_Alt_Vertical";

    // Use this for initialization
    void Start ()
    {
        m_TimeBetweenNavigation = 0.25f;
        m_FocusTime = 0.0f;
        m_IsFocused = false;
        m_InputField = GetComponent<InputField>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (m_InputField.isFocused == true && m_IsFocused == false)
        {
            m_IsFocused = true;
            m_FocusTime = Time.realtimeSinceStartup;
        }
        if (m_InputField.isFocused == false && m_IsFocused == true)
        {
            m_IsFocused = false;
        }

        // Prevents the user from getting stuck on this input field on controller, but prevent navigation on keyboard.
        GameInputComponent playerObject = InputManager.CM.Players[PlayerIndex];
        PlayerInput playerInput = (PlayerInput)playerObject.Input;

        if (playerInput.Device > InputDevice.Keyboard)
        {
            if (m_IsFocused && Time.realtimeSinceStartup - m_TimeBetweenNavigation >= m_FocusTime && NextNavigableInput != null)
            {
                if (Input.GetAxisRaw(m_MenuVerticalInput) != 0.0f || Input.GetAxisRaw(m_MenuAltVerticalInput) != 0.0f)
                {
                    StartCoroutine(SelectNextNavigableInput());
                }
            }
        }
	}

    IEnumerator SelectNextNavigableInput()
    {
        yield return null;

        if (NextNavigableInput != null)
        {
            NextNavigableInput.Select();
        }

        yield return null;
    }
}
