﻿using UnityEngine;
using System.Collections;

public class KillFeedService : MonoBehaviour
{
    public delegate void RegisterKillFeedItem(string aAttackerString, int aAttackerTeamIndex, string aDefenderString, int aDefenderTeamIndex);
    public event RegisterKillFeedItem OnRegisterKillFeedItem;

    private static KillFeedService s_Instance = null;
    private static object s_InstanceLock = new object();

    private GameModeManager m_GameModeManager = null;

    private const string m_KillFeedServiceTransform = "KillFeedService";

    public static KillFeedService Instance
    {
        get
        {
            if (s_Instance == null)
            {
                lock (s_InstanceLock)
                {
                    if (s_Instance == null)
                    {
                        GameObject KillFeedService = new GameObject(m_KillFeedServiceTransform);
                        KillFeedService.AddComponent<KillFeedService>();
                        DontDestroyOnLoad(KillFeedService);
                    }
                }
            }

            return s_Instance;
        }
    }

    void Awake()
    {
        if (s_Instance == null)
        {
            lock (s_InstanceLock)
            {
                if (s_Instance == null)
                {
                    s_Instance = this;

                    // set up control manager once in this function
                    InitKillFeedService();
                }
            }
        }
        else if (s_Instance != null)
        {
            Destroy(gameObject);
        }
    }

    void InitKillFeedService()
    {

    }

    public void RegisterKill(string aAttackerString, int aAttackerTeamIndex, string aDefenderString, int aDefenderTeamIndex)
    {
        if (m_GameModeManager == null)
            m_GameModeManager = InputManager.CM.GameModeManager;
        
        // Prevent extra kill feed items from showing up at the end of the game
        if (OnRegisterKillFeedItem != null && m_GameModeManager.CurrentGameMode.GameCondition != GameCondition.GameCompleted)
        {
            OnRegisterKillFeedItem(aAttackerString, aAttackerTeamIndex, aDefenderString, aDefenderTeamIndex);
        }
    }
}
