﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class KillFeedItem : MonoBehaviour
{
    public Text AttackerText;
    public Image KillFeedItemImage;
    public Text DefenderText;

    private const float MAX_TIME_ON_SCREEN = 5.0f;
    private const float FADE_OUT_TIME = 1.0f;
    private float m_ElapsedTime;

    private bool m_Active;

    private Image m_PanelImage;
    private Color m_OriginalPanelColor;

	// Use this for initialization
	void Awake ()
    {
        m_PanelImage = GetComponent<Image>();
        m_OriginalPanelColor = m_PanelImage.color;
        m_ElapsedTime = 0;
        m_Active = true;
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (m_Active == true)
        {
            m_ElapsedTime += Time.deltaTime;

            if (m_ElapsedTime > MAX_TIME_ON_SCREEN + FADE_OUT_TIME)
            {
                m_Active = false;
                gameObject.SetActive(false);
                //Destroy(gameObject);
                return;
            }

            if (m_ElapsedTime > MAX_TIME_ON_SCREEN)
            {
                // If the elapsed time is > MAX_TIME_ON_SCREEN, the UI elements should start to fade out.
                // Calculate the current alpha between the time of the end of the MAX_TIME_ON_SCREEN (1.0) and the FADE_OUT_TIME (0.0)
                Vector2 minAlpha = Vector2.zero;
                Vector2 maxAlpha = new Vector2(1.0f, 1.0f);

                float maxLerpTime = FADE_OUT_TIME;
                float currentLerpTime = m_ElapsedTime - MAX_TIME_ON_SCREEN;

                maxLerpTime = Mathf.Clamp01(maxLerpTime);
                currentLerpTime = Mathf.Clamp01(currentLerpTime);

                Vector2 lerpedAlpha = Vector2.Lerp(maxAlpha, minAlpha, currentLerpTime / maxLerpTime);

                // Sets the alpha values of the UI elements.

                // Panel (Parent)
                SetGraphicAlpha(m_PanelImage, lerpedAlpha.y * m_OriginalPanelColor.a);

                // Attacker text
                SetGraphicAlpha(AttackerText, lerpedAlpha.y);

                // Image
                SetGraphicAlpha(KillFeedItemImage, lerpedAlpha.y);

                // Defender text
                SetGraphicAlpha(DefenderText, lerpedAlpha.y);
            }
        }
	}

    // Set the alpha value of the Color of a Graphic element
    // i.e. a UnityEngine.UI.Text or an UnityEngine.UI.Image UI element.
    void SetGraphicAlpha(Graphic aGraphic, float aAlpha)
    {
        if (aGraphic != null)
        {
            Color aGraphicColor = aGraphic.color;
            aGraphicColor.a = aAlpha;
            aGraphic.color = aGraphicColor;
        }
    }

    public void ResetKillFeedItem(string aAttackerName, Color aAttackerColor, string aDefenderName, Color aDefenderColor)
    {
        m_ElapsedTime = 0;
        m_Active = true;

        if (m_PanelImage == null)
        {
            m_PanelImage = GetComponent<Image>();
        }

        if (m_OriginalPanelColor == null)
        {
            m_OriginalPanelColor = m_PanelImage.color;
        }

        SetGraphicAlpha(m_PanelImage, m_OriginalPanelColor.a);
        SetGraphicAlpha(KillFeedItemImage, 1);
        SetGraphicAlpha(AttackerText, 1);
        SetGraphicAlpha(DefenderText, 1);

        AttackerText.text = aAttackerName;
        AttackerText.color = aAttackerColor;

        DefenderText.text = aDefenderName;
        DefenderText.color = aDefenderColor;
    }
}
