﻿using UnityEngine;
using System.Collections;

public class KillFeedPanel : MonoBehaviour
{
    public GameObject KillFeedItemPrefab;

    bool m_IsRegistered = false;

    private ObjectPool m_PooledKillFeedItems = null;

	// Use this for initialization
	void Start ()
    {
        RegisterWithService();
	}

    public void RegisterWithService()
    {
        if (m_IsRegistered == false)
        {
            if (m_PooledKillFeedItems == null)
            {
                m_PooledKillFeedItems = new ObjectPool();
                m_PooledKillFeedItems.Initialize(10);
                m_PooledKillFeedItems.FillPoolWithPrefab(KillFeedItemPrefab, transform, false);
            }
            
            KillFeedService.Instance.OnRegisterKillFeedItem += OnRegisterKillFeedItem;
        }
    }

    public void UnregisterWithService()
    {
        if (m_IsRegistered == true)
        {
            KillFeedService.Instance.OnRegisterKillFeedItem -= OnRegisterKillFeedItem;
        }
    }

    void OnRegisterKillFeedItem(string aAttackerString, int aAttackerTeamIndex, string aDefenderString, int aDefenderTeamIndex)
    {
        // Get first available pooled object and set it up as the newest kill feed item.
        GameObject killFeedItemObject = m_PooledKillFeedItems.GetFirstInactiveObject();
        if (killFeedItemObject != null)
        {
            //killFeedItemObject.transform.SetParent(transform, true);
            killFeedItemObject.transform.SetAsLastSibling();
            killFeedItemObject.SetActive(true);

            Color attackerColor = BaseGameMode.TeamColors[aAttackerTeamIndex];
            attackerColor.a = 1.0f;
            Color defenderColor = BaseGameMode.TeamColors[aDefenderTeamIndex];
            defenderColor.a = 1.0f;

            KillFeedItem item = killFeedItemObject.GetComponent<KillFeedItem>();
            item.ResetKillFeedItem(aAttackerString, attackerColor, aDefenderString, defenderColor);
        }
    }

    // Make sure that this KillFeedPanel is not registered when this Player is destroyed.
    void OnDestroy()
    {
        UnregisterWithService();
    }
}
