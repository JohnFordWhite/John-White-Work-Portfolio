﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PersonalKillNotification : MonoBehaviour
{
    public Player Owner;
    public Text KilledByText;
    public Text RespawnTimerText;
    protected Player Killer;

    private const string StringKilledBy = "Killed by: ";
    private const string StringRespawnIn = "Respawn in: ";
    private const string StringOutOfLives = "Out of lives";
    private const string StringKilledSelf = "You killed yourself";


    private bool updatedText = false;

    private GameModeManager game;

	// Use this for initialization
	void Start ()
    {
        game = InputManager.CM.GameModeManager;
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Owner == null || Owner.IsAI)
        {
            gameObject.SetActive(false);
            return;
        }

        bool showKilledByText = false;
	    if (Owner.IsDead && game.PlayerRespawnTime >= 0.5f)
        {
            showKilledByText = true;
        }

        if (KilledByText.gameObject.activeInHierarchy != showKilledByText)
            KilledByText.gameObject.SetActive(showKilledByText);

        if (RespawnTimerText.gameObject.activeInHierarchy != showKilledByText)
            RespawnTimerText.gameObject.SetActive(showKilledByText);

        if (showKilledByText == true)
        {
            if (game.CurrentGameMode.IsPlayerDisqualified(Owner))
            {
                RespawnTimerText.text = StringOutOfLives;
            }
            else
            {
                // Update the time remaining before respawning
                int respawnTimeRemaining = (int)Mathf.Ceil((1.0f - ((Time.time - Owner.LastDeathTime) / game.PlayerRespawnTime)) * game.PlayerRespawnTime);

                RespawnTimerText.text = StringRespawnIn + respawnTimeRemaining;
            }
        }
    }

    public void SetKilledByPlayer(Player aPlayer)
    {
        // Show who last killed the player
        Killer = aPlayer;

        if (Killer != null)
        {
            if (Killer == Owner)
            {
                KilledByText.text = StringKilledSelf;
            }
            else
            {
                KilledByText.text = StringKilledBy + Killer.GameInput.LongPlayerName;
            }
        }
        else
        {
            KilledByText.text = string.Empty;
        }
    }
}
