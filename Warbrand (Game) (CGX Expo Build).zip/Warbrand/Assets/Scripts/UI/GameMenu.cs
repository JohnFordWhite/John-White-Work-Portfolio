﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;

public abstract class GameMenu : MonoBehaviour
{

    // Set this to false in a child menu to prevent this one from receiving inputs.
    // Remember to set it back to true when done!
    public bool EnableInputs = true;
    public GameMenu ParentMenu = null;
    public GameObject FirstSelectableMenuItem = null;
    protected GameObject m_LastSelectedGameObject = null;

    protected const string STRING_MENU_HORIZONTAL = "Menu_Horizontal";
    protected const string STRING_MENU_VERTICAL = "Menu_Vertical";
    protected const string STRING_DISABLED = "DISABLED";
    protected const string STRING_EVENT_SYSTEM = "EventSystem";

    // Remember whether or not this menu allows navigation.
    // This is needed for when a child menu closes and the parent menu has
    // different settings from the child menu.
    protected bool m_ThisMenuEnabledNavigation = false;

    public bool HasNavigationEnabled { get { return m_ThisMenuEnabledNavigation; } }

    public const float BUTTON_PRESS_DELAY = 0.25f;
    public static float s_SubmitButtonDelay = 0;
    public static float s_BackButtonDelay = 0;

    public static readonly KeyCode[] KeyboardSubmitButtons =
    {
        KeyCode.Return,
        KeyCode.Space
    };

    public static readonly KeyCode[] KeyboardCancelButtons =
    {
        KeyCode.Escape
    };

    public virtual bool IsSubmitButtonPressed()
    {
        if (s_SubmitButtonDelay <= 0.0f)
        {
            // Check Keyboard
            for (int i = 0; i < KeyboardSubmitButtons.Length; i++)
            {
                if (Input.GetKeyDown(KeyboardSubmitButtons[i]))
                {
                    s_SubmitButtonDelay = BUTTON_PRESS_DELAY;
                    return true;
                }
            }

            // Check Controllers
            for (int i = 0; i < InputManager.CM.JoystickStates.Length; i++)
            {
                if (InputManager.CM.JoystickStates[i].IsSubmitButtonPressed())
                {
                    s_SubmitButtonDelay = BUTTON_PRESS_DELAY;
                    return true;
                }
            }
        }

        return false;
    }

    public virtual bool IsCancelButtonPressed()
    {
        if (s_BackButtonDelay <= 0.0f)
        {
            // Check Keyboard
            for (int i = 0; i < KeyboardCancelButtons.Length; i++)
            {
                if (Input.GetKeyDown(KeyboardCancelButtons[i]))
                {
                    s_BackButtonDelay = BUTTON_PRESS_DELAY;
                    return true;
                }
            }

            // Check Controllers
            for (int i = 0; i < InputManager.CM.JoystickStates.Length; i++)
            {
                if (InputManager.CM.JoystickStates[i].IsCancelButtonPressed())
                {
                    s_BackButtonDelay = BUTTON_PRESS_DELAY;
                    return true;
                }
            }
        }
        return false;
    }

    public virtual void TryCurrentSelectableOnClick()
    {
        if (EventSystem.current.currentSelectedGameObject != null)
        {
            // Generic way to perform an onclick/submit on a button, dropdown, toggle, etc.
            Selectable selectable = EventSystem.current.currentSelectedGameObject.GetComponent<Selectable>();
            if (selectable != null)
            {
                s_SubmitButtonDelay = BUTTON_PRESS_DELAY;

                ExecuteEvents.Execute(selectable.gameObject, null, ExecuteEvents.submitHandler);

#if UNITY_EDITOR
                DebugManager.Log("Execute Selectable OnSubmit: " + selectable.gameObject, Developmer.Evan);
#endif
            }
        }
    }

    // Use this for initialization
    protected virtual void Start ()
    {
        // Need to check if the event system was created. If not, create one.
        // The EventSystem must be it's own GameObject and not a child of a menu,
        // in case the parent menu or other GameObjects must be disabled.
        // The new EventSystem will be persisted with DontDestroyOnLoad.
        if (EventSystem.current == null)
        {
            GameObject eventSystemObject = new GameObject(STRING_EVENT_SYSTEM);
            //tempEventSystem.transform.parent = this.transform;

            EventSystem eventSystem = eventSystemObject.AddComponent<EventSystem>();
            eventSystem.sendNavigationEvents = false;

            EventSystem.current = eventSystem;

            // EventSystem needs this.
            StandaloneInputModule inputModule = eventSystemObject.AddComponent<StandaloneInputModule>();

            // We want to handle button click events manually
            inputModule.submitButton = STRING_DISABLED;

            // By default allow navigation. If a child GameMenu does not need it
            // the navigation can be disabled with DisableNavigation().
            EnableNavigation();

            DontDestroyOnLoad(eventSystemObject);
        }

        //m_LastSelectedGameObject = FirstSelectableMenuItem;

        SelectFirstMenuItem();
    }
	
    public virtual void SelectFirstMenuItem()
    {
        EventSystem.current.firstSelectedGameObject = null;
        EventSystem.current.SetSelectedGameObject(null);

        if (FirstSelectableMenuItem != null)
        {
            StartCoroutine(HandleSelectFirstMenuItem());
        }
    }

    protected virtual IEnumerator HandleSelectFirstMenuItem()
    {
        // Wait one frame for scene/menu to be loaded
        yield return null;
        
        EventSystem.current.firstSelectedGameObject = FirstSelectableMenuItem;
        EventSystem.current.SetSelectedGameObject(FirstSelectableMenuItem);
    }

	// Update is called once per frame
    protected virtual void Update ()
    {
        if (EnableInputs && EventSystem.current != null)
        {
            if (EventSystem.current.currentSelectedGameObject != null)
            {
                m_LastSelectedGameObject = EventSystem.current.currentSelectedGameObject;
            }

            if (m_LastSelectedGameObject == null)
            {
                m_LastSelectedGameObject = FirstSelectableMenuItem;
            }

            if (EventSystem.current.currentSelectedGameObject == null)
            {
                EventSystem.current.SetSelectedGameObject(m_LastSelectedGameObject);
            }
        }
    }

    // Call this method when finished with the menu to unlock the parent menu's controls.
    // Destroys this menu GameObject. If the menu was created from a scene that was loaded
    // additively, call CloseMenu(string aParentSceneName) instead.
    // If you want to keep this game menu in memory, aDestroyThisMenu should be false.
    protected virtual void CloseMenu(bool aDestroyThisMenu = true)
    {
        if (ParentMenu != null)
        {
            ParentMenu.EnableInputs = true;

            ParentMenu.gameObject.SetActive(true);
            ParentMenu.enabled = true;
            
            ParentMenu.ChildMenuClosed();
        }

        //EventSystem.current.firstSelectedGameObject = null;
        //EventSystem.current.SetSelectedGameObject(null);

        //if (aDestroyThisMenu == true)
        //{
        //    Destroy(gameObject);
        //}
        //else
        //{
        //    this.gameObject.SetActive(false);
        //}
        StartCoroutine(HandleDisableChildMenu(aDestroyThisMenu));
    }

    IEnumerator HandleDisableChildMenu(bool aDestroyThisMenu = true)
    {
        yield return null;

        if (aDestroyThisMenu == true)
        {
            Destroy(gameObject);
        }
        else
        {
            this.gameObject.SetActive(false);
        }
    }

    // Call this method if the menu is inside of its own scene that was loaded additionally.
    protected virtual void CloseMenu(string aChildMenuSceneName)
    {
        CloseMenu(true);

        if (aChildMenuSceneName != null && aChildMenuSceneName != string.Empty)
        {
            StartCoroutine(HandleUnloadingScene(aChildMenuSceneName));
        }
    }

    IEnumerator HandleUnloadingScene(string aChildMenuSceneName)
    {
        yield return null;

        // With SceneManager.UnloadScene, it is recommended to call
        // Resources.UnloadUnusedAssets because the memory is not cleared by Unity.
        // It would be recommended to use SceneManager.UnloadSceneAsync, but that is
        // introduced in a later version of Unity (Unity 5.5) - Current version is 5.4.0f3.
        // https://docs.unity3d.com/ScriptReference/SceneManagement.SceneManager.UnloadScene.html
        SceneManager.UnloadScene(aChildMenuSceneName);
        Resources.UnloadUnusedAssets();
    }

    public virtual void VirtualKeyboardResponse(VirtualKeyboardValue aResponse)
    {

    }

    public void EnableNavigation()
    {
        m_LastSelectedGameObject = null;
        //EventSystem.current.SetSelectedGameObject(null);
        EventSystem.current.firstSelectedGameObject = FirstSelectableMenuItem;

        // Enable components
        m_ThisMenuEnabledNavigation = true;
        EventSystem.current.sendNavigationEvents = true;
        StandaloneInputModule inputModule = EventSystem.current.GetComponent<StandaloneInputModule>();
        inputModule.ActivateModule();
        inputModule.forceModuleActive = true;
        inputModule.horizontalAxis = STRING_MENU_HORIZONTAL;
        inputModule.verticalAxis = STRING_MENU_VERTICAL;

        // Forces Update to select the first menu item.
        //StartCoroutine(HandleForceSelectionOfFirstMenuItem());
    }

    public void ForceSelectionOfFirstMenuItem()
    {
        EventSystem.current.SetSelectedGameObject(null);
    }

    // Use this if the UI is navigable by means outside of using EventSystem.
    public void DisableNavigation()
    {
        m_ThisMenuEnabledNavigation = false;
        EventSystem.current.sendNavigationEvents = false;
        StandaloneInputModule inputModule = EventSystem.current.GetComponent<StandaloneInputModule>();
        inputModule.forceModuleActive = false;
        inputModule.DeactivateModule();
        inputModule.horizontalAxis = STRING_DISABLED;
        inputModule.horizontalAxis = STRING_DISABLED;
    }

    public void ChildMenuClosed()
    {
        if (m_ThisMenuEnabledNavigation == true)
        {
            EnableNavigation();
        }
        else
        {
            DisableNavigation();
        }

        SelectFirstMenuItem();
    }

    public virtual void OnEditControlsScriptComplete(int aPlayerIndex)
    {

    }
}
