﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class HealthUIScript : MonoBehaviour
{
    public Material HealthBarMaterialPrefab;

    public Player Owner;

    public Image HealthFill;
    public Text HealthText;

    private Health HealthScript;

    private const float HEALTH_LOWER_SPEED = 5f;
    private float m_CurrentHealth;

    private const string StringHealthPercent = "_HealthPercent";
    private const string StringSlash = " / ";

	void Start ()
    {
        HealthScript = Owner.Health;
        m_CurrentHealth = HealthScript.HealthPercentage;

        HealthFill.material = MonoBehaviour.Instantiate(HealthBarMaterialPrefab) as Material;
    }
	
	// Update is called once per frame
	void Update ()
    {
        m_CurrentHealth = Mathf.Lerp(m_CurrentHealth, HealthScript.HealthPercentage, Time.deltaTime * HEALTH_LOWER_SPEED);
        HealthFill.material.SetFloat(StringHealthPercent,  m_CurrentHealth);

        HealthText.text =(HealthScript.CurrentHealth - HealthScript.CurrentHealth % 1).ToString() + StringSlash + HealthScript.MaxHealth.ToString();
    }
}
