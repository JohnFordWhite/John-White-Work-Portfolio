﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        AbilityUICooldownsScript                                                       *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 29th, 2016                                                             *
 *                                                                                                 *
 * This script is meant to be placed on the game object that contains all UI elements that pertain *
 * to a specific ability that the player has. This script has it's information set by              *
 * AbilityUICooldownScript.cs. This script affects the appearance of the individual UI elements    *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 27th, 2016                                          *
\***************************************************************************************************/

using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class AbilityUIAppearanceScript : MonoBehaviour
{
    public AbilityUICooldownsScript.AbilityCooldownInfo AbilityInfo;

    Image m_UseCooldownCounter;
    Image m_ChargeCooldownCounter;
    Image m_InactiveOverlay;
    Image m_Slash;
    Text m_ChargesLeft;
    Text m_MaxCharges;

    private const string m_CooldownCounterTransform = "CooldownCounter";
    private const string m_AbilityIconCooldownCounterTransform = "AbilityIcon/CooldownCounter";
    private const string m_InactiveOverlayTransform = "InactiveOverlay";
    private const string m_AbilityIconInactiveOverlayTransform = "AbilityIcon/InactiveOverlay";
    private const string m_ChargesTransform = "Charges";
    private const string m_ChargeCooldownCounterTransform = "ChargeCooldownCounter";
    private const string m_SlashTransform = "Slash";
    private const string m_ChargesLeftTransform = "ChargesLeft";
    private const string m_MaxChargesTransform = "MaxCharges";

    void Start ()
    {
        //Ability -> Component
        Transform cooldownCounter = transform.FindChild(m_CooldownCounterTransform);
        if (cooldownCounter == null)
            cooldownCounter = transform.FindChild(m_AbilityIconCooldownCounterTransform);

        m_UseCooldownCounter = cooldownCounter.gameObject.GetComponent<Image>();

        Transform inactiveOverlay = transform.FindChild(m_InactiveOverlayTransform);
        if (inactiveOverlay == null)
            inactiveOverlay = transform.FindChild(m_AbilityIconInactiveOverlayTransform);

        m_InactiveOverlay = inactiveOverlay.gameObject.GetComponent<Image>();

        //Ability -> Charges -> Component
        m_ChargeCooldownCounter = transform.FindChild(m_ChargesTransform).FindChild(m_ChargeCooldownCounterTransform).gameObject.GetComponent<Image>();
        m_Slash = transform.FindChild(m_ChargesTransform).FindChild(m_SlashTransform).gameObject.GetComponent<Image>();
        m_ChargesLeft = transform.FindChild(m_ChargesTransform).FindChild(m_ChargesLeftTransform).gameObject.GetComponent<Text>();
        m_MaxCharges = transform.FindChild(m_ChargesTransform).FindChild(m_MaxChargesTransform).gameObject.GetComponent<Text>();
    }
	
	// Update is called once per frame
	void Update ()
    {
        m_UseCooldownCounter.fillAmount = AbilityInfo.UseCooldown;
        m_ChargeCooldownCounter.fillAmount = 1 - AbilityInfo.ChargeCooldown;
        m_InactiveOverlay.enabled = !AbilityInfo.Usable;
        m_ChargeCooldownCounter.enabled = AbilityInfo.HasCharges;
        m_ChargesLeft.enabled = AbilityInfo.HasCharges;
        m_MaxCharges.enabled = AbilityInfo.HasCharges;
        m_Slash.enabled = AbilityInfo.HasCharges;
        m_ChargesLeft.text = AbilityInfo.ChargesLeft.ToString();
        m_MaxCharges.text = AbilityInfo.MaxCharges.ToString();
        
	}
}
