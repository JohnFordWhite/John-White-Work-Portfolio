﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;

public class EditControlScript : GameMenu
{

    //
    // Public
    //

    public const int NumSliderTicks = 100;

    // Child GameObjects
    public Text ConfigureStatusText;
    public Transform OverlayPanel;
    public Transform ScrollView;
    public Text PlayerSlotText;
    public Text DeviceText;
    public Transform Viewport;
    public GameObject Content;
    public Button EditJoystickButton;
    public Button EditKeyboardButton;
    public Button ResetButton;
    public Button BackButton;
    public RectTransform ScrollViewContentSize;

    public List<int> ButtonsToIgnore;
    public List<EditControlItemScript> ScrollListItems;

    public const string ConfigureStatusDefault = "Select an input below to configure.";
    public const string ConfigureStatusConfiguring = "Press any button to configure input.";

    // ScrollView Item Prefab
    public GameObject EditControlItemPrefab;

    // Player to configure
    public int PlayerIndex;
    public GameInputComponent PlayerObject;

    public bool IsConfiguring = false;

    public float AxisDeadzoneScrollIncrement;
    public float SensitivityScrollIncrement;

    //
    // Private
    //
    private InputName m_InputToConfigure;
    private float m_Sign;
    private PlayerInput m_Input;
    private int m_CurrentEditingIndex;
    private float m_AxisSign;

    // Used for joystick navigation
    private int m_SelectedIndex;
    private bool m_RecolorSelected;

    private bool m_WasModified;

    private List<float> m_ChildrenHeights;
    private float m_ScrollRectContentHeight = 0;

    // Store the previous GameState so we know where to return
    private GameState m_PreviousGameState;

	// Use this for initialization
	protected override void Start ()
    {
        base.Start();

        DisableNavigation();

        m_PreviousGameState = InputManager.CM.CurrentGameState;
        InputManager.CM.CurrentGameState = GameState.ConfigureControls;

        ConfigureStatusText.text = ConfigureStatusDefault;

        if (ScrollListItems == null)
        {
            ScrollListItems = new List<EditControlItemScript>();
        }
    }

    public void PopulateScrollView()
    {
        StartCoroutine(HandlePopulateScrollView());
    }

    IEnumerator HandlePopulateScrollView()
    {
        ScrollListItems.Clear();
        int buttonIndex = 0;

        // Populate the Scroll View with all of the controls that can be re-mapped.
        ScrollListItems.Add(AddConfigurableControl("Move Horizontal", string.Empty, InputName.Horizontal, true, buttonIndex++));
        ScrollListItems.Add(AddConfigurableControl("Move Vertical", string.Empty, InputName.Vertical, true, buttonIndex++));
        ScrollListItems.Add(AddConfigurableControl("Look Horizontal", string.Empty, InputName.LookHorizontal, true, buttonIndex++));
        ScrollListItems.Add(AddConfigurableControl("Look Vertical", string.Empty, InputName.LookVertical, true, buttonIndex++));
        //ScrollListItems.Add(AddConfigurableControl("Taunt Horizontal", string.Empty, InputName.TauntHorizontal, true, buttonIndex++));
        //ScrollListItems.Add(AddConfigurableControl("Taunt Vertical", string.Empty, InputName.TauntVertical, true, buttonIndex++));
        ScrollListItems.Add(AddConfigurableControl("Attack 1", string.Empty, InputName.Attack1, false, buttonIndex++));
        ScrollListItems.Add(AddConfigurableControl("Attack 2", string.Empty, InputName.Attack2, false, buttonIndex++));
        ScrollListItems.Add(AddConfigurableControl("Jump", string.Empty, InputName.Jump, false, buttonIndex++));
        ScrollListItems.Add(AddConfigurableControl("Ability 1", string.Empty, InputName.Ability1, false, buttonIndex++));
        ScrollListItems.Add(AddConfigurableControl("Ability 2", string.Empty, InputName.Ability2, false, buttonIndex++));
        ScrollListItems.Add(AddConfigurableControl("Ability 3", string.Empty, InputName.Ability3, false, buttonIndex++));
        ScrollListItems.Add(AddConfigurableControl("Movement Ability", string.Empty, InputName.Movement, false, buttonIndex++));
        ScrollListItems.Add(AddConfigurableControl("Reload", string.Empty, InputName.Reload, false, buttonIndex++));
        //ScrollListItems.Add(AddConfigurableControl("Sprint",            string.Empty, InputName.Sprint,         false, buttonIndex++));
        //ScrollListItems.Add(AddConfigurableControl("Crouch", string.Empty, InputName.Crouch, false, buttonIndex++));

        // Wait for sizes to be calculated
        yield return null;

        if (m_ChildrenHeights == null)
        {
            m_ChildrenHeights = new List<float>();
        }
        m_ChildrenHeights.Clear();

        int childCount = Content.transform.childCount;
        for (int i = 0; i < childCount; i++)
        {
            Transform child = Content.transform.GetChild(i);

            RectTransform rectTransform = child.GetComponent<RectTransform>();
            if (rectTransform != null)
            {
                m_ChildrenHeights.Add(rectTransform.rect.height);
                m_ScrollRectContentHeight += rectTransform.rect.height;
            }
        }

        m_SelectedIndex = 0;
        SetSelectedIndex(m_SelectedIndex, false);
    }

    EditControlItemScript AddConfigurableControl(string aActionName, string aActionMapping, InputName aGameAction, bool aKeepNegativeButton, int aButtonIndex)
    {
        PlayerInput player = (PlayerInput)PlayerObject.Input;
        InputMapping input = player.CurrentConfiguration.InputMap[(int)aGameAction];

        GameObject TempControlItem = Instantiate(EditControlItemPrefab);

        EditControlItemScript ControlItem = TempControlItem.GetComponent<EditControlItemScript>();

        // Fix slider min and max values
        ControlItem.AxisDeadzoneSlider.minValue = 0;
        ControlItem.AxisDeadzoneSlider.maxValue = NumSliderTicks;

        ControlItem.SensitivitySlider.minValue = 0;
        ControlItem.SensitivitySlider.maxValue = NumSliderTicks;

        ControlItem.ActionNameLabel.text = aActionName;
        ControlItem.ActionMappingLabel.text = aActionMapping;
        ControlItem.ActionToMap = aGameAction;
        ControlItem.ParentMenu = this;
        ControlItem.ButtonIndex = aButtonIndex;

        if (aKeepNegativeButton == false)
        {
            ControlItem.SetNegativeButtonEnabled(false);
            ControlItem.SetAxisToggleEnabled(false);
        }

        if (Content != null)
        {
            // Set the Scroll View Content as the parent of this Item
            ControlItem.transform.SetParent(Content.transform, false);

            // By default it is positioned at the top, even stacked on top of other objects.
            // This forces it to the bottom of the list of any children that are already in the list.
            ControlItem.GetComponent<RectTransform>().SetAsLastSibling();
        }

        // Determine whether or not we want to display the bottom configuration panel.
        bool showBottomPanel = false;

        // This mapped control allows sensitivity change
        if (input.CanChangeSensitivity == true)
        {
            showBottomPanel = true;

            float sensitivity = ((AxisInputMapping)(input)).SensitivityModifier;

            // deadzone is a value between DefaultControls MinSensitivity and MaxSensitivity.
            // Need to convert it to a value between 0 and NumSliderTicks.

            float normalized = (sensitivity - DefaultControls.MIN_AXIS_SENSITIVITY) / (DefaultControls.MAX_AXIS_SENSITIVITY - DefaultControls.MIN_AXIS_SENSITIVITY);

            float lerpedValue = Mathf.Lerp(0, NumSliderTicks, normalized);

            ControlItem.SensitivitySlider.value = lerpedValue;
            ControlItem.SensitivityText.text = "Sensitivity: " + ((int)lerpedValue).ToString();
        }
        else
        {
            ControlItem.SensitivitySlider.gameObject.SetActive(false);
            ControlItem.SensitivityText.gameObject.SetActive(false);
        }

        // This mapped control is an axis
        if (input is AxisInputMapping)
        {
            showBottomPanel = true;

            float deadzone = ((AxisInputMapping)(input)).AxisDeadZone;

            // deadzone is a value between DefaultControls MinDeadzone and MaxDeadzone.
            // Need to convert it to a value between 0 and NumSliderTicks.

            float normalized = (deadzone - DefaultControls.MIN_AXIS_DEADZONE) / (DefaultControls.MAX_AXIS_DEADZONE - DefaultControls.MIN_AXIS_DEADZONE);

            float lerpedValue = Mathf.Lerp(0, NumSliderTicks, normalized);

            ControlItem.AxisDeadzoneSlider.value = lerpedValue;
            ControlItem.AxisDeadzoneText.text = "Axis Deadzone: " + ((int)lerpedValue).ToString();
        }
        else
        {
            ControlItem.AxisDeadzoneSlider.gameObject.SetActive(false);
            ControlItem.AxisDeadzoneText.gameObject.SetActive(false);
        }

        // Hide the bottom panel if none of the controls are active for it.
        if (showBottomPanel == false)
        {
            ControlItem.BottomConfigurationPanel.SetActive(false);
        }

        return ControlItem;
    }


	// Update is called once per frame
	protected override void Update ()
    {
        if (EnableInputs == true)
        {
            if (IsConfiguring == true)
            {
                if (Input.GetKeyDown(KeyCode.Escape) || m_Input.GetInput(InputName.Menu_Back, InputType.ButtonPressed) != 0.0f)
                {
                    ScrollListItems[m_SelectedIndex].Configure(false);

                    ConfigureStatusText.text = ConfigureStatusDefault;

                    IsConfiguring = false;
                    return;
                }

                if (PlayerObject != null)
                {
                    PlayerInput input = PlayerObject.Input as PlayerInput;

                    if (input.MapNewInputJoystick(m_InputToConfigure, ButtonsToIgnore, m_AxisSign))
                    {
                        IsConfiguring = false;

                        ConfigureStatusText.text = ConfigureStatusDefault;

                        EditControlItemScript ScrollListItem = ScrollListItems[m_CurrentEditingIndex];
                        ScrollListItem.ActionMappingLabel.text = input.GetInputString(m_InputToConfigure);
                        ScrollListItem.Configure(false);

                        // Save the configuration
                        input.InputConfigurations[InputDeviceType.Joystick.ToString()] = input.CurrentConfiguration;

                        m_WasModified = true;
                    }
                }
            }
            else
            {
                if ((m_Input != null && m_Input.GetInput(InputName.Menu_Cancel, InputType.ButtonPressed) != 0.0f) || Input.GetKeyDown(KeyCode.Escape))
                {
                    Return();
                }

                // Scroll up/down using buttons
                float verticalAxis = -m_Input.GetInput(InputName.Menu_Vertical, InputType.ButtonPressed, true) + -m_Input.GetInput(InputName.Menu_Alt_Vertical, InputType.ButtonPressed, true);
                if (verticalAxis != 0.0f || m_RecolorSelected)
                {
                    SetSelectedIndex(m_SelectedIndex + (int)verticalAxis, true);
                }

                // Activate PositiveAxisButton
                if (m_Input.GetInput(InputName.Menu_Pause, InputType.ButtonPressed) != 0.0f)
                {
                    StartConfiguring(m_SelectedIndex, ScrollListItems[m_SelectedIndex].ActionToMap, 1.0f);
                }

                // Activate NegativeAxisButton
                if (m_Input.GetInput(InputName.Menu_Back, InputType.ButtonPressed) != 0.0f)
                {
                    StartConfiguring(m_SelectedIndex, ScrollListItems[m_SelectedIndex].ActionToMap, -1.0f);
                }

                // Activate AxisInvertedToggle
                if (m_Input.GetInput(InputName.Menu_Configure, InputType.ButtonPressed) != 0.0f)
                {
                    SetAxisInverted(m_SelectedIndex, ScrollListItems[m_SelectedIndex].ActionToMap, !ScrollListItems[m_SelectedIndex].InvertAxisToggle.isOn);
                }

                // Increase/Decrease Axis Deadzone
                {
                    float scrollValue = m_Input.GetInput(InputName.Menu_Scroll1, InputType.ButtonHeld, true);

                    SetAxisDeadzone(m_SelectedIndex, ScrollListItems[m_SelectedIndex].ActionToMap, scrollValue);
                }

                // Increase/Decrease Sensitivity
                {
                    float positiveAxis = m_Input.GetInput(InputName.Menu_Scroll2, InputType.ButtonHeld, true);
                    float negativeAxis = m_Input.GetInput(InputName.Menu_Scroll3, InputType.ButtonHeld, true);

                    float scrollValue = (positiveAxis - negativeAxis);

                    SetSensitivity(m_SelectedIndex, ScrollListItems[m_SelectedIndex].ActionToMap, scrollValue);
                }

                // Reset Controls
                if (m_Input.GetInput(InputName.Menu_Reset, InputType.ButtonPressed) != 0.0f)
                {
                    ResetPlayerControls();
                }
            }
        }
	}

    void OnGUI()
    {
        if (EnableInputs == true)
        {
            // Used for Keyboard configuration
            if (IsConfiguring == true)
            {
                if (PlayerObject != null)
                {
                    PlayerInput input = PlayerObject.Input as PlayerInput;

                    if (input.MapNewInputKeyboard(m_InputToConfigure, ButtonsToIgnore, m_AxisSign))
                    {
                        IsConfiguring = false;

                        ConfigureStatusText.text = ConfigureStatusDefault;

                        EditControlItemScript ScrollListItem = ScrollListItems[m_CurrentEditingIndex];
                        ScrollListItem.ActionMappingLabel.text = input.GetInputString(m_InputToConfigure);

                        // Save the configuration
                        input.InputConfigurations[InputDeviceType.Keyboard.ToString()] = input.CurrentConfiguration;

                        m_WasModified = true;
                    }
                }
            }
        }
    }

    public void ResetPlayerControls()
    {
        if (EnableInputs == true)
        {
            if (IsConfiguring == false)
            {
                if (m_Input != null)
                {
                    if (m_Input.Device == InputDevice.Keyboard)
                    {
                        DefaultControls.SetDefaultKeyboardControls(m_Input);
                    }
                    else if (m_Input.Device > InputDevice.Keyboard)
                    {
                        DefaultControls.SetDefaultJoystickControls(m_Input);
                    }

                    // Need to loop through all of the ScrollListItems and set the ActionMapping text.
                    for (int i = 0; i < ScrollListItems.Count; i++)
                    {
                        EditControlItemScript controlItem = ScrollListItems[i];

                        controlItem.ActionMappingLabel.text = m_Input.GetInputString(controlItem.ActionToMap);
                    }
                }
            }
        }
    }

    public void SetupPlayerObject(int aPlayerIndex, GameInputComponent aPlayer)
    {
        m_WasModified = false;

        ConfigureStatusText.text = ConfigureStatusDefault;

        PlayerIndex = aPlayerIndex;

        PlayerObject = aPlayer;
        m_Input = PlayerObject.Input as PlayerInput;

        //PlayerSlotText.text = "Player " + (aPlayerIndex + 1);
        if (aPlayer.PlayerName != null && aPlayer.PlayerName != string.Empty)
        {
            PlayerSlotText.text = "Player: " + aPlayer.PlayerName;
        }
        else
        {
            PlayerSlotText.text = "Player " + (aPlayerIndex + 1);
        }

        DeviceText.text = m_Input.Device.ToString();

        ResetScrollView();
    }

    public void ResetScrollView()
    {
        if (ScrollListItems.Count <= 0)
        {
            PopulateScrollView();
        }
        
        for (int i = 0; i < ScrollListItems.Count; i++)
        {
            EditControlItemScript ScrollListItem = ScrollListItems[i];

            if (m_Input != null)
            {
                // Set current button/axis mapped to the action.
                ScrollListItem.ActionMappingLabel.text = m_Input.GetInputString(ScrollListItem.ActionToMap);

                // Set toggle on or off depending on if axis is inverted.
                ScrollListItem.InvertAxisToggle.isOn = m_Input.GetAxisInverted(ScrollListItem.ActionToMap);
            }
            else
            {
                ScrollListItem.ActionMappingLabel.text = "UNASSIGNED";
            }
        }

        m_RecolorSelected = true;
    }

    public void StartConfiguring(int aButtonIndex, InputName aInputToConfigure, float aSign = 1.0f)
    {
        if (EnableInputs == true)
        {
            IsConfiguring = true;
            ConfigureStatusText.text = ConfigureStatusConfiguring;
            m_InputToConfigure = aInputToConfigure;
            m_CurrentEditingIndex = aButtonIndex;
            m_AxisSign = aSign;

            if (ButtonsToIgnore == null)
            {
                ButtonsToIgnore = new List<int>();
            }
            ButtonsToIgnore.Clear();

            if (m_Input != null)
            {
                // Setup Keyboard ignores
                if (m_Input.Device == InputDevice.Keyboard)
                {
                    // Add buttons that should not be overwritten
                    ButtonsToIgnore.Add((int)KeyCode.Escape);
                    ButtonsToIgnore.Add((int)KeyCode.Tab);
                    ButtonsToIgnore.Add((int)KeyCode.Return);
                }
                // Setup Joystick ignores
                else if (m_Input.Device > InputDevice.Keyboard)
                {
                    ButtonsToIgnore.Add(JoystickMap.BUTTON_START);
                    ButtonsToIgnore.Add(JoystickMap.BUTTON_BACK);
                }

                ScrollListItems[m_SelectedIndex].Configure(true);
            }
        }
    }

    public void SetAxisInverted(int aButtonIndex, InputName aInputToConfigure, bool aIsInverted)
    {
        if (EnableInputs == true)
        {
            EditControlItemScript controlItem = ScrollListItems[aButtonIndex];
            Toggle toggle = controlItem.InvertAxisToggle;

            if (m_Input != null)
            {
                m_Input.SetAxisInverted(aInputToConfigure, aIsInverted);

                // Need to set toggled to false in case toggling the InputMapping failed.
                toggle.isOn = m_Input.GetAxisInverted(aInputToConfigure);

                m_WasModified = true;
            }
            else
            {
                // Set back to off - in this case, the InputMap in the Player probably does not have that axis mapped.
                toggle.isOn = false;
            }
        }
    }

    public void SetAxisDeadzone(int aButtonIndex, InputName aInputToConfigure, float aScrollValue)
    {
        if (EnableInputs == true)
        {
            if (aScrollValue != 0.0f)
            {
                EditControlItemScript controlItem = ScrollListItems[aButtonIndex];
                float axisDeadzone = controlItem.AxisDeadzoneSlider.value;
                float valueIncrement = AxisDeadzoneScrollIncrement * aScrollValue;

                axisDeadzone = axisDeadzone + valueIncrement;
                if (axisDeadzone < controlItem.AxisDeadzoneSlider.minValue)
                    axisDeadzone = controlItem.AxisDeadzoneSlider.minValue;
                if (axisDeadzone > controlItem.AxisDeadzoneSlider.maxValue)
                    axisDeadzone = controlItem.AxisDeadzoneSlider.maxValue;

                controlItem.SetAxisDeadzone(axisDeadzone);
            }
        }
    }

    public void SetSensitivity(int aButtonIndex, InputName aInputToConfigure, float aScrollValue)
    {
        if (EnableInputs == true)
        {
            if (aScrollValue != 0.0f)
            {
                EditControlItemScript controlItem = ScrollListItems[aButtonIndex];
                float sensitivity = controlItem.SensitivitySlider.value;
                float valueIncrement = SensitivityScrollIncrement * aScrollValue;

                sensitivity = sensitivity + valueIncrement;
                if (sensitivity < controlItem.SensitivitySlider.minValue)
                    sensitivity = controlItem.SensitivitySlider.minValue;
                if (sensitivity > controlItem.SensitivitySlider.maxValue)
                    sensitivity = controlItem.SensitivitySlider.maxValue;

                controlItem.SetSensitivity(sensitivity);
            }
        }
    }

    public void Return()
    {
        if (EnableInputs == true && IsConfiguring == false)
        {
            EnableInputs = false;

            StartCoroutine(HandleReturn());
        }
    }

    IEnumerator HandleReturn()
    {
        // Wait one frame before returning
        yield return null;

        InputManager.CM.CurrentGameState = m_PreviousGameState;

        // Save the current configuration back into the player profile configurations
        // - only need to save if a change was made to the configuration.
        if (m_WasModified)
        {
            if (m_Input.Device == InputDevice.Keyboard)
            {
                m_Input.InputConfigurations[InputDeviceType.Keyboard.ToString()] = m_Input.CurrentConfiguration;
            }
            else if (m_Input.Device > InputDevice.Keyboard)
            {
                m_Input.InputConfigurations[InputDeviceType.Joystick.ToString()] = m_Input.CurrentConfiguration;
            }

            InputManager.CM.PlayerProfileManager.SaveProfiles();
        }

        if (ParentMenu != null)
        {
            ParentMenu.OnEditControlsScriptComplete(PlayerIndex);
        }

        CloseMenu();
    }

    public void SetSelectedIndex(int aSelectedIndex, bool aScrollViewport)
    {
        if (EnableInputs == true)
        {
            //float direction = Mathf.Sign(aSelectedIndex - m_SelectedIndex);

            // Unselect any previously selected element
            EditControlItemScript oldItem = ScrollListItems[m_SelectedIndex];
            oldItem.Select(false);

            // Clamp new index to list size
            if (aSelectedIndex > ScrollListItems.Count - 1)
            {
                aSelectedIndex = ScrollListItems.Count - 1;
            }
            if (aSelectedIndex < 0)
            {
                aSelectedIndex = 0;
            }

            // Select new item
            m_SelectedIndex = aSelectedIndex;

            EditControlItemScript newItem = ScrollListItems[m_SelectedIndex];
            newItem.Select(true);
            m_RecolorSelected = false;

            if (aScrollViewport == true)
            {
                // Need to make sure the scroll view updates to keep the new selection in view.
                ScrollRect scroll = ScrollView.GetComponent<ScrollRect>();

                if (m_ChildrenHeights != null)
                {
                    InterfaceUtils.SetScrollViewViewportHeightPosition(scroll, Content, m_SelectedIndex, Content.transform.childCount, m_ChildrenHeights);
                }
                else
                {
                    InterfaceUtils.SetScrollViewViewportHeightPosition(scroll, Content, m_SelectedIndex, Content.transform.childCount);
                }
            }
        }
    }

    public void SliderChanged()
    {
        if (EnableInputs == true)
        {
            m_WasModified = true;
        }
    }
}
