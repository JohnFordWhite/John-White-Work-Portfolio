﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        AbilityUICooldownsScript                                                       *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 29th, 2016                                                             *
 *                                                                                                 *
 * This script is meant to be placed on the game object that contains all elements of the player's *
 * UI that pertain to their abilities. This script is to make it easier for the ability UI data    *
 * to be set by the player, as well as be accessed by AbilityUIAppearanceScript.cs                 *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 27th, 2016                                          *
\***************************************************************************************************/

using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class AbilityUICooldownsScript : MonoBehaviour
{
    public struct AbilityCooldownInfo
    {
        public float UseCooldown;
        public bool Usable;
        public bool HasCharges;
        public int ChargesLeft;
        public int MaxCharges;
        public float ChargeCooldown;
    }

    public AbilityCooldownInfo MovementAbilityInfo;
    public AbilityCooldownInfo Ability1Info;
    public AbilityCooldownInfo Ability2Info;
    public AbilityCooldownInfo Ability3Info;

    AbilityUIAppearanceScript m_MovementAbility;
    AbilityUIAppearanceScript m_Ability1;
    AbilityUIAppearanceScript m_Ability2;
    AbilityUIAppearanceScript m_Ability3;

    // Use this for initialization
    void Start ()
    {
        m_MovementAbility = transform.FindChild("MovementAbility").GetComponentInChildren<AbilityUIAppearanceScript>();
        m_Ability1 = transform.FindChild("Ability1").GetComponentInChildren<AbilityUIAppearanceScript>();
        m_Ability2 = transform.FindChild("Ability2").GetComponentInChildren<AbilityUIAppearanceScript>();
        m_Ability3 = transform.FindChild("Ability3").GetComponentInChildren<AbilityUIAppearanceScript>();
    }
	
	// Update is called once per frame
	void Update ()
    {
        m_MovementAbility.AbilityInfo.UseCooldown = MovementAbilityInfo.UseCooldown;
        m_Ability1.AbilityInfo.UseCooldown = Ability1Info.UseCooldown;
        m_Ability2.AbilityInfo.UseCooldown = Ability2Info.UseCooldown;
        m_Ability3.AbilityInfo.UseCooldown = Ability3Info.UseCooldown;

        m_MovementAbility.AbilityInfo.Usable = MovementAbilityInfo.Usable;
        m_Ability1.AbilityInfo.Usable = Ability1Info.Usable;
        m_Ability2.AbilityInfo.Usable = Ability2Info.Usable;
        m_Ability3.AbilityInfo.Usable = Ability3Info.Usable;

        m_MovementAbility.AbilityInfo.HasCharges = MovementAbilityInfo.HasCharges;
        m_Ability1.AbilityInfo.HasCharges = Ability1Info.HasCharges;
        m_Ability2.AbilityInfo.HasCharges = Ability2Info.HasCharges;
        m_Ability3.AbilityInfo.HasCharges = Ability3Info.HasCharges;

        m_MovementAbility.AbilityInfo.ChargesLeft = MovementAbilityInfo.ChargesLeft;
        m_Ability1.AbilityInfo.ChargesLeft = Ability1Info.ChargesLeft;
        m_Ability2.AbilityInfo.ChargesLeft = Ability2Info.ChargesLeft;
        m_Ability3.AbilityInfo.ChargesLeft = Ability3Info.ChargesLeft;

        m_MovementAbility.AbilityInfo.MaxCharges = MovementAbilityInfo.MaxCharges;
        m_Ability1.AbilityInfo.MaxCharges = Ability1Info.MaxCharges;
        m_Ability2.AbilityInfo.MaxCharges = Ability2Info.MaxCharges;
        m_Ability3.AbilityInfo.MaxCharges = Ability3Info.MaxCharges;

        m_MovementAbility.AbilityInfo.ChargeCooldown = MovementAbilityInfo.ChargeCooldown;
        m_Ability1.AbilityInfo.ChargeCooldown = Ability1Info.ChargeCooldown;
        m_Ability2.AbilityInfo.ChargeCooldown = Ability2Info.ChargeCooldown;
        m_Ability3.AbilityInfo.ChargeCooldown = Ability3Info.ChargeCooldown;
    }
}
