﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HudButtonIconHelper : MonoBehaviour
{
    // Static sprite instances for all users of this class.
    // This region contains the resource file path of all button/key sprite images.
    // When adding or removing a sprite, remember to add the corresponding button getter and load call inside LoadSprites.
    #region Sprite file paths, loading sprites, sprite-getters

    private const string Key_Sprite_Path = "Art/Sprites/HUD Button Icons/Key";
    private const string Button_A_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_A";
    private const string Button_B_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_B";
    private const string Button_X_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_X";
    private const string Button_Y_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_Y";
    private const string Button_LB_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_LB";
    private const string Button_RB_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_RB";
    private const string Button_LT_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_LT";
    private const string Button_RT_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_RT";
    private const string Button_LS_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_LS";
    private const string Button_RS_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_RS";
    private const string Button_Start_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_Start";
    private const string Button_Back_Sprite_Path = "Art/Sprites/HUD Button Icons/Button_Back";

    private static bool s_SpritesLoaded = false;

    private static void LoadSprites()
    {
        if (s_SpritesLoaded == false)
        {
            s_Sprite_Key = Resources.Load<Sprite>(Key_Sprite_Path);
            s_Sprite_Button_A = Resources.Load<Sprite>(Button_A_Sprite_Path);
            s_Sprite_Button_B = Resources.Load<Sprite>(Button_B_Sprite_Path);
            s_Sprite_Button_X = Resources.Load<Sprite>(Button_X_Sprite_Path);
            s_Sprite_Button_Y = Resources.Load<Sprite>(Button_Y_Sprite_Path);
            s_Sprite_Button_LB = Resources.Load<Sprite>(Button_LB_Sprite_Path);
            s_Sprite_Button_RB = Resources.Load<Sprite>(Button_RB_Sprite_Path);
            s_Sprite_Button_LT = Resources.Load<Sprite>(Button_LT_Sprite_Path);
            s_Sprite_Button_RT = Resources.Load<Sprite>(Button_RT_Sprite_Path);
            s_Sprite_Button_LS = Resources.Load<Sprite>(Button_LS_Sprite_Path);
            s_Sprite_Button_RS = Resources.Load<Sprite>(Button_RS_Sprite_Path);
            s_Sprite_Button_Start = Resources.Load<Sprite>(Button_Start_Sprite_Path);
            s_Sprite_Button_Back = Resources.Load<Sprite>(Button_Back_Sprite_Path);

            s_SpritesLoaded = true;
        }
    }

    public static Sprite Sprite_Key
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Key;
        }
    }
    public static Sprite Sprite_Button_A
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_A;
        }
    }
    public static Sprite Sprite_Button_B
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_B;
        }
    }
    public static Sprite Sprite_Button_X
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_X;
        }
    }
    public static Sprite Sprite_Button_Y
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_Y;
        }
    }
    public static Sprite Sprite_Button_LB
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_LB;
        }
    }
    public static Sprite Sprite_Button_RB
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_RB;
        }
    }
    public static Sprite Sprite_Button_LT
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_LT;
        }
    }
    public static Sprite Sprite_Button_RT
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_RT;
        }
    }
    public static Sprite Sprite_Button_LS
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_LS;
        }
    }
    public static Sprite Sprite_Button_RS
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_RS;
        }
    }
    public static Sprite Sprite_Button_Start
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_Start;
        }
    }
    public static Sprite Sprite_Button_Back
    {
        get
        {
            if (s_SpritesLoaded == false)
            {
                LoadSprites();
            }
            return s_Sprite_Button_Back;
        }
    }

    private static Sprite s_Sprite_Key;
    private static Sprite s_Sprite_Button_A;
    private static Sprite s_Sprite_Button_B;
    private static Sprite s_Sprite_Button_X;
    private static Sprite s_Sprite_Button_Y;
    private static Sprite s_Sprite_Button_LB;
    private static Sprite s_Sprite_Button_RB;
    private static Sprite s_Sprite_Button_LT;
    private static Sprite s_Sprite_Button_RT;
    private static Sprite s_Sprite_Button_LS;
    private static Sprite s_Sprite_Button_RS;
    private static Sprite s_Sprite_Button_Start;
    private static Sprite s_Sprite_Button_Back;

    #endregion

    public Sprite CurrentIcon { get; private set; }

    public Text ButtonIconText;

    private const string StringDefaultText = "";

    Image m_Image;

    public enum ButtonOptions
    {
        Key,
        Button_A,
        Button_B,
        Button_X,
        Button_Y,
        Button_LB,
        Button_RB,
        Button_LT,
        Button_RT,
        Button_LS,
        Button_RS,
        Button_Start,
        Button_Back,
        MAX_BUTTONS
    }

    public void SetCurrentButton(ButtonOptions aButtonOption, string aButtonText = StringDefaultText)
    {
        if (aButtonOption > ButtonOptions.Key)
        {
            ButtonIconText.text = StringDefaultText;
        }
        else
        {
            ButtonIconText.text = aButtonText.ToUpper();
        }

        switch (aButtonOption)
        {
            case ButtonOptions.Key:
                CurrentIcon = Sprite_Key;
                break;
            case ButtonOptions.Button_A:
                CurrentIcon = Sprite_Button_A;
                break;
            case ButtonOptions.Button_B:
                CurrentIcon = Sprite_Button_B;
                break;
            case ButtonOptions.Button_X:
                CurrentIcon = Sprite_Button_X;
                break;
            case ButtonOptions.Button_Y:
                CurrentIcon = Sprite_Button_Y;
                break;
            case ButtonOptions.Button_LB:
                CurrentIcon = Sprite_Button_LB;
                break;
            case ButtonOptions.Button_RB:
                CurrentIcon = Sprite_Button_RB;
                break;
            case ButtonOptions.Button_LT:
                CurrentIcon = Sprite_Button_LT;
                break;
            case ButtonOptions.Button_RT:
                CurrentIcon = Sprite_Button_RT;
                break;
            case ButtonOptions.Button_LS:
                CurrentIcon = Sprite_Button_LS;
                break;
            case ButtonOptions.Button_RS:
                CurrentIcon = Sprite_Button_RS;
                break;
            case ButtonOptions.Button_Start:
                CurrentIcon = Sprite_Button_Start;
                break;
            case ButtonOptions.Button_Back:
                CurrentIcon = Sprite_Button_Back;
                break;
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Invalid button: " + aButtonOption.ToString(), Developmer.AllDevelopmers);
#endif
                return;
        }

        if (m_Image == null)
        {
            m_Image = GetComponent<Image>();
        }

        m_Image.sprite = CurrentIcon;
    }

    public void UpdateAbilityIconButton(PlayerInput aInput, InputName aInputName)
    {
        if (aInput.Device == InputDevice.Keyboard)
        {
            MapKeyToIcon(aInput, aInputName);
        }
        else if (aInput.Device > InputDevice.Keyboard)
        {
            MapControllerIcon(aInput, aInputName);
        }
    }

    void MapKeyToIcon(PlayerInput aInput, InputName aInputName)
    {
        KeyCode aKey = aInput.GetMappedKeyCode(aInputName);

        string keyText = string.Empty;

        if (aKey >= KeyCode.Space && aKey <= KeyCode.Z)
        {
            keyText += (char)aKey;
        }
        else
        {
            keyText = aKey.ToString();
        }

        SetCurrentButton(HudButtonIconHelper.ButtonOptions.Key, keyText);
    }

    void MapControllerIcon(PlayerInput aInput, InputName aInputName)
    {
        InputMapping input = aInput.CurrentConfiguration.InputMap[(int)aInputName];

        if (input is JoystickAxisInputMapping)
        {
            MapJoystickAxisToIcon(aInput, aInputName);
        }
        else if (input is JoystickButtonInputMapping)
        {
            MapButtonToIcon(aInput, aInputName);
        }
        else
        {
#if UNITY_EDITOR
            DebugManager.LogError("Invalid input.", Developmer.AllDevelopmers);
#endif
        }
    }

    void MapButtonToIcon(PlayerInput aInput, InputName aInputName)
    {
        int aButton = aInput.GetMappedJoystickButton(aInputName);

        HudButtonIconHelper.ButtonOptions buttonOption = HudButtonIconHelper.ButtonOptions.MAX_BUTTONS;

        switch (aButton)
        {
            case JoystickMap.BUTTON_A:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_A;
                break;
            case JoystickMap.BUTTON_B:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_B;
                break;
            case JoystickMap.BUTTON_X:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_X;
                break;
            case JoystickMap.BUTTON_Y:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_Y;
                break;
            case JoystickMap.BUTTON_LB:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_LB;
                break;
            case JoystickMap.BUTTON_RB:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_RB;
                break;
            case JoystickMap.BUTTON_LS:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_LS;
                break;
            case JoystickMap.BUTTON_RS:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_RS;
                break;
            case JoystickMap.BUTTON_START:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_Start;
                break;
            case JoystickMap.BUTTON_BACK:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_Back;
                break;
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Invalid input.", Developmer.AllDevelopmers);
#endif
                break;
        }

        SetCurrentButton(buttonOption);
    }

    void MapJoystickAxisToIcon(PlayerInput aInput, InputName aInputName)
    {
        int aAxis = aInput.GetMappedJoystickAxis(aInputName);

        HudButtonIconHelper.ButtonOptions buttonOption = HudButtonIconHelper.ButtonOptions.MAX_BUTTONS;

        switch (aAxis)
        {
            case JoystickMap.JOYSTICK_TRIGGER_LEFT:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_LT;
                break;
            case JoystickMap.JOYSTICK_TRIGGER_RIGHT:
                buttonOption = HudButtonIconHelper.ButtonOptions.Button_RT;
                break;
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Invalid input.", Developmer.AllDevelopmers);
#endif
                break;
        }

        SetCurrentButton(buttonOption);
    }
}
