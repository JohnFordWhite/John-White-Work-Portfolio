﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;

public class NewEditControlScript : GameMenu
{
    public enum EditControlsState
    {
        SelectCharacter,
        SelectInput,
        EditInput
    }

    [Header("Misc. Properties")]
    public bool AllowEditingControlsForMultipleDevices = false;
    public bool ListenToAllConnectedDevicesForInput = false;
    public int PlayerIndex = 0;
    public EditControlsState CurrentState = EditControlsState.SelectCharacter;

    protected List<Selectable> ScrollViewSelectables;

    public bool IsCurrentlyConfiguring
    {
        get
        {
            return m_IsCurrentlyConfiguring;
        }
    }
    protected bool m_IsCurrentlyConfiguring = false;

    public GameObject CurrentSelectedGameObject
    {
        get
        {
            return m_CurrentSelectedGameObject;
        }
    }
    protected GameObject m_CurrentSelectedGameObject = null;

    [Space(10)]
    [Header("Panel to select what player to edit controls for")]
    public GameObject SelectCharacterPanel;
    public GameObject SelectCharacterPanel_FirstSelectableObject;
    public Button LeeroyButton;
    public Button ZephButton;
    public Button QuarkButton;
    public Button PaigeButton;

    [Space(10)]
    [Header("Panel containing the list of Inputs to configure for this character. Also has button to switch between Controller and Keyboard.")]
    public GameObject SelectInputNamePanel;
    public GameObject SelectInputNamePanel_FirstSelectableObject;
    public Text SelectInput_CharacterNameText;
    public Button ControllerEditButton;
    public Button KeyboardEditButton;
    public Button SelectCharacterButton;
    public Button SelectInput_BackButton;

    public GameObject InputItemPrefab;

    // Scroll view containing the list of inputs to configure
    public ScrollRect InputsScrollView;
    public GameObject ScrollViewContentPanel;

    [Space(10)]
    [Header("Panel for editing one input. Contains the mapped button(s), axis deadzone, axis sensitivity, toggled axis controls.")]
    public GameObject EditOneInputPanel;
    public GameObject EditOneInputPanel_FirstSelectableObject;
    public Text ConfigurationStatusText;
    public GameObject NegativeButtonPanel;
    public Button StartConfiguringNegativeButton;
    public Text NegativeButtonText;
    public GameObject PositiveButtonPanel;
    public Button StartConfiguringPositiveButton;
    public Text PositiveButtonText;
    public Slider AxisDeadzoneSlider;
    public Slider AxisSensitivitySlider;
    public Toggle InvertAxisToggle;
    public Button DoneEditingControlsButton;

    public void PopulateInputsList()
    {
        SimpleCoroutine.Instance.StartCoroutine(HandlePopulateScrollList());
    }

    IEnumerator HandlePopulateScrollList()
    {
        int childIndex = 0;

        if (ScrollViewSelectables == null)
        {
            ScrollViewSelectables = new List<Selectable>();
        }
        ScrollViewSelectables.Clear();

        // Populate the Scroll View with all of the controls that can be re-mapped.
        Selectable first = AddInputItem("Move Horizontal", InputName.Horizontal, childIndex++, true, "Left", "Right");
        AddInputItem("Move Vertical", InputName.Vertical, childIndex++, true, "Reverse", "Forward");
        AddInputItem("Look Horizontal", InputName.LookHorizontal, childIndex++, true, "Left", "Right");
        AddInputItem("Look Vertical", InputName.LookVertical, childIndex++, true, "Down", "Up");
        //AddInputItem("Taunt Horizontal", InputName.TauntHorizontal, childIndex++, true);
        //AddInputItem("Taunt Vertical", InputName.TauntVertical, childIndex++, true);
        AddInputItem("Attack 1", InputName.Attack1, childIndex++, false);
        AddInputItem("Attack 2", InputName.Attack2, childIndex++, false);
        AddInputItem("Jump", InputName.Jump, childIndex++, false);
        AddInputItem("Ability 1", InputName.Ability1, childIndex++, false);
        AddInputItem("Ability 2", InputName.Ability2, childIndex++, false);
        AddInputItem("Ability 3", InputName.Ability3, childIndex++, false);
        AddInputItem("Movement Ability", InputName.Movement, childIndex++, false);
        Selectable last = AddInputItem("Reload", InputName.Reload, childIndex++, false);
        //AddInputItem("Sprint", InputName.Sprint,         childIndex++, false);
        //AddInputItem("Crouch", InputName.Crouch, childIndex++, false);

        yield return null;

        // Set navigation manually on first and last elements

        // Children of the scroll rect
        Navigation firstNav = first.navigation;
        firstNav.selectOnUp = SelectInputNamePanel_FirstSelectableObject.GetComponent<Selectable>();
        first.navigation = firstNav;

        Navigation lastNav = last.navigation;
        lastNav.selectOnDown = SelectInput_BackButton;
        last.navigation = lastNav;
    }

    protected Selectable AddInputItem(string aActionName, InputName aGameAction, int aChildIndex, bool aKeepNegativeAxis, string aNegativeAxisName = "", string aPositiveAxisName = "")
    {
        GameObject buttonPanel = Instantiate(InputItemPrefab);
        buttonPanel.transform.SetParent(ScrollViewContentPanel.transform, false);
        buttonPanel.transform.SetAsLastSibling();

        Transform TextObject = buttonPanel.transform.Find("Button/Text");
        if (TextObject != null)
        {
            Text buttonText = TextObject.GetComponent<Text>();
            buttonText.text = aActionName;
            buttonText.fontSize = 36;
            buttonText.resizeTextForBestFit = false;

            Button button = buttonText.transform.parent.GetComponent<Button>();
            button.onClick.AddListener
            (
                delegate
                {
                    EditInput(aActionName, aGameAction, aKeepNegativeAxis, aNegativeAxisName, aPositiveAxisName);
                }
            );
            Navigation nav = button.navigation;
            nav.mode = Navigation.Mode.Vertical;
            button.navigation = nav;

            HorizontalLayoutGroup layoutGroup = buttonPanel.GetComponent<HorizontalLayoutGroup>();
            layoutGroup.childForceExpandWidth = true;

            layoutGroup = button.GetComponent<HorizontalLayoutGroup>();
            layoutGroup.childAlignment = TextAnchor.MiddleLeft;

            ScrollRectChildHelper scrollRectChildHelper = button.gameObject.AddComponent<ScrollRectChildHelper>();
            scrollRectChildHelper.ScrollRect = InputsScrollView;
            scrollRectChildHelper.ChildIndex = aChildIndex;

            ContentSizeFitter contentSizeFitter = TextObject.GetComponent<ContentSizeFitter>();
            if (contentSizeFitter != null)
            {
                DestroyImmediate(contentSizeFitter);
            }

            ScrollViewSelectables.Add(button);
            return button;
        }

        return null;
    }

    public void EditInput(string aActionName, InputName aGameAction, bool aKeepNegativeAxis, string aNegativeAxisName, string aPositiveAxisName)
    {
#if UNITY_EDITOR
        DebugManager.Log("EditInput: " + aActionName + ", " + aGameAction + ", " + aKeepNegativeAxis + ", " + aNegativeAxisName + ", " + aPositiveAxisName, Developmer.Evan);
#endif
        SetState(EditControlsState.EditInput);
    }

	// Use this for initialization
	protected override void Start()
    {
        base.Start();
	}
	
	// Update is called once per frame
	protected override void Update()
    {
        base.Update();

        if (PlayerIndex >= InputManager.CM.Players.Count)
            return;

        HandleNavigation();

        if (IsSubmitButtonPressed())
        {
            TryCurrentSelectableOnClick();
            return;
        }

        if (IsCancelButtonPressed())
        {
            BackButtonFunction();
            return;
        }
	}

    bool HandleNavigation()
    {
        float horizontal = 0;
        float vertical = 0;

        for (int i = 0; i < InputManager.CM.Players.Count; i++)
        {
            if (PlayerIndex == i || AllowEditingControlsForMultipleDevices == true)
            {
                GameInputComponent playerObject = InputManager.CM.Players[i];
                if (playerObject != null)
                {
                    PlayerInput input = playerObject.Input as PlayerInput;

                    horizontal = input.GetInput(InputName.Menu_Horizontal, InputType.ButtonPressed, true) + input.GetInput(InputName.Menu_Alt_Horizontal, InputType.ButtonPressed, true);
                    vertical = input.GetInput(InputName.Menu_Vertical, InputType.ButtonPressed, true) + input.GetInput(InputName.Menu_Alt_Vertical, InputType.ButtonPressed, true);
                }

                if (playerObject == null || (horizontal == 0.0f && vertical == 0.0f))
                    continue;
                
                if (m_CurrentSelectedGameObject != null)
                {
                    Selectable selectable = m_CurrentSelectedGameObject.GetComponent<Selectable>();
                    if (selectable != null)
                    {
                        Selectable adjacentSelectable = null;

                        if (horizontal < 0.0f)
                        {
                            adjacentSelectable = selectable.FindSelectableOnLeft();
                        }
                        else if (horizontal > 0.0f)
                        {
                            adjacentSelectable = selectable.FindSelectableOnRight();
                        }
                        else if (vertical > 0.0f)
                        {
                            if (m_CurrentSelectedGameObject == SelectInput_BackButton.gameObject ||
                                m_CurrentSelectedGameObject == SelectCharacterButton.gameObject)
                            {
                                if (ScrollViewSelectables.Count > 0)
                                {
                                    adjacentSelectable = ScrollViewSelectables[ScrollViewSelectables.Count - 1];
                                }
                            }
                            else
                            {
                                adjacentSelectable = selectable.FindSelectableOnUp();
                            }
                        }
                        else if (vertical < 0.0f)
                        {
                            if (m_CurrentSelectedGameObject == ControllerEditButton.gameObject ||
                                m_CurrentSelectedGameObject == KeyboardEditButton.gameObject)
                            {
                                if (ScrollViewSelectables.Count > 0)
                                {
                                    adjacentSelectable = ScrollViewSelectables[0];
                                }
                            }
                            else
                            {
                                adjacentSelectable = selectable.FindSelectableOnDown();
                            }
                        }

                        if (adjacentSelectable != null)
                        {
                            SelectGameObject(adjacentSelectable.gameObject);
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    public override bool IsSubmitButtonPressed()
    {
        for (int i = 0; i < InputManager.CM.Players.Count; i++)
        {
            if (PlayerIndex == i || AllowEditingControlsForMultipleDevices == true)
            {
                if (InputManager.CM.Players[PlayerIndex].Input.IsSubmitButtonPressed())
                    return true;
            }
        }

        return false;
    }

    public override bool IsCancelButtonPressed()
    {
        for (int i = 0; i < InputManager.CM.Players.Count; i++)
        {
            if (PlayerIndex == i || AllowEditingControlsForMultipleDevices == true)
            {
                if (InputManager.CM.Players[PlayerIndex].Input.IsCancelButtonPressed())
                    return true;
            }
        }

        return false;
    }

    public override void TryCurrentSelectableOnClick()
    {
        Selectable selectable = m_CurrentSelectedGameObject.GetComponent<Selectable>();
        if (selectable != null)
        {
            ExecuteEvents.Execute(selectable.gameObject, null, ExecuteEvents.submitHandler);

#if UNITY_EDITOR
            DebugManager.Log("Execute Selectable OnSubmit: " + selectable.gameObject, Developmer.Evan);
#endif
            return;
        }
    }

    public void BackButtonFunction()
    {
        if (IsCurrentlyConfiguring == false)
        {
            switch (CurrentState)
            {
                case EditControlsState.SelectCharacter:
                    Cancel();
                    break;
                case EditControlsState.SelectInput:
                    Cancel();
                    break;
                case EditControlsState.EditInput:
                    SetState(EditControlsState.SelectInput);
                    break;
            }
        }
    }

    protected void Cancel()
    {
        if (OnEditControlScriptComplete != null)
        {
            if (PlayerIndex < InputManager.CM.Players.Count)
                InputManager.CM.Players[PlayerIndex].EditingControls = false;
            OnEditControlScriptComplete(PlayerIndex);
        }
    }

    public void SetState(EditControlsState aState)
    {
        if (IsCurrentlyConfiguring == false)
        {
            CurrentState = aState;

            switch (CurrentState)
            {
                case EditControlsState.SelectCharacter:
                    SelectCharacterPanel.SetActive(true);
                    SelectInputNamePanel.SetActive(false);
                    EditOneInputPanel.SetActive(false);
                    SelectGameObject(SelectCharacterPanel_FirstSelectableObject);
                    break;
                case EditControlsState.SelectInput:
                    SelectCharacterPanel.SetActive(false);
                    SelectInputNamePanel.SetActive(true);
                    EditOneInputPanel.SetActive(false);
                    SelectGameObject(SelectInputNamePanel_FirstSelectableObject);
                    break;
                case EditControlsState.EditInput:
                    SelectCharacterPanel.SetActive(false);
                    SelectInputNamePanel.SetActive(false);
                    EditOneInputPanel.SetActive(true);
                    SelectGameObject(EditOneInputPanel_FirstSelectableObject);
                    break;
            }
        }
    }

    protected void SelectGameObject(GameObject aSelectableGameObject)
    {
        if (m_CurrentSelectedGameObject != null)
        {
            Selectable selectable = m_CurrentSelectedGameObject.GetComponent<Selectable>();
            if (selectable != null)
            {
                Image mainImage = m_CurrentSelectedGameObject.GetComponent<Image>();

                mainImage.sprite = selectable.spriteState.pressedSprite;
            }
        }

        m_CurrentSelectedGameObject = aSelectableGameObject;

        if (m_CurrentSelectedGameObject != null)
        {
            Selectable selectable = m_CurrentSelectedGameObject.GetComponent<Selectable>();
            if (selectable != null)
            {
                Image mainImage = m_CurrentSelectedGameObject.GetComponent<Image>();

                mainImage.sprite = selectable.spriteState.highlightedSprite;

                // If this object is a child of a scroll rect, 
                ScrollRectChildHelper scrollRectChildHelper = m_CurrentSelectedGameObject.GetComponent<ScrollRectChildHelper>();
                if (scrollRectChildHelper != null)
                {
                    InterfaceUtils.SetScrollViewViewportHeightPosition(
                        scrollRectChildHelper.ScrollRect,
                        ScrollViewContentPanel,
                        scrollRectChildHelper.ChildIndex,
                        ScrollViewContentPanel.transform.childCount
                        );
                }
            }
        }
    }

    public void SetSelectInputToConfigurePanelVisible(CharacterTypes aCharacter)
    {
        SetState(EditControlsState.SelectInput);

        SelectInput_CharacterNameText.text = "Character: " + aCharacter.ToString();
    }

    #region Button event listeners
    // Need these because you cannot set a button with enum as a parameter in the inspector

    // Select Character State button events

    public void LeeroyButtonFunction()
    {
        SetSelectInputToConfigurePanelVisible(CharacterTypes.Leeroy);
    }

    public void ZephButtonFunction()
    {
        SetSelectInputToConfigurePanelVisible(CharacterTypes.Zeph);
    }

    public void QuarkButtonFunction()
    {
        SetSelectInputToConfigurePanelVisible(CharacterTypes.Quark);
    }

    public void PaigeButtonFunction()
    {
        SetSelectInputToConfigurePanelVisible(CharacterTypes.Paige);
    }

    // Select Input State button events

    public void SetDeviceKeyboard()
    {

    }

    public void SetDeviceController()
    {

    }

    public void SetStateToSelectCharacter()
    {
        SetState(EditControlsState.SelectCharacter);
    }

    #endregion

    public delegate void EditControlScriptCompleteDelegate(int aPlayerIndex);
    public event EditControlScriptCompleteDelegate OnEditControlScriptComplete;
}
