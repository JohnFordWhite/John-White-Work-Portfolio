﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class VirtualKeyboardValue
{
    public string InputText;
    public VirtualKeyboard.Status InputStatus;
    public int PlayerIndex;

    public override string ToString()
    {
        return "VirtualKeyboardValue { InputText=" + InputText + ", InputStatus=" + InputStatus.ToString() + ", PlayerIndex=" + PlayerIndex.ToString() + " }";
    }
}

public class VirtualKeyboard : GameMenu
{
    public const string StringErrorExistingName = "This profile already exists: {0}";
    public const string StringErrorEmptyName = "Enter a name.";

    // Green highlighted color
    public Color HighlightedColor = new Color(0.7f, 1.0f, 0.7f, 1.0f);

    public Text Title;
    public Text ErrorMessage;
    public InputField Input;
    public GameObject MiddleKeyboardButtonsPanel;
    public GameObject LowercaseButtons;
    public GameObject UppercaseButtons;

    public enum Status
    {
        Editing,        // User is currently inputting text into the virtual keyboard
        Confirmed,      // User confirmed their input
        Cancelled       // User cancelled text input
    }

    public VirtualKeyboardValue GetInputValue { get { return m_VK_Value; } }

    // prefabs
    [HideInInspector]
    public UnityEngine.Object KeyboardButtonPrefab;
    [HideInInspector]
    public UnityEngine.Object KeyboardSpacerPrefab;

    private VirtualKeyboardValue m_VK_Value;
    private bool m_IsKeyboardShiftEnabled;
    //private InputFieldScript m_InputScript;

    private Button FirstNavigableButton;

    // strings
    private string m_VirtualKeyboardResponse = "VirtualKeyboardResponse";

    protected override void Start()
    {
        base.Start();
    }

    public void Init(string title, int aPlayerIndex, int aCharacterLimit = 20)
    {
        m_VK_Value = new VirtualKeyboardValue();
        m_VK_Value.InputText = string.Empty;
        m_VK_Value.InputStatus = Status.Editing;

        KeyboardButtonPrefab = Resources.Load(KeyboardLayout.KeyboardButtonPrefab);
        KeyboardSpacerPrefab = Resources.Load(KeyboardLayout.KeyboardSpacerPrefab);

        m_IsKeyboardShiftEnabled = false;

        if (Title != null)
        {
            Title.text = title;
        }

        m_VK_Value.PlayerIndex = aPlayerIndex;
        Input.GetComponent<InputFieldScript>().PlayerIndex = aPlayerIndex;

        if (Input != null)
        {
            Input.characterLimit = aCharacterLimit;
            //m_InputScript = Input.GetComponent<InputFieldScript>();
        }

        AlphanumericKeyboardLayout.BuildKeyboard(
            this,
            KeyboardButtonPrefab,
            KeyboardSpacerPrefab,
            false
            );

        ToggleKeyboardShift();

        // Select first input depending on keyboard or controller user.
        // If keyboard, focus on the textbox.
        // If controller, focus on the first button below the textbox and disable navigation to the textbox.

        GameInputComponent input = InputManager.CM.Players[aPlayerIndex];
        PlayerInput playerInput = input.Input as PlayerInput;

        if (playerInput.Device == InputDevice.Keyboard)
        {
            FirstSelectableMenuItem = Input.gameObject;
            //Input.Select();

            ForceSelectionOfFirstMenuItem();
        }
        else
        {
            Navigation navigation = Input.navigation;
            navigation.mode = Navigation.Mode.None;
            Input.navigation = navigation;

            FirstSelectableMenuItem = FirstNavigableButton.gameObject;
            //FirstNavigableButton.Select();

            ForceSelectionOfFirstMenuItem();
        }

        EnableNavigation();
    }

	// Update is called once per frame
	protected override void Update ()
    {
        base.Update();
	}
    
    public void AddCharacterToInputField(string text)
    {
        if (m_VK_Value.InputStatus == Status.Editing)
        {
            if (Input != null)
            {
                Input.text += text;
            }
        }
    }

    public void DeleteCharacter()
    {
        if (m_VK_Value.InputStatus == Status.Editing)
        {
            if (Input.text.Length > 0)
            {
                Input.text = Input.text.Substring(0, Input.text.Length - 1);
            }
        }
    }

    public void ToggleKeyboardShift()
    {
        m_IsKeyboardShiftEnabled = !m_IsKeyboardShiftEnabled;

        UppercaseButtons.SetActive(m_IsKeyboardShiftEnabled);
        LowercaseButtons.SetActive(!m_IsKeyboardShiftEnabled);

        //if (m_InputScript != null)
        {
            if (m_IsKeyboardShiftEnabled)
            {
                FirstNavigableButton = UppercaseButtons.transform.GetChild(0).GetComponent<Button>();
            }
            else
            {
                FirstNavigableButton = LowercaseButtons.transform.GetChild(0).GetComponent<Button>();
            }
        }
    }

    public void ConfirmTextEntry()
    {
        Input.text = Input.text.Trim();

        if (InputManager.CM.PlayerProfileManager.PlayerProfiles.ContainsKey(Input.text) == false)
        {
            if (Input.text != string.Empty)
            {
                m_VK_Value.InputStatus = Status.Confirmed;
                m_VK_Value.InputText = Input.text;
                
                if (ParentMenu != null)
                {
                    ParentMenu.VirtualKeyboardResponse(m_VK_Value);
                }
                CloseMenu();
            }
            else
            {
                ErrorMessage.gameObject.SetActive(true);
                ErrorMessage.text = StringErrorEmptyName;
            }
        }
        else
        {
            ErrorMessage.gameObject.SetActive(true);
            ErrorMessage.text = string.Format(StringErrorExistingName, Input.text);
        }
    }

    public void CancelTextEntry()
    {
        m_VK_Value.InputStatus = Status.Cancelled;
        m_VK_Value.InputText = string.Empty;

        if (ParentMenu != null)
        {
            ParentMenu.SendMessage(m_VirtualKeyboardResponse, m_VK_Value);
        }
        CloseMenu();
    }
}

public class KeyboardLayout
{
    public const string KeyboardButtonPrefab = "Prefabs/UI/DefaultKeyboardButton";
    public const string KeyboardSpacerPrefab = "Prefabs/UI/DefaultKeyboardSpacer";
    public static readonly string[] StandardKeys =
    {
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
        "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
        null, null, null, null // spacers
    };
    // Qwerty format of the keyboard needs indexed based ordering of the letters
    public static readonly int[] StandardKeysQwertyOrder =
    {
        16, 22,  4, 17, 19, 24, 20,  8, 14, 15,  0, 18,  3,  5,  6,
         7,  9, 10, 11, 26, 25, 23,  2, 21,  1, 13, 12, 26, 26, 26
    };
}

public class AlphanumericKeyboardLayout : KeyboardLayout
{
    public static void BuildKeyboard(VirtualKeyboard aVirtualKeyboard, UnityEngine.Object aButtonPrefab, UnityEngine.Object aSpacerPrefab, bool aIsQuerty = true)
    {
        List<string> buttonLabels = new List<string>();

        // Populate buttonLabels with all of the buttons we need to display on the screen.

        // Start with the numpad buttons
        for (int i = 0; i < 10; i++)
        {
            buttonLabels.Add(i.ToString());
        }

        // Create buttons for the letter keys
        if (aIsQuerty == true)
        {
            // qwerty format - use index ordered list

            for (int i = 0; i < StandardKeysQwertyOrder.Length; i++)
            {
                buttonLabels.Add(StandardKeys[StandardKeysQwertyOrder[i]]);
            }
        }
        else
        {
            // abc format - can loop over all ordered characters

            for (int i = 0; i < StandardKeys.Length; i++)
            {
                buttonLabels.Add(StandardKeys[i]);
            }
        }

        // Create the actual UI elements and add them to the Panel.
        for (int i = 0; i < buttonLabels.Count; i++)
        {
            string buttonLabel = buttonLabels[i];

            if (buttonLabel != null)
            {
                // Make a button for uppercase and lowercase.
                InterfaceUtils.MakeButton(
                    aVirtualKeyboard.LowercaseButtons,
                    aVirtualKeyboard.KeyboardButtonPrefab,
                    buttonLabel,
                    delegate { aVirtualKeyboard.AddCharacterToInputField(buttonLabel); }
                    );

                InterfaceUtils.MakeButton(
                    aVirtualKeyboard.UppercaseButtons,
                    aVirtualKeyboard.KeyboardButtonPrefab,
                    buttonLabel.ToUpper(),
                    delegate { aVirtualKeyboard.AddCharacterToInputField(buttonLabel.ToUpper()); }
                    );
            }
            else
            {
                // Add a spacer to fill in the Grid Layout
                InterfaceUtils.InstantiatePrefab(
                    aVirtualKeyboard.LowercaseButtons,
                    aVirtualKeyboard.KeyboardSpacerPrefab,
                    false
                    );

                InterfaceUtils.InstantiatePrefab(
                    aVirtualKeyboard.UppercaseButtons,
                    aVirtualKeyboard.KeyboardSpacerPrefab,
                    false
                    );
            }
        }
    }
}