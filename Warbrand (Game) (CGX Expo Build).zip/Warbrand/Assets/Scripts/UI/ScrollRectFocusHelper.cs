﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;

/*
 * This helper class helps to keep the selected item in a UI Dropdown visible at all times.
 * Without this script, a scrollbar would get cut off the screen if there are a lot of items
 * in it and you wouldn't see your selection anymore.
 */

public class ScrollRectFocusHelper : MonoBehaviour
{

    private GameObject Content;
    private ScrollRect Scroll;

	// Use this for initialization
	void Start ()
    {
        // The object with the masked viewport
        Scroll = GetComponent<ScrollRect>();

        // The object containing the list of selectable game objects.
        Content = transform.FindChild("Viewport").FindChild("Content").gameObject;
	}
	
	// Update is called once per frame
	void Update ()
    {
        int selectedIndex = 0;

        float contentHeight = Content.GetComponent<RectTransform>().rect.height;
        float itemHeight = 0;

        // Get selected child index
        Toggle[] Items = Content.transform.GetComponentsInChildren<Toggle>();
        for (int i = 0; i < Items.Length; i++)
        {
            Toggle toggle = Items[i];
            if (EventSystem.current.currentSelectedGameObject == toggle.gameObject)
            {
                itemHeight = toggle.GetComponent<RectTransform>().rect.height;
                selectedIndex = i;
                break;
            }
        }

        // The verticalNormalizedPosition of the viewport takes a value between 0 (bottom) and 1 (top).
        // We calculate the scroll position using the current selected index / total number of items.
        // Subtract half the height of one item to make it more accurate.
        // If the selected index is at either end (0 or at count - 1), just clamp it to 0 or 1.

        float scrollHeightPercent = itemHeight / contentHeight;

        // Calculate the Y position of the viewport.
        float viewportY = 1.0f - (float)selectedIndex / (float)Items.Length - (scrollHeightPercent / 2.0f);
        
        // Clamp the height at the ends
        if (selectedIndex == 0 || selectedIndex == Items.Length - 1)
        {
            viewportY = Mathf.Round(viewportY);
        }

        // Sets the final scroll position
        Scroll.verticalNormalizedPosition = viewportY;
	}
}
