﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class AbilityDescription : MonoBehaviour
{
    public Image AbilityIconImage;
    public HudButtonIconHelper ButtonIconImage;
    public Text AbilityDescriptionText;

    // The order of the enum here MUST match the order of the InputNames, image and description arrays.
    public enum AbilityIndex
    {
        Attack1,
        Attack2,    // Leeroy's shield
        Ability1,
        Ability2,
        Ability3,
        Movement,
        MAX_ABILITY_INDEX
    }

    public static readonly InputName[] InputNames =
    {
        InputName.Attack1,
        InputName.Attack2,
        InputName.Ability1,
        InputName.Ability2,
        InputName.Ability3,
        InputName.Movement
    };

    #region Ability Icons

    // Leeroy
    public Sprite[] LeeroyAbilityIcons;

    // Zeph
    public Sprite[] ZephAbilityIcons;

    // Quark
    public Sprite[] QuarkAbilityIcons;

    // Paige
    public Sprite[] PaigeAbilityIcons;

    #endregion

    #region Ability Descriptions

    // Leeroy
    private static readonly string[] LeeroyDescriptions =
    {
        "Sword Swing - Attack players with a heavy melee attack.",
        "Shield - Blocks incoming damage from the front.",
        "Clap Stun - Stun enemies directly in front of Leeroy for a few seconds.",
        "Gauntlet Explosive - Launches a grenade that explodes on contact.",
        "Injection - Temporarily boosts Leeroy's attack and speed.",
        "Super Jump - Launches Leeroy into the air.",
    };

    // Zeph
    private static readonly string[] ZephDescriptions =
    {
        "Kusarigama Swing - Attack players with a quick melee attack.",
        string.Empty,
        "Hook - Grabs an enemy in front of Zeph and pulls them in. Enemy is temporarily stunned.",
        "Smoke Grenade - Throws a smoke grenade in front of Zeph. Reduces visibility of enemies and enemy turrets.",
        "Poison Dart - Shoots a poison dart in front of Zeph. Enemies affected take damage over a few seconds.",
        "Teleport - Teleports Zeph a short distance in the direction he is looking.",
    };

    // Quark
    private static readonly string[] QuarkDescriptions =
    {
        "Energy Beam - Shoots a short range energy beam in front of Quark. Hold down the button to use.",
        string.Empty,
        "Build Turret - Builds a turret that will automatically attack enemies. Press primary attack to place.",
        "Build Trap - Builds an electric trap that stuns and damages any enemies that walks over it.",
        "Build Camera - Builds a flying camera that follows enemies. The camera will show Quark enemies through walls.",
        "Knock-Back - Pushes enemies that are in front of Quark away. Quark gets pushed backwards.",
    };

    // Paige
    private static readonly string[] PaigeDescriptions =
    {
        "Shotgun - Shoots a short range shotgun blast in front of Paige. Damage will falloff the farther away the target is.",
        string.Empty,
        "Adhesive Grenade - Shoots a grenade that will release an adhesive on the ground it hits, slowing enemies walking in it.",
        "Charged Heal - Hold down the button to restore health over time. The amount of health restored increases over time.",
        "Ground Pound - While in the air, Paige will slam into the ground below and damage enemies a short distance away.",
        "Jet Pack - Hold down the button to fly through the air for a limited time.",
    };

    #endregion


    public void SetAbilityIconAndDescription(CharacterTypes aCharacter, AbilityIndex aIndex)
    {
        string desc = string.Empty;
        Sprite sprite = null;

        if (aIndex >= AbilityIndex.MAX_ABILITY_INDEX)
        {
#if UNITY_EDITOR
            DebugManager.LogError("Invalid ability index: " + aIndex.ToString(), Developmer.AllDevelopmers);
#endif
            return;
        }

        switch (aCharacter)
        {
            case CharacterTypes.Leeroy:
                desc = LeeroyDescriptions[(int)aIndex];
                sprite = LeeroyAbilityIcons[(int)aIndex];
                break;
            case CharacterTypes.Zeph:
                desc = ZephDescriptions[(int)aIndex];
                sprite = ZephAbilityIcons[(int)aIndex];
                break;
            case CharacterTypes.Quark:
                desc = QuarkDescriptions[(int)aIndex];
                sprite = QuarkAbilityIcons[(int)aIndex];
                break;
            case CharacterTypes.Paige:
                desc = PaigeDescriptions[(int)aIndex];
                sprite = PaigeAbilityIcons[(int)aIndex];
                break;
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Invalid character type: " + aCharacter.ToString(), Developmer.AllDevelopmers);
#endif
                return;
        }

        AbilityDescriptionText.text = desc;
        AbilityIconImage.sprite = sprite;
    }
}
