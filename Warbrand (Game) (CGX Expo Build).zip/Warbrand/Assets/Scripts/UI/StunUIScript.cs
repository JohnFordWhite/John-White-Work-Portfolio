﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        StunUIScript                                                                   *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 30th, 2016                                                             *
 *                                                                                                 *
 * This script will enable or disable an image depending on whether a player is stunned or not.    *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 30th, 2016                                          *
\***************************************************************************************************/
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class StunUIScript : MonoBehaviour
{

    public Player Owner;
    Image m_StunNotification;

	void Start ()
    {
        m_StunNotification = GetComponent<Image>();
	}
	
	void Update ()
    {
        if (Owner == null)
            return;

        m_StunNotification.enabled = Owner.IsStunned;
	}
}
