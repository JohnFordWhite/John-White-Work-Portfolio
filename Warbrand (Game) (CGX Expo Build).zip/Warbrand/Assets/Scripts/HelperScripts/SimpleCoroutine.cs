﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        SimpleCoroutine                                                                *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            October 28th, 2016                                                             *
 *                                                                                                 *
 * Allows for using coroutines in non-MonoBehaviour classes                                        *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - October 28th, 2016                                          *
\***************************************************************************************************/

using UnityEngine;

public class SimpleCoroutine : MonoBehaviour
{
    private const string m_SimpleCoroutineTransform = "SimpleCoroutine";

    private static SimpleCoroutine m_Instance = null;
    public static SimpleCoroutine Instance
    {
        get
        {
            if (m_Instance == null)
            {
                m_Instance = (new GameObject(m_SimpleCoroutineTransform)).AddComponent<SimpleCoroutine>();
                DontDestroyOnLoad(m_Instance.gameObject);
            }
            return m_Instance;
        }
    }
}