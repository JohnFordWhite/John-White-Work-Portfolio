﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        InterfaceUtils                                                                 *
 * FileExtension:   .cs                                                                            *
 * Author:          Evan Campbell                                                                  *
 * Date:            November 23th, 2016                                                            *
 *                                                                                                 *
 * This file contains useful static functions for creating Unity interface GameObjects (Buttons,   *
 * etc.) and adding them to the scene.                                                             *
 * There are also other useful functions related to Unity UI in this file.                         *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Evan Campbell) - November 23th, 2016                                      *
 * V 1.1 - Added Layout component disable function (Evan Campbell) - February 20, 2017             *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;

public class InterfaceUtils
{
    public const string TextGameObject = "Text";

    public static GameObject InstantiatePrefab(GameObject aParentObject, Object aPrefab, bool aWorldPositionStays = true)
    {
        GameObject newObject = GameObject.Instantiate(aPrefab) as GameObject;

        // Add object to a parent (if applicable)
        if (aParentObject != null && newObject != null)
        {
            newObject.transform.SetParent(aParentObject.transform, aWorldPositionStays);
        }

        return newObject;
    }

    public static Button MakeButton(Object aButtonPrefab, string aButtonText, UnityEngine.Events.UnityAction aCall)
    {
        return MakeButton(null, aButtonPrefab, aButtonText, aCall);
    }

    public static Button MakeButton(GameObject aParentPanel, Object aButtonPrefab, string aButtonText, UnityEngine.Events.UnityAction aCall)
    {
        GameObject buttonObject = GameObject.Instantiate(aButtonPrefab) as GameObject;
        Button button = buttonObject.GetComponent<Button>();
        if (button != null)
        {
            button.transform.FindChild(TextGameObject).GetComponent<Text>().text = aButtonText;
            // Sets this button to a child of a GameObject (e.g. "Panel" object)
            if (aParentPanel != null)
            {
                buttonObject.transform.SetParent(aParentPanel.transform, false);
            }
            // Adds the ActionListener
            if (aCall != null)
            {
                button.onClick.AddListener(aCall);
            }
            // Default ActionListener - error catching for development
#if UNITY_EDITOR
            else
            {
                button.onClick.AddListener(delegate { Debug.LogError("Button '" + aButtonText + "' not implemented. " + buttonObject.ToString()); });
            }
#endif

            return button;
        }

        return null;
    }

    // We need to disable as many Layout elements as we can that do not impact dynamically added components.
    // The reason why we need to disable them is that behind the scenes, Canvas.SendWillRenderCanvases gets called
    // periodically, and it is very expensive if there are a lot of enabled Layout components active.
    // Once the canvas is all set up with everything the correct size, there is no reason to keep these components
    // active after that if it will just slow down the game.
    // Some UI objects may require these components to stay active, e.g. UI elements that are dynamically added and
    // rely on correct positioning. In this case, include them in aIgnoreObjects and they will not be disabled.
    public static void DisableLayoutComponentsFromCanvas(Transform aCanvas, Transform[] aIgnoreObjects)
    {
        if (aCanvas != null)
        {
            if (aIgnoreObjects != null && aIgnoreObjects.Length > 0)
            {
                for (int i = 0; i < aIgnoreObjects.Length; i++)
                {
                    if (aCanvas == aIgnoreObjects[i])
                        return;
                }
            }

            // HorizontalLayoutGroup, VerticalLayoutGroup, GridLayoutGroup, etc.
            LayoutGroup layoutGroup = aCanvas.GetComponent<LayoutGroup>();
            if (layoutGroup != null)
                layoutGroup.enabled = false;

            // Sizing properties, e.g. Min width/height, preferred width/height, flexible width/height
            LayoutElement layoutElement = aCanvas.GetComponent<LayoutElement>();
            if (layoutElement != null)
                layoutElement.enabled = false;

            int childCount = aCanvas.childCount;
            for (int i = 0; i < childCount; i++)
            {
                Transform child = aCanvas.GetChild(i);

                DisableLayoutComponentsFromCanvas(child, aIgnoreObjects);
            }
        }
    }

    // Sets a ScrollRect's vertical scroll position. This assumes that all of the ScrollRect Content's children are the same height.
    public static void SetScrollViewViewportHeightPosition(ScrollRect aScrollRect, GameObject aContentPanel, int aSelectedIndex, int aContentChildCount)
    {
        float contentHeight = aContentPanel.GetComponent<RectTransform>().rect.height;
        float itemHeight = contentHeight / (float)aContentChildCount;

        float itemHeightPercent = itemHeight / contentHeight;

        float viewportY = 1.0f - (((float)aSelectedIndex / (float)aContentChildCount) - (itemHeightPercent / 2.0f));
        if (aSelectedIndex == 0 || aSelectedIndex == aContentChildCount - 1)
        {
            viewportY = Mathf.Round(viewportY);
        }
        viewportY = Mathf.Clamp01(viewportY);

        aScrollRect.verticalNormalizedPosition = viewportY;
    }

    public static void SetScrollViewViewportHeightPosition(ScrollRect aScrollRect, GameObject aContentPanel, int aSelectedIndex, int aContentChildCount, List<float> aChildHeights)
    {
        float contentHeight = aContentPanel.GetComponent<RectTransform>().rect.height;
        float prevItemHeightTotal = 0.0f;
        for (int i = 0; i < aSelectedIndex - 1; i++)
        {
            prevItemHeightTotal += aChildHeights[i];
        }

        float itemHeight = aChildHeights[aSelectedIndex];

        float itemHeightPercent = itemHeight / contentHeight;

        //float itemHeight = contentHeight / (float)aContentChildCount;

        //float itemHeightPercent = itemHeight / contentHeight;

        float viewportY = 1.0f - ((prevItemHeightTotal / contentHeight) - (itemHeightPercent / 2.0f));
        if (aSelectedIndex == 0 || aSelectedIndex == aContentChildCount - 1)
        {
            viewportY = Mathf.Round(viewportY);
        }
        viewportY = Mathf.Clamp01(viewportY);

        aScrollRect.verticalNormalizedPosition = viewportY;
    }
}
