﻿#if UNITY_EDITOR

// From Unity Docs
// https://docs.unity3d.com/Manual/CommandLineArguments.html

using System;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public class UnityProjectBuilder
{
    static string buildOutputPathFlag = "-buildOutputPath";

	static void PerformBuild()
    {
        // The build exe path is passed in as a command line argument.
        var commandLineArguments = System.Environment.GetCommandLineArgs();

        // Full path to the output exe file
        string buildExe = string.Empty;

        // To get the build exe path, find the -buildOutputPath flag.
        // The folder path we want is 1 after this.
        // The short .exe file name is 2 after this.
        for (int i = 0; i < commandLineArguments.Length; i++)
        {
            if (commandLineArguments[i] == buildOutputPathFlag)
            {
                buildExe = commandLineArguments[i + 1];

                // Make sure the folder path ends with a folder separator (slash)
                if ((buildExe.EndsWith("\\") || buildExe.EndsWith("/")) == false)
                {
                    // Use / instead of \ so it is cross platform.
                    buildExe += "/";
                }

                buildExe += Application.productName + ".exe";

                // in case there are any stray quotations in the passed in file path, we must remove them.
                buildExe.Replace("\"", "");
                break;
            }
        }

        Debug.Log("Build Exe File: " + buildExe);

        // All of the scenes we want to build are in here.
        EditorBuildSettingsScene[] scenes = EditorBuildSettings.scenes;

        // Do the Build
        BuildPipeline.BuildPlayer(scenes, buildExe, BuildTarget.StandaloneWindows64, BuildOptions.None);
    }
}

#endif