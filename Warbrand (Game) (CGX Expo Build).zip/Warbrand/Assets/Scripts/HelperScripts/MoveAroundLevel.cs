﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        MoveAroundLevel                                                                *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            February 7th, 2017                                                             *
 *                                                                                                 *
 * Handles moving the main camera around the arena during the main menu scene                      *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - February 7th, 2017                                          *
\***************************************************************************************************/

using UnityEngine;
using System.Linq;
using System.Collections;

public class MoveAroundLevel : MonoBehaviour
{
    public GameObject CameraWaypoints;

    private Transform m_StartMarker;
    private Transform m_EndMarker;
    private Transform[] m_Waypoints;
    private int m_CurrentStartPoint;
    private float m_StartTime;
    private float m_DistToNextPoint;
    private float m_MoveSpeed = 3.5f;
    private float m_RotationSpeed = 0.75f;

    void Start()
    {
        m_Waypoints = CameraWaypoints.GetComponentsInChildren<Transform>().Where(x => x.gameObject.transform.parent != transform.parent).ToArray();

        BeginFromStart();
    }

    void Update()
    {
        float distCovered = (Time.time - m_StartTime) * m_MoveSpeed;
        float fracJourney = distCovered / m_DistToNextPoint;

        transform.rotation = Quaternion.Slerp(transform.rotation, m_EndMarker.rotation, Time.deltaTime * m_RotationSpeed);
        transform.position = Vector3.Lerp(m_StartMarker.position, m_EndMarker.position, fracJourney);

        if (fracJourney >= 1f && m_CurrentStartPoint + 1 < m_Waypoints.Length)
        {
            m_CurrentStartPoint++;

            if (m_CurrentStartPoint != m_Waypoints.Length - 1)
            {
                SetPoints();
            }
            else
            {
                BeginFromStart();
            }
        }
    }

    void BeginFromStart()
    {
        m_CurrentStartPoint = 0;

        transform.position = m_Waypoints[m_CurrentStartPoint].transform.position;

        SetPoints();
    }

    void SetPoints()
    {
        m_StartMarker = m_Waypoints[m_CurrentStartPoint];
        m_EndMarker = m_Waypoints[m_CurrentStartPoint + 1];
        m_StartTime = Time.time;
        m_DistToNextPoint = Vector3.Distance(m_StartMarker.position, m_EndMarker.position);
    }
}
