﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        AudioUtils                                                                     *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            January 212th, 2017                                                            *
 *                                                                                                 *
 * Audio helper functions.                                                                         *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - January 212th, 2017                                         *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using UnityEngine.Audio;
using System.Collections.Generic;

public class AudioUtils : MonoBehaviour
{
    public static IEnumerator FadeOut(AudioSource aAudioSource, float aStartVolume, float aFadeTime)
    {
        if (aAudioSource != null)
        {
            float currentVolume = aAudioSource.volume;
            while (aAudioSource.volume > 0)
            {
                aAudioSource.volume -= currentVolume * Time.deltaTime / aFadeTime;

                yield return null;

                if (aAudioSource == null)
                {
                    yield break;
                }
            }

            aAudioSource.Stop();
            aAudioSource.volume = aStartVolume;
        }

    }

    public static IEnumerator FadeIn(AudioSource aAudioSource,float aStartVolume, float aEndVolume, float aFadeTime)
    {
        aAudioSource.volume = aStartVolume;

        if (aAudioSource != null)
        {
            float currentVolume = aAudioSource.volume;
            while (aAudioSource.volume < aEndVolume)
            {
                aAudioSource.volume += Time.deltaTime / aFadeTime;

                yield return null;

                if (aAudioSource == null)
                {
                    yield break;
                }
            }

            aAudioSource.volume = aEndVolume;
        }
    }

    public static void SetLPF(GameObject aAudioSourceHolder,string aMixerLowPassFilterParam)
    {
        AudioMixer m_MasterAudioMixer = aAudioSourceHolder.GetComponent<AudioSource>().outputAudioMixerGroup.audioMixer;

        Player closestPlayer = GetClosestPlayer(aAudioSourceHolder);

        float DistClosestPlayer = Vector3.Distance(aAudioSourceHolder.transform.position, closestPlayer.transform.position);

        float proximity = (aAudioSourceHolder.transform.position - closestPlayer.transform.position).magnitude;

        float effectPercentage = 1.0f;

        if (proximity>5)
            effectPercentage = 1 - (proximity / 20);

        float cutoffFrequency = 22000 * effectPercentage;
        if (cutoffFrequency < 2000)
            cutoffFrequency = 2000;

        //Debug.Log(cutoffFrequency);

        m_MasterAudioMixer.SetFloat(aMixerLowPassFilterParam, cutoffFrequency);
    }

    public static void SetVolumeByDistance(GameObject aAudioSourceHolder, bool aVolumeCanBeZero, float aMaxVolume = 1)
    {
        if (aAudioSourceHolder == null)
            return;

        Player closestPlayer = GetClosestPlayer(aAudioSourceHolder);

        if (closestPlayer == null)
            return;

        float DistClosestPlayer = Vector3.Distance(aAudioSourceHolder.transform.position, closestPlayer.transform.position);

        float newVolume = ((DistClosestPlayer - 40) / (1 - 40)) * 2;

        if(aVolumeCanBeZero)
            newVolume = Mathf.Clamp(newVolume, 0.0f, 1.0f);
        else
            newVolume = Mathf.Clamp(newVolume, 0.3f, 1.0f);

        if (newVolume > aMaxVolume)
            newVolume = aMaxVolume;

        aAudioSourceHolder.GetComponent<AudioSource>().volume = newVolume;

        //Debug.Log("newVolume: " + newVolume);
    }

    public static Player GetClosestPlayer(GameObject aObjectToCheckFrom)
    {
        List<Player> allPlayers = Information.AllHumanPlayers;

        float DistClosestPlayer = float.MaxValue;
        Player closestPlayer = null;
        
        for (int i = 0; i < allPlayers.Count; i++)
        {
            Player player = allPlayers[i];

            if (player == null)
                continue;

            if (Vector3.Distance(aObjectToCheckFrom.transform.position, player.transform.position) < DistClosestPlayer)
            {
                DistClosestPlayer = Vector3.Distance(aObjectToCheckFrom.transform.position, player.transform.position);
                closestPlayer = player;
            }
        }
        return closestPlayer;
    }
}