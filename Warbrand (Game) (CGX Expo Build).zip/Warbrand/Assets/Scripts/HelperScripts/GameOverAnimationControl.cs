﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameOverAnimationControl : MonoBehaviour
{
    private Animator m_PlayerAnimator1;
    private Animator m_PlayerAnimator2;
    private Animator m_PlayerAnimator3;
    private Animator m_PlayerAnimator4;
    private Animator m_PlayerAnimator5;
    private Animator m_PlayerAnimator6;
    private Animator m_PlayerAnimator7;
    private Animator m_PlayerAnimator8;

    List<Player> winningPlayers = new List<Player>();
    
    void Start()
    {
        ScoreboardPlayerRow[] players = InputManager.CM.GameModeManager.Scoreboard.TeamPanels[0].PlayersInTeam;
        for (int i = 0; i < InputManager.CM.Players.Count; i++)
        {
            Player player = InputManager.CM.Players[i].Input.Character;

            for (int j = 0; j < players.Length; j++)
            {
                int id = players[0].PlayerID;

                if (player.PlayerID == id)
                {
                    winningPlayers.Add(player);
                }
            }
        }

        for (int i = 0; i < winningPlayers.Count; i++)
        {
            //winningPlayers[i].gameObject.GetComponent<Animator>().SetTrigger(winningPlayers[i].Character.ToString() + "Victory");
        }
    }
    
    void Update()
    {




    }
}
