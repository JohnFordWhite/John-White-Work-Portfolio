﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Spawn Points                                                                   *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            October 13th, 2016                                                             *
 *                                                                                                 *
 * A manager class which holds all of the Spawn Points on the Map                                  *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - October 13th, 2016                                      *
\***************************************************************************************************/

using UnityEngine;

public class SpawnPoints : MonoBehaviour
{
    public static SpawnPoints Current = null;

    public Transform[] SpawnPointsList;

    private float m_LineDistance = 2.0f;

    void Start ()
    {
        if (Current != null)
            return;

        Current = this;
	}
}
