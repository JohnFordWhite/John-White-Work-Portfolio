﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ObjectPool
{
    private List<GameObject> m_Pool;

    private Transform m_PoolManagerTransform;

    private const string StringPoolManager = "PoolManager";

    public ObjectPool()
    {
        m_Pool = new List<GameObject>();

        GameObject PoolManager = GameObject.Find(StringPoolManager);
        if (PoolManager == null)
        {
            PoolManager = new GameObject(StringPoolManager);
            
            GameObject.DontDestroyOnLoad(PoolManager);
        }

        m_PoolManagerTransform = PoolManager.transform;
    }

    public void Initialize(int size)
    {
        m_Pool.Capacity = size;

        for (int i = 0; i < m_Pool.Capacity; i++)
        {
            m_Pool.Add(null);
        }
    }

    public void FillPoolWithPrefab(GameObject prefab, Transform parent = null, bool worldPositionStays = true)
    {
        for (int i = 0; i < m_Pool.Capacity; i++)
        {
            m_Pool[i] = MonoBehaviour.Instantiate(prefab);
            m_Pool[i].SetActive(false);
            if (parent == null)
            {
                m_Pool[i].transform.parent = m_PoolManagerTransform;
            }
            else
            {
                m_Pool[i].transform.SetParent(parent, worldPositionStays);
            }
        }
    }

    public void InitializeFirstInactiveObject(Transform aTransform)
    {
        GameObject obj = GetFirstInactiveObject();

        obj.SetActive(true);
        obj.transform.position = aTransform.position;
        obj.transform.rotation = aTransform.rotation;

        return;
    }

    public GameObject GetFirstInactiveObject()
    {
        for (int i = 0; i < m_Pool.Capacity; i++)
        {
            if (m_Pool[i] != null && m_Pool[i].activeInHierarchy == false)
            {
                return m_Pool[i];
            }
        }

#if UNITY_EDITOR
        DebugManager.Log("couldn't find any inactive objects", Developmer.AllDevelopmers);
#endif

        return null;
    }

    public List<GameObject> GetPool()
    {
        return m_Pool;
    }
}
