﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ThrowableComponent                                                             *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            October 14th, 2016                                                             *
 *                                                                                                 *
 * A component to add to any throwable object, detailing exactly what it is.                       *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - October 14th, 2016                                      *
\***************************************************************************************************/

using UnityEngine;

public enum ThrowableType
{
    None,
    TMNAdhesive,
    SmokeScreenGrenade,
    Turret,
    Camera,
    ElectricWall,
    PoisonDart
}

public class ThrowableComponent : MonoBehaviour
{
    ThrowableComponent(ThrowableType aType) { Type = aType; }
    ThrowableComponent() { }

    public ThrowableType Type = ThrowableType.None;
}
