﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Health : MonoBehaviour
{
    //
    // Public
    //
    public float StartingMaxHealth = 100f;
    public float CurrentHealth { get { return m_Health.Value; } set { m_Health.Value = value; } }
    public float MaxHealth { get { return m_Health.MaximumValue; } set { m_Health.MaximumValue = value; } }

    //
    // Private
    //
    private ClampedFloat m_Health;
    //private float m_WaitTimeBeforeRespawn = 0.1f;
    [SerializeField] private float EditorHealth; // Used to see the health in the editor
    private float m_PlayDamageSoundTimer = 5f;
    private float m_TimeBetweenDamageSounds = 5f;
    private float m_ChanceToPlayKilledPlayerDialogue = 0.05f;
    private float m_ChanceToPlayTurretKillDialogue = 0.05f;
    private Player m_ThisPlayer = null;
    private GameInputComponent m_InputComponent = null;
    public void InitHealth()
    {
        m_Health = new ClampedFloat(StartingMaxHealth, 0f, StartingMaxHealth);
    }

    void Start()
    {
        InitHealth();

        m_DamageTakenModifiers = new List<float>();
        m_DamageTakenModifiers.Capacity = 5;
        for (int i = 0; i < m_DamageTakenModifiers.Capacity; i++)
        {
            m_DamageTakenModifiers.Add(0.0f);
        }

        if (m_ThisPlayer == null)
        {
            m_ThisPlayer = gameObject.GetComponent<Player>();
        }
            
        if (m_ThisPlayer != null)
        {
            m_InputComponent = m_ThisPlayer.GameInput;
        }
    }

    void Update()
    {
        EditorHealth = CurrentHealth;
        m_PlayDamageSoundTimer -= Time.deltaTime;
    }

    public bool IsDead
    {
        get
        {
            return MathUtils.AlmostEquals((int)(m_Health.Value), (int)(m_Health.MinimumValue));
        }
    }
    public float HealthPercentage { get { return (m_Health.Value / m_Health.MaximumValue); } }
    public bool HasFullHealth { get { return MathUtils.AlmostEquals(m_Health.Value, m_Health.MaximumValue); } }

    public bool IsInvincible = false;

    private List<float> m_DamageTakenModifiers;
    private float m_DamageTakenPercent = 1;

    //Return true if this attack killed the player
    public bool Damage(Player aAttacker, GameObject aOrigin, float aDamage, DeathType aDeathType = DeathType.None, bool aSetAIDamageBehaviour = true, bool friendlyFire = false)
    {
        if(IsInvincible == true)
        {
            return false;
        }

        if(IsDead == true)
        {
            return true;
        }

        if(aDamage < 0f)
        {
            Heal(-aDamage);
            return false;
        }

        // Attacker gets a hit marker notification
        if (aAttacker != null)
        {
            int attackerTeam = aAttacker.TeamIndex;
            int myTeam = -1;
            
            if (m_ThisPlayer != null)
            {
                myTeam = m_ThisPlayer.TeamIndex;
            }
            // Make sure we don't get notification if attacking ourself.
            // Also prevent friendly fire if this is a teammate.
            if(!friendlyFire)
            {
                if (aAttacker == m_ThisPlayer ||
                    attackerTeam == myTeam)
                {
                    return false;
                }
            }
            // Show hitmarker on attacker's screen,
            // but not if the player is damaging themself!
            if (aAttacker != m_ThisPlayer)
            {
                aAttacker.HitTarget();
            }
        }

        if(m_ThisPlayer != null && aAttacker != null)
        {
            if (aSetAIDamageBehaviour)
            {
                if (m_ThisPlayer.IsAI)
                {
                    AICharacter aiCharacter = GetComponent<AICharacter>();

                    if (aiCharacter.AIBehaviour != null)
                        aiCharacter.SetDamageReaction(aAttacker.gameObject);
                }
            }
            if(m_ThisPlayer.IsAI == false && m_ThisPlayer.RecieveDamageIndicator && aOrigin)
                m_ThisPlayer.RecieveDamageIndicator.AddIndicator(aOrigin);
            
        }
        
        if (IsDead == false)
        {
            CurrentHealth -= aDamage * m_DamageTakenPercent;

            //Jostle lower spine a bit for visual notification of causing damage
            if (GetComponent<ManualBoneRotator>() != null && aDeathType != DeathType.PoisonGas)
            {
                GetComponent<ManualBoneRotator>().HandleRotationOnDamage();
            }

            if (m_PlayDamageSoundTimer <= 0 && m_ThisPlayer != null)
            {
                DialogueManager.Instance.PlayDialogue(m_ThisPlayer.Character, DialogueContext.Damage, false, true);
                m_PlayDamageSoundTimer = m_TimeBetweenDamageSounds;
            }

            // Death event
            // Traps and Quark's items have health, but we only want to register a Player death.
            if (IsDead && m_ThisPlayer != null)
            {
                if (aDeathType == DeathType.Turret)
                {
                    bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayTurretKillDialogue;
                    if (playDialogue)
                    {
                        DialogueManager.Instance.PlayDialogue(CharacterTypes.Quark, DialogueContext.QuarkTurretGetsKill, true, false);
                    }
                }

                else if (aAttacker != null)
                {
                    DialogueContext dialogueContext = DialogueContext.None;

                    switch (m_ThisPlayer.Character)
                    {
                        case CharacterTypes.Paige:
                            dialogueContext = DialogueContext.KilledPaige;
                            break;
                        case CharacterTypes.Quark:
                            dialogueContext = DialogueContext.KilledQuark;
                            break;
                        case CharacterTypes.Leeroy:
                            dialogueContext = DialogueContext.KilledLeeroy;
                            break;
                        case CharacterTypes.Zeph:
                            dialogueContext = DialogueContext.KilledZeph;
                            break;
                        default:
                            break;
                    }

                    bool playDialogue = UnityEngine.Random.value < m_ChanceToPlayKilledPlayerDialogue;
                    if (playDialogue)
                    {
                        DialogueManager.Instance.PlayDialogue(aAttacker.Character, dialogueContext, true, false);
                    }

                }

                GameModeManager game = InputManager.CM.GameModeManager;

                if (game != null && game.CurrentGameMode != null)
                {
                    // Register death

                    string attackerName = string.Empty;
                    int attackerTeam = 0;
                    string defenderName = string.Empty;
                    int defenderTeam = 0;

                    if (m_InputComponent != null)
                    {
                        game.CurrentGameMode.IncrementDeathCount(m_ThisPlayer);

                        defenderName = m_InputComponent.LongPlayerName;
                        defenderTeam = m_InputComponent.TeamIndex;

                        if (aAttacker != null && aAttacker.transform.parent != null)
                        {
                            GameInputComponent enemyInputComponent = aAttacker.GameInput;
                            if (enemyInputComponent != null)
                            {
                                attackerName = enemyInputComponent.LongPlayerName;
                                attackerTeam = enemyInputComponent.TeamIndex;
                            }
                        }
                    }

                    // Register kill - This needs to occur AFTER registering a death. This gives certain game modes (namely Juggernaut)
                    // a chance to unregister the current Juggernaut before a new one can be set.
                    // Traps and Quark's items have health, but we only want to register a Player kill.

                    // Notify attacker of kill
                    if (aAttacker != null)
                    {
                        if (aAttacker != m_ThisPlayer && aAttacker.TeamIndex != m_ThisPlayer.TeamIndex)
                            game.CurrentGameMode.IncrementKillCount(aAttacker);
                    }

                    // Update kill feed
                    KillFeedService.Instance.RegisterKill(attackerName, attackerTeam, defenderName, defenderTeam);
                }

                if (m_ThisPlayer.IsAI)
                {
                    AICharacter aiCharacter = GetComponent<AICharacter>();

                    if (aiCharacter.AIBehaviour != null)
                        aiCharacter.AIBehaviour.ClearAIBehaviour();
                }
            }
            else if(IsDead && aAttacker != null)
            {
                if (gameObject.GetComponent<ExplosiveBarrel>() != null)
                {
                    gameObject.GetComponent<ExplosiveBarrel>().Exploder = aAttacker;
                }
                else if (gameObject.GetComponent<ShockBarrel>() != null)
                {
                    gameObject.GetComponent<ShockBarrel>().Exploder = aAttacker;
                }
            }
        }

        Paige paige = gameObject.GetComponent<Paige>();
        if (paige != null)
        {
            paige.HealingAbility.AbilityInterrupted = true;
        }

        if (IsDead && m_ThisPlayer != null)
        {
            if (m_ThisPlayer.IsAI == false)
            {
                m_ThisPlayer.PersonalKillNotification.SetKilledByPlayer(aAttacker);
            }

            Kill();
            switch (aDeathType)
            {
                case DeathType.Fan:
                    AchievementsManager.IncrementInteger(GetComponent<Player>(), Achievements.KilledByFan, 1);
                    break;
                case DeathType.Spikes:
                    AchievementsManager.IncrementInteger(GetComponent<Player>(), Achievements.KilledBySpikeTrap, 1);
                    break;
                case DeathType.PoisonGas:
                    AchievementsManager.IncrementInteger(GetComponent<Player>(), Achievements.KilledByGasTrap, 1);
                    break;
            }
        }

        if(IsDead)
        {
            TurretScript turret = GetComponent<TurretScript>();

            if (turret)
            {
                if (turret.Owner.IsAI)
                    turret.Owner.GetComponent<QuarkAICharacter>().NotifyTurretDestroyed(gameObject);
            }
        }

        if (m_ThisPlayer != null)
            AchievementsManager.IncrementFloat(m_ThisPlayer, Achievements.DamageTaken, aDamage);
        if (aAttacker != null)
            AchievementsManager.IncrementFloat(aAttacker, Achievements.DamageGiven, aDamage);

        if (IsDead)
        {
            if(m_ThisPlayer != null)
            {
                m_ThisPlayer.deathType = aDeathType;
            }
            return true;
        }

        return false;
    }

    public void Heal(float aHeal)
    {
        if (aHeal == 0f)
            return;
        if (aHeal < 0f)
        {
            Damage(null, null, -aHeal);
            return;
        }
        
        CurrentHealth += aHeal;
        if (m_ThisPlayer != null)
            AchievementsManager.IncrementFloat(m_ThisPlayer, Achievements.MostHealthHealed, aHeal);
    }

    public void Kill(bool aSpawnRagdoll = true)
    {
        CurrentHealth = 0;

        if (m_ThisPlayer != null)
        {
            RemoveAllModifiers();

            m_ThisPlayer.LastDeathTime = Time.time;

            InputManager.CM.GameModeManager.RespawnPlayer(m_ThisPlayer, aSpawnRagdoll);
        }
    }

    public void AddDamageTakenModifier(float modifier)
    {
        AddRemoveModifier.AddModifier(ref m_DamageTakenModifiers, modifier);
        AddRemoveModifier.UpdateModifierPercent(ref m_DamageTakenModifiers, ref m_DamageTakenPercent);
    }

    public void RemoveDamageTakenModifier(float modifier)
    {
        AddRemoveModifier.RemoveModifier(ref m_DamageTakenModifiers, modifier);
        AddRemoveModifier.UpdateModifierPercent(ref m_DamageTakenModifiers, ref m_DamageTakenPercent);
    }

    public void RemoveAllModifiers()
    {
        AddRemoveModifier.RemoveAllModifiers(ref m_DamageTakenModifiers);
    }

    //IEnumerator WaitThenRespawn(float aTimeToWait)
    //{
    //    yield return new WaitForSeconds(aTimeToWait);

    //    // Only respawn if game is in progress.
    //    GameInputComponent GameInput = gameObject.GetComponent<Player>().GameInput;

    //    GameModeManager game = InputManager.CM.GameModeManager;
    //    if (game != null && game.CurrentGameMode != null &&
    //        game.CurrentGameMode.GameCondition == GameCondition.GameInProgress &&
    //        game.CurrentGameMode.IsPlayerDisqualified(GameInput.PlayerID) == false)
    //    {
    //        gameObject.GetComponent<Player>().SpawnPlayer();
    //    }
    //}
}

public enum DeathType
{
    None,
    Fan,
    Spikes, 
    PoisonGas,
    PoisonDart,
    Physics,
    Turret,
    MAX_DEATH_TYPES
}