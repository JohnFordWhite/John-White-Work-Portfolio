﻿using UnityEngine;
using System.Collections;

public class ObjectiveHelper
{
    private const string StringGroundTag = "Ground";

    /// <summary>
    /// Calculates the point of this objective on the ground for the purpose
    /// of NavMesh navigation.
    /// </summary>
    public static Vector3 GetObjectivePositionAtGround(GameObject aObjective, float aMaxDistanceDown = 10.0f)
    {
        Vector3 pointAtGround = Vector3.zero;

        RaycastHit[] hitInfo;
        Vector3 direction = aObjective.transform.up * -1.0f;
        float maxDistance = 10.0f;

        hitInfo = Physics.RaycastAll(aObjective.transform.position, direction, maxDistance);

        if (hitInfo != null && hitInfo.Length > 0)
        {
            float minDistance = float.MaxValue;
            for (int i = 0; i < hitInfo.Length; i++)
            {
                RaycastHit hit = hitInfo[i];

                if (hit.transform.tag == StringGroundTag)
                {
                    Vector3 hitPoint = hit.point;
                    float distance = Vector3.Distance(aObjective.transform.position, hitPoint);
                    if (distance < minDistance)
                    {
                        minDistance = distance;
                        pointAtGround = hitPoint;
                    }
                }
            }
        }

        return pointAtGround;
    }
}