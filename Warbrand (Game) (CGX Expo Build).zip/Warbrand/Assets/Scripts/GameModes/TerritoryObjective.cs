﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TerritoryObjective : MonoBehaviour
{
    public Renderer ZoneRenderer;
    public Renderer FlagRenderer;

    // How long it takes to capture a territory from a neutral state.
    public const float TerritoryCaptureTime = 5.0f;
    public const float AnimationTimeModifier = 16.0f;

    public List<Player> PlayersInsideTerritory;
    public List<int> TeamsInsideTerritory;

    protected Color m_NeutralTerritoryColor;

    protected GameModeManager m_GameModeManager;

    private const string StringCurrentHillColor = "_CurrentHillColor";
    private const string StringCapturingHillColor = "_CapturingHillColor";
    private const string StringCaptureAmount = "_CaptureAmount";
    private const string StringBorderAlpha = "_BorderAlpha";

    protected Color m_CurrentTerritoryColor;

    public bool FullyOwned
    {
        get
        {
            return MathUtils.AlmostEquals(m_TerritoryOwnershipAmount, TerritoryCaptureTime);
        }
    }

    public int m_TerritoryOwnerTeam { get; protected set; }
    protected Player m_TerritoryOwner;
    protected float m_TerritoryOwnershipAmount;
    protected bool m_IsHillContested;
    protected float m_TimeContested = 0;
    protected float m_BorderAlpha = 1;

    public Vector3 PointAtGround { get { return m_PointAtGround; } }
    protected Vector3 m_PointAtGround;

	// Use this for initialization
	void Start ()
    {
        PlayersInsideTerritory = new List<Player>();
        TeamsInsideTerritory = new List<int>();

        int neutralTerritoryColorIndex = BaseGameMode.TeamColors.Length - 1;

        m_NeutralTerritoryColor = BaseGameMode.TeamColors[neutralTerritoryColorIndex];
        m_CurrentTerritoryColor = m_NeutralTerritoryColor;

        m_GameModeManager = InputManager.CM.GameModeManager;

        m_TerritoryOwnerTeam = -1;
        m_TerritoryOwner = null;
        m_TerritoryOwnershipAmount = 0.0f;
        m_IsHillContested = false;

        SetShaderProperties();

        // Calculate the point on the ground for the AI players.
        m_PointAtGround = ObjectiveHelper.GetObjectivePositionAtGround(gameObject);
    }
	
	// Update is called once per frame
	void Update ()
    {
	    // Only add score to the owner of territory.
        if (m_TerritoryOwner != null)
        {
            GameInputComponent inputComponent = m_TerritoryOwner.GameInput;

            m_GameModeManager.CurrentGameMode.IncrementTimeScore(inputComponent.TeamIndex, inputComponent.PlayerID, Time.deltaTime);
        }

        // There is only one player team inside the territory.
        // If there are multiple players on the same team inside the territory,
        // the objective will be captured faster.
        if (TeamsInsideTerritory.Count == 1)
        {
            // Loop over all players to determine who is in the territory right now.
            for (int i = 0; i < PlayersInsideTerritory.Count; i++)
            {
                Player player = PlayersInsideTerritory[i];

                // The territory is currently owned by a player
                if (m_TerritoryOwner != null)
                {
                    // If this player's team currently owns the hill, start re-capturing the territory.
                    if (player.TeamIndex == m_TerritoryOwner.TeamIndex)
                    {
                        m_TerritoryOwnershipAmount += Time.deltaTime;
                        if (m_TerritoryOwnershipAmount > TerritoryCaptureTime)
                        {
                            m_TerritoryOwnershipAmount = TerritoryCaptureTime;
                            m_IsHillContested = false;
                        }
                    }
                    // This player is currently trying to attack the territory
                    else
                    {
                        m_TerritoryOwnershipAmount -= Time.deltaTime;
                        m_IsHillContested = true;
                        if (m_TerritoryOwnershipAmount < 0)
                        {
                            m_TerritoryOwnershipAmount = 0;
                            m_TerritoryOwner = null;
                            // Allows this player's team to start capturing the territory.
                            m_TerritoryOwnerTeam = player.TeamIndex;
                            //m_CurrentTerritoryColor = BaseGameMode.TeamColors[TeamsInsideTerritory[0]];
                        }
                    }
                }
                // The territory is currently neutral
                else
                {
                    // This player's team is the same team that is capturing the territory.
                    if (player.TeamIndex == m_TerritoryOwnerTeam)
                    {
                        m_TerritoryOwnershipAmount += Time.deltaTime;
                        m_IsHillContested = true;
                        if (m_TerritoryOwnershipAmount > TerritoryCaptureTime)
                        {
                            m_TerritoryOwnershipAmount = TerritoryCaptureTime;
                            m_TerritoryOwner = player;
                        }
                    }
                    // This player is not on the same team as the one currently capturing the territory
                    else
                    {
                        m_TerritoryOwnershipAmount -= Time.deltaTime;
                        m_IsHillContested = true;
                        if (m_TerritoryOwnershipAmount < 0)
                        {
                            m_TerritoryOwnershipAmount = 0;
                            // Allows this player's team to start capturing the hill.
                            m_TerritoryOwnerTeam = player.TeamIndex;
                            //m_CurrentTerritoryColor = BaseGameMode.TeamColors[TeamsInsideTerritory[0]];
                        }
                    }
                }
            }
        }
        else if (TeamsInsideTerritory.Count > 1)
        {
            m_IsHillContested = true;
        }

        if ((m_TerritoryOwnershipAmount >= TerritoryCaptureTime &&
            TeamsInsideTerritory.Count <= 1) ||
            m_TerritoryOwnerTeam == -1)
        {
            m_IsHillContested = false;
            if (m_TerritoryOwnerTeam < 0)
            {
                m_CurrentTerritoryColor = m_NeutralTerritoryColor;
            }
            else
            {
                m_CurrentTerritoryColor = BaseGameMode.TeamColors[m_TerritoryOwnerTeam];
            }
        }
        else
        {
            float lerpAmount = (Mathf.Sin(Time.time * AnimationTimeModifier) + 1.0f) / 2.0f;

            m_CurrentTerritoryColor = BaseGameMode.TeamColors[m_TerritoryOwnerTeam];
        }

        if (m_IsHillContested)
        {
            m_TimeContested += Time.deltaTime;
            m_BorderAlpha = (Mathf.Cos(m_TimeContested * 5.0f) + 1.0f) * 0.5f;
        }
        else
        {
            m_BorderAlpha = Mathf.Lerp(m_BorderAlpha, 1, Time.deltaTime * 3);
        }

        DecreaseIfEmpty();

        SetShaderProperties();
	}

    void DecreaseIfEmpty()
    {
        float captureAmount = m_TerritoryOwnershipAmount / TerritoryCaptureTime;
        if (PlayersInsideTerritory.Count == 0 && !(MathUtils.AlmostEquals(captureAmount, 1f)))
        {
            m_IsHillContested = false;
            m_CurrentTerritoryColor = m_NeutralTerritoryColor;
            if (m_TerritoryOwnershipAmount > 0f)
                m_TerritoryOwnershipAmount -= Time.deltaTime;
            else
                m_TerritoryOwnershipAmount = 0f;
        }
    }

    void OnTriggerEnter(Collider other)
    {
        PlayerHitboxScript playerHitboxScript = other.gameObject.GetComponent<PlayerHitboxScript>();

        if (playerHitboxScript != null)
        {
            Player player = playerHitboxScript.Owner;

            if (player != null)
            {
                if (PlayersInsideTerritory.Contains(player) == false)
                {
                    //DebugManager.Log("Hill: OnTriggerEnter: " + other.transform.ToString(), Developmer.Evan);
                    PlayersInsideTerritory.Add(player);

                    if (TeamsInsideTerritory.Contains(player.TeamIndex) == false)
                    {
                        TeamsInsideTerritory.Add(player.TeamIndex);
                    }
                }
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        PlayerHitboxScript hitbox = other.gameObject.GetComponent<PlayerHitboxScript>();
        if (hitbox)
        {
            Player player = hitbox.Owner;

            if (player != null)
            {
                if (PlayersInsideTerritory.Contains(player))
                {
                    //DebugManager.Log("Hill: OnTriggerExit: " + other.transform.ToString(), Developmer.Evan);
                    PlayersInsideTerritory.Remove(player);

                    // After removing a player, we need to see if any more players in the
                    // hill are on this team. If not, remove the team index from the hill.
                    int teamIndex = player.TeamIndex;
                    bool teamInHill = false;
                    for (int i = 0; i < PlayersInsideTerritory.Count; i++)
                    {
                        if (PlayersInsideTerritory[i].TeamIndex == teamIndex)
                        {
                            teamInHill = true;
                            break;
                        }
                    }

                    if (teamInHill == false)
                    {
                        TeamsInsideTerritory.Remove(teamIndex);
                    }
                }
            }
        }
    }

    public Color CurrentTerritoryColor()
    {
        return m_CurrentTerritoryColor;
    }

    public bool IsPlayerInsideObjective(GameObject aPlayer)
    {
        Player checkedPlayer = aPlayer.GetComponent<Player>();

        for (int i = 0; i < PlayersInsideTerritory.Count; i++)
        {
            Player player = PlayersInsideTerritory[i];

            if (player == checkedPlayer)
                return true;
        }

        return false;
    }

    void SetShaderProperties()
    {
        float captureAmount = m_TerritoryOwnershipAmount / TerritoryCaptureTime;
        ZoneRenderer.materials[0].SetColor(StringCurrentHillColor, m_NeutralTerritoryColor);
        ZoneRenderer.materials[0].SetColor(StringCapturingHillColor, m_CurrentTerritoryColor);
        ZoneRenderer.materials[0].SetFloat(StringCaptureAmount, captureAmount);
        ZoneRenderer.materials[0].SetFloat(StringBorderAlpha, m_BorderAlpha);

        ZoneRenderer.materials[1].SetColor(StringCurrentHillColor, m_NeutralTerritoryColor);
        ZoneRenderer.materials[1].SetColor(StringCapturingHillColor, m_CurrentTerritoryColor);
        ZoneRenderer.materials[1].SetFloat(StringCaptureAmount, captureAmount);
        ZoneRenderer.materials[1].SetFloat(StringBorderAlpha, m_BorderAlpha);

        FlagRenderer.materials[0].SetColor(StringCurrentHillColor, m_NeutralTerritoryColor);
        FlagRenderer.materials[0].SetColor(StringCapturingHillColor, m_CurrentTerritoryColor);
        FlagRenderer.materials[0].SetFloat(StringCaptureAmount, captureAmount);
    }
}
