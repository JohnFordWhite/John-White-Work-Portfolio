﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public abstract class BaseGameMode
{
    public static float MIN_SPAWN_DISTANCE = 30.0f;

	public static Color[] TeamColors =
	{
		new Color(0.843f, 0.270f, 0.270f, 1.0f), //Red,    #D74545
		//new Color(0.207f, 0.207f, 0.572f, 0.5f), //Blue,   #353592
        new Color(0.300f, 0.300f, 1.000f, 1.0f), //Blue,   #4D4DFF
		new Color(0.733f, 0.643f, 0.000f, 1.0f), //Yellow, #BBA400
		new Color(0.105f, 0.505f, 0.105f, 1.0f), //Green,  #1B811B
		//new Color(0.415f, 0.027f, 0.415f, 0.5f), //Purple, #6A076A
        new Color(0.615f, 0.227f, 0.615f, 1.0f), //Purple, #9D3A9D
		new Color(0.000f, 0.647f, 0.647f, 1.0f), //Cyan,   #00A5A5
		new Color(0.894f, 0.501f, 0.003f, 1.0f), //Orange, #E48001
		new Color(0.800f, 0.427f, 0.800f, 1.0f), //Pink,   #CC6DCC
		new Color(0.870f, 0.870f, 0.870f, 1.0f), //Grey (MAX_TEAM_COLORS)
	};

    public static readonly string[] TeamNames =
    {
        "Red Team",
        "Blue Team",
        "Yellow Team",
        "Green Team",
        "Purple Team",
        "Cyan Team",
        "Orange Team",
        "Pink Team"
    };

    public abstract string GameModeName();

	public float ScoreLimit;
	public float TimeLimit;

	// Elapsed play time
	public float ElapsedTime { get; protected set; }

	// How often should the formatted game timer string should be updated
	public float UpdateFormattedStringTimerInterval = 0.1f;

	public float ElapsedTimeUpdateTimer { get; protected set; }

	public GameCondition GameCondition { get; protected set; }

	protected string m_TimeFormattedString;

	protected GameModeManager m_GameModeManager;

	public virtual void Setup()
	{
		m_GameModeManager = InputManager.CM.GameModeManager;
	}

	public virtual GameCondition CheckGameCondition(float aDeltaTime)
	{
		if (GameCondition == GameCondition.GameInProgress)
		{
			if (TimeLimit > 0.0f)
			{
				if (ElapsedTime > TimeLimit)
				{
					GameCondition = GameCondition.GameCompleted;
                    ElapsedTime = TimeLimit;
				}
			}
		}

		return GameCondition;
	}

	public virtual void IncrementKillCount(Player aPlayer, int aAmount = 1, bool aIncrementScore = true)
	{
        if (m_GameModeManager.CurrentGameMode.GameCondition == GameCondition.GameInProgress)
		{
            List<ScoreboardTeamPanel> TeamPanels = m_GameModeManager.Scoreboard.TeamPanels;

            // Loop over all teams to get the team to award the point to
            for (int i = 0; i < TeamPanels.Count; i++)
            {
                if (aPlayer.TeamIndex == TeamPanels[i].TeamID)
                {
                    // Loop over all players in this team to determine who to award the point to
                    for (int j = 0; j < TeamPanels[i].PlayersInTeam.Length; j++)
                    {
                        if (aPlayer.PlayerID == TeamPanels[i].PlayersInTeam[j].PlayerID)
                        {
                            TeamPanels[i].PlayersInTeam[j].IncrementKillCount(aAmount, aIncrementScore);
                            TeamPanels[i].UpdateTeamScoreboard();

                            break;
                        }
                    }

                    break;
                }
            }

            m_GameModeManager.Scoreboard.SortScoreboard();
        }
    }

	public virtual void IncrementDeathCount(Player aPlayer, int aAmount = 1, bool aIncrementScore = false)
	{
		if (m_GameModeManager.CurrentGameMode.GameCondition == GameCondition.GameInProgress)
		{
            List<ScoreboardTeamPanel> TeamPanels = m_GameModeManager.Scoreboard.TeamPanels;

            // Loop over all teams to get the team to award the point to
            for (int i = 0; i < TeamPanels.Count; i++)
            {
                if (aPlayer.TeamIndex == TeamPanels[i].TeamID)
                {
                    // Loop over all players in this team to determine who to award the point to
                    for (int j = 0; j < TeamPanels[i].PlayersInTeam.Length; j++)
                    {
                        if (aPlayer.PlayerID == TeamPanels[i].PlayersInTeam[j].PlayerID)
                        {
                            TeamPanels[i].PlayersInTeam[j].IncrementDeathCount(aAmount, aIncrementScore);
                            TeamPanels[i].UpdateTeamScoreboard();

                            break;
                        }
                    }

                    break;
                }
            }

            m_GameModeManager.Scoreboard.SortScoreboard();
        }
    }

	// Each game mode subclass may need to implement or accumulate time score differently.

	// Accumulates score for one player, based on player ID
	public virtual void IncrementTimeScore(int aTeamIndex, int aPlayerID, float aTime) { }

	// Accumulates selected players' score.
	public virtual void IncrementTimeScoreSelected(List<Player> aPlayers, float aTime) { }

	// Accumulates score for all players - condition can be customized inside inherited function.
	// This function is faster than the single score method if you need to add score to all players based on condition.
	public virtual void IncrementTimeScoreAll(float aTime) { }

	public virtual string GetGameModeFormattedTime()
	{
		return m_TimeFormattedString;
	}

	protected void UpdateTimers(float aDeltaTime)
	{
		// Only update timer if not paused
		if (InputManager.CM.CurrentGameState == GameState.PlayGame)
		{
			ElapsedTime += aDeltaTime;
			ElapsedTimeUpdateTimer += aDeltaTime;


			if (ElapsedTimeUpdateTimer > UpdateFormattedStringTimerInterval)
			{
                m_GameModeManager.Scoreboard.UpdateTimers(ElapsedTime);
				ElapsedTimeUpdateTimer = 0;
			}
		}
	}

	public abstract bool IsPlayerDisqualified(Player aPlayer);

	public virtual void ResetGameMode()
	{
		GameCondition = GameCondition.GameNotStarted;
		ElapsedTime = 0;
		ElapsedTimeUpdateTimer = 0;
	}

	public virtual IEnumerator HandleLateSetup()
	{
		GameCondition = GameCondition.GameInProgress;

        m_GameModeManager.Scoreboard.SetupFooterPanel(ScoreLimit, TimeLimit);

		yield return null;
	}

	public virtual Transform[] GetCurrentObjectiveLocations()
	{
		return null;
	}

	public virtual Color[] GetCurrentObjectiveColors()
	{
		Color[] colors = { Color.white };

		return colors;
	}

    public abstract GameModeType GetGameModeType();

    public virtual GameObject GetSpawnPointForPlayer(Player aPlayer)
    {
        // Calculate the spawn point that is farthest away from all of the action.

        float largestDistance = 0;
        int largestDistanceIndex = 0;

        GameObject[] spawnPoints = Information.SpawnPoints;

        if (spawnPoints == null || spawnPoints.Length <= 0)
            return null;

        List<Player> players = Information.AllPlayers;
        if (players == null || players.Count <= 0)
            return null;

        // TODO: cache this dictionary so it's not recreated every respawn

        // <spawn point array index, distance>
        Dictionary<int, float> spawnPointDistances = new Dictionary<int, float>();

        List<GameObject> acceptableSpawnPoints = new List<GameObject>();

        GameObject farthestSpawnPoint = null;

        // If this is the first player to spawn, just give them a random spawn point.
        // GameModeManager.FirstPlayerHasSpawned is initially set to false on a new game.
        if (GameModeManager.FirstPlayerHasSpawned == false)
        {
            farthestSpawnPoint = GetRandomSpawnPoint();
            GameModeManager.FirstPlayerHasSpawned = true;
        }
        // After the first player, find a spawn point that is farthest away from all of the players.
        else
        {
            // Loop over spawn points
            for (int i = 0; i < spawnPoints.Length; i++)
            {
                // Default the closest distance for this spawn point to the max possible value.
                spawnPointDistances[i] = float.MaxValue;

                GameObject spawnPoint = spawnPoints[i];

                Vector3 spawnPointPosition = spawnPoint.transform.position;

                // Loop over all players
                for (int j = 0; j < players.Count; j++)
                {
                    Player player = players[j];

                    // Ignore this player
                    if (player == aPlayer)
                        continue;

                    Vector3 playerPosition = player.transform.position;

                    float distance = Vector3.Distance(playerPosition, spawnPointPosition);

                    // Store the closest value
                    if (distance < spawnPointDistances[i])
                    {
                        spawnPointDistances[i] = distance;
                    }
                }
            }

            // At this point, we have recorded the relative distance from each spawn point to its closest player.
            // Loop over all dictionary distances to get the greatest distance of all spawn points.
            for (int i = 0; i < spawnPoints.Length; i++)
            {
                // Record new largest distance and spawn point index
                if (spawnPointDistances[i] > largestDistance)
                {
                    largestDistance = spawnPointDistances[i];
                    largestDistanceIndex = i;
                }
                // Keep track of any spawn points that are greater than the min spawn distance.
                if (spawnPointDistances[i] > MIN_SPAWN_DISTANCE && aPlayer.InitialSpawned == true)
                {
                    acceptableSpawnPoints.Add(spawnPoints[i]);
                }
            }

            // If there are some acceptable spawn points, get a random one
            if (acceptableSpawnPoints.Count > 0)
            {
                int spawnPointIndex = UnityEngine.Random.Range(0, acceptableSpawnPoints.Count - 1);

                farthestSpawnPoint = acceptableSpawnPoints[spawnPointIndex];
            }
            // Default to the known farthest spawn point
            else
            {
                farthestSpawnPoint = spawnPoints[largestDistanceIndex];
            }

            // If for some reason one wasn't found just use a random one.
            if (farthestSpawnPoint == null)
            {
                farthestSpawnPoint = GetRandomSpawnPoint();
            }
        }

        return farthestSpawnPoint;
    }

    public virtual GameObject GetRandomSpawnPoint()
    {
        GameObject[] spawnPoints = Information.SpawnPoints;

        if (spawnPoints == null || spawnPoints.Length <= 0)
            return null;

        return spawnPoints[UnityEngine.Random.Range(0, spawnPoints.Length)];
    }
}

// A Game mode that does not do anything to handle any kind of end condition. It is simply in progress after it is setup.
public class FreePlayGameMode : BaseGameMode
{
    public override string GameModeName()
    {
        return GameModeManager.StringTitleFreePlayGameMode;
    }

    public override GameCondition CheckGameCondition(float aDeltaTime)
	{
		if (GameCondition == GameCondition.GameInProgress)
		{
			UpdateTimers(aDeltaTime);
		}

		return GameCondition;
	}

	public override bool IsPlayerDisqualified(Player aPlayer)
	{
		return false;
	}

	public override void Setup()
	{
		base.Setup();
	}

    public override GameModeType GetGameModeType()
    {
        return GameModeType.FreePlayGameMode;
    }
}