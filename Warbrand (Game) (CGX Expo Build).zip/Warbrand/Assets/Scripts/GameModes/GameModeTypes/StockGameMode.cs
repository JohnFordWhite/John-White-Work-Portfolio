﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

// A Game mode that ends when one player remains after all remaining players run out of lives.
public class StockGameMode : BaseGameMode
{
	public float SortScoreboardInterval = 0.25f;
	protected float m_CurrentSortInterval;

	public float UpdateTimeInGameStringInterval = 0.25f;
	protected float m_CurrentUpdateTimeInterval;

    public override string GameModeName()
    {
        return GameModeManager.StringTitleStockGameMode;
    }

    public override GameCondition CheckGameCondition(float aDeltaTime)
	{
		if (GameCondition == GameCondition.GameInProgress)
		{
			UpdateTimers(aDeltaTime);

			base.CheckGameCondition(aDeltaTime);

			if (GameCondition == GameCondition.GameInProgress)
			{
				// Update the alive time for all players still in the game.
				IncrementTimeScoreAll(aDeltaTime);

				m_CurrentSortInterval += aDeltaTime;
				if (m_CurrentSortInterval > SortScoreboardInterval)
				{
                    List<ScoreboardTeamPanel> TeamPanels = m_GameModeManager.Scoreboard.TeamPanels;
                    for (int i = 0; i < TeamPanels.Count; i++)
                    {
                        TeamPanels[i].UpdateTeamScoreboard();
                    }

                    m_GameModeManager.Scoreboard.SortScoreboard();
					//SortScoreboard();
					m_CurrentSortInterval = 0.0f;
				}

                // End game if only one team has lives remaining.
                {
                    int numTeamsAlive = 0;

                    List<ScoreboardTeamPanel> TeamPanels = m_GameModeManager.Scoreboard.TeamPanels;
                    for (int i = 0; i < TeamPanels.Count; i++)
                    {
                        ScoreboardPlayerRow[] playerRows = TeamPanels[i].PlayersInTeam;
                        for (int j = 0; j < playerRows.Length; j++)
                        {
                            // As soon as we know that one player in this team is alive,
                            // we can add 1 to teams alive and proceed to the next team.
                            if (playerRows[j].PlayerDeaths < ScoreLimit)
                            {
                                numTeamsAlive++;
                                break;
                            }
                        }
                        // We can stop looping as soon as we know about 2 players that are still playing.
                        if (numTeamsAlive >= 2)
                        {
                            break;
                        }
                    }

                    if (numTeamsAlive <= 1)
                    {
                        GameCondition = GameCondition.GameCompleted;
                    }
                }
			}
		}

		return GameCondition;
	}

    public override void IncrementKillCount(Player aPlayer, int aAmount = 1, bool aIncrementScore = false)
    {
        base.IncrementKillCount(aPlayer, aAmount, false);
    }

    public override void IncrementDeathCount(Player aPlayer, int aAmount = 1, bool aIncrementScore = true)
    {
        base.IncrementDeathCount(aPlayer, aAmount, true);

        if (IsPlayerDisqualified(aPlayer) == true)
        {
            m_GameModeManager.Scoreboard.MarkPlayerAsDisqualified(aPlayer);
        }
    }

    public override void Setup()
	{
		base.Setup();

		m_CurrentUpdateTimeInterval = 0.0f;
		m_CurrentSortInterval = 0.0f;
	}

    public override IEnumerator HandleLateSetup()
    {
        m_GameModeManager.Scoreboard.ScoreLimit = ScoreLimit;
        m_GameModeManager.Scoreboard.SetupLivesScoring();

        return base.HandleLateSetup();
    }

    // Increment score for all players if they have lives remaining
    public override void IncrementTimeScoreAll(float aTime)
	{
		if (m_GameModeManager.CurrentGameMode.GameCondition == GameCondition.GameInProgress)
		{
			bool updateTimeString = false;

			m_CurrentUpdateTimeInterval += aTime;
			if (m_CurrentUpdateTimeInterval > UpdateTimeInGameStringInterval)
			{
				m_CurrentUpdateTimeInterval = 0.0f;
				updateTimeString = true;
			}

            List<ScoreboardTeamPanel> TeamPanels = m_GameModeManager.Scoreboard.TeamPanels;

            for (int i = 0; i < TeamPanels.Count; i++)
            {
                ScoreboardPlayerRow[] playerRows = TeamPanels[i].PlayersInTeam;

                for (int j = 0; j < playerRows.Length; j++)
                {
                    if (playerRows[j].PlayerDeaths < ScoreLimit)
                    {
                        playerRows[j].IncrementTimeAlive(aTime, false, updateTimeString);
                    }
                }
            }
		}
	}

	public override bool IsPlayerDisqualified(Player aPlayer)
	{
		List<ScoreboardTeamPanel> TeamPanels = m_GameModeManager.Scoreboard.TeamPanels;

        for (int i = 0; i < TeamPanels.Count; i++)
        {
            if (TeamPanels[i].TeamID == aPlayer.TeamIndex)
            {
                ScoreboardPlayerRow[] playerRows = TeamPanels[i].PlayersInTeam;

                for (int j = 0; j < playerRows.Length; j++)
                {
                    if (playerRows[j].PlayerID == aPlayer.PlayerID)
                    {
                        if (playerRows[j].PlayerDeaths >= ScoreLimit)
                        {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
	}

    public override GameModeType GetGameModeType()
    {
        return GameModeType.StockGameMode;
    }
}