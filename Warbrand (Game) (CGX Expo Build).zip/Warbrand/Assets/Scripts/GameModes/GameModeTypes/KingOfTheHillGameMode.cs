﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public enum HillRotationOption
{
	Static,
	Ordered,
	Random,
	MAX_OPTION
}

public class KingOfTheHillGameMode : BaseGameMode
{
	public float SortScoreboardInterval = 0.1f;
	protected float m_CurrentSortInterval;

	protected HillObjective[] m_HillObjectives;

	protected int m_CurrentHillIndex;

	protected float m_HillChangeTime = 0.0f;

	public HillRotationOption KothHillRotationOption;

	public float HillRotationInterval;

	protected System.Random m_rnd = new System.Random();

    private const string m_MapStaticObjectivesTransform = "MapStaticObjectives";
    private const string m_HillObjectivesTransform = "HillObjectives";

    public override string GameModeName()
    {
        return GameModeManager.StringTitleKingOfTheHillGameMode;
    }

    public KingOfTheHillGameMode()
	{

	}

	public override GameCondition CheckGameCondition(float aDeltaTime)
	{
		if (GameCondition == GameCondition.GameInProgress)
		{
			UpdateTimers(aDeltaTime);

			// Update the hill
			if (KothHillRotationOption != HillRotationOption.Static)
			{
				m_HillChangeTime += aDeltaTime;
				if (m_HillChangeTime >= HillRotationInterval)
				{
					m_HillChangeTime = 0;
					ChangeHills();
				}
			}

            // Update the scoreboard
			m_CurrentSortInterval += aDeltaTime;
			if (m_CurrentSortInterval > SortScoreboardInterval)
			{
                m_GameModeManager.Scoreboard.SortScoreboard();
				//SortScoreboard();
				m_CurrentSortInterval = 0.0f;
			}

			// End game if the time limit is reached
			base.CheckGameCondition(aDeltaTime);

			if (GameCondition == GameCondition.GameInProgress)
			{
                // End game if one of the teams reached the score limit
                for (int i = 0; i < m_GameModeManager.Scoreboard.TeamPanels.Count; i++)
                {
                    ScoreboardTeamPanel team = m_GameModeManager.Scoreboard.TeamPanels[i];

                    if (team.TeamScoreCount >= ScoreLimit)
                    {
                        GameCondition = GameCondition.GameCompleted;
                        break;
                    }
                }
            }
		}

		return GameCondition;
	}

    public override void IncrementKillCount(Player aPlayer, int aAmount = 1, bool aIncrementScore = false)
    {
        base.IncrementKillCount(aPlayer, aAmount, false);
    }

    public override bool IsPlayerDisqualified(Player aPlayer)
	{
		return false;
	}

	public override void Setup()
	{
		base.Setup();
	}

	public override IEnumerator HandleLateSetup()
	{
		yield return null;

        // Get the container for static map objectives.
        GameObject mapStaticObjectives = null;

        // The map may take a few seconds to load.
        while (mapStaticObjectives == null)
        {
            mapStaticObjectives = GameObject.Find(m_MapStaticObjectivesTransform);

            if (mapStaticObjectives != null)
            {
                // This won't find inactive objects.
                Transform hillObjectivesParent = mapStaticObjectives.transform.FindChild(m_HillObjectivesTransform);
                // Enable the hill objectives if they are not active.
                hillObjectivesParent.gameObject.SetActive(true);

                // Get the list of all hills and store the references locally.
                m_HillObjectives = hillObjectivesParent.transform.GetComponentsInChildren<HillObjective>(true);

                // There MUST be at least one hill or there is an error.
                if (m_HillObjectives == null || m_HillObjectives.Length <= 0)
                {
#if UNITY_EDITOR
                    DebugManager.LogError("KingOfTheHillGameMode() - No hills found in map!", Developmer.Evan);
#endif
                }
                else
                {
#if UNITY_EDITOR
                    DebugManager.Log("KingOfTheHillGameMode() - Hill count: " + m_HillObjectives.Length, Developmer.Evan);
#endif

                    m_CurrentHillIndex = -1;

                    // Reset hills (disable all hills except for one)
                    ChangeHills();
                }
            }
#if UNITY_EDITOR
            else
            {
                DebugManager.LogWarning("KingOfTheHillGameMode() - GameObject 'MapStaticObjectives' does not exist!", Developmer.Evan);
            }
#endif

            yield return null;
        }

		yield return base.HandleLateSetup();
	}

	public void ChangeHills()
	{
		if (m_HillObjectives != null && m_HillObjectives.Length > 0)
		{
			// Ordered pattern
			if (KothHillRotationOption == HillRotationOption.Ordered)
			{
				m_CurrentHillIndex++;

				if (m_CurrentHillIndex >= m_HillObjectives.Length)
				{
					m_CurrentHillIndex = 0;
				}
			}
			// Random
			else if (KothHillRotationOption == HillRotationOption.Random)
			{
				int tempHillIndex = m_rnd.Next(0, m_HillObjectives.Length);
				// If the new random hill is the same as the old one, just make it the next one.
				if (tempHillIndex == m_CurrentHillIndex)
				{
					tempHillIndex++;

					if (tempHillIndex >= m_HillObjectives.Length)
					{
						tempHillIndex = 0;
					}

				}
				m_CurrentHillIndex = tempHillIndex;
			}
			// Static
			else
			{
				m_CurrentHillIndex = 0;
			}

			// Loop over all of the hills and set the current hill active and all others inactive.
			for (int i = 0; i < m_HillObjectives.Length; i++)
			{
				if (i == m_CurrentHillIndex)
				{
					m_HillObjectives[i].gameObject.SetActive(true);
				}
				else
				{
					m_HillObjectives[i].ResetHill();
					m_HillObjectives[i].gameObject.SetActive(false);
				}
			}
		}
	}

	public override void IncrementTimeScore(int aTeamIndex, int aPlayerID, float aTime)
	{
		if (m_GameModeManager.CurrentGameMode.GameCondition == GameCondition.GameInProgress)
		{
            List<ScoreboardTeamPanel> TeamPanels = m_GameModeManager.Scoreboard.TeamPanels;

            // Loop over all teams to get the team to award the point to
            for (int i = 0; i < TeamPanels.Count; i++)
            {
                if (aTeamIndex == TeamPanels[i].TeamID)
                {
                    // Loop over all players in this team to determine who to award the point to
                    for (int j = 0; j < TeamPanels[i].PlayersInTeam.Length; j++)
                    {
                        // If this player is the Juggernaut and they got a kill, award one point to that player.
                        if (aPlayerID == TeamPanels[i].PlayersInTeam[j].PlayerID)
                        {
                            TeamPanels[i].PlayersInTeam[j].IncrementScoreCount(aTime);
                            TeamPanels[i].UpdateTeamScoreboard();

                            break;
                        }
                    }

                    break;
                }
            }
        }
	}

	public override void IncrementTimeScoreSelected(List<Player> aPlayers, float aTime)
	{
		if (m_GameModeManager.CurrentGameMode.GameCondition == GameCondition.GameInProgress)
		{
            for (int i = 0; i < aPlayers.Count; i++)
			{
                Player player = aPlayers[i];

				GameInputComponent input = player.GameInput;
				if (input != null)
				{
					IncrementTimeScore(input.TeamIndex, input.PlayerID, aTime);
				}
			}
		}
	}

	public override Transform[] GetCurrentObjectiveLocations()
	{
		if (m_HillObjectives != null)
		{
			Transform[] hills = new Transform[m_HillObjectives.Length];
			for (int i = 0; i < hills.Length; i++)
			{
				hills[i] = m_HillObjectives[i].transform;
			}

			return hills;
		}
		else
		{
			Transform[] hills = { };

			return hills;
		}
	}

	public override Color[] GetCurrentObjectiveColors()
	{
		if (m_HillObjectives != null)
		{
			//Color[] colors = { m_HillObjectives[m_CurrentHillIndex].CurrentHillColor() };
			Color[] colors = new Color[m_HillObjectives.Length];
			for (int i = 0; i < colors.Length; i++)
			{
				colors[i] = m_HillObjectives[i].CurrentHillColor();
			}

			return colors;
		}
		else
		{
			Color[] colors = { Color.white };

			return colors;
		}
	}

	public override void ResetGameMode()
	{
		base.ResetGameMode();

		m_HillChangeTime = 0;
	}

    public override GameModeType GetGameModeType()
    {
        return GameModeType.KingOfTheHillGameMode;
    }
}