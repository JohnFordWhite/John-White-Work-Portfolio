﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

// A Game mode that ends after a player reaches a specific score count.
public class DeathmatchGameMode : BaseGameMode
{
    public override string GameModeName()
    {
        return GameModeManager.StringTitleDeathmatchGameMode;
    }

    public override GameCondition CheckGameCondition(float aDeltaTime)
	{
		if (GameCondition == GameCondition.GameInProgress)
		{
			UpdateTimers(aDeltaTime);

			// End game if time limit is reached
			base.CheckGameCondition(aDeltaTime);

			if (GameCondition == GameCondition.GameInProgress)
			{
				// End game if one of the teams reached the score limit
                for (int i = 0; i < m_GameModeManager.Scoreboard.TeamPanels.Count; i++)
                {
                    ScoreboardTeamPanel team = m_GameModeManager.Scoreboard.TeamPanels[i];

                    if (team.TeamScoreCount >= ScoreLimit)
                    {
                        GameCondition = GameCondition.GameCompleted;
                        break;
                    }
                }
			}
		}

		return GameCondition;
	}

	public override bool IsPlayerDisqualified(Player aPlayer)
	{
		return false;
	}

	public override void Setup()
	{
		base.Setup();
	}

    public override GameModeType GetGameModeType()
    {
        return GameModeType.DeathmatchGameMode;
    }
}