﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class TerritoriesGameMode : BaseGameMode
{
    public float SortScoreboardInterval = 0.1f;
    protected float m_CurrentSortInterval;

    protected TerritoryObjective[] m_TerritoryObjectives;

    private const string m_MapStaticObjectivesTransform = "MapStaticObjectives";
    private const string m_TerritoryObjectivesTransform = "TerritoryObjectives";

    public override string GameModeName()
    {
        return GameModeManager.StringTitleTerritoriesGameMode;
    }

    public override GameCondition CheckGameCondition(float aDeltaTime)
	{
		if (GameCondition == GameCondition.GameInProgress)
        {
            UpdateTimers(aDeltaTime);

            // Update the scoreboard
            m_CurrentSortInterval += aDeltaTime;
            if (m_CurrentSortInterval > SortScoreboardInterval)
            {
                m_GameModeManager.Scoreboard.SortScoreboard();
                //SortScoreboard();
                m_CurrentSortInterval = 0.0f;
            }

            // End game if the time limit is reached
            base.CheckGameCondition(aDeltaTime);

            if (GameCondition == GameCondition.GameInProgress)
            {
                // End game if one of the teams reached the score limit
                for (int i = 0; i < m_GameModeManager.Scoreboard.TeamPanels.Count; i++)
                {
                    ScoreboardTeamPanel team = m_GameModeManager.Scoreboard.TeamPanels[i];

                    if (team.TeamScoreCount >= ScoreLimit)
                    {
                        GameCondition = GameCondition.GameCompleted;
                        break;
                    }
                }
            }
        }

        return GameCondition;
	}

    public override void IncrementKillCount(Player aPlayer, int aAmount = 1, bool aIncrementScore = false)
    {
        base.IncrementKillCount(aPlayer, aAmount, false);
    }

    public override bool IsPlayerDisqualified(Player aPlayer)
    {
        return false;
    }

    public override void Setup()
	{
		base.Setup();
	}

	public override IEnumerator HandleLateSetup()
	{
		yield return null;

        // Get the container for static map objectives.
        GameObject mapStaticObjectives = null;

        // The map may take a few seconds to load.
        while (mapStaticObjectives == null)
        {
            mapStaticObjectives = GameObject.Find(m_MapStaticObjectivesTransform);

            if (mapStaticObjectives != null)
            {
                // This won't find inactive objects.
                Transform territoriesObjectivesParent = mapStaticObjectives.transform.FindChild(m_TerritoryObjectivesTransform);
                // Enable the hill objectives if they are not active.
                territoriesObjectivesParent.gameObject.SetActive(true);

                // Get the list of all hills and store the references locally.
                m_TerritoryObjectives = territoriesObjectivesParent.transform.GetComponentsInChildren<TerritoryObjective>(true);

                // There MUST be at least one hill or there is an error.
                if (m_TerritoryObjectives == null || m_TerritoryObjectives.Length <= 0)
                {
#if UNITY_EDITOR
                    DebugManager.LogError("TerritoriesGameMode() - No territories found in map!", Developmer.Evan);
#endif
                }
                else
                {
#if UNITY_EDITOR
                    DebugManager.Log("TerritoriesGameMode() - Territories count: " + m_TerritoryObjectives.Length, Developmer.Evan);
#endif
                }
            }
#if UNITY_EDITOR
            else
            {
                DebugManager.LogWarning("TerritoriesGameMode() - GameObject 'MapStaticObjectives' does not exist!", Developmer.Evan);
            }
#endif
            yield return null;
        }

		yield return base.HandleLateSetup();
	}

    public override void IncrementTimeScore(int aTeamIndex, int aPlayerID, float aTime)
	{
		if (m_GameModeManager.CurrentGameMode.GameCondition == GameCondition.GameInProgress)
		{
            List<ScoreboardTeamPanel> TeamPanels = m_GameModeManager.Scoreboard.TeamPanels;

            // Loop over all teams to get the team to award the point to
            for (int i = 0; i < TeamPanels.Count; i++)
            {
                if (aTeamIndex == TeamPanels[i].TeamID)
                {
                    // Loop over all players in this team to determine who to award the point to
                    for (int j = 0; j < TeamPanels[i].PlayersInTeam.Length; j++)
                    {
                        // If this player is the Juggernaut and they got a kill, award one point to that player.
                        if (aPlayerID == TeamPanels[i].PlayersInTeam[j].PlayerID)
                        {
                            TeamPanels[i].PlayersInTeam[j].IncrementScoreCount(aTime);
                            TeamPanels[i].UpdateTeamScoreboard();

                            break;
                        }
                    }

                    break;
                }
            }
        }
	}

    public override Transform[] GetCurrentObjectiveLocations()
    {
        if (m_TerritoryObjectives != null)
        {
            Transform[] territories = new Transform[m_TerritoryObjectives.Length];
            for (int i = 0; i < territories.Length; i++)
            {
                if (m_TerritoryObjectives[i] != null)
                {
                    territories[i] = m_TerritoryObjectives[i].transform;
                }
                else
                {
                    territories[i] = null;
                }
            }

            return territories;
        }
        else
        {
            Transform[] hills = { };

            return hills;
        }
    }

    public override Color[] GetCurrentObjectiveColors()
    {
        if (m_TerritoryObjectives != null)
        {
            Color[] colors = new Color[m_TerritoryObjectives.Length];
            for (int i = 0; i < colors.Length; i++)
            {
                colors[i] = m_TerritoryObjectives[i].CurrentTerritoryColor();
            }

            return colors;
        }
        else
        {
            Color[] colors = { Color.white };

            return colors;
        }
    }

    public override void ResetGameMode()
    {
        base.ResetGameMode();
    }

    public override GameModeType GetGameModeType()
    {
        return GameModeType.TerritoriesGameMode;
    }
}