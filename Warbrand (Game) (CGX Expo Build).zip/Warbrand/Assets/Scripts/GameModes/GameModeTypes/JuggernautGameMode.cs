﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class JuggernautGameMode : BaseGameMode
{
    protected Player m_CurrentJuggernaut;

    public override string GameModeName()
    {
        return GameModeManager.StringTitleJuggernautGameMode;
    }

    public override GameCondition CheckGameCondition(float aDeltaTime)
	{
		if (GameCondition == GameCondition.GameInProgress)
        {
            UpdateTimers(aDeltaTime);

            // End game if the time limit is reached
            base.CheckGameCondition(aDeltaTime);

            if (GameCondition == GameCondition.GameInProgress)
            {
                // End game if one of the teams reached the score limit
                for (int i = 0; i < m_GameModeManager.Scoreboard.TeamPanels.Count; i++)
                {
                    ScoreboardTeamPanel team = m_GameModeManager.Scoreboard.TeamPanels[i];

                    if (team.TeamScoreCount >= ScoreLimit)
                    {
                        GameCondition = GameCondition.GameCompleted;
                        break;
                    }
                }
            }
        }

        return GameCondition;
	}

    public override bool IsPlayerDisqualified(Player aPlayer)
    {
        return false;
    }

    public override void Setup()
    {
        base.Setup();
    }

    public override void ResetGameMode()
    {
        base.ResetGameMode();

        m_CurrentJuggernaut = null;
    }

    public override void IncrementKillCount(Player aPlayer, int aAmount = 1, bool aIncrementScore = false)
    {
        if (m_GameModeManager.CurrentGameMode.GameCondition == GameCondition.GameInProgress)
        {
            if (m_CurrentJuggernaut != null)
            {
                int juggernautID = m_CurrentJuggernaut.GameInput.PlayerID;

                List<ScoreboardTeamPanel> TeamPanels = m_GameModeManager.Scoreboard.TeamPanels;

                // Loop over all teams to get the team to award the point to
                for (int i = 0; i < TeamPanels.Count; i++)
                {
                    if (aPlayer.TeamIndex == TeamPanels[i].TeamID)
                    {
                        // Loop over all players in this team to determine who to award the point to
                        for (int j = 0; j < TeamPanels[i].PlayersInTeam.Length; j++)
                        {
                            // If this player is the Juggernaut and they got a kill, award one point to that player.
                            if (aPlayer.PlayerID == TeamPanels[i].PlayersInTeam[j].PlayerID &&
                                aPlayer.PlayerID == juggernautID)
                            {
                                TeamPanels[i].PlayersInTeam[j].IncrementKillCount(aAmount, aIncrementScore);
                                TeamPanels[i].UpdateTeamScoreboard();

                                break;
                            }
                        }

                        break;
                    }
                }
            }
            // If there was no current Juggernaut, this player will become the Juggernaut.
            else
            {
                //Player newJuggernaut = Information.GetPlayerForID(aPlayer.PlayerID);

                //m_CurrentJuggernaut = newJuggernaut;

                m_CurrentJuggernaut = aPlayer;

                base.IncrementKillCount(aPlayer, aAmount, false);
            }

        }
    }

    public override void IncrementDeathCount(Player aPlayer, int aAmount = 1, bool aIncrementScore = false)
    {
        if (m_GameModeManager.CurrentGameMode.GameCondition == GameCondition.GameInProgress)
        {
            if (m_CurrentJuggernaut != null)
            {
                int juggernautID = m_CurrentJuggernaut.GameInput.PlayerID;

                // If the Juggernaut just died, remove Juggernaut status from that player.
                if (aPlayer.PlayerID == juggernautID)
                {
                    m_CurrentJuggernaut = null;
                }
            }

            base.IncrementDeathCount(aPlayer);
        }
    }

    public override Transform[] GetCurrentObjectiveLocations()
    {
        if (m_CurrentJuggernaut != null)
        {
            Transform[] objective = new Transform[1];
            if (m_CurrentJuggernaut.ObjectiveIndicatorPosition != null)
            {
                objective[0] = m_CurrentJuggernaut.ObjectiveIndicatorPosition;
            }
            else
            {
                objective[0] = m_CurrentJuggernaut.transform;
            }

            return objective;
        }
        else
        {
            Transform[] objective = { null };

            return objective;
        }
    }

    public override Color[] GetCurrentObjectiveColors()
    {
        if (m_CurrentJuggernaut != null)
        {
            Color[] colors = new Color[1];
            colors[0] = BaseGameMode.TeamColors[m_CurrentJuggernaut.TeamIndex];

            return colors;
        }
        else
        {
            Color[] colors = { Color.white };

            return colors;
        }
    }

    public override GameModeType GetGameModeType()
    {
        return GameModeType.JuggernautGameMode;
    }
}