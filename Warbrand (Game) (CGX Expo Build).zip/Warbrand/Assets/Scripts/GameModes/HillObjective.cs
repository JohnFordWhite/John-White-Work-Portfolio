﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class HillObjective : MonoBehaviour
{
    public Renderer ZoneRenderer;
    public Renderer FlagRenderer;

    public List<Player> PlayersInsideHill;
    public List<int> TeamsInsideHill;

    protected Color m_NeutralHillColor;

    protected GameModeManager m_GameModeManager;

    private const string StringHillColor = "_CapturingHillColor";
    private const string StringBorderAlpha = "_BorderAlpha";

    protected Color m_CurrentHillColor;

    public Vector3 PointAtGround { get { return m_PointAtGround; } }
    protected Vector3 m_PointAtGround;

	// Use this for initialization
	void Start ()
    {
        PlayersInsideHill = new List<Player>();
        TeamsInsideHill = new List<int>();

        int neutralHillColorIndex = BaseGameMode.TeamColors.Length - 1;

        m_NeutralHillColor = BaseGameMode.TeamColors[neutralHillColorIndex];

        SetHillColor(m_NeutralHillColor);  

        m_GameModeManager = InputManager.CM.GameModeManager;

        // Calculate the point on the ground for the AI players.
        m_PointAtGround = ObjectiveHelper.GetObjectivePositionAtGround(gameObject);
    }
	
	// Update is called once per frame
	void Update ()
    {
#if UNITY_EDITOR
        //DebugManager.DrawLine(transform.position, m_PointAtGround, Color.red, Developmer.Evan);
#endif

        // Only add score if there is one team in the hill. If there are multiple
        // team mates, they all get score.
        if (TeamsInsideHill.Count == 1)
        {
            m_CurrentHillColor = BaseGameMode.TeamColors[TeamsInsideHill[0]];
            
            m_GameModeManager.CurrentGameMode.IncrementTimeScoreSelected(PlayersInsideHill, Time.deltaTime);
        }
        else
        {
            m_CurrentHillColor = m_NeutralHillColor;
        }

        if(ZoneRenderer != null && FlagRenderer != null)
        {
            SetHillColor(m_CurrentHillColor);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        Player player = null;

        if (other.gameObject.GetComponent<PlayerHitboxScript>() != null)
            player = other.gameObject.GetComponent<PlayerHitboxScript>().Owner;

        if (player != null)
        {
            if (PlayersInsideHill.Contains(player) == false)
            {
                //DebugManager.Log("Hill: OnTriggerEnter: " + other.transform.ToString(), Developmer.Evan);
                PlayersInsideHill.Add(player);

                if (TeamsInsideHill.Contains(player.TeamIndex) == false)
                {
                    TeamsInsideHill.Add(player.TeamIndex);
                }
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        PlayerHitboxScript playerHitboxScript = other.gameObject.GetComponent<PlayerHitboxScript>();

        if (playerHitboxScript != null)
        {
            Player player = playerHitboxScript.Owner;

            if (player != null)
            {
                if (PlayersInsideHill.Contains(player))
                {
                    //DebugManager.Log("Hill: OnTriggerExit: " + other.transform.ToString(), Developmer.Evan);
                    PlayersInsideHill.Remove(player);

                    // After removing a player, we need to see if any more players in the
                    // hill are on this team. If not, remove the team index from the hill.
                    int teamIndex = player.TeamIndex;
                    bool teamInHill = false;
                    for (int i = 0; i < PlayersInsideHill.Count; i++)
                    {
                        if (PlayersInsideHill[i].TeamIndex == teamIndex)
                        {
                            teamInHill = true;
                            break;
                        }
                    }

                    if (teamInHill == false)
                    {
                        TeamsInsideHill.Remove(teamIndex);
                    }
                }
            }
        }
    }

    public void ResetHill(bool aResetHillColor = true)
    {
        if (PlayersInsideHill != null)
        {
            PlayersInsideHill.Clear();
        }
        if (TeamsInsideHill != null)
        {
            TeamsInsideHill.Clear();
        }
        if (ZoneRenderer != null && FlagRenderer != null && aResetHillColor == true)
        {
            SetHillColor(m_NeutralHillColor);
        }
    }

    public Color CurrentHillColor()
    {
        return m_CurrentHillColor;
    }

    public bool IsPlayerInsideObjective(GameObject aPlayer)
    {
        Player checkedPlayer = aPlayer.GetComponent<Player>();
        
        for (int i = 0; i < PlayersInsideHill.Count; i++)
        {
            Player player = PlayersInsideHill[i];

            if (player == checkedPlayer)
                return true;
        }

        return false;
    }

    private void SetHillColor(Color col)
    {
        ZoneRenderer.materials[0].SetColor(StringHillColor, col);
        ZoneRenderer.materials[0].SetFloat(StringBorderAlpha, 1);
        ZoneRenderer.materials[1].SetColor(StringHillColor, col);
        ZoneRenderer.materials[1].SetFloat(StringBorderAlpha, 1);
        FlagRenderer.material.SetColor(StringHillColor, col);
    }
}
