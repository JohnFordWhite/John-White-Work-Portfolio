﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class GameModeManager : MonoBehaviour
{
    [HideInInspector]
    public BaseGameMode CurrentGameMode;
    public Scoreboard Scoreboard;

    public const string StringScoreboardPrefab = "Prefabs/UI/Scoreboard/Scoreboard";

    private const string StringGameOverScene = "GameOverScene";

    public const string StringTitleFreePlayGameMode = "Free Play Mode";
    public const string StringTitleDeathmatchGameMode = "Deathmatch";
    public const string StringTitleStockGameMode = "Stock";
    public const string StringTitleKingOfTheHillGameMode = "King of the Hill";
    public const string StringTitleTerritoriesGameMode = "Territories";
    public const string StringTitleJuggernautGameMode = "Juggernaut";

    public GameCondition GameCondition { get { return m_CurrentGameCondition; } }
    private GameCondition m_CurrentGameCondition;
    private bool m_TransitionToOtherScene;

    public bool TeamsEnabled = false;

    public static bool FirstPlayerHasSpawned = false;

    public bool AllPlayersSpawned
    {
        get
        {
            return m_AllPlayersSpawned;
        }
    }
    private bool m_AllPlayersSpawned = false;

    protected GameModeType m_GameModeType = GameModeType.MAX_GAME_MODES;

    public float PlayerRespawnTime
    {
        get
        {
            return m_PlayerRespawnTime;
        }
    }
    private float m_PlayerRespawnTime = 0.1f;
    private WaitForSeconds RespawnWait;

    private const float TransitionToGameOverSceneTime = 3.0f;
    private WaitForSeconds TransitionToGameOverSceneWait = new WaitForSeconds(TransitionToGameOverSceneTime);

    private const string m_ScoreboardTransform = "Scoreboard";
    private const string m_ScoreboardCloneTransform = "Scoreboard(Clone)";

    // Use this for initialization 
    void Start ()
    {
        //StartGameMode(GameModeType.NullGameMode);
        m_TransitionToOtherScene = false;
	}
	
    public void VerifyTeams()
    {
        // if teams are turned off, or if a game mode where teams are not allowed is selected,
        // make sure each player has a unique team index.

        // Even if teams are enabled and each player picks their own custom team, the custom-selected team should be kept if there is no conflict.
        if (TeamsEnabled == false ||
            m_GameModeType == GameModeType.JuggernautGameMode)
        {
            List<int> uniqueTeamIDs = new List<int>();

            // First pass through, we want to see how many unique teams there are.
            for (int i = 0; i < InputManager.CM.Players.Count; i++)
            {
                GameInputComponent input = InputManager.CM.Players[i];

                if (uniqueTeamIDs.Contains(input.TeamIndex) == false)
                {
                    uniqueTeamIDs.Add(input.TeamIndex);
                }
            }

            // If the number of teams does not match the number of players, reassign team index for each player.
            if (uniqueTeamIDs.Count != InputManager.CM.Players.Count)
            {
                for (int i = 0; i < InputManager.CM.Players.Count; i++)
                {
                    GameInputComponent input = InputManager.CM.Players[i];

                    input.TeamIndex = i;
                }

                TeamsEnabled = false;
            }
        }
    }

    // This mode acts like a "factory" for creating a new game mode instance.
    public BaseGameMode CreateGameMode(GameModeType aGameModeType)
    {
        // Clear previous game mode
        CurrentGameMode = null;

        switch (aGameModeType)
        {
            case GameModeType.FreePlayGameMode:
                CurrentGameMode = new FreePlayGameMode();
                break;
            case GameModeType.DeathmatchGameMode:
                CurrentGameMode = new DeathmatchGameMode();
                break;
            case GameModeType.StockGameMode:
                CurrentGameMode = new StockGameMode();
                break;
            case GameModeType.KingOfTheHillGameMode:
                CurrentGameMode = new KingOfTheHillGameMode();
                break;
            case GameModeType.TerritoriesGameMode:
                CurrentGameMode = new TerritoriesGameMode();
                break;
            case GameModeType.JuggernautGameMode:
                CurrentGameMode = new JuggernautGameMode();
                break;
            default:
#if UNITY_EDITOR
                DebugManager.LogError("GameModeManager Error - Unimplemented Game Mode Type: " + aGameModeType.ToString(), Developmer.Evan);
#endif
                break;
        }

        m_GameModeType = aGameModeType;

        VerifyTeams();

        return CurrentGameMode;
    }

	// Update is called once per frame
	void Update ()
    {
        if (CurrentGameMode != null)
        {
            m_CurrentGameCondition = CurrentGameMode.CheckGameCondition(Time.deltaTime);
            
            // If the game is complete, go to the game results scene.
            if (m_TransitionToOtherScene == false)
            {
                if (InputManager.CM.CurrentGameState == GameState.PlayGame && m_CurrentGameCondition == GameCondition.GameCompleted)
                {
                    m_TransitionToOtherScene = true;
                    StartCoroutine(TransitionToGameOverScene());
                }
            }
        }
	}

    IEnumerator TransitionToGameOverScene()
    {
        yield return TransitionToGameOverSceneWait;

        InputManager.CM.CleanupGame(true);

        InputManager.CM.CurrentGameState = GameState.GameOver;

        SceneManager.LoadScene(StringGameOverScene);

        m_TransitionToOtherScene = false;

        yield break;
    }

    public void RestartCurrentGameMode()
    {
        if (CurrentGameMode != null)
        {
            if (Scoreboard == null)
            {
                GameObject scoreboard = GameObject.Find(m_ScoreboardTransform);
                if (scoreboard == null)
                {
                    scoreboard = GameObject.Find(m_ScoreboardCloneTransform);
                    if (scoreboard == null)
                    {
#if UNITY_EDITOR
                        DebugManager.Log("No scoreboard, making one", Developmer.Evan);
#endif
                        scoreboard = Instantiate(Resources.Load(StringScoreboardPrefab)) as GameObject;
                    }
                }
                Scoreboard = scoreboard.GetComponent<Scoreboard>();
                DontDestroyOnLoad(Scoreboard.gameObject);
            }

            CurrentGameMode.ResetGameMode();
            CurrentGameMode.Setup();

            if (Scoreboard != null)
            {
                Scoreboard.ClearScoreboardEntries();
                Scoreboard.BuildScoreboard();
                Scoreboard.UpdateTimers(0);
                Scoreboard.RefreshScoreboard();
            }

            StartCoroutine(CurrentGameMode.HandleLateSetup());
        }
    }

    // Creates an empty scoreboard just for testing purposes
    public void BuildDummyScoreboard()
    {
        if (Scoreboard == null)
        {
            GameObject scoreboard = GameObject.Find(m_ScoreboardTransform);
            if (scoreboard == null)
            {
                scoreboard = GameObject.Find(m_ScoreboardCloneTransform);
                if (scoreboard == null)
                {
#if UNITY_EDITOR
                    DebugManager.Log("No scoreboard, making one", Developmer.Evan);
#endif
                    scoreboard = Instantiate(Resources.Load(StringScoreboardPrefab)) as GameObject;
                }
            }
            Scoreboard = scoreboard.GetComponent<Scoreboard>();
            DontDestroyOnLoad(Scoreboard.gameObject);
        }

        CreateGameMode(GameModeType.FreePlayGameMode);
        CurrentGameMode.ResetGameMode();
        CurrentGameMode.Setup();

        if (Scoreboard != null)
        {
            Scoreboard.ClearScoreboardEntries();
            Scoreboard.BuildScoreboard();
            Scoreboard.UpdateTimers(0);
            Scoreboard.RefreshScoreboard();
        }
    }

    public void RespawnPlayer(Player aPlayer, bool aSpawnRagdoll = false)
    {
        if (aPlayer != null)
        {
            if (aPlayer.IsAI == false)
            {
                aPlayer.ShowBlackScreen(true);
                aPlayer.RecieveDamageIndicator.ClearAllIndicators();
            }
            aPlayer.Health.RemoveAllModifiers();

            StartCoroutine(HandleRespawnPlayer(aPlayer, aSpawnRagdoll));
        }
    }

    public void SetRespawnTime(float aRespawnTime)
    {
        m_PlayerRespawnTime = aRespawnTime;
        RespawnWait = new WaitForSeconds(aRespawnTime);
    }

    IEnumerator HandleRespawnPlayer(Player aPlayer, bool aSpawnRagdoll)
    {
        if (aPlayer != null)
        {
            // We need to wait to give the black screen a chance to show up before disabling the player.
            yield return null;

            if (aSpawnRagdoll == true)
            {
                aPlayer.SpawnRagdoll(aPlayer.transform);
            }

            // This will trigger OnTriggerExit for hill objectives, otherwise a hill
            // will not detect or handle a player dying and keep giving them points.
            aPlayer.transform.position = new Vector3(5000.0f, 5000.0f, 5000.0f);

            yield return null;

            aPlayer.gameObject.SetActive(false);

            // The actual amount of time we want to wait for
            yield return RespawnWait;

            // Only respawn if game is in progress, and they are not disqualified from the game.

            if (CurrentGameMode != null &&
                CurrentGameMode.GameCondition == GameCondition.GameInProgress)
            {
                if (CurrentGameMode.IsPlayerDisqualified(aPlayer) == false)
                {
                    aPlayer.gameObject.SetActive(true);

                    aPlayer.SpawnPlayer();

                    if (aPlayer.IsAI == false)
                    {
                        aPlayer.ShowBlackScreen(false);
                    }
                }
            }
        }
    }

    public void InitialPlayerSpawn()
    {
        m_AllPlayersSpawned = false;

        FirstPlayerHasSpawned = false;

        StartCoroutine(HandleInitialPlayerSpawn());
    }

    IEnumerator HandleInitialPlayerSpawn()
    {
        List<Player> AllPlayers = Information.AllPlayers;

        for (int i = 0; i < AllPlayers.Count; i++)
        {
            Player player = AllPlayers[i];

            // Need to set gameobject active before starting coroutine on it.
            if (player.gameObject.activeSelf == false)
                player.gameObject.SetActive(true);
            
            player.LateStartGameCleanup();

            yield return null;
        }

        AchievementsManager.ResetValues();

        // While waiting for all players to be ready, keep polling all of them to see if their late start has completed.
        bool allSpawned = false;
        while (allSpawned == false)
        {
            int spawnCount = 0;
            for (int i = 0; i < AllPlayers.Count; i++)
            {
                Player player = AllPlayers[i];

                if (player.InitialSpawned == true)
                    spawnCount++;
            }

            if (spawnCount == AllPlayers.Count)
                allSpawned = true;

            yield return null;
        }

        m_AllPlayersSpawned = true;

        yield return null;
    }
}

public enum GameModeType
{
    FreePlayGameMode,
    DeathmatchGameMode,
    StockGameMode,
    KingOfTheHillGameMode,
    TerritoriesGameMode,
    JuggernautGameMode,
    MAX_GAME_MODES
}

public enum GameCondition
{
    GameNotStarted,
    GameInProgress,
    GameCompleted
}
