﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class ObjectiveWaypoint : MonoBehaviour
{
    public GameObject WaypointPrefab;

    public Player Owner;

    public Sprite FlagSprite;
    public Sprite SkullSprite;

    protected GameModeManager m_GameModeManager;

    protected Transform[] m_Objectives;

    protected List<Image> m_WaypointImages;

    protected GameInputComponent m_OwnerInput;

	private const string StringObjectiveColor = "_ObjectiveColor";

    private const string FlagSpritePath = "Art/Sprites/Flag Icon";
    private const string SkullSpritePath = "Art/Sprites/SkullIcon";
    
    public void Setup()
    {
        StartCoroutine(HandleSetup());
    }

    IEnumerator HandleSetup()
    {
        yield return null;

        if (FlagSprite == null)
        {
            FlagSprite = Resources.Load<Sprite>(FlagSpritePath);
        }
        if (SkullSprite == null)
        {
            SkullSprite = Resources.Load<Sprite>(SkullSpritePath);
        }

        m_GameModeManager = InputManager.CM.GameModeManager;

        yield return null;

        //// Get the parent Player GameObject. Needed in order to get the UI camera.
        //// this > GenericUI > Player (Clone)
        //Owner = transform.parent.parent.GetComponentInChildren<Player>();

        //Debug.Log(transform);
        //Debug.Log(transform.parent);
        //Debug.Log(transform.parent.parent);
        //Debug.Log(transform.parent.parent.GetComponentInChildren<Player>());

        //if (Owner != null)
        //{
        //    m_OwnerInput = Owner.GameInput;
        //}

        m_OwnerInput = transform.parent.parent.parent.GetComponent<GameInputComponent>();
        Owner = m_OwnerInput.Input.Character;

        m_WaypointImages = new List<Image>();

        RectTransform canvasRect = Owner.UICanvas.GetComponent<RectTransform>();
        //float canvasRatio = canvasRect.rect.width / canvasRect.rect.height;
        float canvasRatio = InputManager.CM.GetComponent<CameraManager>().GetCanvasRatioForPlayer(Owner);

        //canvasRatio = (Screen.width / Screen.height) * 2.0f;

        List<Player> players = Information.AllHumanPlayers;

        while (m_GameModeManager.CurrentGameMode == null)
        {
            yield return null;
        }

        GameModeType gameModeType = m_GameModeManager.CurrentGameMode.GetGameModeType();

        for (int i = 0; i < 8; i++)
        {
            GameObject waypoint = Instantiate(WaypointPrefab);
            waypoint.transform.SetParent(transform, true);
            m_WaypointImages.Add(waypoint.GetComponent<Image>());
            // Need to create a new material instance and apply it back to the image,
            // or else it will be treated like a shared material
            // - i.e. any changes done to this instance effect all instances.
            Material tempMaterial = new Material(m_WaypointImages[i].material);
            m_WaypointImages[i].material = tempMaterial;

            // For some reason, loading a prefab of a recttransform sets all values to garbage values,
            // even if they are all set to 0 or 1 manaully in the editor.

            int allHumanPlayers = Information.AllHumanPlayers.Count;

            RectTransform rect = waypoint.GetComponent<RectTransform>();
            rect.localPosition = Vector3.zero;

            // HACK: UI image does not scale properly with screen aspect ratio and appears stretched.
            // This will rescale the image depending on the number of players to make it look more round.
            //if (allHumanPlayers == 2)
            //{
            //    rect.localScale = new Vector3(0.05f, 0.05f, 1.0f);
            //}
            //else
            //{
            //    rect.localScale = new Vector3(0.032f, 0.05f, 1.0f);
            //}
            //if (canvasRatio >= 0)
            //{
            //    if (Owner == players[0] && players.Count == 3 || players.Count == 2)
            //    {
            //        rect.localScale = new Vector3(0.025f, 0.025f * canvasRatio, 1.0f);
            //    }
            //    else if (players.Count == 3 || players.Count == 4)
            //    {
            //        rect.localScale = new Vector3(0.05f, 0.05f * canvasRatio, 1.0f);
            //    }
            //    else
            //    {
            //        rect.localScale = new Vector3(0.025f, 0.025f * canvasRatio, 1.0f);
            //    }
            //}
            //else
            //{
            //    if (Owner == players[0] && players.Count == 3 || players.Count == 2)
            //    {
            //        rect.localScale = new Vector3(0.025f * canvasRatio, 0.025f, 1.0f);
            //    }
            //    else if (players.Count == 3 || players.Count == 4)
            //    {
            //        rect.localScale = new Vector3(0.05f * canvasRatio, 0.05f, 1.0f);
            //    }
            //    else
            //    {
            //        rect.localScale = new Vector3(0.025f * canvasRatio, 0.025f, 1.0f);
            //    }
            //}

            if (gameModeType == GameModeType.KingOfTheHillGameMode || gameModeType == GameModeType.TerritoriesGameMode)
            {
                m_WaypointImages[i].sprite = FlagSprite;
            }
            else
            {
                m_WaypointImages[i].sprite = SkullSprite;
            }

            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            //rect.sizeDelta = new Vector2(32.0f, 32.0f);

            rect.localScale = new Vector3(1.0f, 1.0f, 1.0f);
            rect.localRotation = Quaternion.identity;
            rect.sizeDelta = Vector2.zero;
        }
        
        yield return null;

        for (int i = 0; i < m_WaypointImages.Count; i++)
        {
            RectTransform rect = m_WaypointImages[i].GetComponent<RectTransform>();

            rect.sizeDelta = new Vector2(32.0f, 32.0f);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (m_GameModeManager != null && m_WaypointImages != null)
        {
            if (m_GameModeManager.CurrentGameMode != null)
            {
                Transform[] objectives = m_GameModeManager.CurrentGameMode.GetCurrentObjectiveLocations();
                if (objectives != m_Objectives)
                {
                    m_Objectives = objectives;

                    for (int i = 0; i < m_Objectives.Length; i++)
                    {
                        if (i >= m_Objectives.Length)
                            break;

                        GameObject waypoint = m_WaypointImages[i].gameObject;
                        if (waypoint != null && m_Objectives != null && m_Objectives.Length > 0)
                        {
                            // Check to see if the waypoint is this player. If it is, hide it.
                            if (m_Objectives[i] != null && m_Objectives[i].parent != null)
                            {
                                if (Owner == null)
                                    Owner = m_OwnerInput.Input.Character;

                                if (m_Objectives[i].parent == Owner.transform)
                                {
                                    waypoint.SetActive(false);
                                    continue;
                                }
                            }

                            if (m_Objectives[i] != null && m_Objectives[i].gameObject.activeSelf == true)
                            {
                                waypoint.SetActive(true);

                                // Update the position of the waypoint

                                SetWaypointPosition(m_WaypointImages[i], m_Objectives[i].gameObject);

                                // Update waypoint with the objective color

                                Material material = m_WaypointImages[i].material;

                                material.SetColor(StringObjectiveColor, m_GameModeManager.CurrentGameMode.GetCurrentObjectiveColors()[i]);
                            }
                            else
                            {
                                waypoint.SetActive(false);
                            }
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < m_WaypointImages.Count; i++)
                    {
                        GameObject waypoint = m_WaypointImages[i].gameObject;
                        waypoint.SetActive(false);
                    }
                }
            }
        }
    }

    void SetWaypointPosition(Image aWaypointImage, GameObject aTarget)
    {
        Camera PlayerCamera = Owner.PlayerCamera;
        RectTransform waypointRect = aWaypointImage.GetComponent<RectTransform>();
        RectTransform canvasRect = Owner.UICanvas.GetComponent<RectTransform>();
        
        RectTransform ObjectiveWaypointsWidth = GetComponent<RectTransform>();

        Vector2 waypointImageSize = new Vector2(
            aWaypointImage.rectTransform.rect.width * aWaypointImage.rectTransform.localScale.x,
            aWaypointImage.rectTransform.rect.height * aWaypointImage.rectTransform.localScale.y
            );

        Vector2 cameraDimensions = new Vector2(ObjectiveWaypointsWidth.rect.width, ObjectiveWaypointsWidth.rect.height);

        // Convert the 3D world space position of the target game object to 2D screen space
        Vector3 objectivePositionOnScreen = PlayerCamera.WorldToScreenPoint(aTarget.transform.position);
        Vector3 objectivePositionInViewport = PlayerCamera.WorldToViewportPoint(aTarget.transform.position);

        // Final position of the indicator on the screen
        Vector2 localPoint = Vector2.zero;

        // check to see if the point on screen is in the visible area of the viewport.
        if (IsObjectivePositionOnScreenVisible(objectivePositionInViewport))
        {
            // If the object is viewable on the screen, that makes the placement
            // of the indicator easy as the camera can give that position to us.

            // Places the indicator in the middle of the screen on top of the target position
            //RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRect, objectivePositionOnScreen, PlayerCamera, out localPoint);

            //Debug.Log(localPoint);

            localPoint = objectivePositionInViewport;
            localPoint.Scale(new Vector2(canvasRect.rect.width, canvasRect.rect.height));
            localPoint -= new Vector2(canvasRect.rect.width / 2.0f, canvasRect.rect.height / 2.0f);
        }
        else
        {

            // If the target is not visible, that requires some extra work to resolve a point on the screen
            // to represent where the target is.

            // When the z position is < 0, it means that the object is somewhere behind the camera.
            // However, the coordinates are also flipped. This operation fixes the flipped coordinates
            // and makes it easier to plot the position of the indicator.
            // This step seems hacky but it is actually necessary or else angles will be reversed.
            if (objectivePositionOnScreen.z < 0)
            {
                objectivePositionOnScreen *= -1.0f;
            }

            // Make the origin point for the calculations in the middle of the screen.
            // Also, this makes it easier to set the final position as RectTransform likes to use a (-1, -1) to (1, 1) coordinate system.
            Vector2 centerPos = new Vector2(cameraDimensions.x / 2.0f, cameraDimensions.y / 2.0f);
            float cartesianXPos = objectivePositionOnScreen.x - centerPos.x;
            float cartesianYPos = objectivePositionOnScreen.y - centerPos.y;

            // The slope is the difference between the center point and the screen point of the target. Essentially,
            // y = mx + b.
            float slope = (cartesianYPos / cartesianXPos);

            // Setting up for the final position.
            Vector2 finalPosition = Vector2.zero;

            // Using y = mx, we can find out where on the edge of the screen we can plot the position of the indicator.
            // For the top and bottom of the screen:
            // We can assume the indicator will be at the top of the screen if the slope is positive
            // or it will be at the bottom of the screen if the slope is negative.
            // For x/y, we don't need to worry about clamping it here.
            // If the slope is > 1 or < -1, the slope is very steep and will pass through the top or bottom of the screen and the y position will be clamped here.
            // If the slope is < 1 or > -1, the slope will intersect with the left or right sides of the screen.

            // To prevent the image from clipping off screen, the image's size will be taken into account.

            // Object is above the horizon line
            if (cartesianYPos > 0.0f)
            {
                finalPosition.x = (cameraDimensions.y / 2.0f) / slope;
                finalPosition.y = (cameraDimensions.y / 2.0f);

                if (finalPosition.y > cameraDimensions.y / 2.0f - waypointImageSize.y)
                {
                    finalPosition.y = cameraDimensions.y / 2.0f - waypointImageSize.y;
                }
            }
            else
            {
                finalPosition.x = (-cameraDimensions.y / 2.0f) / slope;
                finalPosition.y = (-cameraDimensions.y / 2.0f);

                if (finalPosition.y < -cameraDimensions.y / 2.0f + waypointImageSize.y)
                {
                    finalPosition.y = -cameraDimensions.y / 2.0f + waypointImageSize.y;
                }
            }

            // Check if the final x position is out of the bounds of the camera's pixel width.
            // This final update will only occur if the slope is not steep (slope < 1 and > -1).
            // This will handle clamping the x position to the edge of the screen.
            
            // Object is off the right side of the screen
            if (finalPosition.x > cameraDimensions.x / 2.0f - waypointImageSize.x)
            {
                finalPosition.x = cameraDimensions.x / 2.0f - waypointImageSize.x;
                finalPosition.y = (cameraDimensions.x / 2.0f) * slope;
            }
            // Object is off the left side of the screen
            else if (finalPosition.x < -cameraDimensions.x / 2.0f + waypointImageSize.x)
            {
                finalPosition.x = -cameraDimensions.x / 2.0f + waypointImageSize.x;
                finalPosition.y = (-cameraDimensions.x / 2.0f) * slope;
            }

            // Set the final screen position of the indicator
            localPoint = finalPosition;
        }

        // Clamp the final position of the waypoint image so it doesn't clip off the side of the screen.
        if (localPoint.y > cameraDimensions.y / 2.0f - waypointImageSize.y)
        {
            localPoint.y = cameraDimensions.y / 2.0f - waypointImageSize.y;
        }
        if (localPoint.y < -cameraDimensions.y / 2.0f + waypointImageSize.y)
        {
            localPoint.y = -cameraDimensions.y / 2.0f + waypointImageSize.y;
        }
        if (localPoint.x > cameraDimensions.x / 2.0f - waypointImageSize.x)
        {
            localPoint.x = cameraDimensions.x / 2.0f - waypointImageSize.x;
        }
        else if (localPoint.x < -cameraDimensions.x / 2.0f + waypointImageSize.x)
        {
            localPoint.x = -cameraDimensions.x / 2.0f + waypointImageSize.x;
        }

        // Sets the final position
        waypointRect.localPosition = localPoint;
    }

    bool IsObjectivePositionOnScreenVisible(Vector3 aScreenPosition)
    {
        if (aScreenPosition.x >= 0 && aScreenPosition.x <= 1.0f &&
            aScreenPosition.y >= 0 && aScreenPosition.y <= 1.0f &&
            aScreenPosition.z > 0)
        {
            return true;
        }
        return false;
    }
}
