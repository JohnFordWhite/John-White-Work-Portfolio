﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        MathUtils                                                                      *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            October 9th, 2016                                                              *
 *                                                                                                 *
 * A static class that has math helper functions, to be used if Mathf is not enough.               *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - October 9th, 2016                                       *
\***************************************************************************************************/

using UnityEngine;
using System.Collections.Generic;
using System.Security.Cryptography;
using System;

public class HSVColor
{
    public HSVColor(float aH, float aS, float aV)
    {
        h = aH;
        s = aS;
        v = aV;
    }
    public float h;
    public float s;
    public float v;
}

public static class MathUtils
{
    public static float CompareEpsilon = 0.0001f;

    public static int GetRandomSign()
    {
        return (UnityEngine.Random.Range(0f, 1f) > 0.5f) ? 1 : -1;
    }

    public static HSVColor RGBtoHSV(Color aColor)
    {
        float h;
        float s;
        float v;

        Color.RGBToHSV(aColor, out h, out s, out v);

        return new HSVColor(h, s, v);
    }

    public static Color HSVtoRGB(HSVColor aColor)
    {
        return Color.HSVToRGB(aColor.h, aColor.s, aColor.v);
    }
    public static void Shuffle<T>(this IList<T> list)
    {
        RNGCryptoServiceProvider provider = new RNGCryptoServiceProvider();
        int n = list.Count;
        while (n > 1)
        {
            byte[] box = new byte[1];
            do provider.GetBytes(box);
            while (!(box[0] < n * (Byte.MaxValue / n)));
            int k = (box[0] % n);
            n--;
            T value = list[k];
            list[k] = list[n];
            list[n] = value;
        }
    }

    public static bool IsBetween(float aNum, float aMin, float aMax)
    {
        if (aMin >= aMax)
        {
            float temp = aMin;
            aMin = aMax;
            aMax = temp;
        }

        if (aNum < aMin || aNum > aMax)
            return false;

        return true;
    }

    public static bool AlmostEquals(float v1, float v2, float epsilon)
    {
        return Mathf.Abs(v2 - v1) <= epsilon;
    }
    
    public static bool AlmostEquals(float v1, float v2)
    {
        return AlmostEquals(v1, v2, CompareEpsilon);
    }

    public static bool AlmostEquals(Vector3 lhs, Vector3 rhs, float epsilon)
    {
        return AlmostEquals(lhs.x, rhs.x, epsilon) && AlmostEquals(lhs.y, rhs.y, epsilon) && AlmostEquals(lhs.z, rhs.z, epsilon);
    }

    public static bool AlmostEquals(Vector3 lhs, Vector3 rhs)
    {
        return AlmostEquals(lhs, rhs, CompareEpsilon);
    }

    public static T WeightedRandom<T>(Dictionary<T, float> aOptions)
    {
        // Get the sum of all the weights
        float sum = 0f;

        looprestart:
        foreach (var option in aOptions)
        {
            if (option.Value < 0f)
            {
                aOptions.Remove(option.Key);
                sum = 0f;
                goto looprestart; // Yes, I know I'm using goto's. They get the job done cleanly here. -Nathan
            }
            sum += option.Value;
        }

        // Get a random number between 0 and the sum
        float num = UnityEngine.Random.Range(0f, sum);

        // Subtract weights until num is equal to 0
        foreach (var option in aOptions)
        {
            if (num <= option.Value || MathUtils.AlmostEquals(num, option.Value))
                return option.Key;
            num -= option.Value;
        }
#if UNITY_EDITOR
        DebugManager.LogError("Weighted Random Could Not Select An Object", Developmer.AllDevelopmers);
#endif
        return default(T);
    }

    public static Vector2 xy(this Vector3 aVector)
    {
        return new Vector2(aVector.x, aVector.y);
    }
    public static Vector2 xz(this Vector3 aVector)
    {
        return new Vector2(aVector.x, aVector.z);
    }
    public static Vector2 yz(this Vector3 aVector)
    {
        return new Vector2(aVector.y, aVector.z);
    }
    public static Vector2 yx(this Vector3 aVector)
    {
        return new Vector2(aVector.y, aVector.x);
    }
    public static Vector2 zx(this Vector3 aVector)
    {
        return new Vector2(aVector.z, aVector.x);
    }
    public static Vector2 zy(this Vector3 aVector)
    {
        return new Vector2(aVector.z, aVector.y);
    }

    public static Vector3 Sum(this Vector3[] aVectors)
    {
        Vector3 sum = Vector3.zero;
        
        for (int i = 0; i < aVectors.Length; i++)
        {
            Vector3 vec = aVectors[i];

            sum += vec;
        }

        return sum;
    }

    public static Vector3 Average(this Vector3[] aVectors)
    {
        return aVectors.Sum() / aVectors.Length;
    }

    public static bool IsPointToLeft(GameObject aOrigin, Vector3 aTarget)
    {
        Vector3 forward = aOrigin.transform.forward;
        Vector3 up = aOrigin.transform.up;
        Vector3 targetDirection = (aTarget - aOrigin.transform.position).normalized;

        Vector3 perpendicular = Vector3.Cross(forward, targetDirection);
        float dir = Vector3.Dot(perpendicular, up);

        return (dir < 0f);
    }

    public static bool IsPointToRight(GameObject aOrigin, Vector3 aTarget)
    {
        Vector3 forward = aOrigin.transform.forward;
        Vector3 up = aOrigin.transform.up;
        Vector3 targetDirection = (aTarget - aOrigin.transform.position).normalized;

        Vector3 perpendicular = Vector3.Cross(forward, targetDirection);
        float dir = Vector3.Dot(perpendicular, up);

        return (dir > 0f);
    }

    private const float NavMeshRadius = 100f;
    public static Vector3 RandomPointOnNavMesh()
    {
        Vector3 randomDirection = UnityEngine.Random.insideUnitSphere * NavMeshRadius;

        NavMeshHit hit;
        NavMesh.SamplePosition(randomDirection, out hit, NavMeshRadius, 1);

        return hit.position;
    }

    public static bool AIVector3Distance(Vector3 lhs, Vector3 rhs, float aHorizontalAcceptance, float aVerticalAcceptance)
    {
        if (Vector2.Distance(lhs.xz(), rhs.xz()) >= aHorizontalAcceptance)
            return false;

        if (Mathf.Abs(lhs.y - rhs.y) >= aVerticalAcceptance)
            return false;

        return true;
    }
    
    public static Player[] GetPlayersCloseToGameObject(GameObject aObject, float aDistance, bool aIncludeThisObject = false, Player[] aObjectsToIgnore = null)
    {
        List<Player> list = new List<Player>();

        List<Player> allPlayers = Information.AllPlayers;

        Player onePlayer = aObject.GetComponent<Player>();

        if (aIncludeThisObject && onePlayer)
            list.Add(onePlayer);
        
        for (int i = 0; i < allPlayers.Count; i++)
        {
            Player player = allPlayers[i];

            if (player == aObject)
                continue;

            if (Vector3.Distance(aObject.transform.position, player.transform.position) < aDistance)
                list.Add(player);
        }

        if (aObjectsToIgnore != null)
        {
            for (int i = 0; i < aObjectsToIgnore.Length; i++)
            {
                Player player = aObjectsToIgnore[i];

                list.Remove(player);
            }
        }
        return list.ToArray();
    }

    public static Vector3 GetClosestPointOnNavMesh(Vector3 aPoint)
    {
        NavMeshHit hit;
        NavMesh.SamplePosition(aPoint, out hit, 1000, -1);
        return hit.position;
    }

    public static Vector3 Position(this GameObject aObj)
    {
        return aObj.transform.position;
    }

    public static Quaternion Rotation(this GameObject aObj)
    {
        return aObj.transform.rotation;
    }

    public static Vector3 EulerAngles(this GameObject aObj)
    {
        return aObj.transform.eulerAngles;
    }

    public static float Distance(float lhs, float rhs)
    {
        return Mathf.Abs(lhs - rhs);
    }

    public static Vector3 CreateXZVector3(Vector2 aXZ, float aY = 0f)
    {
        return new Vector3(aXZ.x, aY, aXZ.y);
    }

    public static Vector3 DirectionVector(Vector3 aStartPoint, Vector3 aEndPoint)
    {
        return (aEndPoint - aStartPoint).normalized;
    }

    public static float TotalDistance(this NavMeshPath aPath)
    {
        return TotalDistance(aPath.corners);
    }

    public static float TotalDistance(this Vector3[] aPath)
    {
        float dist = 0f;

        for(int i = 0; i < aPath.Length - 1; i++)
        {
            dist += Vector3.Distance(aPath[i], aPath[i + 1]);
        }

        return dist;
    }
}
