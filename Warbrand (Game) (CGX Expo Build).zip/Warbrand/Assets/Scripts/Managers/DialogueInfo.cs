﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum DialogueContext
{
    //All Characters
    CharSelected,
    Damage,
    SeeZeph,
    SeeLeeroy,
    SeeQuark,
    SeePaige,
    SeeQuarkTurret,
    DestroyQuarkTurret,
    InQuarkTrap,
    Hooked,
    InSmoke,
    InAdhesive,
    WitnessKill,
    KilledZeph,
    KilledLeeroy,
    KilledQuark,
    KilledPaige,

    //Leeroy & Zeph melee
    MainAttack,

    //Paige
    PaigeThrowAdhesive,
    PaigeTargetInAdhesiveOnLand,
    PaigeHealingInterupt,

    //Leeroy
    LeeroyPounce,
    LeeroyMainAttackRaged,
    LeeroyClapstun,
    LeeroyGrenadeHit,
    LeeroidRage,
    LeeroyDamagedRaged,

    //Quark
    QuarkMovementAbilityConnects,
    QuarkPlaceTurret,
    QuarkPlaceTrap,
    QuarkSeeTrapTriggered,
    QuarkThrowCamera,
    QuarkTurretGetsKill,
    
    //Zeph
    ZephThrowsHook,
    ZephPullOpponent,
    ZephCatchesPplInSmoke,
    ZephSuccessfulPoison,
    ZephMissThrownAttack,
    ZephTeleport,

    None
}
public class DialogueInfo : MonoBehaviour
{
    #region Leeroy Variables
    public Dictionary<DialogueContext, List<AudioClip>> LeeroyDialogueDictionary = new Dictionary<DialogueContext, List<AudioClip>>();

    //Generic clips
    private List<AudioClip> m_LeeroySelectedClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyDamageClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroySeeZephClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroySeeQuarkClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroySeePaigeClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroySeeQuarkTurretClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyDestroyQuarkTurretClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyInQuarkTrapClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyHookedClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyInSmokeClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyInAdhesiveClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyWitnessKillClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyKillQuarkClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyKillZephClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyKillPaigeClipList = new List<AudioClip>();

    //Character specific clips
    private List<AudioClip> m_LeeroyPounceClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyMainAttackClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyMainAttackRagedClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyClapstunClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyGrenadeHitClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyLeeroidRageClipList = new List<AudioClip>();
    private List<AudioClip> m_LeeroyReceiveDamageRagedClipList = new List<AudioClip>();

    private const string m_LeeroySelectedClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_selected_0";
    private const string m_LeeroySelectedClip1String = "Audio/Dialogue/Leeroy/dialogue_leeroy_selected_1";
    private const string m_LeeroySelectedClip2String = "Audio/Dialogue/Leeroy/dialogue_leeroy_selected_2";
    private const string m_LeeroySelectedClip3String = "Audio/Dialogue/Leeroy/dialogue_leeroy_selected_3";
    private const string m_LeeroyDamageClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamage_0";
    private const string m_LeeroyDamageClip1String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamage_1";
    private const string m_LeeroyDamageClip2String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamage_2";
    private const string m_LeeroyDamageClip3String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamage_3";
    private const string m_LeeroyDamageClip4String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamage_4";
    private const string m_LeeroyDamageClip5String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamage_5";
    private const string m_LeeroyDamageClip6String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamage_6";
    private const string m_LeeroyDamageClip7String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamage_7";
    private const string m_LeeroyDamageClip8String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamage_8";
    private const string m_LeeroyDamageClip9String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamage_9";
    private const string m_LeeroySeeZephClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_zephsight_0";
    private const string m_LeeroySeeZephClip1String = "Audio/Dialogue/Leeroy/dialogue_leeroy_zephsight_1";
    private const string m_LeeroySeeQuarkClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_quarksight_0";
    private const string m_LeeroySeeQuarkClip1String = "Audio/Dialogue/Leeroy/dialogue_leeroy_quarksight_1";
    private const string m_LeeroySeePaigeClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_paigesight_0";
    private const string m_LeeroySeePaigeClip1String = "Audio/Dialogue/Leeroy/dialogue_leeroy_paigesight_1";
    private const string m_LeeroySeeQuarkTurretClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_quarkturretsight_0";
    private const string m_LeeroyDestroyQuarkTurretClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_destroyquarkturret_0";
    private const string m_LeeroyHookedClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_hooked_0";
    private const string m_LeeroyInSmokeClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_insmokescreen_0";
    private const string m_LeeroyInAdhesiveClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_inadhesive_0";
    private const string m_LeeroyWitnessKillClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_witnesskill_0";
    private const string m_LeeroyKillQuarkClip0String  = "Audio/Dialogue/Leeroy/dialogue_leeroy_killquark_0";
    private const string m_LeeroyKillZephClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_killzeph_0";
    private const string m_LeeroyKillZephClip1String = "Audio/Dialogue/Leeroy/dialogue_leeroy_killzeph_1";
    private const string m_LeeroyKillPaigeClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_killpaige_0";
    private const string m_LeeroyKillPaigeClip1String = "Audio/Dialogue/Leeroy/dialogue_leeroy_killpaige_1";
    private const string m_LeeroyPounceClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_pounce_0";
    private const string m_LeeroyPounceClip1String = "Audio/Dialogue/Leeroy/dialogue_leeroy_pounce_1";
    private const string m_LeeroyPounceClip2String = "Audio/Dialogue/Leeroy/dialogue_leeroy_pounce_2";
    private const string m_LeeroyMainAttackClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_melee_0";
    private const string m_LeeroyMainAttackClip1String = "Audio/Dialogue/Leeroy/dialogue_leeroy_melee_1";
    private const string m_LeeroyMainAttackClip2String = "Audio/Dialogue/Leeroy/dialogue_leeroy_melee_2";
    private const string m_LeeroyMainAttackClip3String = "Audio/Dialogue/Leeroy/dialogue_leeroy_melee_3";
    private const string m_LeeroyMainAttackClip4String = "Audio/Dialogue/Leeroy/dialogue_leeroy_melee_4";
    private const string m_LeeroyMainAttackClip5String = "Audio/Dialogue/Leeroy/dialogue_leeroy_melee_5";
    private const string m_LeeroyMainAttackClip6String = "Audio/Dialogue/Leeroy/dialogue_leeroy_melee_6";
    private const string m_LeeroyMainAttackClip7String = "Audio/Dialogue/Leeroy/dialogue_leeroy_melee_7";
    private const string m_LeeroyMainAttackClip8String = "Audio/Dialogue/Leeroy/dialogue_leeroy_melee_8";
    private const string m_LeeroyMainAttackRagedClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_ragemelee_0";
    private const string m_LeeroyMainAttackRagedClip1String = "Audio/Dialogue/Leeroy/dialogue_leeroy_ragemelee_1";
    private const string m_LeeroyMainAttackRagedClip2String = "Audio/Dialogue/Leeroy/dialogue_leeroy_ragemelee_2";
    private const string m_LeeroyMainAttackRagedClip3String = "Audio/Dialogue/Leeroy/dialogue_leeroy_ragemelee_3";
    private const string m_LeeroyClapstunClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_clapstun_0";
    private const string m_LeeroyGrenadeHitClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_grenadehits_0";
    private const string m_LeeroyLeeroidRageClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_leeroidrageuse_0";
    private const string m_LeeroyReceiveDamageRagedClip0String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamagerage_0";
    private const string m_LeeroyReceiveDamageRagedClip1String = "Audio/Dialogue/Leeroy/dialogue_leeroy_receivedamagerage_1";
    private AudioClip m_LeeroySelectedClip0;
    private AudioClip m_LeeroySelectedClip1;
    private AudioClip m_LeeroySelectedClip2;
    private AudioClip m_LeeroySelectedClip3;
    private AudioClip m_LeeroyDamageClip0;
    private AudioClip m_LeeroyDamageClip1;
    private AudioClip m_LeeroyDamageClip2;
    private AudioClip m_LeeroyDamageClip3;
    private AudioClip m_LeeroyDamageClip4;
    private AudioClip m_LeeroyDamageClip5;
    private AudioClip m_LeeroyDamageClip6;
    private AudioClip m_LeeroyDamageClip7;
    private AudioClip m_LeeroyDamageClip8;
    private AudioClip m_LeeroyDamageClip9;
    private AudioClip m_LeeroySeeZephClip0;
    private AudioClip m_LeeroySeeZephClip1;
    private AudioClip m_LeeroySeeQuarkClip0;
    private AudioClip m_LeeroySeeQuarkClip1;
    private AudioClip m_LeeroySeePaigeClip0;
    private AudioClip m_LeeroySeePaigeClip1;
    private AudioClip m_LeeroySeeQuarkTurretClip0;
    private AudioClip m_LeeroyDestroyQuarkTurretClip0;
    private AudioClip m_LeeroyHookedClip0;
    private AudioClip m_LeeroyInSmokeClip0;
    private AudioClip m_LeeroyInAdhesiveClip0;
    private AudioClip m_LeeroyWitnessKillClip0;
    private AudioClip m_LeeroyKillQuarkClip0;
    private AudioClip m_LeeroyKillZephClip0;
    private AudioClip m_LeeroyKillZephClip1;
    private AudioClip m_LeeroyKillPaigeClip0;
    private AudioClip m_LeeroyKillPaigeClip1;
    private AudioClip m_LeeroyPounceClip0;
    private AudioClip m_LeeroyPounceClip1;
    private AudioClip m_LeeroyPounceClip2;
    private AudioClip m_LeeroyMainAttackClip0;
    private AudioClip m_LeeroyMainAttackClip1;
    private AudioClip m_LeeroyMainAttackClip2;
    private AudioClip m_LeeroyMainAttackClip3;
    private AudioClip m_LeeroyMainAttackClip4;
    private AudioClip m_LeeroyMainAttackClip5;
    private AudioClip m_LeeroyMainAttackClip6;
    private AudioClip m_LeeroyMainAttackClip7;
    private AudioClip m_LeeroyMainAttackClip8;
    private AudioClip m_LeeroyMainAttackRagedClip0;
    private AudioClip m_LeeroyMainAttackRagedClip1;
    private AudioClip m_LeeroyMainAttackRagedClip2;
    private AudioClip m_LeeroyMainAttackRagedClip3;
    private AudioClip m_LeeroyClapstunClip0;
    private AudioClip m_LeeroyGrenadeHitClip0;
    private AudioClip m_LeeroyLeeroidRageClip0;
    private AudioClip m_LeeroyReceiveDamageRagedClip0;
    private AudioClip m_LeeroyReceiveDamageRagedClip1;

    #endregion

    #region Paige Variables

    public Dictionary<DialogueContext, List<AudioClip>> PaigeDialogueDictionary = new Dictionary<DialogueContext, List<AudioClip>>();

    //Generic clips
    private List<AudioClip> m_PaigeSelectedClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeDamageClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeSeeZephClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeSeeLeeroyClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeSeeQuarkClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeSeePaigeClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeSeeQuarkTurretClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeDestroyQuarkTurretClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeInQuarkTrapClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeHookedClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeInSmokeClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeWitnessKillClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeKillQuarkClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeKillZephClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeKillLeeroyClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeKillPaigeClipList = new List<AudioClip>();

    //Character specific clips
    private List<AudioClip> m_PaigeThrowAdhesiveClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeTargetInAdhesiveOnLandClipList = new List<AudioClip>();
    private List<AudioClip> m_PaigeHealingInteruptedClipList = new List<AudioClip>();

    private const string m_PaigeSelectedClip0String = "Audio/Dialogue/Paige/dialogue_paige_selected_0";
    private const string m_PaigeSelectedClip1String = "Audio/Dialogue/Paige/dialogue_paige_selected_1";
    private const string m_PaigeSelectedClip2String = "Audio/Dialogue/Paige/dialogue_paige_selected_2";
    private const string m_PaigeSelectedClip3String = "Audio/Dialogue/Paige/dialogue_paige_selected_3";
    private AudioClip m_PaigeSelectedClip0;
    private AudioClip m_PaigeSelectedClip1;
    private AudioClip m_PaigeSelectedClip2;
    private AudioClip m_PaigeSelectedClip3;

    private const string m_PaigeDamageClip0String = "Audio/Dialogue/Paige/dialogue_paige_receivedamage_0";
    private const string m_PaigeDamageClip1String = "Audio/Dialogue/Paige/dialogue_paige_receivedamage_1";
    private const string m_PaigeDamageClip2String = "Audio/Dialogue/Paige/dialogue_paige_receivedamage_2";
    private const string m_PaigeDamageClip3String = "Audio/Dialogue/Paige/dialogue_paige_receivedamage_3";
    private const string m_PaigeDamageClip4String = "Audio/Dialogue/Paige/dialogue_paige_receivedamage_4";
    private const string m_PaigeDamageClip5String = "Audio/Dialogue/Paige/dialogue_paige_receivedamage_5";
    private const string m_PaigeDamageClip6String = "Audio/Dialogue/Paige/dialogue_paige_receivedamage_6";
    private const string m_PaigeDamageClip7String = "Audio/Dialogue/Paige/dialogue_paige_receivedamage_7";
    private const string m_PaigeDamageClip8String = "Audio/Dialogue/Paige/dialogue_paige_receivedamage_8";
    private AudioClip m_PaigeDamageClip0;
    private AudioClip m_PaigeDamageClip1;
    private AudioClip m_PaigeDamageClip2;
    private AudioClip m_PaigeDamageClip3;
    private AudioClip m_PaigeDamageClip4;
    private AudioClip m_PaigeDamageClip5;
    private AudioClip m_PaigeDamageClip6;
    private AudioClip m_PaigeDamageClip7;
    private AudioClip m_PaigeDamageClip8;

    private const string m_PaigeSeeZephClip0String = "Audio/Dialogue/Paige/dialogue_paige_zephsight_0";
    private const string m_PaigeSeeZephClip1String = "Audio/Dialogue/Paige/dialogue_paige_zephsight_1";
    private AudioClip m_PaigeSeeZephClip0;
    private AudioClip m_PaigeSeeZephClip1;

    private const string m_PaigeSeeLeeroyClip0String = "Audio/Dialogue/Paige/dialogue_paige_leeroysight_0";
    private const string m_PaigeSeeLeeroyClip1String = "Audio/Dialogue/Paige/dialogue_paige_leeroysight_1";
    private AudioClip m_PaigeSeeLeeroyClip0;
    private AudioClip m_PaigeSeeLeeroyClip1;

    private const string m_PaigeSeeQuarkClip0String = "Audio/Dialogue/Paige/dialogue_paige_quarksight_0";
    private const string m_PaigeSeeQuarkClip1String = "Audio/Dialogue/Paige/dialogue_paige_quarksight_1";
    private AudioClip m_PaigeSeeQuarkClip0;
    private AudioClip m_PaigeSeeQuarkClip1;

    private const string m_PaigeSeeQuarkTurretClip0String = "Audio/Dialogue/Paige/dialogue_paige_quarkturretsight_0";
    private AudioClip m_PaigeSeeQuarkTurretClip0;

    private const string m_PaigeDestroyQuarkTurretClip0String = "Audio/Dialogue/Paige/dialogue_paige_destroyquarkturret_0";
    private const string m_PaigeDestroyQuarkTurretClip1String = "Audio/Dialogue/Paige/dialogue_paige_destroyquarkturret_1";
    private AudioClip m_PaigeDestroyQuarkTurretClip0;
    private AudioClip m_PaigeDestroyQuarkTurretClip1;

    private const string m_PaigeInQuarkTrapClip0String = "Audio/Dialogue/Paige/dialogue_paige_trapped_0";
    private AudioClip m_PaigeInQuarkTrapClip0;

    private const string m_PaigeHookedClip0String = "Audio/Dialogue/Paige/dialogue_paige_hooked_0";
    private AudioClip m_PaigeHookedClip0;

    private const string m_PaigeInSmokeClip0String = "Audio/Dialogue/Paige/dialogue_paige_insmokescreen_0";
    private AudioClip m_PaigeInSmokeClip0;

    private const string m_PaigeWitnessKill0String = "Audio/Dialogue/Paige/dialogue_paige_witnesskill_0";
    private AudioClip m_PaigeWitnessKillClip0;

    private const string m_PaigeKillZephClip0String = "Audio/Dialogue/Paige/dialogue_paige_killzeph_0";
    private const string m_PaigeKillZephClip1String = "Audio/Dialogue/Paige/dialogue_paige_killzeph_1";
    private AudioClip m_PaigeKillZephClip0;
    private AudioClip m_PaigeKillZephClip1;

    private const string m_PaigeKillLeeroyClip0String = "Audio/Dialogue/Paige/dialogue_paige_killleeroy_0";
    private const string m_PaigeKillLeeroyClip1String = "Audio/Dialogue/Paige/dialogue_paige_killleeroy_1";
    private AudioClip m_PaigeKillLeeroyClip0;
    private AudioClip m_PaigeKillLeeroyClip1;

    private const string m_PaigeKillQuarkClip0String = "Audio/Dialogue/Paige/dialogue_paige_killquark_0";
    private const string m_PaigeKillQuarkClip1String = "Audio/Dialogue/Paige/dialogue_paige_killquark_1";
    private AudioClip m_PaigeKillQuarkClip0;
    private AudioClip m_PaigeKillQuarkClip1;

    private const string m_PaigeThrowAdhesiveClip0String = "Audio/Dialogue/Paige/dialogue_paige_adhesivethrow_0";
    private const string m_PaigeThrowAdhesiveClip1String = "Audio/Dialogue/Paige/dialogue_paige_adhesivethrow_1";
    private AudioClip m_PaigeThrowAdhesiveClip0;
    private AudioClip m_PaigeThrowAdhesiveClip1;

    private const string m_PaigeTargetInAdhesiveOnLandClip0String = "Audio/Dialogue/Paige/dialogue_paige_adhesiveconnects_0";
    private const string m_PaigeTargetInAdhesiveOnLandClip1String = "Audio/Dialogue/Paige/dialogue_paige_adhesiveconnects_1";
    private AudioClip m_PaigeTargetInAdhesiveOnLandClip0;
    private AudioClip m_PaigeTargetInAdhesiveOnLandClip1;

    private const string m_PaigeHealingInteruptedClip0String = "Audio/Dialogue/Paige/dialogue_paige_healingfail_0";
    private AudioClip m_PaigeHealingInteruptedClip0;

    #endregion

    #region Quark Variables
    public Dictionary<DialogueContext, List<AudioClip>> QuarkDialogueDictionary = new Dictionary<DialogueContext, List<AudioClip>>();
    
    //Generic clips
    private List<AudioClip> m_QuarkSelectedClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkDamageClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkSeeZephClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkSeeLeeroyClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkSeePaigeClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkHookedClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkInSmokeClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkWitnessKillClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkKillZephClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkKillLeeroyClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkKillPaigeClipList = new List<AudioClip>();

    private List<AudioClip> m_QuarkMovementAbilityConnectsClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkPlaceTurretClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkPlaceTrapClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkSeeTrapTriggeredClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkThrowCameraClipList = new List<AudioClip>();
    private List<AudioClip> m_QuarkTurretGetsKillClipList = new List<AudioClip>();


    private const string m_QuarkSelectedClip0String = "Audio/Dialogue/Quark/dialogue_Quark_selected_0";
    private const string m_QuarkSelectedClip1String = "Audio/Dialogue/Quark/dialogue_Quark_selected_1";
    private const string m_QuarkSelectedClip2String = "Audio/Dialogue/Quark/dialogue_Quark_selected_2";
    private const string m_QuarkSelectedClip3String = "Audio/Dialogue/Quark/dialogue_Quark_selected_3";
    private const string m_QuarkDamageClip0String = "Audio/Dialogue/Quark/dialogue_quark_receivedamage_0";
    private const string m_QuarkDamageClip1String = "Audio/Dialogue/Quark/dialogue_quark_receivedamage_1";
    private const string m_QuarkDamageClip2String = "Audio/Dialogue/Quark/dialogue_quark_receivedamage_2";
    private const string m_QuarkDamageClip3String = "Audio/Dialogue/Quark/dialogue_quark_receivedamage_3";
    private const string m_QuarkDamageClip4String = "Audio/Dialogue/Quark/dialogue_quark_receivedamage_4";
    private const string m_QuarkDamageClip5String = "Audio/Dialogue/Quark/dialogue_quark_receivedamage_5";
    private const string m_QuarkDamageClip6String = "Audio/Dialogue/Quark/dialogue_quark_receivedamage_6";
    private const string m_QuarkDamageClip7String = "Audio/Dialogue/Quark/dialogue_quark_receivedamage_7";
    private const string m_QuarkDamageClip8String = "Audio/Dialogue/Quark/dialogue_quark_receivedamage_8";
    private const string m_QuarkDamageClip9String = "Audio/Dialogue/Quark/dialogue_quark_receivedamage_9";
    private const string m_QuarkDamageClip10String = "Audio/Dialogue/Quark/dialogue_quark_receivedamage_10";
    private const string m_QuarkSeeZephClip0String = "Audio/Dialogue/Quark/dialogue_quark_zephsight_0";
    private const string m_QuarkSeeZephClip1String = "Audio/Dialogue/Quark/dialogue_quark_zephsight_1";
    private const string m_QuarkSeeLeeroyClip0String = "Audio/Dialogue/Quark/dialogue_quark_leeroysight_0";
    private const string m_QuarkSeeLeeroyClip1String = "Audio/Dialogue/Quark/dialogue_quark_leeroysight_1";
    private const string m_QuarkSeePaigeClip0String = "Audio/Dialogue/Quark/dialogue_quark_paigesight_0";
    private const string m_QuarkSeePaigeClip1String = "Audio/Dialogue/Quark/dialogue_quark_paigesight_1";
    private const string m_QuarkHookedClip0String = "Audio/Dialogue/Quark/dialogue_quark_hooked_0";
    private const string m_QuarkInSmokeClip0String = "Audio/Dialogue/Quark/dialogue_quark_insmokescreen_0";
    private const string m_QuarkWitnessKillClip0String = "Audio/Dialogue/Quark/dialogue_quark_witnesskill_0";
    private const string m_QuarkKillZephClip0String = "Audio/Dialogue/Quark/dialogue_quark_killzeph_0";
    private const string m_QuarkKillZephClip1String = "Audio/Dialogue/Quark/dialogue_quark_killzeph_1";
    private const string m_QuarkKillLeeroyClip0String = "Audio/Dialogue/Quark/dialogue_quark_killleeroy_0";
    private const string m_QuarkKillLeeroyClip1String = "Audio/Dialogue/Quark/dialogue_quark_killleeroy_1";
    private const string m_QuarkKillPaigeClip0String = "Audio/Dialogue/Quark/dialogue_quark_killpaige_0";
    private const string m_QuarkKillPaigeClip1String = "Audio/Dialogue/Quark/dialogue_quark_killpaige_1";
    private const string m_QuarkMovementAbilityConnectsClip0String = "Audio/Dialogue/Quark/dialogue_quark_movementconnects_0";
    private const string m_QuarkMovementAbilityConnectsClip1String = "Audio/Dialogue/Quark/dialogue_quark_movementconnects_1";
    private const string m_QuarkMovementAbilityConnectsClip2String = "Audio/Dialogue/Quark/dialogue_quark_movementconnects_2";
    private const string m_QuarkPlaceTurretClip0String = "Audio/Dialogue/Quark/dialogue_quark_placeturret_0";
    private const string m_QuarkPlaceTurretClip1String = "Audio/Dialogue/Quark/dialogue_quark_placeturret_1";
    private const string m_QuarkPlaceTurretClip2String = "Audio/Dialogue/Quark/dialogue_quark_placeturret_2";
    private const string m_QuarkPlaceTurretClip3String = "Audio/Dialogue/Quark/dialogue_quark_placeturret_3";
    private const string m_QuarkPlaceTurretClip4String = "Audio/Dialogue/Quark/dialogue_quark_placeturret_4";
    private const string m_QuarkPlaceTrapClip0String = "Audio/Dialogue/Quark/dialogue_quark_placetrap_0";
    private const string m_QuarkPlaceTrapClip1String = "Audio/Dialogue/Quark/dialogue_quark_placetrap_1";
    private const string m_QuarkPlaceTrapClip2String = "Audio/Dialogue/Quark/dialogue_quark_placetrap_2";
    private const string m_QuarkSeeTrapTriggeredClip0String = "Audio/Dialogue/Quark/dialogue_quark_seetraptriggered_0";
    private const string m_QuarkSeeTrapTriggeredClip1String = "Audio/Dialogue/Quark/dialogue_quark_seetraptriggered_1";
    private const string m_QuarkSeeTrapTriggeredClip2String = "Audio/Dialogue/Quark/dialogue_quark_seetraptriggered_2";
    private const string m_QuarkThrowCameraClip0String = "Audio/Dialogue/Quark/dialogue_quark_throwcamera_0";
    private const string m_QuarkThrowCameraClip1String = "Audio/Dialogue/Quark/dialogue_quark_throwcamera_1";
    private const string m_QuarkThrowCameraClip2String = "Audio/Dialogue/Quark/dialogue_quark_throwcamera_2";
    private const string m_QuarkTurretGetsKillClip0String = "Audio/Dialogue/Quark/dialogue_quark_turretkill_0";
    private const string m_QuarkTurretGetsKillClip1String = "Audio/Dialogue/Quark/dialogue_quark_turretkill_1";
    private const string m_QuarkTurretGetsKillClip2String = "Audio/Dialogue/Quark/dialogue_quark_turretkill_2";

    private AudioClip m_QuarkSelectedClip0;
    private AudioClip m_QuarkSelectedClip1;
    private AudioClip m_QuarkSelectedClip2;
    private AudioClip m_QuarkSelectedClip3;

    private AudioClip m_QuarkDamageClip0;
    private AudioClip m_QuarkDamageClip1;
    private AudioClip m_QuarkDamageClip2;
    private AudioClip m_QuarkDamageClip3;
    private AudioClip m_QuarkDamageClip4;
    private AudioClip m_QuarkDamageClip5;
    private AudioClip m_QuarkDamageClip6;
    private AudioClip m_QuarkDamageClip7;
    private AudioClip m_QuarkDamageClip8;
    private AudioClip m_QuarkDamageClip9;
    private AudioClip m_QuarkDamageClip10;

    private AudioClip m_QuarkSeeZephClip0;
    private AudioClip m_QuarkSeeZephClip1;

    private AudioClip m_QuarkSeeLeeroyClip0;
    private AudioClip m_QuarkSeeLeeroyClip1;

    private AudioClip m_QuarkSeePaigeClip0;
    private AudioClip m_QuarkSeePaigeClip1;

    private AudioClip m_QuarkHookedClip0;

    private AudioClip m_QuarkInSmokeClip0;

    private AudioClip m_QuarkWitnessKillClip0;

    private AudioClip m_QuarkKillZephClip0;
    private AudioClip m_QuarkKillZephClip1;

    private AudioClip m_QuarkKillLeeroyClip0;
    private AudioClip m_QuarkKillLeeroyClip1;

    private AudioClip m_QuarkKillPaigeClip0;
    private AudioClip m_QuarkKillPaigeClip1;

    private AudioClip m_QuarkMovementAbilityConnectsClip0;
    private AudioClip m_QuarkMovementAbilityConnectsClip1;
    private AudioClip m_QuarkMovementAbilityConnectsClip2;

    private AudioClip m_QuarkPlaceTurretClip0;
    private AudioClip m_QuarkPlaceTurretClip1;
    private AudioClip m_QuarkPlaceTurretClip2;
    private AudioClip m_QuarkPlaceTurretClip3;
    private AudioClip m_QuarkPlaceTurretClip4;

    private AudioClip m_QuarkPlaceTrapClip0;
    private AudioClip m_QuarkPlaceTrapClip1;
    private AudioClip m_QuarkPlaceTrapClip2;

    private AudioClip m_QuarkSeeTrapTriggeredClip0;
    private AudioClip m_QuarkSeeTrapTriggeredClip1;
    private AudioClip m_QuarkSeeTrapTriggeredClip2;

    private AudioClip m_QuarkThrowCameraClip0;
    private AudioClip m_QuarkThrowCameraClip1;
    private AudioClip m_QuarkThrowCameraClip2;

    private AudioClip m_QuarkTurretGetsKillClip0;
    private AudioClip m_QuarkTurretGetsKillClip1;
    private AudioClip m_QuarkTurretGetsKillClip2;
    #endregion

    #region Zeph Variables
    public Dictionary<DialogueContext, List<AudioClip>> ZephDialogueDictionary = new Dictionary<DialogueContext, List<AudioClip>>();

    //Generic clips
    private List<AudioClip> m_ZephSelectedClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephDamageClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephSeeLeeroyClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephSeeQuarkClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephSeePaigeClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephSeeQuarkTurretClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephDestroyQuarkTurretClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephInQuarkTrapClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephInAdhesiveClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephWitnessKillClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephKillQuarkClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephKillLeeroyClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephKillPaigeClipList = new List<AudioClip>();

    private List<AudioClip> m_ZephMainAttackClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephPullOpponentClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephCatchesPplInSMokeClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephSuccessfulPoisonClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephMissThrownAttackClipList = new List<AudioClip>();
    private List<AudioClip> m_ZephTeleportClipList = new List<AudioClip>();

    private const string m_ZephSelectedClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_selected_0";
    private const string m_ZephSelectedClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_selected_1";
    private const string m_ZephSelectedClip2String = "Audio/Dialogue/Zeph/dialogue_zeph_selected_2";
    private const string m_ZephSelectedClip3String = "Audio/Dialogue/Zeph/dialogue_zeph_selected_3";
    private const string m_ZephDamageClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_receivedamage_0";
    private const string m_ZephDamageClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_receivedamage_1";
    private const string m_ZephDamageClip2String = "Audio/Dialogue/Zeph/dialogue_zeph_receivedamage_2";
    private const string m_ZephDamageClip3String = "Audio/Dialogue/Zeph/dialogue_zeph_receivedamage_3";
    private const string m_ZephDamageClip4String = "Audio/Dialogue/Zeph/dialogue_zeph_receivedamage_4";
    private const string m_ZephDamageClip5String = "Audio/Dialogue/Zeph/dialogue_zeph_receivedamage_5";
    private const string m_ZephDamageClip6String = "Audio/Dialogue/Zeph/dialogue_zeph_receivedamage_6";
    private const string m_ZephDamageClip7String = "Audio/Dialogue/Zeph/dialogue_zeph_receivedamage_7";
    private const string m_ZephDamageClip8String = "Audio/Dialogue/Zeph/dialogue_zeph_receivedamage_8";
    private const string m_ZephSeeLeeroyClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_leeroysight_0";
    private const string m_ZephSeeLeeroyClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_leeroysight_1";
    private const string m_ZephSeeQuarkClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_quarksight_0";
    private const string m_ZephSeeQuarkClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_quarksight_1";
    private const string m_ZephSeePaigeClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_paigesight_0";
    private const string m_ZephSeePaigeClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_paigesight_1";
    private const string m_ZephSeeQuarkTurretClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_quarkturretsight_0";
    private const string m_ZephDestroyQuarkTurretClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_destroyquarkturret_0";
    private const string m_ZephDestroyQuarkTurretClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_destroyquarkturret_1";
    private const string m_ZephInQuarkTrapClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_trapped_0";
    private const string m_ZephInAdhesiveClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_inadhesive_0";
    private const string m_ZephWitnessKillClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_witnesskill_0";
    private const string m_ZephKillQuarkClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_killquark_0";
    private const string m_ZephKillQuarkClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_killquark_1";
    private const string m_ZephKillLeeroyClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_killleeroy_0";
    private const string m_ZephKillLeeroyClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_killleeroy_1";
    private const string m_ZephKillPaigeClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_killpaige_0";
    private const string m_ZephKillPaigeClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_killpaige_1";
    private const string m_ZephMainAttackClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_melee_0";
    private const string m_ZephMainAttackClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_melee_1";
    private const string m_ZephMainAttackClip2String = "Audio/Dialogue/Zeph/dialogue_zeph_melee_2";
    private const string m_ZephMainAttackClip3String = "Audio/Dialogue/Zeph/dialogue_zeph_melee_3";
    private const string m_ZephMainAttackClip4String = "Audio/Dialogue/Zeph/dialogue_zeph_melee_4";
    private const string m_ZephMainAttackClip5String = "Audio/Dialogue/Zeph/dialogue_zeph_melee_5";
    private const string m_ZephMainAttackClip6String = "Audio/Dialogue/Zeph/dialogue_zeph_melee_6";
    private const string m_ZephMainAttackClip7String = "Audio/Dialogue/Zeph/dialogue_zeph_melee_7";
    private const string m_ZephMainAttackClip8String = "Audio/Dialogue/Zeph/dialogue_zeph_melee_8";
    private const string m_ZephMainAttackClip9String = "Audio/Dialogue/Zeph/dialogue_zeph_melee_9";
    private const string m_ZephMainAttackClip10String = "Audio/Dialogue/Zeph/dialogue_zeph_melee_10";
    private const string m_ZephPullOpponentClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_pulls_0";
    private const string m_ZephCatchesPplInSMokeClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_smokeconnects_0";
    private const string m_ZephCatchesPplInSMokeClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_smokeconnects_1";
    private const string m_ZephSuccessfulPoisonClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_poisonsuccess_0";
    private const string m_ZephSuccessfulPoisonClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_poisonsuccess_1";
    private const string m_ZephMissThrownAttackClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_thrownmiss_0";
    private const string m_ZephMissThrownAttackClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_thrownmiss_1";
    private const string m_ZephTeleportClip0String = "Audio/Dialogue/Zeph/dialogue_zeph_teleport_0";
    private const string m_ZephTeleportClip1String = "Audio/Dialogue/Zeph/dialogue_zeph_teleport_1";

    private AudioClip m_ZephSelectedClip0; 
    private AudioClip m_ZephSelectedClip1; 
    private AudioClip m_ZephSelectedClip2; 
    private AudioClip m_ZephSelectedClip3; 
    private AudioClip m_ZephDamageClip0;
    private AudioClip m_ZephDamageClip1;
    private AudioClip m_ZephDamageClip2;
    private AudioClip m_ZephDamageClip3;
    private AudioClip m_ZephDamageClip4;
    private AudioClip m_ZephDamageClip5;
    private AudioClip m_ZephDamageClip6;
    private AudioClip m_ZephDamageClip7;
    private AudioClip m_ZephDamageClip8; 
    private AudioClip m_ZephSeeLeeroyClip0; 
    private AudioClip m_ZephSeeLeeroyClip1; 
    private AudioClip m_ZephSeeQuarkClip0; 
    private AudioClip m_ZephSeeQuarkClip1; 
    private AudioClip m_ZephSeePaigeClip0; 
    private AudioClip m_ZephSeePaigeClip1;
    private AudioClip m_ZephSeeQuarkTurretClip0;
    private AudioClip m_ZephDestroyQuarkTurretClip0; 
    private AudioClip m_ZephDestroyQuarkTurretClip1; 
    private AudioClip m_ZephInQuarkTrapClip0; 
    private AudioClip m_ZephInAdhesiveClip0; 
    private AudioClip m_ZephWitnessKillClip0; 
    private AudioClip m_ZephKillQuarkClip0; 
    private AudioClip m_ZephKillQuarkClip1; 
    private AudioClip m_ZephKillLeeroyClip0; 
    private AudioClip m_ZephKillLeeroyClip1; 
    private AudioClip m_ZephKillPaigeClip0; 
    private AudioClip m_ZephKillPaigeClip1; 
    private AudioClip m_ZephMainAttackClip0; 
    private AudioClip m_ZephMainAttackClip1; 
    private AudioClip m_ZephMainAttackClip2; 
    private AudioClip m_ZephMainAttackClip3; 
    private AudioClip m_ZephMainAttackClip4; 
    private AudioClip m_ZephMainAttackClip5; 
    private AudioClip m_ZephMainAttackClip6; 
    private AudioClip m_ZephMainAttackClip7; 
    private AudioClip m_ZephMainAttackClip8; 
    private AudioClip m_ZephMainAttackClip9;  
    private AudioClip m_ZephMainAttackClip10;      
    private AudioClip m_ZephPullOpponentClip0;
    private AudioClip m_ZephCatchesPplInSMokeClip0;
    private AudioClip m_ZephCatchesPplInSMokeClip1;
    private AudioClip m_ZephSuccessfulPoisonClip0;
    private AudioClip m_ZephSuccessfulPoisonClip1;
    private AudioClip m_ZephMissThrownAttackClip0;
    private AudioClip m_ZephMissThrownAttackClip1;
    private AudioClip m_ZephTeleportClip0;
    private AudioClip m_ZephTeleportClip1;

    #endregion

    void Start()
    {
        #region Leeroy Variable Initialization

        m_LeeroySelectedClip0 = (AudioClip)Resources.Load(m_LeeroySelectedClip0String);
        m_LeeroySelectedClip1 = (AudioClip)Resources.Load(m_LeeroySelectedClip1String);
        m_LeeroySelectedClip2 = (AudioClip)Resources.Load(m_LeeroySelectedClip2String);
        m_LeeroySelectedClip3 = (AudioClip)Resources.Load(m_LeeroySelectedClip3String);
        m_LeeroySelectedClipList.Add(m_LeeroySelectedClip0);
        m_LeeroySelectedClipList.Add(m_LeeroySelectedClip1);
        m_LeeroySelectedClipList.Add(m_LeeroySelectedClip2);
        m_LeeroySelectedClipList.Add(m_LeeroySelectedClip3);
        LeeroyDialogueDictionary.Add(DialogueContext.CharSelected, m_LeeroySelectedClipList);

        m_LeeroyDamageClip0 = (AudioClip)Resources.Load(m_LeeroyDamageClip0String);
        m_LeeroyDamageClip1 = (AudioClip)Resources.Load(m_LeeroyDamageClip1String);
        m_LeeroyDamageClip2 = (AudioClip)Resources.Load(m_LeeroyDamageClip2String);
        m_LeeroyDamageClip3 = (AudioClip)Resources.Load(m_LeeroyDamageClip3String);
        m_LeeroyDamageClip4 = (AudioClip)Resources.Load(m_LeeroyDamageClip4String);
        m_LeeroyDamageClip5 = (AudioClip)Resources.Load(m_LeeroyDamageClip5String);
        m_LeeroyDamageClip6 = (AudioClip)Resources.Load(m_LeeroyDamageClip6String);
        m_LeeroyDamageClip7 = (AudioClip)Resources.Load(m_LeeroyDamageClip7String);
        m_LeeroyDamageClip8 = (AudioClip)Resources.Load(m_LeeroyDamageClip8String);
        m_LeeroyDamageClip9 = (AudioClip)Resources.Load(m_LeeroyDamageClip9String);
        m_LeeroyDamageClipList.Add(m_LeeroyDamageClip0);
        m_LeeroyDamageClipList.Add(m_LeeroyDamageClip1);
        m_LeeroyDamageClipList.Add(m_LeeroyDamageClip2);
        m_LeeroyDamageClipList.Add(m_LeeroyDamageClip3);
        m_LeeroyDamageClipList.Add(m_LeeroyDamageClip4);
        m_LeeroyDamageClipList.Add(m_LeeroyDamageClip5);
        m_LeeroyDamageClipList.Add(m_LeeroyDamageClip6);
        m_LeeroyDamageClipList.Add(m_LeeroyDamageClip7);
        m_LeeroyDamageClipList.Add(m_LeeroyDamageClip8);
        m_LeeroyDamageClipList.Add(m_LeeroyDamageClip9);
        LeeroyDialogueDictionary.Add(DialogueContext.Damage, m_LeeroyDamageClipList);

        m_LeeroySeeZephClip0 = (AudioClip)Resources.Load(m_LeeroySeeZephClip0String);
        m_LeeroySeeZephClip1 = (AudioClip)Resources.Load(m_LeeroySeeZephClip1String);
        m_LeeroySeeZephClipList.Add(m_LeeroySeeZephClip0);
        m_LeeroySeeZephClipList.Add(m_LeeroySeeZephClip1);
        LeeroyDialogueDictionary.Add(DialogueContext.SeeZeph, m_LeeroySeeZephClipList);

        m_LeeroySeeQuarkClip0 = (AudioClip)Resources.Load(m_LeeroySeeQuarkClip0String);
        m_LeeroySeeQuarkClip1 = (AudioClip)Resources.Load(m_LeeroySeeQuarkClip1String);
        m_LeeroySeeQuarkClipList.Add(m_LeeroySeeQuarkClip0);
        m_LeeroySeeQuarkClipList.Add(m_LeeroySeeQuarkClip1);
        LeeroyDialogueDictionary.Add(DialogueContext.SeeQuark, m_LeeroySeeQuarkClipList);

        m_LeeroySeePaigeClip0 = (AudioClip)Resources.Load(m_LeeroySeePaigeClip0String);
        m_LeeroySeePaigeClip1 = (AudioClip)Resources.Load(m_LeeroySeePaigeClip1String);
        m_LeeroySeePaigeClipList.Add(m_LeeroySeePaigeClip0);
        m_LeeroySeePaigeClipList.Add(m_LeeroySeePaigeClip1);
        LeeroyDialogueDictionary.Add(DialogueContext.SeePaige, m_LeeroySeePaigeClipList);

        m_LeeroySeeQuarkTurretClip0 = (AudioClip)Resources.Load(m_LeeroySeeQuarkTurretClip0String);
        m_LeeroySeeQuarkTurretClipList.Add(m_LeeroySeeQuarkTurretClip0);
        LeeroyDialogueDictionary.Add(DialogueContext.SeeQuarkTurret, m_LeeroySeeQuarkTurretClipList);

        m_LeeroyDestroyQuarkTurretClip0 = (AudioClip)Resources.Load(m_LeeroyDestroyQuarkTurretClip0String);
        m_LeeroyDestroyQuarkTurretClipList.Add(m_LeeroyDestroyQuarkTurretClip0);
        LeeroyDialogueDictionary.Add(DialogueContext.DestroyQuarkTurret, m_LeeroyDestroyQuarkTurretClipList);

        m_LeeroyHookedClip0 = (AudioClip)Resources.Load(m_LeeroyHookedClip0String);
        m_LeeroyHookedClipList.Add(m_LeeroyHookedClip0);
        LeeroyDialogueDictionary.Add(DialogueContext.Hooked, m_LeeroyHookedClipList);

        m_LeeroyInSmokeClip0 = (AudioClip)Resources.Load(m_LeeroyInSmokeClip0String);
        m_LeeroyInSmokeClipList.Add(m_LeeroyInSmokeClip0);
        LeeroyDialogueDictionary.Add(DialogueContext.InSmoke, m_LeeroyInSmokeClipList);

        m_LeeroyInAdhesiveClip0 = (AudioClip)Resources.Load(m_LeeroyInAdhesiveClip0String);
        m_LeeroyInAdhesiveClipList.Add(m_LeeroyInAdhesiveClip0);
        LeeroyDialogueDictionary.Add(DialogueContext.InAdhesive, m_LeeroyInAdhesiveClipList);

        m_LeeroyWitnessKillClip0 = (AudioClip)Resources.Load(m_LeeroyWitnessKillClip0String);
        m_LeeroyWitnessKillClipList.Add(m_LeeroyWitnessKillClip0);
        LeeroyDialogueDictionary.Add(DialogueContext.WitnessKill, m_LeeroyWitnessKillClipList);

        m_LeeroyKillQuarkClip0 = (AudioClip)Resources.Load(m_LeeroyKillQuarkClip0String);
        m_LeeroyKillQuarkClipList.Add(m_LeeroyKillQuarkClip0);
        LeeroyDialogueDictionary.Add(DialogueContext.KilledQuark, m_LeeroyKillQuarkClipList);

        m_LeeroyKillZephClip0 = (AudioClip)Resources.Load(m_LeeroyKillZephClip0String);
        m_LeeroyKillZephClip1 = (AudioClip)Resources.Load(m_LeeroyKillZephClip1String);
        m_LeeroyKillZephClipList.Add(m_LeeroyKillZephClip0);
        m_LeeroyKillZephClipList.Add(m_LeeroyKillZephClip1);
        LeeroyDialogueDictionary.Add(DialogueContext.KilledZeph, m_LeeroyKillZephClipList);

        m_LeeroyKillPaigeClip0 = (AudioClip)Resources.Load(m_LeeroyKillPaigeClip0String);
        m_LeeroyKillPaigeClip1 = (AudioClip)Resources.Load(m_LeeroyKillPaigeClip1String);
        m_LeeroyKillPaigeClipList.Add(m_LeeroyKillPaigeClip0);
        m_LeeroyKillPaigeClipList.Add(m_LeeroyKillPaigeClip1);
        LeeroyDialogueDictionary.Add(DialogueContext.KilledPaige, m_LeeroyKillPaigeClipList);

        m_LeeroyPounceClip0 = (AudioClip)Resources.Load(m_LeeroyPounceClip0String);
        m_LeeroyPounceClip1 = (AudioClip)Resources.Load(m_LeeroyPounceClip1String);
        m_LeeroyPounceClip2 = (AudioClip)Resources.Load(m_LeeroyPounceClip2String);
        m_LeeroyPounceClipList.Add(m_LeeroyPounceClip0);
        m_LeeroyPounceClipList.Add(m_LeeroyPounceClip1);
        m_LeeroyPounceClipList.Add(m_LeeroyPounceClip2);
        LeeroyDialogueDictionary.Add(DialogueContext.LeeroyPounce, m_LeeroyPounceClipList);

        m_LeeroyMainAttackClip0 = (AudioClip)Resources.Load(m_LeeroyMainAttackClip0String);
        m_LeeroyMainAttackClip1 = (AudioClip)Resources.Load(m_LeeroyMainAttackClip1String);
        m_LeeroyMainAttackClip2 = (AudioClip)Resources.Load(m_LeeroyMainAttackClip2String);
        m_LeeroyMainAttackClip3 = (AudioClip)Resources.Load(m_LeeroyMainAttackClip3String);
        m_LeeroyMainAttackClip4 = (AudioClip)Resources.Load(m_LeeroyMainAttackClip4String);
        m_LeeroyMainAttackClip5 = (AudioClip)Resources.Load(m_LeeroyMainAttackClip5String);
        m_LeeroyMainAttackClip6 = (AudioClip)Resources.Load(m_LeeroyMainAttackClip6String);
        m_LeeroyMainAttackClip7 = (AudioClip)Resources.Load(m_LeeroyMainAttackClip7String);
        m_LeeroyMainAttackClip8 = (AudioClip)Resources.Load(m_LeeroyMainAttackClip8String);
        m_LeeroyMainAttackClipList.Add(m_LeeroyMainAttackClip0);
        m_LeeroyMainAttackClipList.Add(m_LeeroyMainAttackClip1);
        m_LeeroyMainAttackClipList.Add(m_LeeroyMainAttackClip2);
        m_LeeroyMainAttackClipList.Add(m_LeeroyMainAttackClip3);
        m_LeeroyMainAttackClipList.Add(m_LeeroyMainAttackClip4);
        m_LeeroyMainAttackClipList.Add(m_LeeroyMainAttackClip5);
        m_LeeroyMainAttackClipList.Add(m_LeeroyMainAttackClip6);
        m_LeeroyMainAttackClipList.Add(m_LeeroyMainAttackClip7);
        m_LeeroyMainAttackClipList.Add(m_LeeroyMainAttackClip8);
        LeeroyDialogueDictionary.Add(DialogueContext.MainAttack, m_LeeroyMainAttackClipList);

        m_LeeroyMainAttackRagedClip0 = (AudioClip)Resources.Load(m_LeeroyMainAttackRagedClip0String);
        m_LeeroyMainAttackRagedClip1 = (AudioClip)Resources.Load(m_LeeroyMainAttackRagedClip1String);
        m_LeeroyMainAttackRagedClip2 = (AudioClip)Resources.Load(m_LeeroyMainAttackRagedClip2String);
        m_LeeroyMainAttackRagedClip3 = (AudioClip)Resources.Load(m_LeeroyMainAttackRagedClip3String);
        m_LeeroyMainAttackRagedClipList.Add(m_LeeroyMainAttackRagedClip0);
        m_LeeroyMainAttackRagedClipList.Add(m_LeeroyMainAttackRagedClip1);
        m_LeeroyMainAttackRagedClipList.Add(m_LeeroyMainAttackRagedClip2);
        m_LeeroyMainAttackRagedClipList.Add(m_LeeroyMainAttackRagedClip3);
        LeeroyDialogueDictionary.Add(DialogueContext.LeeroyMainAttackRaged, m_LeeroyMainAttackRagedClipList);

        m_LeeroyClapstunClip0 = (AudioClip)Resources.Load(m_LeeroyClapstunClip0String);
        m_LeeroyClapstunClipList.Add(m_LeeroyClapstunClip0);
        LeeroyDialogueDictionary.Add(DialogueContext.LeeroyClapstun, m_LeeroyClapstunClipList);

        m_LeeroyGrenadeHitClip0 = (AudioClip)Resources.Load(m_LeeroyGrenadeHitClip0String);
        m_LeeroyGrenadeHitClipList.Add(m_LeeroyGrenadeHitClip0);
        LeeroyDialogueDictionary.Add(DialogueContext.LeeroyGrenadeHit, m_LeeroyGrenadeHitClipList);

        m_LeeroyLeeroidRageClip0 = (AudioClip)Resources.Load(m_LeeroyLeeroidRageClip0String);
        m_LeeroyLeeroidRageClipList.Add(m_LeeroyLeeroidRageClip0);
        LeeroyDialogueDictionary.Add(DialogueContext.LeeroidRage, m_LeeroyLeeroidRageClipList);

        m_LeeroyReceiveDamageRagedClip0 = (AudioClip)Resources.Load(m_LeeroyReceiveDamageRagedClip0String);
        m_LeeroyReceiveDamageRagedClip1 = (AudioClip)Resources.Load(m_LeeroyReceiveDamageRagedClip1String);
        m_LeeroyReceiveDamageRagedClipList.Add(m_LeeroyReceiveDamageRagedClip0);
        m_LeeroyReceiveDamageRagedClipList.Add(m_LeeroyReceiveDamageRagedClip1);
        LeeroyDialogueDictionary.Add(DialogueContext.LeeroyDamagedRaged, m_LeeroyReceiveDamageRagedClipList);

        #endregion

        #region Paige Variable Initialization

        m_PaigeSelectedClip0 = (AudioClip)Resources.Load(m_PaigeSelectedClip0String);
        m_PaigeSelectedClip1 = (AudioClip)Resources.Load(m_PaigeSelectedClip1String);
        m_PaigeSelectedClip2 = (AudioClip)Resources.Load(m_PaigeSelectedClip2String);
        m_PaigeSelectedClip3 = (AudioClip)Resources.Load(m_PaigeSelectedClip3String);
        m_PaigeSelectedClipList.Add(m_PaigeSelectedClip0);
        m_PaigeSelectedClipList.Add(m_PaigeSelectedClip1);
        m_PaigeSelectedClipList.Add(m_PaigeSelectedClip2);
        m_PaigeSelectedClipList.Add(m_PaigeSelectedClip3);
        PaigeDialogueDictionary.Add(DialogueContext.CharSelected, m_PaigeSelectedClipList);

        m_PaigeDamageClip0 = (AudioClip)Resources.Load(m_PaigeDamageClip0String);
        m_PaigeDamageClip1 = (AudioClip)Resources.Load(m_PaigeDamageClip1String);
        m_PaigeDamageClip2 = (AudioClip)Resources.Load(m_PaigeDamageClip2String);
        m_PaigeDamageClip3 = (AudioClip)Resources.Load(m_PaigeDamageClip3String);
        m_PaigeDamageClip4 = (AudioClip)Resources.Load(m_PaigeDamageClip4String);
        m_PaigeDamageClip5 = (AudioClip)Resources.Load(m_PaigeDamageClip5String);
        m_PaigeDamageClip6 = (AudioClip)Resources.Load(m_PaigeDamageClip6String);
        m_PaigeDamageClip7 = (AudioClip)Resources.Load(m_PaigeDamageClip7String);
        m_PaigeDamageClip8 = (AudioClip)Resources.Load(m_PaigeDamageClip8String);
        m_PaigeDamageClipList.Add(m_PaigeDamageClip0);
        m_PaigeDamageClipList.Add(m_PaigeDamageClip1);
        m_PaigeDamageClipList.Add(m_PaigeDamageClip2);
        m_PaigeDamageClipList.Add(m_PaigeDamageClip3);
        m_PaigeDamageClipList.Add(m_PaigeDamageClip4);
        m_PaigeDamageClipList.Add(m_PaigeDamageClip5);
        m_PaigeDamageClipList.Add(m_PaigeDamageClip6);
        m_PaigeDamageClipList.Add(m_PaigeDamageClip7);
        m_PaigeDamageClipList.Add(m_PaigeDamageClip8);
        PaigeDialogueDictionary.Add(DialogueContext.Damage, m_PaigeDamageClipList);


        m_PaigeSeeZephClip0 = (AudioClip)Resources.Load(m_PaigeSeeZephClip0String);
        m_PaigeSeeZephClip1 = (AudioClip)Resources.Load(m_PaigeSeeZephClip1String);
        m_PaigeSeeZephClipList.Add(m_PaigeSeeZephClip0);
        m_PaigeSeeZephClipList.Add(m_PaigeSeeZephClip1);
        PaigeDialogueDictionary.Add(DialogueContext.SeeZeph, m_PaigeSeeZephClipList);

        m_PaigeSeeLeeroyClip0 = (AudioClip)Resources.Load(m_PaigeSeeLeeroyClip0String);
        m_PaigeSeeLeeroyClip1 = (AudioClip)Resources.Load(m_PaigeSeeLeeroyClip1String);
        m_PaigeSeeLeeroyClipList.Add(m_PaigeSeeLeeroyClip0);
        m_PaigeSeeLeeroyClipList.Add(m_PaigeSeeLeeroyClip1);
        PaigeDialogueDictionary.Add(DialogueContext.SeeLeeroy, m_PaigeSeeLeeroyClipList);

        m_PaigeSeeQuarkClip0 = (AudioClip)Resources.Load(m_PaigeSeeQuarkClip0String);
        m_PaigeSeeQuarkClip1 = (AudioClip)Resources.Load(m_PaigeSeeQuarkClip1String);
        m_PaigeSeeQuarkClipList.Add(m_PaigeSeeQuarkClip0);
        m_PaigeSeeQuarkClipList.Add(m_PaigeSeeQuarkClip1);
        PaigeDialogueDictionary.Add(DialogueContext.SeeQuark, m_PaigeSeeQuarkClipList);

        m_PaigeSeeQuarkTurretClip0 = (AudioClip)Resources.Load(m_PaigeSeeQuarkTurretClip0String);
        m_PaigeSeeQuarkTurretClipList.Add(m_PaigeSeeQuarkTurretClip0);
        PaigeDialogueDictionary.Add(DialogueContext.SeeQuarkTurret, m_PaigeSeeQuarkTurretClipList);

        m_PaigeDestroyQuarkTurretClip0 = (AudioClip)Resources.Load(m_PaigeDestroyQuarkTurretClip0String);
        m_PaigeDestroyQuarkTurretClip1 = (AudioClip)Resources.Load(m_PaigeDestroyQuarkTurretClip1String);
        m_PaigeDestroyQuarkTurretClipList.Add(m_PaigeDestroyQuarkTurretClip0);
        m_PaigeDestroyQuarkTurretClipList.Add(m_PaigeDestroyQuarkTurretClip1);
        PaigeDialogueDictionary.Add(DialogueContext.DestroyQuarkTurret, m_PaigeDestroyQuarkTurretClipList);

        m_PaigeInQuarkTrapClip0 = (AudioClip)Resources.Load(m_PaigeInQuarkTrapClip0String);
        m_PaigeInQuarkTrapClipList.Add(m_PaigeInQuarkTrapClip0);
        PaigeDialogueDictionary.Add(DialogueContext.InQuarkTrap, m_PaigeInQuarkTrapClipList);

        m_PaigeHookedClip0 = (AudioClip)Resources.Load(m_PaigeHookedClip0String);
        m_PaigeHookedClipList.Add(m_PaigeHookedClip0);
        PaigeDialogueDictionary.Add(DialogueContext.Hooked, m_PaigeHookedClipList);

        m_PaigeInSmokeClip0 = (AudioClip)Resources.Load(m_PaigeInSmokeClip0String);
        m_PaigeInSmokeClipList.Add(m_PaigeInSmokeClip0);
        PaigeDialogueDictionary.Add(DialogueContext.InSmoke, m_PaigeInSmokeClipList);

        m_PaigeWitnessKillClip0 = (AudioClip)Resources.Load(m_PaigeWitnessKill0String);
        m_PaigeWitnessKillClipList.Add(m_PaigeWitnessKillClip0);
        PaigeDialogueDictionary.Add(DialogueContext.WitnessKill, m_PaigeWitnessKillClipList);

        m_PaigeKillZephClip0 = (AudioClip)Resources.Load(m_PaigeKillZephClip0String);
        m_PaigeKillZephClip1 = (AudioClip)Resources.Load(m_PaigeKillZephClip1String);
        m_PaigeKillZephClipList.Add(m_PaigeKillZephClip0);
        m_PaigeKillZephClipList.Add(m_PaigeKillZephClip1);
        PaigeDialogueDictionary.Add(DialogueContext.KilledZeph, m_PaigeKillZephClipList);

        m_PaigeKillLeeroyClip0 = (AudioClip)Resources.Load(m_PaigeKillLeeroyClip0String);
        m_PaigeKillLeeroyClip1 = (AudioClip)Resources.Load(m_PaigeKillLeeroyClip1String);
        m_PaigeKillLeeroyClipList.Add(m_PaigeKillLeeroyClip0);
        m_PaigeKillLeeroyClipList.Add(m_PaigeKillLeeroyClip1);
        PaigeDialogueDictionary.Add(DialogueContext.KilledLeeroy, m_PaigeKillLeeroyClipList);

        m_PaigeKillQuarkClip0 = (AudioClip)Resources.Load(m_PaigeKillQuarkClip0String);
        m_PaigeKillQuarkClip1 = (AudioClip)Resources.Load(m_PaigeKillQuarkClip1String);
        m_PaigeKillQuarkClipList.Add(m_PaigeKillQuarkClip0);
        m_PaigeKillQuarkClipList.Add(m_PaigeKillQuarkClip1);
        PaigeDialogueDictionary.Add(DialogueContext.KilledQuark, m_PaigeKillQuarkClipList);

        m_PaigeThrowAdhesiveClip0 = (AudioClip)Resources.Load(m_PaigeThrowAdhesiveClip0String);
        m_PaigeThrowAdhesiveClip1 = (AudioClip)Resources.Load(m_PaigeThrowAdhesiveClip0String);
        m_PaigeThrowAdhesiveClipList.Add(m_PaigeThrowAdhesiveClip0);
        m_PaigeThrowAdhesiveClipList.Add(m_PaigeThrowAdhesiveClip1);
        PaigeDialogueDictionary.Add(DialogueContext.PaigeThrowAdhesive, m_PaigeThrowAdhesiveClipList);

        m_PaigeTargetInAdhesiveOnLandClip0 = (AudioClip)Resources.Load(m_PaigeTargetInAdhesiveOnLandClip0String);
        m_PaigeTargetInAdhesiveOnLandClip1 = (AudioClip)Resources.Load(m_PaigeTargetInAdhesiveOnLandClip1String);
        m_PaigeTargetInAdhesiveOnLandClipList.Add(m_PaigeTargetInAdhesiveOnLandClip0);
        m_PaigeTargetInAdhesiveOnLandClipList.Add(m_PaigeTargetInAdhesiveOnLandClip1);
        PaigeDialogueDictionary.Add(DialogueContext.PaigeTargetInAdhesiveOnLand, m_PaigeTargetInAdhesiveOnLandClipList);

        m_PaigeHealingInteruptedClip0 = (AudioClip)Resources.Load(m_PaigeHealingInteruptedClip0String);
        m_PaigeHealingInteruptedClipList.Add(m_PaigeHealingInteruptedClip0);
        PaigeDialogueDictionary.Add(DialogueContext.PaigeHealingInterupt, m_PaigeHealingInteruptedClipList);

        #endregion

        #region Quark Variable Initialization

        m_QuarkSelectedClip0 = (AudioClip)Resources.Load(m_QuarkSelectedClip0String);
        m_QuarkSelectedClip1 = (AudioClip)Resources.Load(m_QuarkSelectedClip1String);
        m_QuarkSelectedClip2 = (AudioClip)Resources.Load(m_QuarkSelectedClip2String);
        m_QuarkSelectedClip3 = (AudioClip)Resources.Load(m_QuarkSelectedClip3String);
        m_QuarkSelectedClipList.Add(m_QuarkSelectedClip0);
        m_QuarkSelectedClipList.Add(m_QuarkSelectedClip1);
        m_QuarkSelectedClipList.Add(m_QuarkSelectedClip2);
        m_QuarkSelectedClipList.Add(m_QuarkSelectedClip3);
        QuarkDialogueDictionary.Add(DialogueContext.CharSelected, m_QuarkSelectedClipList);

        m_QuarkDamageClip0 = (AudioClip)Resources.Load(m_QuarkDamageClip0String);
        m_QuarkDamageClip1 = (AudioClip)Resources.Load(m_QuarkDamageClip1String);
        m_QuarkDamageClip2 = (AudioClip)Resources.Load(m_QuarkDamageClip2String);
        m_QuarkDamageClip3 = (AudioClip)Resources.Load(m_QuarkDamageClip3String);
        m_QuarkDamageClip4 = (AudioClip)Resources.Load(m_QuarkDamageClip4String);
        m_QuarkDamageClip5 = (AudioClip)Resources.Load(m_QuarkDamageClip5String);
        m_QuarkDamageClip6 = (AudioClip)Resources.Load(m_QuarkDamageClip6String);
        m_QuarkDamageClip7 = (AudioClip)Resources.Load(m_QuarkDamageClip7String);
        m_QuarkDamageClip8 = (AudioClip)Resources.Load(m_QuarkDamageClip8String);
        m_QuarkDamageClip9 = (AudioClip)Resources.Load(m_QuarkDamageClip9String);
        m_QuarkDamageClip10 = (AudioClip)Resources.Load(m_QuarkDamageClip10String);
        m_QuarkDamageClipList.Add(m_QuarkDamageClip0);
        m_QuarkDamageClipList.Add(m_QuarkDamageClip2);
        m_QuarkDamageClipList.Add(m_QuarkDamageClip3);
        m_QuarkDamageClipList.Add(m_QuarkDamageClip4);
        m_QuarkDamageClipList.Add(m_QuarkDamageClip5);
        m_QuarkDamageClipList.Add(m_QuarkDamageClip6);
        m_QuarkDamageClipList.Add(m_QuarkDamageClip7);
        m_QuarkDamageClipList.Add(m_QuarkDamageClip8);
        m_QuarkDamageClipList.Add(m_QuarkDamageClip9);
        m_QuarkDamageClipList.Add(m_QuarkDamageClip10);
        QuarkDialogueDictionary.Add(DialogueContext.Damage, m_QuarkDamageClipList);

        m_QuarkSeeZephClip0 = (AudioClip)Resources.Load(m_QuarkSeeZephClip0String);
        m_QuarkSeeZephClip1 = (AudioClip)Resources.Load(m_QuarkSeeZephClip0String);
        m_QuarkSeeZephClipList.Add(m_QuarkSeeZephClip0);
        m_QuarkSeeZephClipList.Add(m_QuarkSeeZephClip1);
        QuarkDialogueDictionary.Add(DialogueContext.SeeZeph, m_QuarkSeeZephClipList);

        m_QuarkSeeLeeroyClip0 = (AudioClip)Resources.Load(m_QuarkSeeLeeroyClip0String);
        m_QuarkSeeLeeroyClip1 = (AudioClip)Resources.Load(m_QuarkSeeLeeroyClip1String);
        m_QuarkSeeLeeroyClipList.Add(m_QuarkSeeLeeroyClip0);
        m_QuarkSeeLeeroyClipList.Add(m_QuarkSeeLeeroyClip1);
        QuarkDialogueDictionary.Add(DialogueContext.SeeLeeroy, m_QuarkSeeLeeroyClipList);

        m_QuarkSeePaigeClip0 = (AudioClip)Resources.Load(m_QuarkSeePaigeClip0String);
        m_QuarkSeePaigeClip1 = (AudioClip)Resources.Load(m_QuarkSeePaigeClip0String);
        m_QuarkSeePaigeClipList.Add(m_QuarkSeePaigeClip0);
        m_QuarkSeePaigeClipList.Add(m_QuarkSeePaigeClip1);
        QuarkDialogueDictionary.Add(DialogueContext.SeePaige, m_QuarkSeePaigeClipList);

        m_QuarkHookedClip0 = (AudioClip)Resources.Load(m_QuarkHookedClip0String);
        m_QuarkHookedClipList.Add(m_QuarkHookedClip0);
        QuarkDialogueDictionary.Add(DialogueContext.Hooked, m_QuarkHookedClipList);

        m_QuarkInSmokeClip0 = (AudioClip)Resources.Load(m_QuarkInSmokeClip0String);
        m_QuarkInSmokeClipList.Add(m_QuarkInSmokeClip0);
        QuarkDialogueDictionary.Add(DialogueContext.InSmoke, m_QuarkInSmokeClipList);

        m_QuarkWitnessKillClip0 = (AudioClip)Resources.Load(m_QuarkWitnessKillClip0String);
        m_QuarkWitnessKillClipList.Add(m_QuarkWitnessKillClip0);
        QuarkDialogueDictionary.Add(DialogueContext.WitnessKill, m_QuarkWitnessKillClipList);

        m_QuarkKillZephClip0 = (AudioClip)Resources.Load(m_QuarkKillZephClip0String);
        m_QuarkKillZephClip1 = (AudioClip)Resources.Load(m_QuarkKillZephClip0String);
        m_QuarkKillZephClipList.Add(m_QuarkKillZephClip0);
        m_QuarkKillZephClipList.Add(m_QuarkKillZephClip1);
        QuarkDialogueDictionary.Add(DialogueContext.KilledZeph, m_QuarkKillZephClipList);

        m_QuarkKillLeeroyClip0 = (AudioClip)Resources.Load(m_QuarkKillLeeroyClip0String);
        m_QuarkKillLeeroyClip1 = (AudioClip)Resources.Load(m_QuarkKillLeeroyClip0String);
        m_QuarkKillLeeroyClipList.Add(m_QuarkKillLeeroyClip0);
        m_QuarkKillLeeroyClipList.Add(m_QuarkKillLeeroyClip1);
        QuarkDialogueDictionary.Add(DialogueContext.KilledLeeroy, m_QuarkKillLeeroyClipList);

        m_QuarkKillPaigeClip0 = (AudioClip)Resources.Load(m_QuarkKillPaigeClip0String);
        m_QuarkKillPaigeClip1 = (AudioClip)Resources.Load(m_QuarkKillPaigeClip0String);
        m_QuarkKillPaigeClipList.Add(m_QuarkKillPaigeClip0);
        m_QuarkKillPaigeClipList.Add(m_QuarkKillPaigeClip1);
        QuarkDialogueDictionary.Add(DialogueContext.KilledPaige, m_QuarkKillPaigeClipList);

        m_QuarkMovementAbilityConnectsClip0 = (AudioClip)Resources.Load(m_QuarkMovementAbilityConnectsClip0String);
        m_QuarkMovementAbilityConnectsClip1 = (AudioClip)Resources.Load(m_QuarkMovementAbilityConnectsClip1String);
        m_QuarkMovementAbilityConnectsClip2 = (AudioClip)Resources.Load(m_QuarkMovementAbilityConnectsClip2String);
        m_QuarkMovementAbilityConnectsClipList.Add(m_QuarkMovementAbilityConnectsClip0);
        m_QuarkMovementAbilityConnectsClipList.Add(m_QuarkMovementAbilityConnectsClip1);
        m_QuarkMovementAbilityConnectsClipList.Add(m_QuarkMovementAbilityConnectsClip2);
        QuarkDialogueDictionary.Add(DialogueContext.QuarkMovementAbilityConnects, m_QuarkMovementAbilityConnectsClipList);

        m_QuarkPlaceTurretClip0 = (AudioClip)Resources.Load(m_QuarkPlaceTurretClip0String);
        m_QuarkPlaceTurretClip1 = (AudioClip)Resources.Load(m_QuarkPlaceTurretClip1String);
        m_QuarkPlaceTurretClip2 = (AudioClip)Resources.Load(m_QuarkPlaceTurretClip2String);
        m_QuarkPlaceTurretClip3 = (AudioClip)Resources.Load(m_QuarkPlaceTurretClip3String);
        m_QuarkPlaceTurretClip4 = (AudioClip)Resources.Load(m_QuarkPlaceTurretClip4String);
        m_QuarkPlaceTurretClipList.Add(m_QuarkPlaceTurretClip0);
        m_QuarkPlaceTurretClipList.Add(m_QuarkPlaceTurretClip1);
        m_QuarkPlaceTurretClipList.Add(m_QuarkPlaceTurretClip2);
        m_QuarkPlaceTurretClipList.Add(m_QuarkPlaceTurretClip3);
        m_QuarkPlaceTurretClipList.Add(m_QuarkPlaceTurretClip4);
        QuarkDialogueDictionary.Add(DialogueContext.QuarkPlaceTurret, m_QuarkPlaceTurretClipList);

        m_QuarkPlaceTrapClip0 = (AudioClip)Resources.Load(m_QuarkPlaceTrapClip0String);
        m_QuarkPlaceTrapClip1 = (AudioClip)Resources.Load(m_QuarkPlaceTrapClip1String);
        m_QuarkPlaceTrapClip2 = (AudioClip)Resources.Load(m_QuarkPlaceTrapClip2String);
        m_QuarkPlaceTrapClipList.Add(m_QuarkPlaceTrapClip0);
        m_QuarkPlaceTrapClipList.Add(m_QuarkPlaceTrapClip1);
        m_QuarkPlaceTrapClipList.Add(m_QuarkPlaceTrapClip2);
        QuarkDialogueDictionary.Add(DialogueContext.QuarkPlaceTrap, m_QuarkPlaceTrapClipList);

        m_QuarkSeeTrapTriggeredClip0 = (AudioClip)Resources.Load(m_QuarkSeeTrapTriggeredClip0String);
        m_QuarkSeeTrapTriggeredClip1 = (AudioClip)Resources.Load(m_QuarkSeeTrapTriggeredClip1String);
        m_QuarkSeeTrapTriggeredClip2 = (AudioClip)Resources.Load(m_QuarkSeeTrapTriggeredClip2String);
        m_QuarkSeeTrapTriggeredClipList.Add(m_QuarkSeeTrapTriggeredClip0);
        m_QuarkSeeTrapTriggeredClipList.Add(m_QuarkSeeTrapTriggeredClip1);
        m_QuarkSeeTrapTriggeredClipList.Add(m_QuarkSeeTrapTriggeredClip2);
        QuarkDialogueDictionary.Add(DialogueContext.QuarkSeeTrapTriggered, m_QuarkSeeTrapTriggeredClipList);

        m_QuarkThrowCameraClip0 = (AudioClip)Resources.Load(m_QuarkThrowCameraClip0String);
        m_QuarkThrowCameraClip1 = (AudioClip)Resources.Load(m_QuarkThrowCameraClip1String);
        m_QuarkThrowCameraClip2 = (AudioClip)Resources.Load(m_QuarkThrowCameraClip2String);
        m_QuarkThrowCameraClipList.Add(m_QuarkThrowCameraClip0);
        m_QuarkThrowCameraClipList.Add(m_QuarkThrowCameraClip1);
        m_QuarkThrowCameraClipList.Add(m_QuarkThrowCameraClip2);
        QuarkDialogueDictionary.Add(DialogueContext.QuarkThrowCamera, m_QuarkThrowCameraClipList);

        m_QuarkTurretGetsKillClip0 = (AudioClip)Resources.Load(m_QuarkTurretGetsKillClip0String);
        m_QuarkTurretGetsKillClip1 = (AudioClip)Resources.Load(m_QuarkTurretGetsKillClip1String);
        m_QuarkTurretGetsKillClip2 = (AudioClip)Resources.Load(m_QuarkTurretGetsKillClip2String);
        m_QuarkTurretGetsKillClipList.Add(m_QuarkTurretGetsKillClip0);
        m_QuarkTurretGetsKillClipList.Add(m_QuarkTurretGetsKillClip1);
        m_QuarkTurretGetsKillClipList.Add(m_QuarkTurretGetsKillClip2);
        QuarkDialogueDictionary.Add(DialogueContext.QuarkTurretGetsKill, m_QuarkTurretGetsKillClipList);

        #endregion

        #region Zeph Initialization

        m_ZephSelectedClip0 = (AudioClip)Resources.Load(m_ZephSelectedClip0String);
        m_ZephSelectedClip1 = (AudioClip)Resources.Load(m_ZephSelectedClip1String);
        m_ZephSelectedClip2 = (AudioClip)Resources.Load(m_ZephSelectedClip2String);
        m_ZephSelectedClip3 = (AudioClip)Resources.Load(m_ZephSelectedClip3String);
        m_ZephSelectedClipList.Add(m_ZephSelectedClip0);
        m_ZephSelectedClipList.Add(m_ZephSelectedClip1);
        m_ZephSelectedClipList.Add(m_ZephSelectedClip2);
        m_ZephSelectedClipList.Add(m_ZephSelectedClip3);
        ZephDialogueDictionary.Add(DialogueContext.CharSelected, m_ZephSelectedClipList);

        m_ZephDamageClip0 = (AudioClip)Resources.Load(m_ZephDamageClip0String);
        m_ZephDamageClip1 = (AudioClip)Resources.Load(m_ZephDamageClip1String);
        m_ZephDamageClip2 = (AudioClip)Resources.Load(m_ZephDamageClip2String);
        m_ZephDamageClip3 = (AudioClip)Resources.Load(m_ZephDamageClip3String);
        m_ZephDamageClip4 = (AudioClip)Resources.Load(m_ZephDamageClip4String);
        m_ZephDamageClip5 = (AudioClip)Resources.Load(m_ZephDamageClip5String);
        m_ZephDamageClip6 = (AudioClip)Resources.Load(m_ZephDamageClip6String);
        m_ZephDamageClip7 = (AudioClip)Resources.Load(m_ZephDamageClip7String);
        m_ZephDamageClip8 = (AudioClip)Resources.Load(m_ZephDamageClip8String);
        m_ZephDamageClipList.Add(m_ZephDamageClip0);
        m_ZephDamageClipList.Add(m_ZephDamageClip1);
        m_ZephDamageClipList.Add(m_ZephDamageClip2);
        m_ZephDamageClipList.Add(m_ZephDamageClip3);
        m_ZephDamageClipList.Add(m_ZephDamageClip4);
        m_ZephDamageClipList.Add(m_ZephDamageClip5);
        m_ZephDamageClipList.Add(m_ZephDamageClip6);
        m_ZephDamageClipList.Add(m_ZephDamageClip7);
        m_ZephDamageClipList.Add(m_ZephDamageClip8);
        ZephDialogueDictionary.Add(DialogueContext.Damage, m_ZephDamageClipList);

        m_ZephSeeLeeroyClip0 = (AudioClip)Resources.Load(m_ZephSeeLeeroyClip0String);
        m_ZephSeeLeeroyClip1 = (AudioClip)Resources.Load(m_ZephSeeLeeroyClip0String);
        m_ZephSeeLeeroyClipList.Add(m_ZephSeeLeeroyClip0);
        m_ZephSeeLeeroyClipList.Add(m_ZephSeeLeeroyClip1);
        ZephDialogueDictionary.Add(DialogueContext.SeeLeeroy, m_ZephSeeLeeroyClipList);

        m_ZephSeeQuarkClip0 = (AudioClip)Resources.Load(m_ZephSeeQuarkClip0String);
        m_ZephSeeQuarkClip1 = (AudioClip)Resources.Load(m_ZephSeeQuarkClip1String);
        m_ZephSeeQuarkClipList.Add(m_ZephSeeQuarkClip0);
        m_ZephSeeQuarkClipList.Add(m_ZephSeeQuarkClip1);
        ZephDialogueDictionary.Add(DialogueContext.SeeQuark, m_ZephSeeQuarkClipList);

        m_ZephSeePaigeClip0 = (AudioClip)Resources.Load(m_ZephSeePaigeClip0String);
        m_ZephSeePaigeClip1 = (AudioClip)Resources.Load(m_ZephSeePaigeClip1String);
        m_ZephSeePaigeClipList.Add(m_ZephSeePaigeClip0);
        m_ZephSeePaigeClipList.Add(m_ZephSeePaigeClip1);
        ZephDialogueDictionary.Add(DialogueContext.SeePaige, m_ZephSeePaigeClipList);

        m_ZephSeeQuarkTurretClip0 = (AudioClip)Resources.Load(m_ZephSeeQuarkTurretClip0String);
        m_ZephSeeQuarkTurretClipList.Add(m_ZephSeeQuarkTurretClip0);
        ZephDialogueDictionary.Add(DialogueContext.SeeQuarkTurret, m_ZephSeeQuarkTurretClipList);

        m_ZephDestroyQuarkTurretClip0 = (AudioClip)Resources.Load(m_ZephDestroyQuarkTurretClip0String);
        m_ZephDestroyQuarkTurretClip1 = (AudioClip)Resources.Load(m_ZephDestroyQuarkTurretClip1String);
        m_ZephDestroyQuarkTurretClipList.Add(m_ZephDestroyQuarkTurretClip0);
        m_ZephDestroyQuarkTurretClipList.Add(m_ZephDestroyQuarkTurretClip1);
        ZephDialogueDictionary.Add(DialogueContext.DestroyQuarkTurret, m_ZephDestroyQuarkTurretClipList);

        m_ZephInQuarkTrapClip0 = (AudioClip)Resources.Load(m_ZephInQuarkTrapClip0String);
        m_ZephInQuarkTrapClipList.Add(m_ZephInQuarkTrapClip0);
        ZephDialogueDictionary.Add(DialogueContext.InQuarkTrap, m_ZephInQuarkTrapClipList);

        m_ZephInAdhesiveClip0 = (AudioClip)Resources.Load(m_ZephInAdhesiveClip0String);
        m_ZephInAdhesiveClipList.Add(m_ZephInAdhesiveClip0);
        ZephDialogueDictionary.Add(DialogueContext.InAdhesive, m_ZephInAdhesiveClipList);

        m_ZephWitnessKillClip0 = (AudioClip)Resources.Load(m_ZephWitnessKillClip0String);
        m_ZephWitnessKillClipList.Add(m_ZephWitnessKillClip0);
        ZephDialogueDictionary.Add(DialogueContext.WitnessKill, m_ZephWitnessKillClipList);

        m_ZephKillQuarkClip0 = (AudioClip)Resources.Load(m_ZephKillQuarkClip0String);
        m_ZephKillQuarkClip1 = (AudioClip)Resources.Load(m_ZephKillQuarkClip1String);
        m_ZephKillQuarkClipList.Add(m_ZephKillQuarkClip0);
        m_ZephKillQuarkClipList.Add(m_ZephKillQuarkClip1);
        ZephDialogueDictionary.Add(DialogueContext.KilledQuark, m_ZephKillQuarkClipList);

        m_ZephKillLeeroyClip0 = (AudioClip)Resources.Load(m_ZephKillLeeroyClip0String);
        m_ZephKillLeeroyClip1 = (AudioClip)Resources.Load(m_ZephKillLeeroyClip1String);
        m_ZephKillLeeroyClipList.Add(m_ZephKillLeeroyClip0);
        m_ZephKillLeeroyClipList.Add(m_ZephKillLeeroyClip1);
        ZephDialogueDictionary.Add(DialogueContext.KilledLeeroy, m_ZephKillLeeroyClipList);

        m_ZephKillPaigeClip0 = (AudioClip)Resources.Load(m_ZephKillPaigeClip0String);
        m_ZephKillPaigeClip1 = (AudioClip)Resources.Load(m_ZephKillPaigeClip1String);
        m_ZephKillPaigeClipList.Add(m_ZephKillPaigeClip0);
        m_ZephKillPaigeClipList.Add(m_ZephKillPaigeClip1);
        ZephDialogueDictionary.Add(DialogueContext.KilledPaige, m_ZephKillPaigeClipList);

        m_ZephMainAttackClip0 = (AudioClip)Resources.Load(m_ZephMainAttackClip0String);
        m_ZephMainAttackClip1 = (AudioClip)Resources.Load(m_ZephMainAttackClip1String);
        m_ZephMainAttackClip2 = (AudioClip)Resources.Load(m_ZephMainAttackClip2String);
        m_ZephMainAttackClip3 = (AudioClip)Resources.Load(m_ZephMainAttackClip3String);
        m_ZephMainAttackClip4 = (AudioClip)Resources.Load(m_ZephMainAttackClip4String);
        m_ZephMainAttackClip5 = (AudioClip)Resources.Load(m_ZephMainAttackClip5String);
        m_ZephMainAttackClip6 = (AudioClip)Resources.Load(m_ZephMainAttackClip6String);
        m_ZephMainAttackClip7 = (AudioClip)Resources.Load(m_ZephMainAttackClip7String);
        m_ZephMainAttackClip8 = (AudioClip)Resources.Load(m_ZephMainAttackClip8String);
        m_ZephMainAttackClip9 = (AudioClip)Resources.Load(m_ZephMainAttackClip9String);
        m_ZephMainAttackClip10 = (AudioClip)Resources.Load(m_ZephMainAttackClip10String);
        m_ZephMainAttackClipList.Add(m_ZephMainAttackClip0);
        m_ZephMainAttackClipList.Add(m_ZephMainAttackClip1);
        m_ZephMainAttackClipList.Add(m_ZephMainAttackClip2);
        m_ZephMainAttackClipList.Add(m_ZephMainAttackClip3);
        m_ZephMainAttackClipList.Add(m_ZephMainAttackClip4);
        m_ZephMainAttackClipList.Add(m_ZephMainAttackClip5);
        m_ZephMainAttackClipList.Add(m_ZephMainAttackClip6);
        m_ZephMainAttackClipList.Add(m_ZephMainAttackClip7);
        m_ZephMainAttackClipList.Add(m_ZephMainAttackClip8);
        m_ZephMainAttackClipList.Add(m_ZephMainAttackClip9);
        m_ZephMainAttackClipList.Add(m_ZephMainAttackClip10);
        ZephDialogueDictionary.Add(DialogueContext.MainAttack, m_ZephMainAttackClipList);

        m_ZephPullOpponentClip0 = (AudioClip)Resources.Load(m_ZephPullOpponentClip0String);
        m_ZephPullOpponentClipList.Add(m_ZephPullOpponentClip0);
        ZephDialogueDictionary.Add(DialogueContext.ZephPullOpponent, m_ZephPullOpponentClipList);

        m_ZephCatchesPplInSMokeClip0 = (AudioClip)Resources.Load(m_ZephCatchesPplInSMokeClip0String);
        m_ZephCatchesPplInSMokeClip1 = (AudioClip)Resources.Load(m_ZephCatchesPplInSMokeClip1String);
        m_ZephCatchesPplInSMokeClipList.Add(m_ZephCatchesPplInSMokeClip0);
        m_ZephCatchesPplInSMokeClipList.Add(m_ZephCatchesPplInSMokeClip1);
        ZephDialogueDictionary.Add(DialogueContext.ZephCatchesPplInSmoke, m_ZephCatchesPplInSMokeClipList);

        m_ZephSuccessfulPoisonClip0 = (AudioClip)Resources.Load(m_ZephSuccessfulPoisonClip0String);
        m_ZephSuccessfulPoisonClip1 = (AudioClip)Resources.Load(m_ZephSuccessfulPoisonClip1String);
        m_ZephSuccessfulPoisonClipList.Add(m_ZephSuccessfulPoisonClip0);
        m_ZephSuccessfulPoisonClipList.Add(m_ZephSuccessfulPoisonClip1);
        ZephDialogueDictionary.Add(DialogueContext.ZephSuccessfulPoison, m_ZephSuccessfulPoisonClipList);

        m_ZephMissThrownAttackClip0 = (AudioClip)Resources.Load(m_ZephMissThrownAttackClip0String);
        m_ZephMissThrownAttackClip1 = (AudioClip)Resources.Load(m_ZephMissThrownAttackClip1String);
        m_ZephMissThrownAttackClipList.Add(m_ZephMissThrownAttackClip0);
        m_ZephMissThrownAttackClipList.Add(m_ZephMissThrownAttackClip1);
        ZephDialogueDictionary.Add(DialogueContext.ZephMissThrownAttack, m_ZephMissThrownAttackClipList);

        m_ZephTeleportClip0 = (AudioClip)Resources.Load(m_ZephTeleportClip0String);
        m_ZephTeleportClip1 = (AudioClip)Resources.Load(m_ZephTeleportClip1String);
        m_ZephTeleportClipList.Add(m_ZephTeleportClip0);
        m_ZephTeleportClipList.Add(m_ZephTeleportClip1);
        ZephDialogueDictionary.Add(DialogueContext.ZephTeleport, m_ZephTeleportClipList);

        #endregion
    }
}
