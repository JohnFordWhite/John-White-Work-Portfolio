﻿using UnityEngine;
using System.Collections;

public static class OptionsManager
{
    public static bool Vibration = true;
    public static bool VisibleCrosshair = true;
    public static bool VisibleFPS = true;

    private const string BrightnessMultiplyProperty = "_BrightnessMultiply";

    public static float GameBrightness
    {
        get { return m_GameBrightness.Value; }
        set
        {
            m_GameBrightness.Value = value;
            UpdateGameBrightness();
        }
    }

    public static void UpdateGameBrightness()
    {
        Shader.SetGlobalFloat(BrightnessMultiplyProperty, OptionsManager.GameBrightness);
    }

    public static float VolumeMaster
    {
        get { return m_VolumeMaster.Value; }
        set { m_VolumeMaster.Value = value; }
    }

    public static float VolumeVoice
    {
        get { return m_VolumeVoice.Value * m_VolumeMaster.Value; }
        set { m_VolumeVoice.Value = value; }
    }

    public static float VolumeMusic
    {
        get { return m_VolumeMusic.Value * m_VolumeMaster.Value; }
        set { m_VolumeMusic.Value = value; }
    }

    public static float VolumeEffects
    {
        get { return m_VolumeEffects.Value * m_VolumeMaster.Value; }
        set { m_VolumeEffects.Value = value; }
    }

    public static float VolumeFootsteps
    {
        get { return m_VolumeFootsteps.Value * m_VolumeMaster.Value; }
        set { m_VolumeFootsteps.Value = value; }
    }

    private static ClampedFloat m_GameBrightness = new ClampedFloat(1f, 0.2f, 3f);
    private static ClampedFloat m_VolumeMaster = new ClampedFloat(0.75f, 0f, 1f);
    private static ClampedFloat m_VolumeVoice = new ClampedFloat(0.75f, 0f, 1f);
    private static ClampedFloat m_VolumeMusic = new ClampedFloat(0.625f, 0f, 1f);
    private static ClampedFloat m_VolumeEffects = new ClampedFloat(0.75f, 0f, 1f);
    private static ClampedFloat m_VolumeFootsteps = new ClampedFloat(0.75f, 0f, 1f);

    public static float GetUnclampedVolumeVoice() { return m_VolumeVoice.Value; }
    public static float GetUnclampedVolumeMusic() { return m_VolumeMusic.Value; }
    public static float GetUnclampedVolumeEffects() { return m_VolumeEffects.Value; }
    public static float GetUnclampedVolumeFootsteps() { return m_VolumeFootsteps.Value; }
}