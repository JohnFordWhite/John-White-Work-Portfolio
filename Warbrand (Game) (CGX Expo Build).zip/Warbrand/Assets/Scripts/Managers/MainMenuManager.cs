﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        MainMenuManager                                                                *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            October 13th, 2016                                                             *
 *                                                                                                 *
 * This file contains functions for the main menu to use. The main menu buttons will call them.    *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - October 13th, 2016                                      *
\***************************************************************************************************/

using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
//using XInputDotNetPure;

public class MainMenuManager : GameMenu
{
    public CameraManager GameCameraManager;
    
    protected bool m_LoadingOptions = false;

    private const string TestScene = "TestScene";
    private const string CharacterSelectionScene = "CharacterSelectionScene";
    private const string CreditsScene = "CreditsScene";
    private const string OptionsScene = "OptionsScene";
    private const string OptionsCanvas = "OptionsCanvas";

    protected override void Start()
    {
        base.Start();

        EnableNavigation();

        Time.timeScale = 1.0f;

        InputManager.CM.CurrentGameState = GameState.MainMenu;

        OptionsManager.UpdateGameBrightness();

        GameCameraManager.HidePlayerCameras();
    }

    protected override void Update()
    {
        base.Update();

        if (EnableInputs == true)
        {
            if (IsSubmitButtonPressed())
            {
                TryCurrentSelectableOnClick();
                return;
            }
        }
    }

    public void TestSceneButtonFunction()
    {
        if (EnableInputs == true)
        {
            EnableInputs = false;

            LoadScene(TestScene);
        }
    }

    public void StartGameButtonFunction()
    {
        if (EnableInputs == true)
        {
            EnableInputs = false;

            LoadScene(CharacterSelectionScene);
        }
    }

    public void OptionsButtonFunction()
    {
        if (EnableInputs == true && m_LoadingOptions == false)
        {
            StartCoroutine(HandleLoadOptions());
        }
    }

    public void CreditsButtonFunction()
    {
        if (EnableInputs == true)
        {
            EnableInputs = false;

            LoadScene(CreditsScene);
        }
    }

    IEnumerator HandleLoadOptions()
    {
        m_LoadingOptions = true;

        SceneManager.LoadScene(OptionsScene, LoadSceneMode.Additive);

        // Wait one frame to let options scene get loaded
        // before trying to access GameObject from newly loaded scene.
        yield return null;

        GameObject optionsCanvas = GameObject.Find(OptionsCanvas);

        if (optionsCanvas != null)
        {
            OptionsScreenScript options = optionsCanvas.GetComponent<OptionsScreenScript>();

            options.ParentMenu = this;

            gameObject.SetActive(false);
        }
        
        m_LoadingOptions = false;

        yield return null;
    }

    private void LoadScene(string aSceneName)
    {
        StartCoroutine(HandleLoadScene(aSceneName));
    }

    IEnumerator HandleLoadScene(string aSceneName)
    {
        // Wait one frame before switching scenes to prevent any issues with buttons/multiple actions being pressed on same frame
        yield return null;

        SceneManager.LoadScene(aSceneName);
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
