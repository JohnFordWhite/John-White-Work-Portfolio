﻿using UnityEngine;
using System.Collections;

public class ParticleManager : MonoBehaviour
{
    public int DefaultHitEffectPoolSize = 20;
    private GameObject[] m_DefaultHitEffects;
    private GameObject m_DefaultHitEffectPrefab;

    private const string m_DefaultHitEffectResource = "Particle Effects/Prefabs/DefaultHitEffect";

    void Start ()
    {
        GameObject.DontDestroyOnLoad(gameObject);
        m_DefaultHitEffectPrefab = Resources.Load(m_DefaultHitEffectResource) as GameObject;

        m_DefaultHitEffects = new GameObject[DefaultHitEffectPoolSize];
        for(int i = 0; i < m_DefaultHitEffects.Length; i++)
        {
            m_DefaultHitEffects[i] = Object.Instantiate(m_DefaultHitEffectPrefab, transform.position, transform.rotation) as GameObject;
            m_DefaultHitEffects[i].transform.parent = this.gameObject.transform;
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
	
	}

    public void SpawnHitEffect(Vector3 position, Vector3 rotation)
    {
        for (int i = 0; i < m_DefaultHitEffects.Length; i++)
        {
            if (m_DefaultHitEffects[i].GetComponentInChildren<ParticleSystem>().isPlaying == false)
            {
                m_DefaultHitEffects[i].transform.position = position;
                m_DefaultHitEffects[i].transform.eulerAngles = rotation;

                ParticleSystem[] hitParticles = m_DefaultHitEffects[i].GetComponentsInChildren<ParticleSystem>();
                for(int j = 0; j < hitParticles.Length; j++)
                {
                    hitParticles[j].Play();
                }
                return;
            }
        }
    }
}
