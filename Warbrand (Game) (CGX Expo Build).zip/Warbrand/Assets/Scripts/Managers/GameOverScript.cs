﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using UnityEngine.UI;

public class GameOverScript : GameMenu
{
    public Camera MainCamera;

    public int NumberOfAchievementsToDisplay = 3;

    public GameObject FirstPlaceTransform;
    public GameObject LastPlaceTransform;

    public GameObject LeeroyPrefab;
    public GameObject PaigePrefab;
    public GameObject QuarkPrefab;
    public GameObject ZephPrefab;

    public Text TitleText;

    public Text ViewStatsButtonText;

    public GameObject AchievementsPanel;

    public const string StringMainMenuScene = "MainMenuScene";
    public const string StringGameScene = "GameScene";
    public const string StringCharacterSelectScene = "CharacterSelectionScene";

    public const string StringViewStats = "View Stats";
    public const string StringHideStats = "Hide Stats";
    public const string StringViewAchievements = "View Achievements";

    public GameObject NoAchievementsPanel;
    public GameObject[] AchievementPanels;
    public Text[] AchievementNames;
    public Text[] AchievementPlayerNames;
    public Text[] AchievementCounts;

    private const string m_RespawnTagString = "Respawn";

    private const string m_IdleAnimation = "Idle(Armed)";

    private bool SpawnPrefabsInEditorTest = false;

    private const int MaxNumFFAPlayers = 3;

    public enum GameOverSceneState
    {
        ShowLeaderboard,
        ShowAchievements,
        HideStats,
        MAX_STATES
    }

    public GameOverSceneState CurrentState;
    //private bool m_ViewStats = false;

    // Use this for initialization
    protected override void Start ()
    {
        base.Start();

        EnableNavigation();

#if UNITY_EDITOR
        // This is just for testing from the editor - starting from the GameOver scene.
        if (InputManager.CM.Players.Count <= 0)
        {
            DebugManager.Log("Starting GameOverScene from the Editor", Developmer.Evan);

            SpawnPrefabsInEditorTest = true;

            GameInputComponent inputComponent = InputManager.CM.AddPlayer(PlayerType.KeyboardPlayer, InputDevice.Keyboard);
            inputComponent.Character = (CharacterTypes)0;
        }

        // If you want to test out spawning prefabs here manually instead of getting from
        // the players list, set SpawnPrefabsInEditorTest to true in here so no more
        // get spawned the normal way.

        #region testing
        
        if (SpawnPrefabsInEditorTest == true)
        {
            CharacterTypes[] rows =
            {
                CharacterTypes.Leeroy,
                CharacterTypes.Paige,
                CharacterTypes.Zeph,
                CharacterTypes.Quark,
                CharacterTypes.Paige,
                CharacterTypes.Leeroy,
                CharacterTypes.Quark,
                CharacterTypes.Zeph
            };

            for (int i = 0; i < rows.Length; i++)
            {
                if (i >= 8)
                    break;

                SpawnCharacter(rows[i], i, 8);
            }

            TitleText.text = "Winner: " + "Player 1 - " + rows[0].ToString();
        }

        #endregion

#endif
        List<Player> winningPlayers = new List<Player>();

        if (SpawnPrefabsInEditorTest == false)
        {
            GameModeManager game = InputManager.CM.GameModeManager;

            // in a team mode, only show the player models from the winning team.
            // show the list of the top 3 teams.
            if (game.TeamsEnabled == true)
            {
                ScoreboardTeamPanel team = game.Scoreboard.TeamPanels[0];

                for (int i = 0; i < team.PlayersInTeam.Length; i++)
                {
                    ScoreboardPlayerRow row = team.PlayersInTeam[i];

                    // All players on the winning team get added.
                    winningPlayers.Add(
                        SpawnCharacter(row.Character,
                            i,
                            team.PlayersInTeam.Length
                            )
                        );
                }

                TitleText.text = "Winner: " + BaseGameMode.TeamNames[team.TeamID];
            }
            // otherwise show the models and scores of the top 3 players.
            else
            {
                List<ScoreboardTeamPanel> teams = game.Scoreboard.TeamPanels;

                for (int i = 0; i < teams.Count; i++)
                {
                    if (i >= MaxNumFFAPlayers)
                        break;

                    ScoreboardPlayerRow row = teams[i].PlayersInTeam[0];

                    Player player = SpawnCharacter(row.Character, i, MaxNumFFAPlayers);

                    // In a FFA game, add the first player.
                    if (i == 0)
                    {
                        winningPlayers.Add(player);
                        TitleText.text = "Winner: " + row.PlayerNameText.text + " - " + row.Character.ToString();
                    }
                }
            }

            // Done adding players

            // TODO: Do something with winningPlayers
            ScoreboardPlayerRow[] players = InputManager.CM.GameModeManager.Scoreboard.TeamPanels[0].PlayersInTeam;

            //Debug.Log("winningplayer at [0]: " + winningPlayers[0].PlayerID);
            // Show scoreboard
            StartCoroutine(HandleShowScoreboard());
        }

        // Unlock cursor
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        // Populate achievements view

        // Store temp count of achievements because we need to remember the number of panels to hide or show.
        int numAchievements = NumberOfAchievementsToDisplay;

        // Load up those juicy achievements
        Achievement[] achievements = AchievementsManager.GetRandomAchievements(ref numAchievements);

        if (achievements.Length <= 0)
        {
            NoAchievementsPanel.SetActive(true);
        }
        else
        {
            NoAchievementsPanel.SetActive(false);

            for (int i = 0; i < NumberOfAchievementsToDisplay; i++)
            {
                if (i < numAchievements)
                {
                    AchievementPanels[i].SetActive(true);
                    
                    Achievement achievement = achievements[i];

                    AchievementNames[i].text = AchievementsManager.GetStringForAchievement(achievement.AchievementName);
                    AchievementPlayerNames[i].text = achievement.Player.GameInput.LongPlayerName;
                    AchievementCounts[i].text = ((int)achievement.Value).ToString();
                }
                else
                {
                    AchievementPanels[i].SetActive(false);
                }
            }
        }

        UpdateUI();
    }

    Player SpawnCharacter(CharacterTypes aRow, int aIndex, int aMax)
    {
        GameObject instanced = null;

        float lerpAmount = ((float)aIndex / ((float)(aMax - 1)));
        // If there are fewer characters, move them closer to the camera.
        if (aMax <= 4)
        {
            lerpAmount *= 0.5f;
        }

        // Set position
        Vector3 targetPosition = Vector3.Lerp(
            FirstPlaceTransform.transform.position,
            LastPlaceTransform.transform.position,
            lerpAmount
            );

        Quaternion targetRotation = Quaternion.Lerp(
            FirstPlaceTransform.transform.rotation,
            LastPlaceTransform.transform.rotation,
            lerpAmount
            );

        switch (aRow)
        {
            case CharacterTypes.Leeroy:
                instanced = (GameObject)Instantiate(LeeroyPrefab, targetPosition, targetRotation);
                break;
            case CharacterTypes.Paige:
                instanced = (GameObject)Instantiate(PaigePrefab, targetPosition, targetRotation);
                break;
            case CharacterTypes.Zeph:
                instanced = (GameObject)Instantiate(ZephPrefab, targetPosition, targetRotation);
                break;
            case CharacterTypes.Quark:
                instanced = (GameObject)Instantiate(QuarkPrefab, targetPosition, targetRotation);
                break;
        }

        if (instanced != null)
        {
            Player player = instanced.GetComponentInChildren<Player>();

            if (player != null)
            {
                // Disable the camera and UI as not needed.
                player.FirstPersonPlayerCamera.gameObject.SetActive(false);
                player.UICanvas.gameObject.SetActive(false);

                Vector3 cameraLookAtPos = MainCamera.transform.position;
                cameraLookAtPos.y = player.transform.position.y;

                player.transform.LookAt(cameraLookAtPos);

                StartCoroutine(SetRandomIdleFrameForPlayer(player));

                return player;
            }
        }

        return null;
    }

    IEnumerator SetRandomIdleFrameForPlayer(Player aPlayer)
    {
        yield return null;

        if (aPlayer != null)
        {
            aPlayer.PlayerAnimator.Play(m_IdleAnimation, 0, Random.Range(0.0f, 1.0f));
        }
    }

    IEnumerator HandleShowScoreboard()
    {
        // HACK: for some reason when transitioning to the other scene,
        // the scoreboard gets hidden by other UI objects.
        // We can force it to become visible by disabling and then enabling it.

        GameModeManager game = InputManager.CM.GameModeManager;

        game.Scoreboard.gameObject.SetActive(false);

        yield return null;

        game.Scoreboard.gameObject.SetActive(true);

        yield return null;

        game.Scoreboard.RefreshScoreboard();
    }
	
	// Update is called once per frame
	protected override void Update ()
    {
        base.Update();

	    if (EnableInputs == true)
        {
            if (IsSubmitButtonPressed())
            {
                TryCurrentSelectableOnClick();
                return;
            }

            float horizontal = 0.0f;
            for (int i = 0; i < InputManager.CM.Players.Count; i++)
            {
                GameInputComponent playerObject = InputManager.CM.Players[i];

                if (horizontal == 0.0f)
                {
                    horizontal = playerObject.Input.GetInput(InputName.Menu_Horizontal, InputType.ButtonPressed, true);
                    if (horizontal == 0.0f)
                    {
                        horizontal = playerObject.Input.GetInput(InputName.Menu_Alt_Horizontal, InputType.ButtonPressed, true);
                    }
                    if (horizontal != 0.0f)
                    {
                        break;
                    }
                }
            }
        }
	}

    public void ViewStatsButton()
    {
        //if (SpawnPrefabsInEditorTest == false)
        {
            if (CurrentState == GameOverSceneState.MAX_STATES - 1)
            {
                CurrentState = 0;
            }
            else
            {
                CurrentState++;
            }

            UpdateUI();


            //m_ViewStats = !m_ViewStats;

            //if (m_ViewStats == true)
            //{
            //    ViewStatsButtonText.text = StringHideStats;

            //    GameModeManager game = InputManager.CM.GameModeManager;

            //    game.Scoreboard.EditorForceVisible = true;

            //    StartCoroutine(HandleShowScoreboard());
            //}
            //else
            //{
            //    ViewStatsButtonText.text = StringViewStats;

            //    GameModeManager game = InputManager.CM.GameModeManager;

            //    game.Scoreboard.EditorForceVisible = false;
            //}
        }
    }

    void UpdateUI()
    {
        GameModeManager game = InputManager.CM.GameModeManager;
#if UNITY_EDITOR
        if (game.Scoreboard == null)
        {
            game.BuildDummyScoreboard();
        }
#endif

        switch (CurrentState)
        {
            case GameOverSceneState.HideStats:
                if (game.Scoreboard != null)
                {
                    game.Scoreboard.EditorForceVisible = false;
                }
                ViewStatsButtonText.text = StringViewStats;
                AchievementsPanel.SetActive(false);
                break;
            case GameOverSceneState.ShowLeaderboard:
                if (game.Scoreboard != null)
                {
                    game.Scoreboard.EditorForceVisible = true;
                    StartCoroutine(HandleShowScoreboard());
                }
                ViewStatsButtonText.text = StringViewAchievements;
                AchievementsPanel.SetActive(false);
                break;
            case GameOverSceneState.ShowAchievements:
                if (game.Scoreboard != null)
                {
                    game.Scoreboard.EditorForceVisible = false;
                }
                ViewStatsButtonText.text = StringHideStats;
                AchievementsPanel.SetActive(true);
                break;
        }
    }

    public void MainMenuButton()
    {
        if (EnableInputs == true)
        {
            EnableInputs = false;

            InputManager.CM.RemoveAIPlayers();

            GameModeManager game = InputManager.CM.GameModeManager;

            game.Scoreboard.EditorForceVisible = false;

            InputManager.CM.CurrentGameState = GameState.MainMenu;

            InputManager.CM.CleanupGame();

            // Load MainMenuScene
            InputManager.CM.GameModeManager.CurrentGameMode.ResetGameMode();

            SceneManager.LoadScene(StringMainMenuScene);

            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }

    public void PlayAgainButton()
    {
        if (EnableInputs == true)
        {
            EnableInputs = false;

            GameModeManager game = InputManager.CM.GameModeManager;

            game.Scoreboard.EditorForceVisible = false;

            StartCoroutine(HandlePlayAgain());
        }
    }

    IEnumerator HandlePlayAgain()
    {
        LoadingScreen.Instance.LoadScreenSceneSwitch(StringGameScene);
        InputManager.CM.StartGame();

        yield return null;
    }

    public void CharacterSelectButton()
    {
        if (EnableInputs == true)
        {
            EnableInputs = false;

            InputManager.CM.RemoveAIPlayers();

            GameModeManager game = InputManager.CM.GameModeManager;

            game.Scoreboard.EditorForceVisible = false;

            InputManager.CM.CurrentGameState = GameState.PlayerSelect;

            InputManager.CM.CleanupGame();

            // Load CharacterSelectionScene
            GameModeManager gameModeManager = InputManager.CM.GameModeManager;
            if (gameModeManager != null && gameModeManager.CurrentGameMode != null)
            {
                gameModeManager.CurrentGameMode.ResetGameMode();
            }

            SceneManager.LoadScene(StringCharacterSelectScene);

            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }
}
