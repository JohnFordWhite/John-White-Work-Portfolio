﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Information                                                                    *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            October 13th, 2016                                                             *
 *                                                                                                 *
 * This file contains static functions and variables, to be used as ease-of-access functions.      *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - October 13th, 2016                                      *
\***************************************************************************************************/

using UnityEngine;
using System.Collections.Generic;

public static class Information
{
    private static List<Player> s_AllPlayers = null;
    private static List<Player> s_AllHumanPlayers = null;
    private static List<Player> s_AllAiPlayers = null;
    private static List<TurretScript> s_AllTurrets = null;
    private static List<OffMeshLink> s_AllOffMeshLinks = null;

    private static GameObject[] s_SpawnPoints = null;

    private const string StringRespawn = "Respawn";

    // DON'T cache AllHumanDevices, because this number will change during CharacterSelectionScene.

    // Should call this every time you start a new game.
    public static void ClearCachedValues()
    {
#if UNITY_EDITOR
        DebugManager.Log("Information.cs: Cleared cached values.", Developmer.Evan);
#endif
        s_AllPlayers = null;
        s_AllHumanPlayers = null;
        s_AllAiPlayers = null;
        s_AllTurrets = null;
        s_AllOffMeshLinks = null;

        s_SpawnPoints = null;
    }

    public static List<OffMeshLink> AllOffMeshLinks
    {
        get
        {
            if(s_AllOffMeshLinks == null || s_AllOffMeshLinks.Count <= 0)
            {
                s_AllOffMeshLinks = new List<OffMeshLink>(GameObject.FindObjectsOfType<OffMeshLink>());
            }

            return s_AllOffMeshLinks;
        }
    }

    public static OffMeshLink[] GetOffMeshLinksPlayerIsOn(Player aPlayer, float aHorizontalDistanceAcceptance = 1f, float aVerticalDistanceAcceptance = 3f)
    {
        List<OffMeshLink> links = new List<OffMeshLink>();

        if (!(aPlayer.GetComponent<BasicMovementScript>().IsGrounded))
            return null;

        for (int i = 0; i < AllOffMeshLinks.Count; i++)
        {
            if (MathUtils.AIVector3Distance(aPlayer.transform.position, AllOffMeshLinks[i].startTransform.position, aHorizontalDistanceAcceptance, aVerticalDistanceAcceptance))
                links.Add(AllOffMeshLinks[i]);
        }

        return links.ToArray();
    }

    public static List<Player> AllPlayers
    {
        get
        {
            if (s_AllPlayers == null || s_AllPlayers.Count <= 0)
            {
                List<Player> players = new List<Player>();

                for (int i = 0; i < InputManager.CM.Players.Count; i++)
                {
                    //Player player = InputManager.CM.Players[i].transform.GetComponentInChildren<Player>(true);
                    Player player = InputManager.CM.Players[i].Input.Character;

                    if (player != null)
                    {
                        players.Add(player);
                    }
                }

                s_AllPlayers = players;
            }

            return s_AllPlayers;
        }
    }

    // This operation is slower than just checking AllHumanPlayers or InputManager.CM.Players when there are no AI added yet.
    //public static List<GameObject> AllHumanDevices
    //{
    //    get
    //    {
    //        List<GameObject> AllHumans = new List<GameObject>();
    //        for (int i = 0; i < InputManager.CM.Players.Count; i++)
    //        {
    //            GameInputComponent player = InputManager.CM.Players[i];

    //            if (player.IsAI == false)
    //            {
    //                AllHumans.Add(player.gameObject);
    //            }
    //        }

    //        return AllHumans;
    //    }
    //}

    public static HealthPackScript[] AllHealthPacks
    {
        get
        {
            return GameObject.FindObjectsOfType<HealthPackScript>();
        }
    }

    public static List<Player> AllHumanPlayers
    {
        get
        {
            if (s_AllHumanPlayers == null || s_AllHumanPlayers.Count <= 0)
            {
                List<Player> players = AllPlayers;

                List<Player> humans = new List<Player>();
                for (int i = 0; i < players.Count; i++)
                {
                    Player player = players[i];

                    if (player == null || player.IsAI)
                        continue;

                    humans.Add(player);
                }

                // Set the players in the correct order
                if (humans.Count > 1)
                {
                    humans.Sort(
                        (player1, player2) => (
                            player1.GameInput.CompareTo(
                                player2.GameInput
                            )
                        )
                        );
                }

                s_AllHumanPlayers = humans;
                //return humans;
            }

            return s_AllHumanPlayers;
        }
    }

    public static List<Player> AllAIPlayers
    {
        get
        {
            if (s_AllAiPlayers == null || s_AllAiPlayers.Count <= 0)
            {
                List<Player> players = AllPlayers;
                List<Player> ai = new List<Player>();
                for (int i = 0; i < players.Count; i++)
                {
                    Player player = players[i];

                    if (player != null && player.IsAI)
                        ai.Add(player);
                }

                s_AllAiPlayers = ai;
                //return ai;
            }

            return s_AllAiPlayers;
        }
    }

    public static GameObject[] AllTerritories
    {
        get
        {
            GameModeType currentGameMode = InputManager.CM.GameModeManager.CurrentGameMode.GetGameModeType();
            if (currentGameMode != GameModeType.TerritoriesGameMode)
            {
#if UNITY_EDITOR
                DebugManager.LogError("Trying to get all territories when game type is " + currentGameMode.ToString(), Developmer.AllDevelopmers);
#endif
                return null;
            }

            Transform[] transforms = InputManager.CM.GameModeManager.CurrentGameMode.GetCurrentObjectiveLocations();
            GameObject[] territories = new GameObject[transforms.Length];
            for (int i = 0; i < territories.Length; i++)
                territories[i] = transforms[i].gameObject;

            return territories;
        }
    }

    public static GameObject[] AllHills
    {
        get
        {
            GameModeType currentGameMode = InputManager.CM.GameModeManager.CurrentGameMode.GetGameModeType();
            if (currentGameMode != GameModeType.KingOfTheHillGameMode)
            {
#if UNITY_EDITOR
                DebugManager.LogError("Trying to get all hills when game type is " + currentGameMode.ToString(), Developmer.AllDevelopmers);
#endif
                return null;
            }
            Transform[] transforms = InputManager.CM.GameModeManager.CurrentGameMode.GetCurrentObjectiveLocations();
            GameObject[] hills = new GameObject[transforms.Length];
            for (int i = 0; i < hills.Length; i++)
                hills[i] = transforms[i].gameObject;

            return hills;
        }
    }

    public static GameObject ActiveHill
    {
        get
        {
            GameModeType currentGameMode = InputManager.CM.GameModeManager.CurrentGameMode.GetGameModeType();
            if (currentGameMode != GameModeType.KingOfTheHillGameMode)
            {
#if UNITY_EDITOR
                DebugManager.LogError("Trying to get active hill when game type is " + currentGameMode.ToString(), Developmer.AllDevelopmers);
#endif
                return null;
            }

            GameObject[] hills = AllHills;

            for(int i = 0; i < hills.Length; i++)
            {
                if (hills[i].activeSelf)
                    return hills[i];
            }

            return null;
        }
    }

    public static Paige[] AllPaige
    {
        get { return GameObject.FindObjectsOfType<Paige>(); }
    }

    public static Leeroy[] AllLeeroy
    {
        get { return GameObject.FindObjectsOfType<Leeroy>(); }
    }

    public static Zeph[] AllZeph
    {
        get { return GameObject.FindObjectsOfType<Zeph>(); }
    }

    public static Quark[] AllQuark
    {
        get { return GameObject.FindObjectsOfType<Quark>(); }
    }

    public static List<TurretScript> AllTurrets
    {
        get
        {
            if (s_AllTurrets == null || s_AllTurrets.Count <= 0)
            {
                List<TurretScript> turrets = new List<TurretScript>();

                s_AllTurrets = turrets;

                s_AllTurrets.Capacity = AllQuark.Length * 3;
            }

            return s_AllTurrets;
        }
    }

    public static void AddTurret(TurretScript turret)
    {
        List<TurretScript> turrets = Information.AllTurrets;

        if (turret != null)
        {
            turrets.Add(turret);
        }

        s_AllTurrets = turrets;
    }

    public static GameInputComponent[] ObjectsWithGameInput
    {
        get { return GameObject.FindObjectsOfType<GameInputComponent>(); }
    }

    public static Player GetPlayerForID(int aID)
    {
        List<Player> players = AllPlayers;
        
        for (int i = 0; i < players.Count; i++)
        {
            Player player = players[i];

            int id = player.GameInput.PlayerID;

            if (id == aID)
                return player;
        }

        return null;
    }

    public static TurretScript[] GetTurretsForOwner(Quark aOwner)
    {
        List<TurretScript> turretsOwned = new List<TurretScript>();
        List<TurretScript> allTurrets = AllTurrets;
        
        for (int i = 0; i < allTurrets.Count; i++)
        {
            TurretScript turret = allTurrets[i];

            if (turret.Owner == aOwner)
                turretsOwned.Add(turret);
        }

        return turretsOwned.ToArray();
    }

    public static GameObject[] SpawnPoints
    {
        get
        {
            //GameObject[] spawnPoints = GameObject.FindGameObjectsWithTag("Respawn");
            //Transform[] transforms = new Transform[spawnPoints.Length];
            //for(int i = 0; i < transforms.Length; i++)
            //{
            //    transforms[i] = spawnPoints[i].transform;
            //}
            //return transforms;

            if (s_SpawnPoints == null || s_SpawnPoints.Length <= 0)
            {
                s_SpawnPoints = GameObject.FindGameObjectsWithTag(StringRespawn);
            }

            return s_SpawnPoints;
        }
    }

    // Checks to see if the camera is on screen. Does not check if objects are in between.
    public static bool IsObjectOnCamera(GameObject aObject, Camera aCamera)
    {
        Vector3 screenPoint = aCamera.WorldToViewportPoint(aObject.transform.position);
        bool onScreen = screenPoint.z > 0 && screenPoint.x > 0 && screenPoint.x < 1 && screenPoint.y > 0 && screenPoint.y < 1;
        return onScreen;
    }

    public static bool AICanSeeObject(GameObject aAI, GameObject aObject)
    {
        return (Vector3.Angle((aObject.transform.position - aAI.transform.position).normalized, aAI.transform.forward) < 80f);
    }

    public static float SmokeScreenRadius = 5f;
    public static float TMNAdhesiveWidth = 4f;

    public static void AddAdhesive(TMNThrowableFunctionality aAdhesive) { m_AdhesiveList.Add(aAdhesive); }
    public static void RemoveAdhesive(TMNThrowableFunctionality aAdhesive) { while (m_AdhesiveList.Contains(aAdhesive)) m_AdhesiveList.Remove(aAdhesive); }
    public static TMNThrowableFunctionality GetAdhesiveForOwner(Paige aOwner)
    {
        for (int i = 0; i < m_AdhesiveList.Count; i++)
        {
            TMNThrowableFunctionality adhesive = m_AdhesiveList[i];

            if (adhesive.Owner == aOwner)
                return adhesive;
        }
        return null;
    }
    private static List<TMNThrowableFunctionality> m_AdhesiveList = new List<TMNThrowableFunctionality>();
    public static bool IsPlayerInAdhesive(Player aPlayer)
    {
        for (int i = 0; i < m_AdhesiveList.Count; i++)
        {
            TMNThrowableFunctionality adhesive = m_AdhesiveList[i];

            if (adhesive.PlayersAffected.Contains(aPlayer))
                return true;
        }
        return false;
    }
}