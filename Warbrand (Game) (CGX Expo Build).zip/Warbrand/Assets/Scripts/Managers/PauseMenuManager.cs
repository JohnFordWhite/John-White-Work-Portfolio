﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PauseMenuManager : GameMenu
{
    public Text TitleText;

    public Button ContinueGameButton;
    public Button OptionsButton;
    public Button ConfigureControlsButton;
    public Button ExitGameButton;

    [HideInInspector]
    // This is the player that paused the game. This player is needed for configure controls.
    public int PausedPlayerIndex = -1;

    private const string MainMenuScene = "MainMenuScene";
    private const string PauseMenuScene = "PauseMenuScene";
    private const string OptionsScene = "OptionsScene";
    private const string OptionsCanvas = "OptionsCanvas";

    private const string m_ControlConfiguratorResource = "Prefabs/UI/ControlConfigurator";

    private bool m_LoadingOptions = false;

    // Use this for initialization
    protected override void Start ()
    {
        base.Start();

        EnableNavigation();
    }
	
	// Update is called once per frame
	protected override void Update ()
    {
        base.Update();

        if (EnableInputs == true)
        {
            if (IsSubmitButtonPressed())
            {
                TryCurrentSelectableOnClick();
                return;
            }

            if (IsCancelButtonPressed())
            {
                ContinueGameButtonFunction();
                return;
            }
        }
	}

    public void UpdateTitleText()
    {
        if (PausedPlayerIndex != -1)
        {
            TitleText.text = "Player " + (PausedPlayerIndex + 1).ToString() + " Paused";
        }
    }

    public void ContinueGameButtonFunction()
    {
        if (EnableInputs == true)
        {
            EnableInputs = false;

            StartCoroutine(HandleContinueGame());
        }
    }

    IEnumerator HandleContinueGame()
    {
        // Wait one frame to return to prevent start button/enter locking in this scene.
        yield return null;

        CloseMenu(PauseMenuScene);

        InputManager.CM.Pause(false);
    }

    public void OptionsButtonFunction()
    {
        if (EnableInputs == true && m_LoadingOptions == false)
        {
            StartCoroutine(HandleLoadOptions());
        }
    }

    IEnumerator HandleLoadOptions()
    {
        m_LoadingOptions = true;

        SceneManager.LoadScene(OptionsScene, LoadSceneMode.Additive);

        // Wait one frame to let options scene get loaded
        // before trying to access GameObject from newly loaded scene.
        yield return null;

        GameObject optionsCanvas = GameObject.Find(OptionsCanvas);

        if (optionsCanvas != null)
        {
            OptionsScreenScript options = optionsCanvas.GetComponent<OptionsScreenScript>();

            options.ParentMenu = this;

            gameObject.SetActive(false);
        }
        
        m_LoadingOptions = false;

        yield return null;
    }

    public void ConfigureControlsButtonFunction()
    {
        if (EnableInputs == true && PausedPlayerIndex >= 0)
        {
            GameObject configuratorObject;
            configuratorObject = Instantiate(Resources.Load(m_ControlConfiguratorResource)) as GameObject;
            EditControlScript configurator = configuratorObject.GetComponent<EditControlScript>();
            configurator.SetupPlayerObject(PausedPlayerIndex, InputManager.CM.Players[PausedPlayerIndex]);

            configurator.ParentMenu = this;
            gameObject.SetActive(false);
        }
    }

    public void ExitGameButtonFunction()
    {
        if (EnableInputs == true)
        {
            EnableInputs = false;

            StartCoroutine(HandleExitGame());
        }
    }

    IEnumerator HandleExitGame()
    {
        InputManager.CM.RemoveAIPlayers();

        InputManager.CM.CleanupGame();

        InputManager.CM.CurrentGameState = GameState.MainMenu;

        SceneManager.LoadScene(MainMenuScene);

        yield return null;
    }
}
