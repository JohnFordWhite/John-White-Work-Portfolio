﻿using UnityEngine;
using System.Collections;

public enum Developmer
{
    None            = 0,        // Developmer flags must be a power of 2.
    Evan            = 1,        // 1    0000 0001
    John            = 1 << 1,   // 2    0000 0010
    Jon             = 1 << 2,   // 4    0000 0100
    Jordan          = 1 << 3,   // 8    0000 1000
    Nathan          = 1 << 4,   // 16   0001 0000
    Nick            = 1 << 5,   // 32   0010 0000
    AllDevelopmers  = Evan | John | Jon | Jordan | Nathan | Nick,
    MAX_DEVELOPMERS
}

public static class DebugManager
{
    private static bool LogEvan = false;
    private static bool LogJohn = false;
    private static bool LogJon = false;
    private static bool LogJordan = false;
    private static bool LogNathan = true;
    private static bool LogNick = false;

    // This method checks to see if the specified Developmer has logging turned on before logging the message.
    // Multiple Developmers can see the log using the bitwise OR operation. For example:
    // (Developmer.Evan | Developmer.Nathan) - if Nathan or Evan have logging enabled, it will log for both Developers.
    // Also has a handy flag for logging for all Developmers who have logging enabled: Developmer.AllDevelopmers
    // This method is much faster than using the built-in Enum.HasFlag().
    private static bool IsDevelopmerOn(Developmer aDevelopmer)
    {
        bool isOn = false;

        if (aDevelopmer >= Developmer.AllDevelopmers &&
            (LogEvan || LogJohn || LogJon || LogJordan || LogNathan || LogNick) == true)
        {
            isOn = true;
        }
        else
        {
            if (LogEvan == true && (aDevelopmer & Developmer.Evan) != 0)
            {
                isOn = true;
            }
            else if (LogJohn == true && (aDevelopmer & Developmer.John) != 0)
            {
                isOn = true;
            }
            else if (LogJon == true && (aDevelopmer & Developmer.Jon) != 0)
            {
                isOn = true;
            }
            else if (LogJordan == true && (aDevelopmer & Developmer.Jordan) != 0)
            {
                isOn = true;
            }
            else if (LogNathan == true && (aDevelopmer & Developmer.Nathan) != 0)
            {
                isOn = true;
            }
            else if (LogNick == true && (aDevelopmer & Developmer.Nick) != 0)
            {
                isOn = true;
            }
        }

        return isOn;
    }

    public static bool Log(object aMessage, Developmer aDevelopmer)
    {
#if UNITY_EDITOR
        if (IsDevelopmerOn(aDevelopmer))
        {
            Debug.Log(aMessage);
            return true;
        }
#endif
        return false;
    }

    public static bool LogWarning(object aMessage, Developmer aDevelopmer)
    {
#if UNITY_EDITOR
        if (IsDevelopmerOn(aDevelopmer))
        {
            Debug.LogWarning(aMessage);
            return true;
        }
#endif
        return false;
    }

    public static bool LogError(object aMessage, Developmer aDevelopmer)
    {
#if UNITY_EDITOR
        if (IsDevelopmerOn(aDevelopmer))
        {
            Debug.LogError(aMessage);
            return true;
        }
#endif
        return false;
    }

    public static bool DrawLine(Vector3 aStart, Vector3 aEnd, Developmer aDevelopmer) { return DrawLine(aStart, aEnd, Color.white, aDevelopmer); }
    public static bool DrawLine(Vector3 aStart, Vector3 aEnd, Color aColor, Developmer aDevelopmer)
    {
#if UNITY_EDITOR
        if (IsDevelopmerOn(aDevelopmer))
        {
            Debug.DrawLine(aStart, aEnd, aColor);
            return true;
        }
#endif
        return false;
    }
    public static bool DrawLine(Vector3 aStart, Vector3 aEnd, Color aColor, float aDuration, Developmer aDevelopmer)
    {
#if UNITY_EDITOR
        if (IsDevelopmerOn(aDevelopmer))
        {
            Debug.DrawLine(aStart, aEnd, aColor, aDuration);
            return true;
        }
#endif
        return false;
    }
}