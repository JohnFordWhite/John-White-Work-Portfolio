﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        LoadingScreen                                                                  *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            January 31st, 2017                                                             *
 *                                                                                                 *
 * Singleton class that loads scenes asynchronously and spins a little image to signify loading.   *
 * A progress bar is also set up, but I like the spinny circles better. Also, at the time of       *
 * writing this, all scenes load so fast (< 1 second), the progress bar is kind of pointless.      *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - January 31st, 2017                                          *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LoadingScreen : MonoBehaviour
{
    //
    //Public
    //

    public static LoadingScreen Instance
    {
        get
        {
            return s_Instance;
        }
    }

    public GameObject LoadingScreenCanvas;
    public GameObject LoadingText;
    public GameObject LoadingScreenSpinner;
    public Image LoadingBarImage;
    public bool DoFakeLoad = false;
    public string LevelToLoad;
    public string m_FakeLoadSceneString;

    //
    //Private
    //
    private Color m_TextCol;
    private static LoadingScreen s_Instance = null;
    private bool CanFadeOut = true;
    private bool CanFadeIn = false;
    private static object s_InstanceLock = new object();
    private int m_FakeLoadTime = 3;

    private CanvasRenderer m_LoadingTextCanvasRenderer;

    void Awake()
    {
        if (s_Instance == null)
        {
            lock (s_InstanceLock)
            {
                if (s_Instance == null)
                {
                    DontDestroyOnLoad(gameObject);
                    s_Instance = this;
                }
            }
        }
        else if (s_Instance != null)
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        LoadingScreenCanvas.SetActive(false);

        LoadingBarImage.fillAmount = 0;
    }

    void Update()
    {
        if(LoadingScreenCanvas.activeSelf)
        {
            LoadingScreenSpinner.transform.Rotate(new Vector3(0, 0, 1), -5f);

            m_TextCol = Color.Lerp(Color.white, Color.black, Mathf.PingPong(Time.time, 1));

            if (m_LoadingTextCanvasRenderer == null)
                LoadingText.GetComponent<CanvasRenderer>();

            if (m_LoadingTextCanvasRenderer != null)
                m_LoadingTextCanvasRenderer.SetColor(m_TextCol);

        }
            if (DoFakeLoad)
                FakeLoad();

    }

    public void LoadScreenSceneSwitch(string aLevelToLoad, LoadSceneMode aLoadSceneMode = LoadSceneMode.Single, bool aFakeTimedLoad = false)
    {
        if(aFakeTimedLoad)
        {
            m_FakeLoadSceneString = aLevelToLoad;
            DoFakeLoad = true;
        }
        else
            StartCoroutine(DisplayLoadingScreen(aLevelToLoad, aLoadSceneMode));
    }

    IEnumerator DisplayLoadingScreen(string aLevelToLoad,LoadSceneMode aLoadSceneMode)
    {
        LoadingScreenCanvas.SetActive(true);
        AsyncOperation async = SceneManager.LoadSceneAsync(aLevelToLoad,aLoadSceneMode);
        while (!async.isDone)
        {
            float progress = Mathf.Clamp01(async.progress / 0.9f);

            //Debug.Log("Loading progress: " + (int)(progress * 100) + "%");

            LoadingBarImage.fillAmount = progress * 100;

            yield return null;
        }

        // Wait one frame before hiding the loading screen to give objects a chance to update properly in the first frame of the game
        // i.e. let the character models hide in first person so the player cannot see it for one frame.
        yield return null;

        LoadingScreenCanvas.SetActive(false);
    }

    void FakeLoad()
    {
        LoadingScreenCanvas.SetActive(true);

        if (LoadingBarImage.fillAmount <= 1)
        {
            LoadingBarImage.fillAmount += 1.0f / m_FakeLoadTime * Time.deltaTime;
        }
        if (LoadingBarImage.fillAmount == 1.0f)
        {
            LoadingScreenCanvas.SetActive(false);
            DoFakeLoad = false;
            SceneManager.LoadScene(m_FakeLoadSceneString, LoadSceneMode.Single);
        }
    }
}
