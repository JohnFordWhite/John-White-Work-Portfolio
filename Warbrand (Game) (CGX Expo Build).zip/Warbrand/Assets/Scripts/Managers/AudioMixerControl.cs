﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        AudioMixerControl                                                              *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            January 10th, 2017                                                             *
 *                                                                                                 *
 * Handles setting the volume of audio mixer groups.                                               *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - January 10th, 2017                                          *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using UnityEngine.Audio;

public class AudioMixerControl : MonoBehaviour
{
    //
    //Public
    //
    public AudioMixer MasterMixer;

    private const string m_MasterVol = "MasterVol";
    private const string m_MusicVol = "MusicVol";
    private const string m_SoundFXVol = "SoundFXVol";
    private const string m_FootstepVol = "FootstepVol";
    private const string m_VoiceVol = "VoiceVol";

    public void SetMasterLevel(float aMasterLevel)
    {
        float newDb = SliderToDB(aMasterLevel);

        MasterMixer.SetFloat(m_MasterVol, newDb);
    }

    public void SetMusicLevel(float aMusicLevel)
    {
        float newDb = SliderToDB(aMusicLevel);

        MasterMixer.SetFloat(m_MusicVol, newDb);
    }

    public void SetSoundFXLevel(float aSoundFXLevel)
    {
        float newDb = SliderToDB(aSoundFXLevel);

        MasterMixer.SetFloat(m_SoundFXVol, newDb);
    }

    public void SetFootstepXLevel(float aFootstepLevel)
    {
        float newDb = SliderToDB(aFootstepLevel);

        MasterMixer.SetFloat(m_FootstepVol, newDb);
    }

    public void SetVoiceLevel(float aVoiceLevel)
    {
        float newDb = SliderToDB(aVoiceLevel);

        MasterMixer.SetFloat(m_VoiceVol, newDb);
    }

    public float SliderToDB(float aSliderValue)
    {
        float dB = 50f * Mathf.Log10(aSliderValue);

        if (dB < -80.0f)
            dB = -80.0f;

        return dB;
    }

}
