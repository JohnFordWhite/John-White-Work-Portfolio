﻿// This class is used by the PlayerInput class since it needs to read Button and Axis values
// from the built-in Unity InputManager.
// A single InputMapping is a reference to a button (or buttons) or an axis that is mapped
// to a single control in the game.
// Two buttons can be mapped to an axis to emulate an axis with a positive and negative value.
// This class supports having a different deadzone sensitivity for each axis.
using System;
using UnityEngine;
//using XInputDotNetPure;

public abstract class InputMapping
{
    public const string KeyboardButtonMapping = "KeyboardButton";
    public const string MouseAxisMapping = "MouseAxis";
    public const string JoystickButtonMapping = "JoystickButton";
    public const string JoystickAxisMapping = "JoystickAxis";

    public enum InputState
    {
        NotPressed,
        JustPressed,
        Held,
        JustReleased
    }

    public bool CanChangeSensitivity;
    public float SensitivityModifier;

    public float AxisDeadZone;
    public bool InvertAxis;

    public PlayerInput player;

    public float CurrentRawInputState;
    public float PreviousRawInputState;

    public float InputDelay;
    public float NextUpdateTime;

    public InputMapping(PlayerInput aPlayerInput)
    {
        InvertAxis = false;
        player = aPlayerInput;
        CanChangeSensitivity = false;
        SensitivityModifier = 1.0f;

        ResetState();
    }

    // Needs to be called every frame.
    // Primarily used for MouseAxisInputMapping and KeyboardButtonInputMapping.
    public virtual void Update()
    {

    }

    public virtual void ResetState()
    {
        CurrentRawInputState = 0.0f;
        PreviousRawInputState = 0.0f;
    }

    public abstract float GetInput(InputType aInputType = InputType.ButtonHeld, bool aRawAxis = false, bool aResetInputState = false, bool aTestInput = false);

    public void DebugInputPressed(Player aPlayer, string aLongInputString, InputType aInputType, bool aTestInput = false)
    {
#if UNITY_EDITOR
        if (aTestInput == true)
        {
            string message = string.Empty;
            message += "Player: ";
            message += (aPlayer == null ? "null" : aPlayer.gameObject.ToString());
            message += ", Device: ";
            message += player.Device.ToString() + "\n";
            message += "Input: " + aLongInputString;
            message += ", Input State: " + aInputType.ToString();
            DebugManager.Log(message, Developmer.Evan);
        }
#endif
    }

    public abstract string GetInputString(bool aLongFormat = false);

    protected InputState m_CurrentInputState;

    // This is used by MouseAxisInputMapping and KeyboardButtonInputMapping primarily. Joystick buttons/axes get updated another way.
    // This needs to be called after setting CurrentRawInputState in Update().
    protected void UpdateCurrentInputState(bool aIsAxis)
    {
        // Axis not pressed
        if (CurrentRawInputState == 0.0f && PreviousRawInputState == 0.0f)
        {
            m_CurrentInputState = InputState.NotPressed;
        }
        // Axis is being held
        else if (CurrentRawInputState != 0.0f && PreviousRawInputState != 0.0f)
        {
            m_CurrentInputState = InputState.Held;
        }
        // Axis was just pressed this frame
        else if (CurrentRawInputState != 0.0f && PreviousRawInputState == 0.0f)
        {
            m_CurrentInputState = InputState.JustPressed;
        }
        // Axis was just released this frame
        else if (CurrentRawInputState == 0.0f && PreviousRawInputState != 0.0f)
        {
            m_CurrentInputState = InputState.JustReleased;
        }

        // This is needed for keyboard player as there is a bug with Unity's Mathf.Sign
        // where it will return 1 if the input value is 0. This behaviour is not wanted.
        if (aIsAxis == true)
        {
            if (Mathf.Abs(CurrentRawInputState) >= AxisDeadZone)
            {
                CurrentRawInputState = Mathf.Sign(CurrentRawInputState);
            }
        }
    }

    protected bool CanUseInput()
    {
        bool canUse = true;

        // InputDelay was set
        if (InputDelay > 0.0f)
        {
            if (Time.unscaledTime < NextUpdateTime)
            {
                canUse = false;
            }
        }

        return canUse;
    }

    public abstract string GetInputMappingType();
    public abstract string GetInputNameValueString(float aSign);

    // This needs to be called whenever the CurrentConfiguration of the PlayerInput gets changed to a new configuration
    // or the axis may be mapped to the wrong device! This does not matter for buttons (keyboard or joystick) but
    // it matters for axes.
    public virtual void ResetInputString()
    {

    }
}

public abstract class ButtonInputMapping : InputMapping
{
    public ButtonInputMapping(PlayerInput aPlayerInput) : base(aPlayerInput)
    {

    }

    public override void Update()
    {
        base.Update();
    }

    protected virtual void UpdateButtonState()
    {

    }
}

public abstract class AxisInputMapping : InputMapping
{
    public string LongAxisString { get; set; }  // Lookup for Unity Input.GetAxis
    public string ShortAxisString { get; set; } // Short, readable format

    public AxisInputMapping(PlayerInput aPlayerInput) : base(aPlayerInput)
    {
        AxisDeadZone = JoystickMap.JOYSTICK_AXIS_DEADZONE;
        LongAxisString = string.Empty;
        ResetState();
    }

    public override void Update()
    {
        base.Update();
    }

    // If an axis state needs to be updated every frame, make sure to override this.
    protected virtual void UpdateAxisState()
    {

    }

    public override void ResetState()
    {
        base.ResetState();

        m_CurrentInputState = InputState.NotPressed;
        CurrentRawInputState = 0;
        PreviousRawInputState = 0;
    }

    // This needs to be called whenever the CurrentConfiguration of the PlayerInput gets changed to a new configuration
    // or the axis may be mapped to the wrong device!
    public override void ResetInputString()
    {
        LongAxisString = player.BuildDeviceAxisString(ShortAxisString);
    }

    public abstract float TestAxis(InputType aInputType, float aAxisDeadZone, bool aRawAxis = false, bool aTestInput = false);
}

// Keyboard player can still read input from Unity's Input engine.
public class KeyboardButtonInputMapping : ButtonInputMapping
{
    public KeyCode PositiveButtonAxis { get; set; }
    public KeyCode NegativeButtonAxis { get; set; }

    protected float m_PositiveValue;
    protected float m_NegativeValue;
    
    public override string GetInputMappingType()
    {
        return KeyboardButtonMapping;
    }

    public override string GetInputNameValueString(float aSign = 1.0f)
    {
        string name = string.Empty;

        if (aSign >= 0)
        {
            if (PositiveButtonAxis != KeyCode.None)
            {
                name = PositiveButtonAxis.ToString();
            }
        }
        else
        {
            if (NegativeButtonAxis != KeyCode.None)
            {
                name = NegativeButtonAxis.ToString();
            }
        }

        return name;
    }

    public KeyboardButtonInputMapping(PlayerInput aPlayerInput) : base(aPlayerInput)
    {
#if UNITY_EDITOR
        if (aPlayerInput.DebugInputMappingConstructor == true)
        {
            DebugManager.Log("New Keyboard button", Developmer.Evan);
        }
#endif

        ResetState();
    }

    public override void ResetState()
    {
        base.ResetState();

        PositiveButtonAxis = KeyCode.None;
        NegativeButtonAxis = KeyCode.None;
    }

    public override void Update()
    {
        base.Update();

        UpdateButtonState();
    }

    protected override void UpdateButtonState()
    {
        // Set the Previous Raw Input State to the current.
        PreviousRawInputState = CurrentRawInputState;

        float positiveValue = (Input.GetKey(PositiveButtonAxis) == true ? 1.0f : 0.0f);
        float negativeValue = (Input.GetKey(NegativeButtonAxis) == true ? 1.0f : 0.0f);
        float axisValue = (positiveValue - negativeValue);

        CurrentRawInputState = axisValue;
        base.UpdateCurrentInputState(false);
    }

    public KeyCode GetMappedKeyCode(float aSign = 1.0f)
    {
        if (aSign > 0.0f)
        {
            return PositiveButtonAxis;
        }
        else
        {
            return NegativeButtonAxis;
        }
    }

    public override float GetInput(InputType aInputType = InputType.ButtonHeld, bool aRawAxis = false, bool aResetInputState = false, bool aTestInput = false)
    {
        float axisValue = 0.0f;

        if (CanUseInput())
        {
            // Key can be used directly as a KeyCode for Input.GetKey if it is a button.
            float positiveValue = TestKey(PositiveButtonAxis, aInputType, 1.0f, 0.0f, KeyCode.None, aTestInput);
            float negativeValue = TestKey(NegativeButtonAxis, aInputType, 1.0f, 0.0f, KeyCode.None, aTestInput);
            axisValue = (positiveValue - negativeValue);

            if (aRawAxis == false)
            {
                axisValue *= SensitivityModifier;
            }

            // Invert the axis if needed
            if (InvertAxis == true)
            {
                axisValue *= -1.0f;
            }

            if (aResetInputState)
                ResetState();

            if (InputDelay > 0.0f && axisValue != 0.0f)
                NextUpdateTime = InputDelay + Time.unscaledTime;
        }
        return axisValue;
    }

    public float TestKey(KeyCode aKeyCode, InputType aInputType = InputType.ButtonHeld, float aTrueValue = 1.0f, float aFalseValue = 0.0f, KeyCode aIgnoreKey = KeyCode.None, bool aTestInput = false)
    {
        float inputValue = 0.0f;

        if (aTestInput == true)
        {
            if (Input.GetKeyDown(aKeyCode))
                Debug.Log(aKeyCode);
        }

        if (aKeyCode != aIgnoreKey)
        {
            // Debugging the key
            if (aTestInput == true)
            {
                Player playerObject = null;
                if (player.Character != null)
                {
                    playerObject = player.Character;
                }
                if (Input.GetKeyDown(aKeyCode))
                {
                    DebugInputPressed(playerObject, GetKeyCodeString(aKeyCode, true), InputType.ButtonPressed, aTestInput);
                }
                if (Input.GetKeyUp(aKeyCode))
                {
                    DebugInputPressed(playerObject, GetKeyCodeString(aKeyCode, true), InputType.ButtonReleased, aTestInput);
                }
            }

            // TODO: m_CurrentInputState seems to be bugged with Keyboard.
            // For now, checking Input.GetKey directly.

            switch (aInputType)
            {
                case InputType.ButtonHeld:
                    return (Input.GetKey(aKeyCode) == true ? aTrueValue : aFalseValue);
                case InputType.ButtonPressed:
                    return (Input.GetKeyDown(aKeyCode) == true ? aTrueValue : aFalseValue);
                case InputType.ButtonReleased:
                    return (Input.GetKeyUp(aKeyCode) == true ? aTrueValue : aFalseValue);
                default:
#if UNITY_EDITOR
                    Debug.LogError("MyInput.TestKey() - Unsupported InputType: " + aInputType.ToString());
#endif
                    break;
            }
        }

        return inputValue;
    }

    public override string GetInputString(bool aLongFormat = false)
    {
        string result = string.Empty;
        if (PositiveButtonAxis != KeyCode.None)
        {
            string readableString = GetKeyCodeString(PositiveButtonAxis, aLongFormat);

            // Look up a more readable string for this input.
            if (JoystickMap.KeyboardInputStrings.ContainsKey(readableString))
            {
                readableString = JoystickMap.KeyboardInputStrings[readableString];
            }
            else
            {
                readableString = "Keyboard - " + readableString;
            }

            result += readableString;

            if (NegativeButtonAxis != KeyCode.None)
            {
                result += " (+ Axis)";
            }
        }
        if (NegativeButtonAxis != KeyCode.None)
        {
            if (PositiveButtonAxis != KeyCode.None)
            {
                result += ",\n";
            }
            else
            {
                result += "UNASSIGNED (+ Axis), ";
            }

            string readableString = GetKeyCodeString(NegativeButtonAxis, aLongFormat);

            // Look up a more readable string for this input.
            if (JoystickMap.KeyboardInputStrings.ContainsKey(readableString))
            {
                readableString = JoystickMap.KeyboardInputStrings[readableString];
            }
            else
            {
                readableString = "Keyboard - " + readableString;
            }

            result += readableString + " (- Axis)";
        }

        if (result.Length <= 0)
        {
            result += "UNASSIGNED";
        }

        return result;
    }

    public string GetKeyCodeString(KeyCode aKeyCode, bool aLongFormat)
    {
        string keyCodeString = string.Empty;

        // Legacy code for Joysticks
        if (aKeyCode >= (KeyCode)JoystickMap.UnityDefinedJoystickSettings.JOYSTICK_KEY_CODE_MIN)
        {
            // Returns Device name and Button name, e.g. "Joystick1Button0"
            if (aLongFormat == true)
            {
                keyCodeString = aKeyCode.ToString();
            }
            // Returns Button name only, e.g. "Button0"
            else
            {
                // Split after "Joystick#"
                keyCodeString = aKeyCode.ToString().Substring(9);
            }
        }
        else if (aKeyCode >= KeyCode.None)
        {
            keyCodeString = aKeyCode.ToString();
        }
        else
        {
            keyCodeString = "UNASSIGNED";
        }

        return keyCodeString;
    }
}

// Get axis from mouse movement. Uses Unity's Input engine.
public class MouseAxisInputMapping : AxisInputMapping
{
    // This class primarily is for mouse movement detection.
    // This class technically supports using Unity's Input Joystick axis detection, but
    // it is better to use XInput (JoystickAxisInputMapping) for joysticks.

    // For reference: http://wiki.unity3d.com/index.php?title=Xbox360Controller#Axises

    // Axis 1  -  Left Stick X                  - (-1 to 1)
    // Axis 2  -  Left Stick Y (-up)            - (-1 to 1)
    // Axis 3  -  Analog Triggers (-right)      - (-1 to 1)
    // Axis 4  -  Right Stick X                 - (-1 to 1)
    // Axis 5  -  Right Stick Y (-up)           - (-1 to 1)
    // Axis 6  -  D Pad X                       - (-1 to 1)
    // Axis 7  -  D Pad Y                       - (-1 to 1)
    // Axis 9  -  Left Trigger                  - (0 to 1)
    // Axis 10 -  Right Trigger                 - (0 to 1)

    // Keyboard/Mouse Axes
    // Axis 1  -  Mouse Move X
    // Axis 2  -  Mouse Move Y
    // Axis 3  -  Scroll Wheel
    
    public override string GetInputMappingType()
    {
        return MouseAxisMapping;
    }

    public override string GetInputNameValueString(float aSign = 1.0f)
    {
        return ShortAxisString;
    }

    public MouseAxisInputMapping(PlayerInput aPlayerInput) : base(aPlayerInput)
    {
#if UNITY_EDITOR
        if (aPlayerInput.DebugInputMappingConstructor == true)
        {
            DebugManager.Log("New Mouse axis", Developmer.Evan);
        }
#endif
    }

    public override void Update()
    {
        base.Update();

        UpdateAxisState();
    }

    public override float GetInput(InputType aInputType = InputType.ButtonHeld, bool aRawAxis = false, bool aResetInputState = false, bool aTestInput = false)
    {
        float axisValue = 0.0f;

        if (CanUseInput())
        {
            axisValue = TestAxis(aInputType, AxisDeadZone, aRawAxis, aTestInput);

            if (aRawAxis == false)
            {
                axisValue *= SensitivityModifier;
            }

            // Invert the axis if needed
            if (InvertAxis == true)
            {
                axisValue *= -1.0f;
            }

            if (aResetInputState)
            {
                ResetState();
            }

            if (InputDelay > 0.0f && axisValue != 0.0f)
                NextUpdateTime = InputDelay + Time.unscaledTime;
        }

        return (Mathf.Abs(axisValue) >= AxisDeadZone ? axisValue : 0.0f);
    }

    protected override void UpdateAxisState()
    {
        if (LongAxisString != string.Empty)
        {
            // Set Previous Raw Axis State to the current.
            PreviousRawInputState = CurrentRawInputState;

            bool axisPressed = Mathf.Abs(Input.GetAxis(LongAxisString)) >= AxisDeadZone;
            //CurrentRawAxisState = Input.GetAxisRaw(LongAxisString);
            CurrentRawInputState = (axisPressed ? Input.GetAxisRaw(LongAxisString) : 0.0f);

            base.UpdateCurrentInputState(true);
        }
    }

    public override float TestAxis(InputType aInputType, float aAxisDeadZone, bool aRawAxis = false, bool aTestInput = false)
    {
        float axisValue = 0.0f;

        // First, check if the requested input type was just pressed.
        if (aInputType == InputType.ButtonPressed && m_CurrentInputState == InputState.JustPressed)
        {
            // Get the sign of the axis.
            axisValue = Mathf.Sign(Input.GetAxisRaw(LongAxisString));
        }
        // Secondly, check if the requested input type was just released.
        else if (aInputType == InputType.ButtonReleased && m_CurrentInputState == InputState.JustReleased)
        {
            // The value of the axis was stored in the previous frame's input.
            axisValue = PreviousRawInputState;
        }
        // For button held, include button pressed as well.
        else if ((aInputType == InputType.ButtonHeld && m_CurrentInputState == InputState.Held) ||
                 (m_CurrentInputState == InputState.JustPressed))
        {
            axisValue = Input.GetAxis(LongAxisString);
            if (Mathf.Abs(axisValue) < aAxisDeadZone)
            {
                axisValue = 0.0f;
            }
            else
            {
                if (aRawAxis)
                {
                    axisValue = Input.GetAxisRaw(LongAxisString);
                }
            }
        }
        // Any other case, consider the axis as not being held at all.
        else
        {
            axisValue = 0.0f;
        }

        // Debugging the axis
        if (aTestInput == true)
        {
            // This will filter out mouse movement as it is very noisy.
            if (player.Device != InputDevice.Keyboard ||
                (player.Device == InputDevice.Keyboard &&
                    (ShortAxisString != "Axis1" && ShortAxisString != "Axis2")))
            {
                Player playerObject = null;
                if (player.Character != null)
                {
                    playerObject = player.Character;
                }
                if (m_CurrentInputState == InputState.JustPressed)
                {
                    DebugInputPressed(playerObject, LongAxisString, InputType.ButtonPressed, aTestInput);
                }
                if (m_CurrentInputState == InputState.JustReleased)
                {
                    DebugInputPressed(playerObject, LongAxisString, InputType.ButtonReleased, aTestInput);
                }
            }
        }

        return axisValue;
    }

    public override string GetInputString(bool aLongFormat = false)
    {
        string result = string.Empty;

        if (LongAxisString != string.Empty)
        {
            if (aLongFormat)
            {
                result += LongAxisString;
            }
            else
            {
                string readableString = ShortAxisString;
                // Look up a more readable string for this input.
                if (JoystickMap.KeyboardInputStrings.ContainsKey(readableString))
                {
                    readableString = JoystickMap.KeyboardInputStrings[readableString];
                }

                result += readableString;
            }
        }

        if (result.Length <= 0)
        {
            result += "UNASSIGNED";
        }

        return result;
    }

    public void SetAxis(string aAxisMapping)
    {
        // Set the axis string. This is a concatenation of the device name and the axis name.
        // All axisString mappings must be created in the Unity Project's InputManager.
        // Edit > Project Settings > Input
        // Examples:
        // Keyboard_Horizontal -> Mouse/Keyboard device, mouse movement (Horizontal)
        // Joystick1_Horizontal -> Joystick 1 device, left stick movement (Horizontal)
        LongAxisString = player.BuildDeviceAxisString(aAxisMapping);
        ShortAxisString = aAxisMapping;
    }
}

// Joysticks need to read their input from the XInput engine.
public class JoystickButtonInputMapping : ButtonInputMapping
{
    public int PositiveButtonAxis { get; set; }

    public int NegativeButtonAxis { get; set; }
    
    public override string GetInputMappingType()
    {
        return JoystickButtonMapping;
    }

    public override string GetInputNameValueString(float aSign = 1.0f)
    {
        string name = string.Empty;

        if (aSign >= 0)
        {
            if (PositiveButtonAxis >= 0)
            {
                name = PositiveButtonAxis.ToString();
            }

        }
        else
        {
            if (NegativeButtonAxis >= 0)
            {
                name = NegativeButtonAxis.ToString();
            }
        }

        return name;
    }

    public JoystickButtonInputMapping(PlayerInput aPlayerInput) : base(aPlayerInput)
    {
#if UNITY_EDITOR
        if (aPlayerInput.DebugInputMappingConstructor == true)
        {
            DebugManager.Log("New Joystick button", Developmer.Evan);
        }
#endif

        ResetState();
    }

    public override void ResetState()
    {
        base.ResetState();

        PositiveButtonAxis = -1;
        NegativeButtonAxis = -1;

        if (player != null && player.GetJoystickIndex() >= 0)
        {
            JoystickState state = InputManager.CM.JoystickStates[player.GetJoystickIndex()];
            if (PositiveButtonAxis >= 0)
                state.ResetButton(PositiveButtonAxis);
            if (NegativeButtonAxis >= 0)
                state.ResetButton(NegativeButtonAxis);
        }
    }

    public int GetMappedButtonIndex(float aSign = 1.0f)
    {
        if (aSign > 0.0f)
        {
            return PositiveButtonAxis;
        }
        else
        {
            return NegativeButtonAxis;
        }
    }

    public override string GetInputString(bool aLongFormat = false)
    {
        string result = string.Empty;

        if (PositiveButtonAxis >= 0)
        {
            result += "Joystick - " + GetButtonString(PositiveButtonAxis, aLongFormat);

            if (NegativeButtonAxis >= 0)
            {
                result += " (+ Axis)";
            }
        }
        if (NegativeButtonAxis >= 0)
        {
            if (PositiveButtonAxis >= 0)
            {
                result += ",\n";
            }
            else
            {
                result += "UNASSIGNED (+ Axis)";
            }
            result += "Joystick - " + GetButtonString(NegativeButtonAxis, aLongFormat) + " (- Axis)";
        }

        if (result.Length <= 0)
        {
            result += "UNASSIGNED";
        }

        return result;
    }

    public override float GetInput(InputType aInputType = InputType.ButtonHeld, bool aRawAxis = false, bool aResetInputState = false, bool aTestInput = false)
    {
        float axisValue = 0.0f;

        if (CanUseInput())
        {
            // Lookup the button index from JoystickMap
            float positiveValue = TestButton(PositiveButtonAxis, aInputType, 1.0f, 0.0f, -1, aTestInput);
            float negativeValue = TestButton(NegativeButtonAxis, aInputType, 1.0f, 0.0f, -1, aTestInput);

            axisValue = (positiveValue - negativeValue);

            if (aRawAxis == false)
            {
                axisValue *= SensitivityModifier;
            }

            // Invert the axis if needed
            if (InvertAxis == true)
            {
                axisValue *= -1.0f;
            }

            if (aResetInputState)
                ResetState();

            if (InputDelay > 0.0f && axisValue != 0.0f)
                NextUpdateTime = InputDelay + Time.unscaledTime;
        }
        return axisValue;
    }

    public float TestButton(int aButtonIndex, InputType aInputType = InputType.ButtonHeld, float aTrueValue = 1.0f, float aFalseValue = 0.0f, int aIgnoreButton = -1, bool aTestInput = false)
    {
        float inputValue = 0.0f;

        if (aButtonIndex != aIgnoreButton)
        {
            JoystickState state = InputManager.CM.JoystickStates[player.GetJoystickIndex()];

            // Debugging the button
            if (aTestInput == true)
            {
                Player playerObject = null;
                if (player.Character != null)
                {
                    playerObject = player.Character;
                }

                if (state.ButtonPressed(aButtonIndex))
                {
                    DebugInputPressed(playerObject, GetButtonString(aButtonIndex, true), InputType.ButtonPressed, aTestInput);
                }
                if (state.ButtonReleased(aButtonIndex))
                {
                    DebugInputPressed(playerObject, GetButtonString(aButtonIndex, true), InputType.ButtonReleased, aTestInput);
                }
            }

            // First, check if the requested input type was just pressed.
            if (aInputType == InputType.ButtonPressed && state.ButtonPressed(aButtonIndex))
            {
                inputValue = 1.0f;
            }
            // Secondly, check if the requested input type was just released.
            else if (aInputType == InputType.ButtonReleased && state.ButtonReleased(aButtonIndex))
            {
                inputValue = 1.0f;
            }
            // For button held
            else if (aInputType == InputType.ButtonHeld && state.ButtonHeld(aButtonIndex))
            {
                inputValue = 1.0f;
            }
        }

        return inputValue;
    }

    public string GetButtonString(int aButtonIndex, bool aLongFormat)
    {
        string buttonString = string.Empty;

        if (aButtonIndex >= 0 && aButtonIndex < JoystickMap.s_ButtonStrings.Length)
        {
            string button = JoystickMap.s_ButtonStrings[aButtonIndex];

            if (aLongFormat == true)
            {
                buttonString = player.Device + " : " + button;
            }
            else
            {
                buttonString = button;
            }
        }
        else
        {
            buttonString = "INVALID INDEX: " + aButtonIndex.ToString();
        }

        return buttonString;
    }
}

public class JoystickAxisInputMapping : AxisInputMapping
{
    int m_AxisIndex;

    public override void ResetState()
    {
        base.ResetState();

        if (player != null && player.GetJoystickIndex() >= 0 && m_AxisIndex >= 0)
        {
            JoystickState state = InputManager.CM.JoystickStates[player.GetJoystickIndex()];
            state.ResetAxis(m_AxisIndex);
        }
    }
    
    public override string GetInputMappingType()
    {
        return JoystickAxisMapping;
    }

    public override string GetInputNameValueString(float aSign = 1.0f)
    {
        return ShortAxisString;
    }

    public JoystickAxisInputMapping(PlayerInput aPlayerInput) : base(aPlayerInput)
    {
#if UNITY_EDITOR
        if (aPlayerInput.DebugInputMappingConstructor == true)
        {
            DebugManager.Log("New Joystick axis", Developmer.Evan);
        }
#endif

        m_AxisIndex = -1;
    }

    public override string GetInputString(bool aLongFormat = false)
    {
        string result = string.Empty;

        if (LongAxisString != string.Empty)
        {
            if (aLongFormat)
            {
                result = "Joystick - " + LongAxisString;
            }
            else
            {
                result = "Joystick - " + ShortAxisString;
            }
        }

        if (result.Length <= 0)
        {
            result += "UNASSIGNED";
        }

        return result;
    }

    public override float TestAxis(InputType aInputType, float aAxisDeadZone, bool aRawAxis = false, bool aTestInput = false)
    {
        float axisValue = 0.0f;

        JoystickState state = InputManager.CM.JoystickStates[player.GetJoystickIndex()];
        float tempValue = state.Axes[m_AxisIndex];

        // First, check if the requested input type was just pressed.
        if (aInputType == InputType.ButtonPressed && state.AxisPressed(m_AxisIndex, aAxisDeadZone))
        {
            // Get the sign of the axis.
            axisValue = Mathf.Sign(tempValue);
        }
        // Secondly, check if the requested input type was just released.
        else if (aInputType == InputType.ButtonReleased && state.AxisReleased(m_AxisIndex, aAxisDeadZone))
        {
            axisValue = 1.0f;
        }
        // For button held, include button pressed as well.
        else if (aInputType == InputType.ButtonHeld && state.AxisHeld(m_AxisIndex, aAxisDeadZone))
        {
            axisValue = tempValue;
            if (Mathf.Abs(axisValue) < aAxisDeadZone)
            {
                axisValue = 0.0f;
            }
            else
            {
                if (aRawAxis)
                {
                    axisValue = Mathf.Sign(tempValue);
                }
            }
        }
        // Any other case, consider the axis as not being held at all.
        else
        {
            axisValue = 0.0f;
        }

        // Debugging the axis
        if (aTestInput == true)
        {
            if (player.Device != InputDevice.Keyboard)
            {
                Player playerObject = null;
                if (player.Character != null)
                {
                    playerObject = player.Character.GetComponent<Player>();
                }
                if (state.AxisPressed(m_AxisIndex, aAxisDeadZone))
                {
                    DebugInputPressed(playerObject, LongAxisString, InputType.ButtonPressed, aTestInput);
                }
                if (state.AxisReleased(m_AxisIndex, aAxisDeadZone))
                {
                    DebugInputPressed(playerObject, LongAxisString, InputType.ButtonReleased, aTestInput);
                }
            }
        }

        return axisValue;
    }

    public override float GetInput(InputType aInputType = InputType.ButtonHeld, bool aRawAxis = false, bool aResetInputState = false, bool aTestInput = false)
    {
        float axisValue = 0.0f;

        if (CanUseInput())
        {
            axisValue = TestAxis(aInputType, AxisDeadZone, aRawAxis, aTestInput);

            if (aRawAxis == false)
            {
                axisValue *= SensitivityModifier;
            }

            // Invert the axis if needed
            if (InvertAxis == true)
            {
                axisValue *= -1.0f;
            }

            if (aResetInputState)
                ResetState();

            axisValue = (Mathf.Abs(axisValue) >= AxisDeadZone ? axisValue : 0.0f);

            if (InputDelay > 0.0f && axisValue != 0.0f)
                NextUpdateTime = InputDelay + Time.unscaledTime;
        }
        return axisValue;
    }

    public void SetAxis(int aAxisIndex)
    {
        m_AxisIndex = aAxisIndex;

        string axisString = string.Empty;

        if (m_AxisIndex >= 0 && m_AxisIndex < JoystickMap.s_AxisStrings.Length)
        {
            axisString = JoystickMap.s_AxisStrings[aAxisIndex];
        }

        if (axisString == string.Empty)
        {
            axisString = "UNASSIGNED";
        }

        ShortAxisString = axisString;
        LongAxisString = player.Device.ToString() + " : " + ShortAxisString;
    }

    public int GetAxis()
    {
        return m_AxisIndex;
    }
}