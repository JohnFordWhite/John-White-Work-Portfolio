﻿/******************************************* File Header *******************************************\
 *                                                                                                  *
 * FileName:        PlayerProfileManager                                                            *
 * FileExtension:   .cs                                                                             *
 * Author:          Evan Campbell                                                                   *
 * Date:            November 11th, 2016                                                             *
 *                                                                                                  *
 * *** Uses 3rd party library: Newtonsoft.Json ***                                                  *
 *                                                                                                  *
 * This file handles saving and loading player preferences to/from a file.                          *
 * When reading inputs from the file, the inputs are validated to ensure that they work properly:   *
 * - It is assumed that the player may edit the player preferences file outside of the game.        *
 * - We need to make sure any of the inputs in the file to not map to any important menu keys       *
 *   to prevent the player from getting locked in the game (escape, start, back, enter, etc.).      *
 * - Need to check if an input that does not allow sensitivity to be modified is not set.           *
 * - Additionally, in case any of the input names or strings are not valid, reset that              *
 *   configuration to use the default controls.                                                     *
 *                                                                                                  *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR  *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS   *
 * FOR A PARTICULAR PURPOSE.                                                                        *
 *                                                                                                  *
 * V 1.0 - Created File (Evan Campbell) - November 11th, 2016                                       *
 * V 1.1 - Got file saving and loading working (Evan Campbell) - December 3rd, 2016                 *
\***************************************************************************************************/

using UnityEngine;
using System;
using System.Collections;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;

// Json file fields
public class PlayerProfilesBuilder
{
    public float Version;
    public List<PlayerProfileBuilder> PlayerProfiles;
}

public class PlayerProfileBuilder
{
    public string ProfileName;
    public List<PlayerInputBuilder> ProfileConfigurations;
}

public class PlayerInputBuilder
{
    public string ConfigurationName;                    // The name of this configuration
    public List<InputMappingBuilder> InputMappings;     // All of the inputs for this control configuration
}

public class InputMappingBuilder
{
    public string InputMappingType;
    public string InputNameTitle;
    public string InputNameValuePositive;
    public string InputNameValueNegative;
    public float AxisDeadzone;
    public bool CanChangeSensitivity;
    public float SensitivityModifier;
    public float InputDelay;
    public bool InvertAxis;

    // These functions determine if the above properties will be written out to the file.
    // Note that these function names must match the property names above exactly.
    public bool ShouldSerializeInputNameValueNegative()
    {
        return (InputNameValueNegative != string.Empty && InputNameValueNegative != InputNameValuePositive);
    }

    public bool ShouldSerializeAxisDeadzone()
    {
        return (AxisDeadzone != 0.0f);
    }

    public bool ShouldSerializeCanChangeSensitivity()
    {
        return (CanChangeSensitivity == true);
    }

    public bool ShouldSerializeSensitivityModifier()
    {
        return (SensitivityModifier != 1.0f && SensitivityModifier > 0.0f);
    }

    public bool ShouldSerializeInputDelay()
    {
        return (InputDelay > 0.0f);
    }

    public bool ShouldSerializeInvertAxis()
    {
        return (InvertAxis == true);
    }
}

// Main class
public class PlayerProfileManager : MonoBehaviour
{
    public const float PlayerProfileVersion = 1.0f;

    public Dictionary<string, PlayerInput> PlayerProfiles
    {
        get
        {
            return m_PlayerProfiles;
        }
    }

    private Dictionary<string, PlayerInput> m_PlayerProfiles;

    public void AddProfile(PlayerInput profile)
    {
        if (m_PlayerProfiles == null)
        {
            m_PlayerProfiles = new Dictionary<string, PlayerInput>();
        }
        m_PlayerProfiles.Add(profile.ProfileName, profile);

        // TODO Remove this - but this is to test writing to a file... for now.
        SaveProfiles();
    }

    public enum WorkingState
    {
        Success,
        Failed,
        SavingInProgress,
        LoadingInProgress,
        NotStarted
    }

    public WorkingState GetCurrentJobState()
    {
        return m_CurrentJobState;
    }

    public int MaxProfileNameLength = 20;   // Max number of characters in name string
    public int MaxProfileCount = 50;        // Max number of profiles to save to/load from profiles list file

    private WorkingState m_CurrentJobState = WorkingState.NotStarted;    // The overall state of saving and loading

    // strings
    private const string FormatProfilesFilePath = "{0}/Profiles/PlayerProfiles.json";
    private const string FormatErrorMessageInvalidInputName = "Invalid Input Name: {0}";
    private const string FormatLoadKeyboardButtonInputError = "LoadKeyboardButtonInput Error:\n{0}";
    private const string FormatLoadMouseAxisInputError = "LoadMouseAxisInput Error:\n{0}";
    private const string FormatLoadJoystickButtonInputError = "LoadJoystickButtonInput Error:\n{0}";
    private const string FormatLoadJoystickAxisInputError = "LoadJoystickAxisInput Error:\n{0}";
    private const string FormatErrorMessageInvalidAxisIndex = "Invalid Axis Index: {0}";
    private const string FormatErrorMessageInvalidButtonIndex = "Invalid Button Index: {0}";
    private const string FormatErrorMessageReservedKey = "Error - Reserved key read from file: {0}";

    public static string ProfilesFilePath
    {
        get
        {
            // Create the file path string once.
            if (m_ProfilesFilePath == null)
            {
                m_ProfilesFilePath = String.Format(FormatProfilesFilePath, Application.persistentDataPath);
            }
            return m_ProfilesFilePath;
        }
    }
    private static string m_ProfilesFilePath = null;

    public WorkingState LoadProfiles()
    {
        if (IsJobFinished())
        {
            m_CurrentJobState = WorkingState.LoadingInProgress;

            StartCoroutine(HandleLoadProfiles());
        }

        return m_CurrentJobState;
    }

    IEnumerator HandleLoadProfiles()
    {
        if (m_PlayerProfiles != null)
        {
            m_PlayerProfiles.Clear();
        }
        else
        {
            m_PlayerProfiles = new Dictionary<string, PlayerInput>();
        }

        //Debug.Log(ProfilesFilePath);

        // Create the directory if it doesn't already exist.
        // This is necessary for File.Exists or it will throw exception if the folder isn't there.
        FileInfo file = new System.IO.FileInfo(ProfilesFilePath);
        file.Directory.Create();

        // Check if the file exists.
        if (File.Exists(ProfilesFilePath))
        {
            string json = File.ReadAllText(ProfilesFilePath);

            //Debug.Log("Read json from file:\n" + json);
            
            PlayerProfilesBuilder input = JsonConvert.DeserializeObject<PlayerProfilesBuilder>(json);

            m_CurrentJobState = WorkingState.LoadingInProgress;

            StartCoroutine(HandleLoadPlayerProfiles(input));

            // TODO: error checking to return Failed state
            m_CurrentJobState = WorkingState.Success;
        }
        else
        {
            // No work to do if file doesn't exist
            m_CurrentJobState = WorkingState.Success;
        }

        yield return null;
    }

    PlayerInput MakeProfile(string aProfileName)
    {
        PlayerInput input = new PlayerInput(null);
        input.ProfileName = aProfileName;

        return input;
    }

    IEnumerator HandleLoadPlayerProfiles(PlayerProfilesBuilder profilesBuilder)
    {
        while (true)
        {
            if (profilesBuilder != null)
            {
                // We may need this later if the format of the file changes.
                float fileVersion = profilesBuilder.Version;

                if (fileVersion > 0.0f)
                {
                    for (int i = 0; i < profilesBuilder.PlayerProfiles.Count && i < MaxProfileCount; i++)
                    {
                        PlayerProfileBuilder profileBuilder = profilesBuilder.PlayerProfiles[i];

                        // Validate this profile before attempting to load it in.
                        //
                        // The profile must have:
                        // - a non-null or non-empty string name
                        // - a string name with MaxProfileNameLength characters or less
                        // - a string that, when trimmed (i.e. no leading or trailing spaces),
                        //   still has a length > 0
                        //
                        // A profile may have 0 or more PlayerInputBuilders. If the profile's
                        // PlayerInputBuilders is missing a specific configuration,
                        // this is acceptable - we can simply add in a default configuration.

                        // Ensure name is shorter or equal to max length
                        if (profileBuilder.ProfileName == null ||
                            profileBuilder.ProfileName.Length <= 0 ||
                            profileBuilder.ProfileName.Length > MaxProfileNameLength)
                        {
                            continue;
                        }

                        // Trim string
                        profileBuilder.ProfileName = profileBuilder.ProfileName.Trim();

                        // If the profile name is empty, assume that this profile is no good,
                        // since a profile MUST have a name to be created.
                        if (profileBuilder.ProfileName.Length <= 0)
                        {
                            continue;
                        }

                        // If we reached here, this is a valid profile we can load.

                        // Build up a PlayerInput
                        PlayerInput playerInput = new PlayerInput(null);
                        playerInput.ProfileName = profileBuilder.ProfileName;

                        // The top level PlayerInputBuilders must have a Keyboard and Joystick configuration.
                        bool profileHasKeyboardConfiguration = false;
                        bool profileHasJoystickConfiguration = false;

                        for (int x = 0; x < profileBuilder.ProfileConfigurations.Count; x++)
                        {
                            PlayerInputBuilder inputBuilder = profileBuilder.ProfileConfigurations[x];
                            if (inputBuilder == null)
                            {
                                continue;
                            }

                            // Only load one keyboard configuration, or the first one that is read.
                            if (inputBuilder.ConfigurationName == InputDeviceType.Keyboard.ToString() &&
                                profileHasKeyboardConfiguration == false)
                            {
                                PlayerInputConfiguration configuration = new PlayerInputConfiguration();
                                configuration.Name = inputBuilder.ConfigurationName;
                                playerInput.CurrentConfiguration = configuration;

                                WorkingState state = HandleLoadPlayerInput(InputDeviceType.Keyboard, inputBuilder, ref playerInput);

                                // Validate the keyboard configuration

                                if (state == WorkingState.Success)
                                {
                                    profileHasKeyboardConfiguration = true;
                                }

                                // Stop processing this control configuration if it has an invalid mapping
                                if (state == WorkingState.Failed)
                                {
                                    break;
                                }

                                continue;
                            }

                            // Only load one joystick configuration, or the first one that is read.
                            if (inputBuilder.ConfigurationName == InputDeviceType.Joystick.ToString() &&
                                profileHasJoystickConfiguration == false)
                            {
                                PlayerInputConfiguration configuration = new PlayerInputConfiguration();
                                configuration.Name = inputBuilder.ConfigurationName;
                                playerInput.CurrentConfiguration = configuration;

                                WorkingState state = HandleLoadPlayerInput(InputDeviceType.Joystick, inputBuilder, ref playerInput);

                                // Validate the keyboard configuration

                                if (state == WorkingState.Success)
                                {
                                    profileHasJoystickConfiguration = true;
                                }

                                // Stop processing this control configuration if it has an invalid mapping
                                if (state == WorkingState.Failed)
                                {
                                    break;
                                }

                                continue;
                            }
                        }

                        // Check keyboard and joystick configurations - create new ones if they were not generated.
                        AddDeviceConfigurationIfMissing(profileHasKeyboardConfiguration, InputDeviceType.Keyboard, ref playerInput);
                        AddDeviceConfigurationIfMissing(profileHasJoystickConfiguration, InputDeviceType.Joystick, ref playerInput);

                        // Add this profile to the PlayerProfiles list.
                        PlayerProfiles.Add(playerInput.ProfileName, playerInput);
                    }
                }
                
                m_CurrentJobState = WorkingState.Success;
                yield break;
            }
            else
            {
                m_CurrentJobState = WorkingState.Failed;
                yield break;
            }
        }
    }

    void AddDeviceConfigurationIfMissing(bool aHasConfiguration, InputDeviceType aDeviceType, ref PlayerInput aPlayerInput)
    {
        if (aHasConfiguration == false)
        {
            PlayerInputConfiguration deviceConfiguration = new PlayerInputConfiguration();
            deviceConfiguration.Name = aDeviceType.ToString();
            aPlayerInput.CurrentConfiguration = deviceConfiguration;

            switch (aDeviceType)
            {
                case InputDeviceType.Keyboard:
                    DefaultControls.SetDefaultKeyboardControls(aPlayerInput);
                    break;
                case InputDeviceType.Joystick:
                    DefaultControls.SetDefaultJoystickControls(aPlayerInput);
                    break;
            }

            aPlayerInput.InputConfigurations.Add(deviceConfiguration.Name, deviceConfiguration);
        }
    }

    WorkingState HandleLoadPlayerInput(InputDeviceType deviceType, PlayerInputBuilder inputBuilder, ref PlayerInput playerInput)
    {
        WorkingState state = WorkingState.NotStarted;

        // Loop over all of the input mapping configurations.
        for (int i = 0; i < inputBuilder.InputMappings.Count; i++)
        {
            InputMappingBuilder inputMappingBuilder = inputBuilder.InputMappings[i];
            inputMappingBuilder.InputMappingType = ValidateInputMappingType(inputMappingBuilder.InputMappingType, inputBuilder.ConfigurationName);

            if (inputMappingBuilder.InputMappingType == InputMapping.KeyboardButtonMapping)
            {
                state = LoadKeyboardButtonInput(ref playerInput, inputMappingBuilder);
            }
            else if (inputMappingBuilder.InputMappingType == InputMapping.MouseAxisMapping)
            {
                state = LoadMouseAxisInput(ref playerInput, inputMappingBuilder);
            }
            else if (inputMappingBuilder.InputMappingType == InputMapping.JoystickButtonMapping)
            {
                state = LoadJoystickButtonInput(ref playerInput, inputMappingBuilder);
            }
            else if (inputMappingBuilder.InputMappingType == InputMapping.JoystickAxisMapping)
            {
                state = LoadJoystickAxisInput(ref playerInput, inputMappingBuilder);
            }
            else
            {
#if UNITY_EDITOR
                DebugManager.LogError("Invalid Input Mapping Type: " + inputMappingBuilder.InputMappingType, Developmer.Evan);
#endif
                state = WorkingState.Failed;
            }

            if (state == WorkingState.Failed)
            {
                // Exit early if there was a problem with this configuration
                playerInput.CurrentConfiguration = null;
                return WorkingState.Failed;
            }
        }

        // Need to add in all of the menu button options.
        if (deviceType == InputDeviceType.Keyboard)
        {
            DefaultControls.AddMenuButtonsForLoadedKeyboardProfile(playerInput);
        }
        else if (deviceType == InputDeviceType.Joystick)
        {
            DefaultControls.AddMenuButtonsForLoadedJoystickProfile(playerInput);
        }
#if UNITY_EDITOR
        else
        {
            DebugManager.LogError("Device type for user profile configuration is not defined!", Developmer.Evan);
        }
#endif

        // if the input mapping configuration was successful, map it to the playerInput's list of configurations.
        if (state == WorkingState.Success)
        {
            PlayerInputConfiguration configuration = playerInput.CurrentConfiguration;

            playerInput.InputConfigurations[configuration.Name] = configuration;
        }

        playerInput.CurrentConfiguration = null;

        return state;
    }

    WorkingState LoadKeyboardButtonInput(ref PlayerInput playerInput, InputMappingBuilder input)
    {
        WorkingState success = WorkingState.LoadingInProgress;

        // Handles enum parse errors
        try
        {
            InputName inputName = (InputName)Enum.Parse(typeof(InputName), input.InputNameTitle);

            // Make sure this InputName is allowed to be remapped
            if (inputName >= InputName._Unconfigurable_Start)
            {
                success = WorkingState.Failed;
                throw new Exception(String.Format(FormatErrorMessageInvalidInputName, input.InputNameTitle));
            }

            KeyCode keyCodePositive = (KeyCode)Enum.Parse(typeof(KeyCode), input.InputNameValuePositive);
            KeyCode keyCodeNegative = KeyCode.None;
            if (input.InputNameValueNegative != null && input.InputNameValueNegative != string.Empty)
            {
                keyCodeNegative = (KeyCode)Enum.Parse(typeof(KeyCode), input.InputNameValueNegative);
            }

            // Validate keyCode. Positive keyCode input MUST have a valid keyCode.
            if (keyCodePositive == KeyCode.None)
            {
                success = WorkingState.Failed;
                throw new Exception(String.Format(FormatErrorMessageInvalidButtonIndex, input.InputNameValuePositive));
            }

            // Make sure keyCode is valid (Does not overwrite an inportant key, e.g. escape, start, etc.)
            for (int i = 0; i < JoystickMap.ReservedKeyCodes.Length; i++)
            {
                KeyCode reservedKeyCode = JoystickMap.ReservedKeyCodes[i];

                if (keyCodePositive == reservedKeyCode)
                {
                    success = WorkingState.Failed;
                    throw new Exception(string.Format(FormatErrorMessageReservedKey, keyCodePositive.ToString()));
                }

                if (keyCodeNegative == reservedKeyCode)
                {
                    success = WorkingState.Failed;
                    throw new Exception(string.Format(FormatErrorMessageReservedKey, keyCodeNegative.ToString()));
                }
            }

            // Validate Sensitivity - Key doesn't need sensitivity so reset it here.
            bool canChangeSensitivity = false;
            float sensitivityModifier = 1.0f;
            float deadZone = 0.0f;
            
            // Validate InputDelay
            float inputDelay = input.InputDelay;

            // For now, only menu buttons are supposed to have any kind of input delay so setting it to 0.
            // In the future if this needs to change, undo this line.
            inputDelay = 0.0f;

            // Validate invert axis
            bool invertAxis = false;
            if (JoystickMap.AllowChangeSensitivityControls.ContainsKey(inputName))
            {
                invertAxis = input.InvertAxis;
            }

            InputMapping mapping = playerInput.SetKeyboardButton(
                inputName,
                keyCodePositive,
                1.0f,
                canChangeSensitivity,
                sensitivityModifier,
                inputDelay
                );
            mapping.InvertAxis = invertAxis;
            mapping.AxisDeadZone = deadZone;
            mapping.InputDelay = inputDelay;

            if (keyCodeNegative != KeyCode.None)
            {
                playerInput.SetKeyboardButton(
                    inputName,
                    keyCodeNegative,
                    -1.0f,
                    canChangeSensitivity,
                    sensitivityModifier,
                    inputDelay
                    );
            }

            success = WorkingState.Success;
        }
        catch(Exception ex)
        {
            success = WorkingState.Failed;
#if UNITY_EDITOR
            Debug.LogError(String.Format(FormatLoadKeyboardButtonInputError, ex.Message));
#endif
        }

        return success;
    }

    WorkingState LoadMouseAxisInput(ref PlayerInput playerInput, InputMappingBuilder input)
    {
        WorkingState success = WorkingState.LoadingInProgress;

        // Handles enum parse errors
        try
        {
            InputName inputName = (InputName)Enum.Parse(typeof(InputName), input.InputNameTitle);

            // Make sure this InputName is allowed to be remapped
            if (inputName >= InputName._Unconfigurable_Start)
            {
                success = WorkingState.Failed;
                throw new Exception(String.Format(FormatErrorMessageInvalidInputName, input.InputNameTitle));
            }

            int index = Array.IndexOf(JoystickMap.UnityDefinedJoystickSettings.AXIS_LIST, input.InputNameValuePositive);
            string axisMapping = string.Empty;

            if (index >= 0 && index < JoystickMap.UnityDefinedJoystickSettings.AXIS_LIST.Length)
            {
                axisMapping = JoystickMap.UnityDefinedJoystickSettings.AXIS_LIST[index];
            }
            else
            {
                throw new Exception(String.Format(FormatErrorMessageInvalidAxisIndex, index));
            }

            // Validate Sensitivity
            bool canChangeSensitivity = false;
            float sensitivityModifier = 1.0f;
            float deadZone = input.AxisDeadzone;

            if (JoystickMap.AllowChangeSensitivityControls.ContainsKey(inputName))
            {
                canChangeSensitivity = true;
                sensitivityModifier = input.SensitivityModifier;
            }

            // Validate SensitivityModifier and Deadzone
            if (sensitivityModifier < DefaultControls.MIN_AXIS_SENSITIVITY)
            {
                sensitivityModifier = DefaultControls.MIN_AXIS_SENSITIVITY;
            }
            if (sensitivityModifier > DefaultControls.MAX_AXIS_SENSITIVITY)
            {
                sensitivityModifier = DefaultControls.MAX_AXIS_SENSITIVITY;
            }
            if (deadZone < DefaultControls.MIN_AXIS_DEADZONE)
            {
                deadZone = DefaultControls.MIN_AXIS_DEADZONE;
            }
            if (deadZone > DefaultControls.MAX_AXIS_DEADZONE)
            {
                deadZone = DefaultControls.MAX_AXIS_DEADZONE;
            }

            // Validate InputDelay
            float inputDelay = input.InputDelay;

            // For now, only menu buttons are supposed to have any kind of input delay so setting it to 0.
            // In the future if this needs to change, undo this line.
            inputDelay = 0.0f;

            // Validate invert axis
            bool invertAxis = false;
            if (JoystickMap.AllowChangeSensitivityControls.ContainsKey(inputName))
            {
                invertAxis = input.InvertAxis;
            }

            InputMapping mapping = playerInput.SetMouseAxis(
                inputName,
                axisMapping,
                deadZone,
                canChangeSensitivity,
                sensitivityModifier
                );
            mapping.InvertAxis = invertAxis;
            mapping.AxisDeadZone = deadZone;
            mapping.InputDelay = inputDelay;

            success = WorkingState.Success;
        }
        catch (Exception ex)
        {
            success = WorkingState.Failed;
#if UNITY_EDITOR
            Debug.LogError(String.Format(FormatLoadMouseAxisInputError, ex.Message));
#endif
        }

        return success;
    }

    WorkingState LoadJoystickButtonInput(ref PlayerInput playerInput, InputMappingBuilder input)
    {
        WorkingState success = WorkingState.LoadingInProgress;

        try
        {
            InputName inputName = (InputName)Enum.Parse(typeof(InputName), input.InputNameTitle);

            // Make sure this InputName is allowed to be remapped
            if (inputName >= InputName._Unconfigurable_Start)
            {
                success = WorkingState.Failed;
                throw new Exception(String.Format(FormatErrorMessageInvalidInputName, input.InputNameTitle));
            }

            // InputValueName should be an int value for a JoystickButton input.
            int buttonIndexPositive = Int32.Parse(input.InputNameValuePositive);
            int buttonIndexNegative = -1;
            if (input.InputNameValueNegative != null && input.InputNameValueNegative != string.Empty)
            {
                buttonIndexNegative = Int32.Parse(input.InputNameValueNegative);
            }

            // Validate button index. Positive button index MUST be 0 or greater.
            if (buttonIndexPositive < 0 || buttonIndexPositive >= JoystickMap.s_ButtonStrings.Length)
            {
                success = WorkingState.Failed;
                throw new Exception(String.Format(FormatErrorMessageInvalidButtonIndex, input.InputNameValuePositive));
            }
            if (buttonIndexNegative >= JoystickMap.s_ButtonStrings.Length)
            {
                success = WorkingState.Failed;
                throw new Exception(String.Format(FormatErrorMessageInvalidButtonIndex, input.InputNameValueNegative));
            }

            // Make sure buttonIndex is valid (Does not overwrite an inportant button, e.g. start, back, etc.)
            for (int i = 0; i < JoystickMap.ReservedButtons.Length; i++)
            {
                int reservedButton = JoystickMap.ReservedButtons[i];

                if (buttonIndexPositive == reservedButton)
                {
                    success = WorkingState.Failed;
                    throw new Exception(string.Format(FormatErrorMessageReservedKey, buttonIndexPositive.ToString()));
                }

                if (buttonIndexNegative == reservedButton)
                {
                    success = WorkingState.Failed;
                    throw new Exception(string.Format(FormatErrorMessageReservedKey, buttonIndexNegative.ToString()));
                }
            }

            // Validate Sensitivity - Button doesn't need sensitivity so reset it here.
            bool canChangeSensitivity = false;
            float sensitivityModifier = 1.0f;
            float deadZone = 0.0f;
            
            // Validate InputDelay
            float inputDelay = input.InputDelay;

            // For now, only menu buttons are supposed to have any kind of input delay so setting it to 0.
            // In the future if this needs to change, undo this line.
            inputDelay = 0.0f;

            // Validate invert axis
            bool invertAxis = false;
            if (JoystickMap.AllowChangeSensitivityControls.ContainsKey(inputName))
            {
                invertAxis = input.InvertAxis;
            }

            InputMapping mapping = playerInput.SetJoystickButton(
                inputName,
                buttonIndexPositive,
                1.0f,
                canChangeSensitivity,
                sensitivityModifier,
                inputDelay
                );
            mapping.InvertAxis = invertAxis;
            mapping.AxisDeadZone = deadZone;
            mapping.InputDelay = inputDelay;

            if (buttonIndexNegative > -1)
            {
                playerInput.SetJoystickButton(
                    inputName,
                    buttonIndexNegative,
                    -1.0f,
                    canChangeSensitivity,
                    sensitivityModifier,
                    inputDelay
                    );
            }

            success = WorkingState.Success;
        }
        catch (Exception ex)
        {
            success = WorkingState.Failed;
#if UNITY_EDITOR
            Debug.LogError(String.Format(FormatLoadJoystickButtonInputError, ex.Message));
#endif
        }

        return success;
    }

    WorkingState LoadJoystickAxisInput(ref PlayerInput playerInput, InputMappingBuilder input)
    {
        WorkingState success = WorkingState.LoadingInProgress;

        try
        {
            InputName inputName = (InputName)Enum.Parse(typeof(InputName), input.InputNameTitle);

            // Make sure this InputName is allowed to be remapped
            if (inputName >= InputName._Unconfigurable_Start)
            {
                success = WorkingState.Failed;
                throw new Exception(String.Format(FormatErrorMessageInvalidInputName, input.InputNameTitle));
            }

            int axisIndex = Array.IndexOf(JoystickMap.s_AxisStrings, input.InputNameValuePositive);

            // Validate axisIndex
            if (axisIndex < 0 || axisIndex >= JoystickMap.JOYSTICK_AXES.Length)
            {
                success = WorkingState.Failed;
                throw new Exception(String.Format(FormatErrorMessageInvalidAxisIndex, axisIndex));
            }

            // Validate Sensitivity
            bool canChangeSensitivity = false;
            float sensitivityModifier = 1.0f;
            float deadZone = 0.0f;

            if (JoystickMap.AllowChangeSensitivityControls.ContainsKey(inputName))
            {
                canChangeSensitivity = true;
                sensitivityModifier = input.SensitivityModifier;
            }

            // Validate SensitivityModifier and Deadzone
            if (sensitivityModifier < DefaultControls.MIN_AXIS_SENSITIVITY)
            {
                sensitivityModifier = DefaultControls.MIN_AXIS_SENSITIVITY;
            }
            if (sensitivityModifier > DefaultControls.MAX_AXIS_SENSITIVITY)
            {
                sensitivityModifier = DefaultControls.MAX_AXIS_SENSITIVITY;
            }
            if (deadZone < DefaultControls.MIN_AXIS_DEADZONE)
            {
                deadZone = DefaultControls.MIN_AXIS_DEADZONE;
            }
            if (deadZone > DefaultControls.MAX_AXIS_DEADZONE)
            {
                deadZone = DefaultControls.MAX_AXIS_DEADZONE;
            }

            // Validate InputDelay
            float inputDelay = input.InputDelay;

            // For now, only menu buttons are supposed to have any kind of input delay so setting it to 0.
            // In the future if this needs to change, undo this line.
            inputDelay = 0.0f;

            // Validate invert axis
            bool invertAxis = false;
            if (JoystickMap.AllowChangeSensitivityControls.ContainsKey(inputName))
            {
                invertAxis = input.InvertAxis;
            }
            
            InputMapping mapping = playerInput.SetJoystickAxis(
                inputName,
                axisIndex,
                deadZone,
                canChangeSensitivity,
                sensitivityModifier
                );
            mapping.InvertAxis = invertAxis;
            mapping.AxisDeadZone = deadZone;
            mapping.InputDelay = inputDelay;
            
            success = WorkingState.Success;
        }
        catch (Exception ex)
        {
            success = WorkingState.Failed;
#if UNITY_EDITOR
            Debug.LogError(String.Format(FormatLoadJoystickAxisInputError, ex.Message));
#endif
        }

        return success;
    }

    public WorkingState SaveProfiles()
    {
        if (IsJobFinished())
        {
            m_CurrentJobState = WorkingState.SavingInProgress;

            StartCoroutine(HandleSaveProfiles());
        }

        return m_CurrentJobState;
    }

    IEnumerator HandleSaveProfiles()
    {
        // We still want to generate the file if the list has no profiles.
        if (m_PlayerProfiles == null)
        {
            m_PlayerProfiles = new Dictionary<string, PlayerInput>();
        }

        // Build the JSON structure

        PlayerProfilesBuilder builder = new PlayerProfilesBuilder();
        builder.Version = PlayerProfileVersion;
        builder.PlayerProfiles = new List<PlayerProfileBuilder>();
        
        foreach (var playerInputProfile in m_PlayerProfiles.Values)
        {
            PlayerProfileBuilder profile = new PlayerProfileBuilder();
            profile.ProfileName = playerInputProfile.ProfileName;
            profile.ProfileConfigurations = new List<PlayerInputBuilder>();

            // Configuration profiles (Joystick, Keyboard)

            foreach (var configuration in playerInputProfile.InputConfigurations.Values)
            {
                PlayerInputBuilder inputBuilder = new PlayerInputBuilder();
                inputBuilder.ConfigurationName = configuration.Name;
                inputBuilder.InputMappings = new List<InputMappingBuilder>();

                foreach (var inputMapping in configuration.InputMap)
                {
                    // Filter out menu buttons
                    if (inputMapping.Key < (int)InputName._Unconfigurable_Start)
                    {
                        InputMappingBuilder inputMappingBuilder = new InputMappingBuilder();
                        inputMappingBuilder.AxisDeadzone = inputMapping.Value.AxisDeadZone;
                        inputMappingBuilder.CanChangeSensitivity = inputMapping.Value.CanChangeSensitivity;
                        inputMappingBuilder.InputDelay = inputMapping.Value.InputDelay;
                        inputMappingBuilder.InputMappingType = ValidateInputMappingType(inputMapping.Value.GetInputMappingType(), configuration.Name);
                        inputMappingBuilder.InputNameTitle = inputMapping.Key.ToString();
                        inputMappingBuilder.InputNameValuePositive = inputMapping.Value.GetInputNameValueString(1.0f);
                        inputMappingBuilder.InputNameValueNegative = inputMapping.Value.GetInputNameValueString(-1.0f);
                        inputMappingBuilder.SensitivityModifier = inputMapping.Value.SensitivityModifier;
                        inputMappingBuilder.InvertAxis = inputMapping.Value.InvertAxis;

                        inputBuilder.InputMappings.Add(inputMappingBuilder);
                    }
                }

                profile.ProfileConfigurations.Add(inputBuilder);
            }

            builder.PlayerProfiles.Add(profile);
        }

        // Get the JSON string
        string output = JsonConvert.SerializeObject(builder, Formatting.Indented);

#if UNITY_EDITOR

        Debug.Log("JSON output:\n" + output);

        Debug.Log("Saving user profiles to file: " + ProfilesFilePath);

#endif

        // Create the directory if it doesn't already exist.
        FileInfo file = new System.IO.FileInfo(ProfilesFilePath);
        file.Directory.Create();

        // Write to the file.
        // TODO: catch exceptions
        File.WriteAllText(ProfilesFilePath, output);

        // TODO: Proper error handling, returning error state, etc.
        m_CurrentJobState = WorkingState.Success;

        yield return null;
    }

    // Makes sure that the correct InputMappingType gets saved for this input.
    string ValidateInputMappingType(string aInputMappingType, string aConfigurationName)
    {
        string validatedMappingType = string.Empty;

        if (aConfigurationName == InputDeviceType.Keyboard.ToString())
        {
            if (aInputMappingType == InputMapping.MouseAxisMapping ||
                aInputMappingType == InputMapping.JoystickAxisMapping)
            {
                validatedMappingType = InputMapping.MouseAxisMapping;
            }
            else if (aInputMappingType == InputMapping.KeyboardButtonMapping ||
                aInputMappingType == InputMapping.JoystickButtonMapping)
            {
                validatedMappingType = InputMapping.KeyboardButtonMapping;
            }
        }
        else if (aConfigurationName == InputDeviceType.Joystick.ToString())
        {
            if (aInputMappingType == InputMapping.MouseAxisMapping ||
                aInputMappingType == InputMapping.JoystickAxisMapping)
            {
                validatedMappingType = InputMapping.JoystickAxisMapping;
            }
            else if (aInputMappingType == InputMapping.KeyboardButtonMapping ||
                aInputMappingType == InputMapping.JoystickButtonMapping)
            {
                validatedMappingType = InputMapping.JoystickButtonMapping;
            }
        }

        return validatedMappingType;
    }

    public bool IsJobFinished()
    {
        if (m_CurrentJobState == WorkingState.Failed || m_CurrentJobState == WorkingState.Success || m_CurrentJobState == WorkingState.NotStarted)
        {
            return true;
        }
        return false;
    }

    public void ClearProfilesList()
    {
        PlayerProfiles.Clear();

        SaveProfiles();
    }
}

public class PlayerConfiguration
{
    public string ProfileName;

    public CharacterConfiguration[] CharacterConfigurations;

	// Use this for initialization
	public PlayerConfiguration()
    {
        CharacterConfigurations = new CharacterConfiguration[(int)CharacterTypes.MAX_CHARACTER_TYPES];
	}
}

public struct CharacterConfiguration
{
    public InputMapping KeyboardConfiguration;
    public InputMapping ControllerConfiguration;
}