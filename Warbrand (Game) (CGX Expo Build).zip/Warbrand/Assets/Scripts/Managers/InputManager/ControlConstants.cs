﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ControlConstants                                                               *
 * FileExtension:   .cs                                                                            *
 * Author:          Evan Campbell                                                                  *
 * Date:            October 9th, 2016                                                              *
 *                                                                                                 *
 * This file contains helper constant values and methods required by the InputManager and          *
 * GameInput classes.                                                                              *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Evan Campbell) - October 9th, 2016                                        *
 *                                                                                                 *
\***************************************************************************************************/

using System;
using System.Collections.Generic;
using UnityEngine;
//using XInputDotNetPure;

public class JoystickMap
{
    // Xbox 360 / Xbox One (XInput) button mappings
    public const int BUTTON_A = 0;
    public const int BUTTON_B = 1;
    public const int BUTTON_X = 2;
    public const int BUTTON_Y = 3;
    public const int BUTTON_LB = 4;
    public const int BUTTON_RB = 5;
    public const int BUTTON_BACK = 6;
    public const int BUTTON_START = 7;
    public const int BUTTON_LS = 8;
    public const int BUTTON_RS = 9;
    public const int DPAD_LEFT = 10;
    public const int DPAD_RIGHT = 11;
    public const int DPAD_UP = 12;
    public const int DPAD_DOWN = 13;

    public static readonly int[] JOYSTICK_BUTTONS =
    {
        BUTTON_A,
        BUTTON_B,
        BUTTON_X,
        BUTTON_Y,
        BUTTON_LB,
        BUTTON_RB,
        BUTTON_BACK,
        BUTTON_START,
        BUTTON_LS,
        BUTTON_RS,
        DPAD_LEFT,
        DPAD_RIGHT,
        DPAD_UP,
        DPAD_DOWN
    };

    

    public const float JOYSTICK_AXIS_DEADZONE = 0.3f; // Change this if joystick movement feels too stiff.



    // These MUST match the list in GetButtonStates.
    // TODO? Add D-Pad buttons.
    
    public static readonly string[] s_ButtonStrings =
    {
        "A",
        "B",
        "X",
        "Y",
        "Left Shoulder",
        "Right Shoulder",
        "Back",
        "Start",
        "Left Stick",
        "Right Stick",
        "DPad Left",
        "DPad Right",
        "DPad Up",
        "DPad Down"
    };

    // Keycodes that are reserved for important functions
    // Remappable keys should not be matched to any of these!
    public static KeyCode[] ReservedKeyCodes =
    {
        KeyCode.Return,
        KeyCode.Escape,
        KeyCode.Tab,
        KeyCode.LeftWindows,
        KeyCode.RightWindows
    };

    // Button indexed that are reserved for important functions
    // Remappable buttons should not be matched to any of these!
    public static int[] ReservedButtons =
    {
        BUTTON_BACK,
        BUTTON_START
    };

    //// There is no easy way to loop over all of the button states on a controller,
    //// so this helper method conveniently puts the current state of all the buttons
    //// into a list.
    //// The button states are updated all the time, so they can't be assigned once at the
    //// beginning of the game.
    //public static ButtonState[] GetButtonStates(GamePadState aGamePadState)
    //{
    //    // The button indices below MUST match s_ButtonStrings.

    //    if (s_ButtonStates == null)
    //    {
    //        s_ButtonStates = new ButtonState[s_ButtonStrings.Length];
    //    }

    //    s_ButtonStates[0] = aGamePadState.Buttons.A;
    //    s_ButtonStates[1] = aGamePadState.Buttons.B;
    //    s_ButtonStates[2] = aGamePadState.Buttons.X;
    //    s_ButtonStates[3] = aGamePadState.Buttons.Y;
    //    s_ButtonStates[4] = aGamePadState.Buttons.LeftShoulder;
    //    s_ButtonStates[5] = aGamePadState.Buttons.RightShoulder;
    //    s_ButtonStates[6] = aGamePadState.Buttons.Back;
    //    s_ButtonStates[7] = aGamePadState.Buttons.Start;
    //    s_ButtonStates[8] = aGamePadState.Buttons.LeftStick;
    //    s_ButtonStates[9] = aGamePadState.Buttons.RightStick;
    //    s_ButtonStates[10] = aGamePadState.DPad.Left;
    //    s_ButtonStates[11] = aGamePadState.DPad.Right;
    //    s_ButtonStates[12] = aGamePadState.DPad.Up;
    //    s_ButtonStates[13] = aGamePadState.DPad.Down;

    //    return s_ButtonStates;
    //}

    //private static ButtonState[] s_ButtonStates = null;


    //// Need a separate function and array variable to keep track of the current and previous button states
    //// or else calling GetPrevButtonStates right after GetButtonStates will completely overwrite the old values.
    //public static ButtonState[] GetPrevButtonStates(GamePadState aGamePadState)
    //{
    //    // The button indices below MUST match s_ButtonStrings.

    //    if (s_PrevButtonStates == null)
    //    {
    //        s_PrevButtonStates = new ButtonState[s_ButtonStrings.Length];
    //    }

    //    s_PrevButtonStates[0] = aGamePadState.Buttons.A;
    //    s_PrevButtonStates[1] = aGamePadState.Buttons.B;
    //    s_PrevButtonStates[2] = aGamePadState.Buttons.X;
    //    s_PrevButtonStates[3] = aGamePadState.Buttons.Y;
    //    s_PrevButtonStates[4] = aGamePadState.Buttons.LeftShoulder;
    //    s_PrevButtonStates[5] = aGamePadState.Buttons.RightShoulder;
    //    s_PrevButtonStates[6] = aGamePadState.Buttons.Back;
    //    s_PrevButtonStates[7] = aGamePadState.Buttons.Start;
    //    s_PrevButtonStates[8] = aGamePadState.Buttons.LeftStick;
    //    s_PrevButtonStates[9] = aGamePadState.Buttons.RightStick;
    //    s_PrevButtonStates[10] = aGamePadState.DPad.Left;
    //    s_PrevButtonStates[11] = aGamePadState.DPad.Right;
    //    s_PrevButtonStates[12] = aGamePadState.DPad.Up;
    //    s_PrevButtonStates[13] = aGamePadState.DPad.Down;

    //    return s_PrevButtonStates;
    //}

    //private static ButtonState[] s_PrevButtonStates = null;

    // These MUST match s_AxisStrings.
    public const int JOYSTICK_THUMBSTICK_LEFT_X = 0;
    public const int JOYSTICK_THUMBSTICK_LEFT_Y = 1;
    public const int JOYSTICK_TRIGGERS = 2;
    public const int JOYSTICK_THUMBSTICK_RIGHT_X = 3;
    public const int JOYSTICK_THUMBSTICK_RIGHT_Y = 4;
    public const int JOYSTICK_DPAD_HORIZONTAL = 5;
    public const int JOYSTICK_DPAD_VERTICAL = 6;
    public const int JOYSTICK_TRIGGER_LEFT = 7;
    public const int JOYSTICK_TRIGGER_RIGHT = 8;

    public static readonly int[] JOYSTICK_AXES =
    {
        JOYSTICK_THUMBSTICK_LEFT_X,
        JOYSTICK_THUMBSTICK_LEFT_Y,
        0,                          // Unity's joined triggers, DirectInput triggers
        JOYSTICK_THUMBSTICK_RIGHT_X,
        JOYSTICK_THUMBSTICK_RIGHT_Y,
        0,                          // Unity's D-Pad horizontal
        0,                          // Unity's D-Pad vertical
        JOYSTICK_TRIGGER_LEFT,
        JOYSTICK_TRIGGER_RIGHT
    };

    public static readonly string[] s_AxisStrings =
    {
        "Left Stick Horizontal",
        "Left Stick Vertical",
        "Triggers",                 // Unity's joined triggers, DirectInput triggers
        "Right Stick Horizontal",
        "Right Stick Vertical",
        "DPad Horizontal",          // Unity's D-Pad horizontal
        "DPad Vertical",            // Unity's D-Pad vertical
        "Left Trigger",
        "Right Trigger"
    };

    //public static float[] GetAxisStates(GamePadState aGamePadState)
    //{
    //    // These MUST match s_AxisStrings.

    //    float[] axisStates =
    //    {
    //        aGamePadState.ThumbSticks.Left.X,
    //        aGamePadState.ThumbSticks.Left.Y,
    //        aGamePadState.ThumbSticks.Right.X,
    //        aGamePadState.ThumbSticks.Right.Y,
    //        aGamePadState.Triggers.Left,
    //        aGamePadState.Triggers.Right
    //    };

    //    return axisStates;
    //}

    public static string GetButtonString(int aButtonIndex)
    {
        if (aButtonIndex >= 0 && aButtonIndex < s_ButtonStrings.Length)
        {
            return s_ButtonStrings[aButtonIndex];
        }

        return "UNASSIGNED";
    }

    // A dictionary containing human-readable values for what the inputs for their device are.
    // For example, a lookup of "Axis1" will return "Mouse Movement - Horizontal".
    public static readonly Dictionary<string, string> KeyboardInputStrings =
        new Dictionary<string, string>()
        {
            { "Axis1", "Mouse Movement - Horizontal" },
            { "Axis2", "Mouse Movement - Vertical" },
            { "Axis3", "Mouse - Scroll Wheel" },
            { "Mouse0", "Mouse - Left Click" },
            { "Mouse1", "Mouse - Right Click" },
            { "Mouse2", "Mouse - Middle Click" }
        };

    // List of controls that are allowed to modify the sensitivity modifier.
    public static readonly Dictionary<InputName, bool> AllowChangeSensitivityControls =
        new Dictionary<InputName, bool>()
        {
            { InputName.LookHorizontal, true },
            { InputName.LookVertical, true }
        };

    public static readonly Dictionary<InputName, bool> AllowInvertAxisControls =
        new Dictionary<InputName, bool>()
        {
            { InputName.Horizontal, true },
            { InputName.Vertical, true },
            { InputName.LookHorizontal, true },
            { InputName.LookVertical, true }
        };

    public static bool IsInputAMenuButton(InputName aInputName)
    {
        bool isMenuButton = false;

        for (InputName input = InputName._Menu_Buttons_Start; input < InputName._Menu_Buttons_End; input++)
        {
            if (aInputName == input)
            {
                isMenuButton = true;
                break;
            }
        }

        return isMenuButton;
    }

    // Information using Unity's Input class for Joysticks.
    // Avoid using this with joysticks if possible. This is mainly useful for getting mouse axis information.
    // The reason to avoid using with joysticks is that Unity will arbitrarily assign trigger inputs on any controller.
    public struct UnityDefinedJoystickSettings
    {
        public const int JOYSTICK_KEY_CODE_MIN = 350;    // joystick 1 button 0
        public const int JOYSTICK_KEY_CODE_MAX = 430;    // joystick 4 button 19
        public const int JOYSTICK_NUM_BUTTONS = 20;      // Number of buttons on each joystick

        // Axis names as they are mapped on a physical device (joystick, mouse)
        // Make sure the axes are mapped in Unity's InputManager for each joystick if they are to be used!
        public const string AXIS_1 = "Axis1";             // Left Stick Horizontal, Mouse Move X
        public const string AXIS_2 = "Axis2";             // Left Stick Vertical, Mouse Move Y
        public const string AXIS_3 = "Axis3";             // Left and Right Triggers, Mouse Scroll Wheel
        public const string AXIS_4 = "Axis4";             // Right Stick Horizontal
        public const string AXIS_5 = "Axis5";             // Right Stick Vertical
        public const string AXIS_6 = "Axis6";             // D-Pad Horizontal
        public const string AXIS_7 = "Axis7";             // D-Pad Vertical
        public const string AXIS_9 = "Axis9";             // Left Trigger
        public const string AXIS_10 = "Axis10";           // Right Trigger

        public static readonly string[] AXIS_LIST =
        {
            // Uncomment these after they are added to the Unity InputManager.
            AXIS_1,
            AXIS_2,
            AXIS_3,
            AXIS_4,
            AXIS_5,
            AXIS_6,
            AXIS_7,
            AXIS_9,
            AXIS_10
        };

        public static readonly string[] KEYBOARD_AXIS_LIST =
        {
            AXIS_1, // Mouse move horizontal
            AXIS_2, // Mouse move vertical
            AXIS_3  // Mouse scroll wheel
        };
    }
}

// Helper class to set all of the default controls for the specified device.
public class DefaultControls
{
    public const float MIN_AXIS_SENSITIVITY = 1.0f;
    public const float MAX_AXIS_SENSITIVITY = 1000.0f;
    // This must be a value > 0 or else axis pressed will not register
    public const float MIN_AXIS_DEADZONE = 0.0001f;
    public const float MAX_AXIS_DEADZONE = 0.9f;

    public const float MENU_BUTTON_INPUT_DELAY = 0.1f;
    public const float DEFAULT_MOUSE_LOOK_SENSITIVITY = 160.0f;
    public const float DEFAULT_JOYSTICK_LOOK_SENSITIVITY = 140.0f;
    public const float DEFAULT_JOYSTICK_MOVE_DEADZONE = 0.1f;
    public const float DEFAULT_JOYSTICK_LOOK_DEADZONE = 0.05f;
    public const float DEFAULT_JOYSTICK_TRIGGER_DEADZONE = 0.2f;

    public static void SetDefaultKeyboardControls(PlayerInput input)
    {
        input.SetKeyboardButton(InputName.Horizontal, KeyCode.A, -1.0f);
        input.SetKeyboardButton(InputName.Horizontal, KeyCode.D, 1.0f);

        input.SetKeyboardButton(InputName.Vertical, KeyCode.W, 1.0f);
        input.SetKeyboardButton(InputName.Vertical, KeyCode.S, -1.0f);

        input.SetMouseAxis(InputName.LookHorizontal, JoystickMap.UnityDefinedJoystickSettings.AXIS_1, 0.0f, true, DEFAULT_MOUSE_LOOK_SENSITIVITY);
        input.SetMouseAxis(InputName.LookVertical, JoystickMap.UnityDefinedJoystickSettings.AXIS_2, 0.0f, true, DEFAULT_MOUSE_LOOK_SENSITIVITY);

        input.SetKeyboardButton(InputName.Jump, KeyCode.Space);
        //input.SetKeyboardButton(InputName.Sprint, KeyCode.LeftShift);
        //input.SetKeyboardButton(InputName.Crouch, KeyCode.LeftControl);
        //input.SetKeyboardButton(InputName.CameraSwitch, KeyCode.T);

        input.SetKeyboardButton(InputName.Attack1, KeyCode.Mouse0);
        input.SetKeyboardButton(InputName.Attack2, KeyCode.Mouse1);

        input.SetKeyboardButton(InputName.Movement, KeyCode.E);
        input.SetKeyboardButton(InputName.Reload, KeyCode.R);

        input.SetKeyboardButton(InputName.Ability1, KeyCode.Alpha1);
        input.SetKeyboardButton(InputName.Ability2, KeyCode.Alpha2);
        input.SetKeyboardButton(InputName.Ability3, KeyCode.Alpha3);

        // menu
        AddMenuButtonsForLoadedKeyboardProfile(input);
    }
    
    public static void SetDefaultJoystickControls(PlayerInput input)
    {
        input.SetJoystickAxis(InputName.Horizontal, JoystickMap.JOYSTICK_THUMBSTICK_LEFT_X, DEFAULT_JOYSTICK_MOVE_DEADZONE);
        input.SetJoystickAxis(InputName.Vertical, JoystickMap.JOYSTICK_THUMBSTICK_LEFT_Y, DEFAULT_JOYSTICK_MOVE_DEADZONE);
        input.SetJoystickAxis(InputName.LookHorizontal, JoystickMap.JOYSTICK_THUMBSTICK_RIGHT_X, DEFAULT_JOYSTICK_LOOK_DEADZONE, true, DEFAULT_JOYSTICK_LOOK_SENSITIVITY);
        input.SetJoystickAxis(InputName.LookVertical, JoystickMap.JOYSTICK_THUMBSTICK_RIGHT_Y, DEFAULT_JOYSTICK_LOOK_DEADZONE, true, DEFAULT_JOYSTICK_LOOK_SENSITIVITY);

        //input.SetButton(InputName.Jump, (KeyCode)(MinButtonIndex + JoystickMap.BUTTON_A));
        input.SetJoystickButton(InputName.Jump, JoystickMap.BUTTON_A);
        //input.SetJoystickButton(InputName.Sprint, JoystickMap.BUTTON_LS);
        //input.SetJoystickButton(InputName.Crouch, JoystickMap.BUTTON_RS);
        //input.SetJoystickButton(InputName.CameraSwitch, JoystickMap.BUTTON_BACK);

        input.SetJoystickAxis(InputName.Attack1, JoystickMap.JOYSTICK_TRIGGER_RIGHT, DEFAULT_JOYSTICK_TRIGGER_DEADZONE);
        input.SetJoystickAxis(InputName.Attack2, JoystickMap.JOYSTICK_TRIGGER_LEFT, DEFAULT_JOYSTICK_TRIGGER_DEADZONE);

        input.SetJoystickButton(InputName.Movement, JoystickMap.BUTTON_LB);
        input.SetJoystickButton(InputName.Reload, JoystickMap.BUTTON_RB);

        input.SetJoystickButton(InputName.Ability1, JoystickMap.BUTTON_X);
        input.SetJoystickButton(InputName.Ability2, JoystickMap.BUTTON_Y);
        input.SetJoystickButton(InputName.Ability3, JoystickMap.BUTTON_B);

        // menu
        AddMenuButtonsForLoadedJoystickProfile(input);
    }

    public static void AddMenuButtonsForLoadedKeyboardProfile(PlayerInput input)
    {
        input.SetKeyboardButton(InputName.Menu_Horizontal, KeyCode.RightArrow, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Horizontal, KeyCode.LeftArrow, -1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Vertical, KeyCode.UpArrow, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Vertical, KeyCode.DownArrow, -1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Alt_Horizontal, KeyCode.D, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Alt_Horizontal, KeyCode.A, -1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Alt_Vertical, KeyCode.W, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Alt_Vertical, KeyCode.S, -1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Pause, KeyCode.Return, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Alt_Pause, KeyCode.Escape, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Submit, KeyCode.Space, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Back, KeyCode.Backspace, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Cancel, KeyCode.Escape, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Configure, KeyCode.Alpha1, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Option, KeyCode.Alpha2, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Reset, KeyCode.Delete, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Scoreboard, KeyCode.Tab, 1, false, 1);

        input.SetKeyboardButton(InputName.Menu_Scroll1, KeyCode.D, 1.0f, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Scroll1, KeyCode.A, -1.0f, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Scroll2, KeyCode.RightArrow, 1.0f, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Scroll2, KeyCode.LeftArrow, -1.0f, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Scroll3, KeyCode.Home, 1.0f, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetKeyboardButton(InputName.Menu_Scroll3, KeyCode.End, -1.0f, false, 1, MENU_BUTTON_INPUT_DELAY);

        input.SetKeyboardButton(InputName.Test_Respawn, KeyCode.End, 1.0f, false, 1.0f, 0.0f);
    }

    public static void AddMenuButtonsForLoadedJoystickProfile(PlayerInput input)
    {
        input.SetJoystickAxis(InputName.Menu_Horizontal, JoystickMap.JOYSTICK_THUMBSTICK_LEFT_X, DEFAULT_JOYSTICK_MOVE_DEADZONE, false, 1.0f, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickAxis(InputName.Menu_Vertical, JoystickMap.JOYSTICK_THUMBSTICK_LEFT_Y, DEFAULT_JOYSTICK_MOVE_DEADZONE, false, 1.0f, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Alt_Horizontal, JoystickMap.DPAD_RIGHT, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Alt_Horizontal, JoystickMap.DPAD_LEFT, -1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Alt_Vertical, JoystickMap.DPAD_UP, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Alt_Vertical, JoystickMap.DPAD_DOWN, -1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Pause, JoystickMap.BUTTON_START, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Submit, JoystickMap.BUTTON_A, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Back, JoystickMap.BUTTON_BACK, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Cancel, JoystickMap.BUTTON_B, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Configure, JoystickMap.BUTTON_Y, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Option, JoystickMap.BUTTON_X, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Reset, JoystickMap.BUTTON_X, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Scoreboard, JoystickMap.BUTTON_BACK, 1, false, 1);
        input.SetJoystickButton(InputName.Menu_Scroll1, JoystickMap.BUTTON_RB, 1.0f, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickButton(InputName.Menu_Scroll1, JoystickMap.BUTTON_LB, -1.0f, false, 1, MENU_BUTTON_INPUT_DELAY);
        input.SetJoystickAxis(InputName.Menu_Scroll2, JoystickMap.JOYSTICK_TRIGGER_RIGHT, 1, false, 1, MENU_BUTTON_INPUT_DELAY);
        // TODO get 2 axes to work together under 1 input
        input.SetJoystickAxis(InputName.Menu_Scroll3, JoystickMap.JOYSTICK_TRIGGER_LEFT, 1, false, 1, MENU_BUTTON_INPUT_DELAY);

        input.SetJoystickButton(InputName.Test_Respawn, JoystickMap.DPAD_UP, 1.0f, false, 1.0f, 0.0f);
    }

    public static void SetupDefaultControlConfigurationsForPlayer(PlayerInput aPlayer, InputDeviceType aDeviceType)
    {
        if (aPlayer != null)
        {
            aPlayer.CurrentConfiguration = null;
            aPlayer.InputConfigurations.Clear();

            // Add Keyboard configuration
            {
                PlayerInputConfiguration keyboard = new PlayerInputConfiguration();
                keyboard.Name = InputDeviceType.Keyboard.ToString();
                aPlayer.CurrentConfiguration = keyboard;
                SetDefaultKeyboardControls(aPlayer);

                aPlayer.InputConfigurations.Add(keyboard.Name, keyboard);
            }

            // Add Joystick configuration
            {
                PlayerInputConfiguration joystick = new PlayerInputConfiguration();
                joystick.Name = InputDeviceType.Joystick.ToString();
                aPlayer.CurrentConfiguration = joystick;
                SetDefaultJoystickControls(aPlayer);

                aPlayer.InputConfigurations.Add(joystick.Name, joystick);
            }

            // If specified, select which configuration to use based on device
            if (aDeviceType == InputDeviceType.Joystick)
            {
                aPlayer.CurrentConfiguration = aPlayer.InputConfigurations[InputDeviceType.Joystick.ToString()];
            }
            else if (aDeviceType == InputDeviceType.Keyboard)
            {
                aPlayer.CurrentConfiguration = aPlayer.InputConfigurations[InputDeviceType.Keyboard.ToString()];
            }
        }
    }
}

public enum InputName
{
    // Axes             // Defaults

    Horizontal,         // Left stick X, A-D
    Vertical,           // Left stick Y, W-S
    LookHorizontal,     // Right stick X, Mouse X
    LookVertical,       // Right stick Y, Mouse Y
    Attack1,            // Right Trigger, Mouse 0 - Primary Attack
    Attack2,            // Left Trigger, Mouse 1 - Zoom/Shield

    // List all configurable buttons here.

    Jump,
    Ability1,           
    Ability2,
    Ability3,
    Movement,
    Reload,
    Sprint,
    Crouch,
    TauntHorizontal,    // D-Pad left/right
    TauntVertical,      // D-Pad up/down
    CameraSwitch,
    
    // Any button not usable by AI players can be put after here.
    
    _Unconfigurable_Start,

    // Any button than cannot be reconfigured or should not be saved to the file should be placed between _Menu_Buttons_Start and _Menu_Buttons_End.
    // Menu buttons

    _Menu_Buttons_Start,    // Used for filtering buttons to save
    Menu_Horizontal,
    Menu_Vertical,
    Menu_Alt_Horizontal,
    Menu_Alt_Vertical,
    Menu_Pause,
    Menu_Alt_Pause,
    Menu_Submit,
    Menu_Back,
    Menu_Cancel,
    Menu_Configure,
    Menu_Option,
    Menu_Reset,
    Menu_Scroll1,
    Menu_Scroll2,
    Menu_Scroll3,
    Menu_Scoreboard,
    _Menu_Buttons_End,      // Used for filtering buttons to save

    // Other testing inputs
    Test_Respawn,           // Instant kill button in game

    // Used for testing axes
    _Temp,
    MAX_INPUT_NAMES
}

public enum InputType
{
    ButtonHeld,
    ButtonPressed,
    ButtonReleased
}

// Specific device
public enum InputDevice
{
    Undefined,
    Keyboard,
    Joystick1,
    Joystick2,
    Joystick3,
    Joystick4
}

// General device
public enum InputDeviceType
{
    Undefined,
    Keyboard,
    Joystick
}

public enum GameState
{
    MainMenu,
    PlayerSelect,
    GameSetup,
    PauseGame,
    PlayGame,
    GameOver,

    ConfigureControls
}

public enum PlayerType
{
    AiPlayer,
    KeyboardPlayer,
    JoystickPlayer
}