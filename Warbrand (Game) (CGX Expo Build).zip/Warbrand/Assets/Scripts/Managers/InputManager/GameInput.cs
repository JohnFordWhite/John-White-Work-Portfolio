﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        GameInput                                                                      *
 * FileExtension:   .cs                                                                            *
 * Author:          Evan Campbell                                                                  *
 * Date:            October 9th, 2016                                                              *
 *                                                                                                 *
 * This file provides input for any class that requires it. This can be sub-classed to make it     *
 * provide values from player input or from AI input.                                              *
 *                                                                                                 *
 * The InputManager is responsible for creating a GameInput for each player in the game            *
 * (Human or AI) and attaching it to the class that requires it.                                   *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Evan Campbell) - October 9th, 2016                                        *
 *                                                                                                 *
\***************************************************************************************************/

using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
//using XInputDotNetPure;

public class GameInputComponent : MonoBehaviour, IComparable<GameInputComponent>
{
    // Generic input object. Add as a subclass (i.e. PlayerInput)
    BaseInput m_BaseInput;

    public BaseInput Input { get { return m_BaseInput; } set { m_BaseInput = value; } }

    // What class this player is playing as.
    CharacterTypes m_CharacterType;

    public CharacterTypes Character { get { return m_CharacterType; } set { m_CharacterType = value; } }

    public bool LockedIn = false;

    public int TeamIndex = -1;

    public string PlayerName
    {
        get
        {
            if (m_PlayerName == string.Empty)
            {
                ResetPlayerName();
                //m_PlayerName = "Player " + PlayerID.ToString();
                //if (IsAI)
                //    m_PlayerName += " (AI)";
            }

            return m_PlayerName;
        }
    }
    protected string m_PlayerName = string.Empty;


    public string LongPlayerName
    {
        get
        {
            if (m_LongPlayerName == string.Empty)
            {
                ResetPlayerName();
            }

            return m_LongPlayerName;
        }
    }
    protected string m_LongPlayerName = string.Empty;

    public void ResetPlayerName()
    {
        if (IsAI == false)
        {
            PlayerInput input = Input as PlayerInput;
            if (input == null || input.ProfileName == string.Empty)
            {
                m_PlayerName = "Player " + PlayerID.ToString();
            }
            else
            {
                m_PlayerName = input.ProfileName;
            }
        }
        else
        {
            m_PlayerName = "Player " + PlayerID.ToString() + " (AI)";
        }

        m_LongPlayerName = m_PlayerName + " (" + Character.ToString() + ")";
    }

    public int PlayerID { get; private set; }

    // These members are used for CharacterSelectionScript
    public bool PickingProfile = false;
    public int CurrentProfileButtonIndex = 0;

    public bool EditingControls = false;

    public bool IsAI
    {
        get
        {
            if (Input == null)
                return false;
            return Input.GetIsAI();
        }
    }

    public void SetNewPlayerID()
    {
        PlayerID = InputManager.GenerateNewPlayerID();
        ResetPlayerName();
    }

    // Update is called once per frame
    void Update()
    {
        if (m_BaseInput != null)
        {
            m_BaseInput.Update();
        }
    }

    void LateUpdate()
    {
        if (m_BaseInput != null)
            m_BaseInput.LateUpdate();
    }

    // Base implementation of GetInput has no logic.
    public float GetInput(InputName aInputName, InputType aInputType = InputType.ButtonHeld, bool aRawAxis = false, bool aTestInput = false)
    {
        if (m_BaseInput != null)
        {
            return m_BaseInput.GetInput(aInputName, aInputType, aRawAxis, aTestInput);
        }
        return 0.0f;
    }

    public int CompareTo(GameInputComponent other)
    {
        int returnValue = 0;

        // First, compare non-ai with ai. Non-ais get sorted first.
        if (this.IsAI == false && other.IsAI == true)
        {
            returnValue = -1;
        }
        else if (this.IsAI == true && other.IsAI == false)
        {
            returnValue = 1;
        }
        // Second, compare PlayerID. Lower PlayerIDs get sorted first.
        else
        {
            if (this.PlayerID < other.PlayerID)
            {
                returnValue = -1;
            }
            else if (this.PlayerID > other.PlayerID)
            {
                returnValue = 1;
            }
        }

        return returnValue;
    }
}

public abstract class BaseInput
{
    public GameInputComponent GameInputComponent { get { return m_GameInput; } set { m_GameInput = value; } }

    GameInputComponent m_GameInput;

    public Player Character;

    public abstract bool GetIsAI();

    public GameInputComponent Input { get { return m_GameInput; } set { m_GameInput = value; } }

    public BaseInput(GameInputComponent gameInput)
    {
        m_GameInput = gameInput;
    }

    public virtual void Update() { }
    public virtual void LateUpdate() { }
    
    public virtual float GetInput(InputName aInputName, InputType aInputType = InputType.ButtonHeld, bool aRawAxis = false, bool aTestInput = false)
    {
#if UNITY_EDITOR
        if (aTestInput)
            Debug.Log("???");
#endif

        return 0.0f;
    }
    
    public void AddPlayer(string aPrefabString)
    {
        if (Character == null)
        {
            GameObject CharacterObject = (GameObject)GameObject.Instantiate(Resources.Load(aPrefabString), Vector3.zero, Quaternion.identity);
            Character = CharacterObject.GetComponentInChildren<Player>();
            Character.Health.InitHealth();

            // Set in new player
            BasicMovementScript player = Character.GetComponent<BasicMovementScript>();
            player.GameInput = Input;

            // Set character's parent to this
            CharacterObject.transform.parent = m_GameInput.transform;

            Character.gameObject.SetActive(false);
        }
    }

    public void DropPlayer()
    {
        if (Character != null)
        {
            GameObject.Destroy(Character);
        }
    }

    protected const string StringError = "[ERROR]";

    public virtual bool IsSubmitButtonPressed() { return false; }

    public virtual bool IsCancelButtonPressed() { return false; }
}

public class PlayerInputConfiguration
{
    public string Name;

    //public Dictionary<InputName, InputMapping> InputMap;
    public Dictionary<int, InputMapping> InputMap;

    // More specific configuration set
    // i.e. Keyboard/Paige, Joystick/Quark, etc.
    public List<PlayerInputConfiguration> SubConfigurations;

    public PlayerInputConfiguration()
    {
        //InputMap = new Dictionary<InputName, InputMapping>();
        InputMap = new Dictionary<int, InputMapping>();

        SubConfigurations = new List<PlayerInputConfiguration>();
    }
}

public class PlayerInput : BaseInput
{
    public InputDevice Device;

    public Dictionary<string, PlayerInputConfiguration> InputConfigurations;
    public PlayerInputConfiguration CurrentConfiguration;

    // Fine-tuned logging settings
    public bool DebugInput = false;
    public bool DebugInputMappingConstructor = false;
    public bool DebugEachInput = false;
    public bool DebugInputPressed = false;

    public static readonly InputName[] SubmitButtons =
    {
        InputName.Menu_Pause,
        InputName.Menu_Submit
    };

    public static readonly InputName[] CancelButtons =
    {
        InputName.Menu_Cancel
    };

    public string ProfileName
    {
        get
        {
            return m_ProfileName;
        }
        set
        {
            m_ProfileName = value;
        }
    }

    protected string m_ProfileName = string.Empty;

    public override bool GetIsAI()
    {
        return false;
    }

    public PlayerInput(GameInputComponent gameInput) : base(gameInput)
    {
        InputConfigurations = new Dictionary<string, PlayerInputConfiguration>();

        CurrentConfiguration = null;
    }

    public override void Update()
    {
        base.Update();

        UpdateAxisStates();
    }

    // Iterates over all input mappings and re links the device for each one
    public void ResetDevice()
    {
        //foreach (var inputMapping in CurrentConfiguration.InputMap.Values)
        //{
        //    inputMapping.ResetInputString();
        //}

        for (int i = 0; i < (int)InputName.MAX_INPUT_NAMES; i++)
        {
            InputMapping input = null;

            CurrentConfiguration.InputMap.TryGetValue(i, out input);

            if (input != null)
            {
                input.ResetInputString();
            }
        }
    }

    // The meat of the PlayerInput class. This retrieves the value required by the GameObject polling for inputs.
    public override float GetInput(InputName aInputName, InputType aInputType = InputType.ButtonHeld, bool aRawAxis = false, bool aTestInput = false)
    {
        // Dictionary/Map lookup is much faster than array/list iteration so no need to worry about performance here.
        // Additionally, Enums are much faster than strings for comparisons.

        InputMapping input = null;
        if (CurrentConfiguration != null && CurrentConfiguration.InputMap != null)
        {
            CurrentConfiguration.InputMap.TryGetValue((int)aInputName, out input);

#if UNITY_EDITOR
            if (input == null)
            {
                DebugManager.LogError("InputMapping is null for button: " + aInputName.ToString() + "! - Device is: " + Device.ToString(), Developmer.Evan);
            }
#endif

            if (input != null)
            {
                return input.GetInput(aInputType, aRawAxis, false, aTestInput);
            }
        }

#if UNITY_EDITOR
        // These should never happen. If any of these LogErrors get printed then something is wrong.

        if (CurrentConfiguration == null)
        {
            DebugManager.LogError("CurrentConfiguration is null for device: " + Device.ToString(), Developmer.Evan);
        }
        if (CurrentConfiguration.InputMap == null)
        {
            DebugManager.LogError("CurrentConfiguration InputMap is null for device: " + Device.ToString(), Developmer.Evan);
        }
        else if (CurrentConfiguration.InputMap.Keys.Count <= 0)
        {
            DebugManager.LogError("CurrentConfiguration InputMap has no keys set for device: " + Device.ToString(), Developmer.Evan);
        }
        if (input == null)
        {
            DebugManager.LogError("InputMapping is null for button: " + aInputName.ToString() + "! - Device is: " + Device.ToString(), Developmer.Evan);
        }
#endif

        return 0.0f;
    }

    public InputMapping GetLastInput()
    {
        // TODO

        // Device is Keyboard - Call GetLastInput during OnGUI
        if (Device == InputDevice.Keyboard)
        {

        }
        // Device is Joystick - Call GetLastInput during Update
        else if (Device > InputDevice.Keyboard)
        {

        }
        return null;
    }

    public bool MapNewInputKeyboard(InputName aInputToMap, List<int> aIgnoreList, float aSign = 1.0f)
    {
        bool result = false;
        if (Device == InputDevice.Keyboard)
        {

            Event keyEvent = Event.current;

            if (keyEvent.isKey ||
                // Shift keys are not reported by this KeyEvent so we need to check manually.
                UnityEngine.Input.GetKey(KeyCode.LeftShift) ||
                UnityEngine.Input.GetKey(KeyCode.RightShift))
            {
                if (UnityEngine.Input.GetKeyDown(keyEvent.keyCode))
                {
                    // Need to loop through the list of buttons to ignore.
                    for (int ignoreIndex = 0; ignoreIndex < aIgnoreList.Count; ignoreIndex++)
                    {
                        // Get the current ignore key from the list.
                        KeyCode ignoreKey = (KeyCode)(aIgnoreList[ignoreIndex]);

                        // Compare the button the player just pressed with the current button to ignore.
                        if (keyEvent.keyCode == ignoreKey)
                        {
                            // At this point we already know that this key cannot be mapped, so we can return immediately.
                            return false;
                        }
                    }

                    // The key that the player just pressed is good - we can now map this button to the action and return.
                    SetKeyboardButton(aInputToMap, keyEvent.keyCode, aSign);
                    return true;
                }

                // Need to manually check LeftShift and RightShift as these keys are not detected in Event.current.
                if (UnityEngine.Input.GetKey(KeyCode.LeftShift))
                {
                    SetKeyboardButton(aInputToMap, KeyCode.LeftShift, aSign);
                    return true;
                }
                if (UnityEngine.Input.GetKey(KeyCode.RightShift))
                {
                    SetKeyboardButton(aInputToMap, KeyCode.RightShift, aSign);
                    return true;
                }
            }

            // Listen for mouse movement and scroll wheel.

            // Create a temp InputMapping, and then loop over all of the axis strings to see if one of them was pressed.
            MouseAxisInputMapping input = SetMouseAxis(InputName._Temp, string.Empty, JoystickMap.JOYSTICK_AXIS_DEADZONE);

            string[] axisList = JoystickMap.UnityDefinedJoystickSettings.KEYBOARD_AXIS_LIST;

            for (int i = 0; i < axisList.Length; i++)
            {
                string shortAxisString = axisList[i];

                //string axisString = BuildDeviceAxisString(shortAxisString);

                // Set the next axis string and clear/recheck the current state.
                SetMouseAxis(InputName._Temp, shortAxisString, JoystickMap.JOYSTICK_AXIS_DEADZONE);
                input.SetAxis(shortAxisString);
                input.ResetState();
                input.Update();

                float axisValue = input.TestAxis(InputType.ButtonPressed, JoystickMap.JOYSTICK_AXIS_DEADZONE);

                // Listen for Just Pressed state
                if (axisValue != 0.0f)
                {
                    // If it was just pressed, set the axis and return true.
                    SetMouseAxis(aInputToMap, shortAxisString, JoystickMap.JOYSTICK_AXIS_DEADZONE);
                    return true;
                }
            }
        }
        return result;
    }


    public void ResetAndUpdateAxisStates()
    {
        if (CurrentConfiguration != null)
        {
            //foreach (KeyValuePair<int, InputMapping> axis in CurrentConfiguration.InputMap)
            //{
            //    InputMapping input = axis.Value;

            //    input.ResetState();
            //    input.Update();
            //}

            for (int i = 0; i < (int)InputName.MAX_INPUT_NAMES; i++)
            {
                InputMapping input = null;

                CurrentConfiguration.InputMap.TryGetValue(i, out input);

                if (input != null)
                {
                    input.ResetState();
                    input.Update();
                }
            }
        }
    }

    public int GetJoystickIndex()
    {
        int joystickIndex = -1;

        if (Device > InputDevice.Keyboard)
        {
            // TODO: Cleanup?
            // Determine the current joystick index
            switch (Device)
            {
                case InputDevice.Joystick1:
                    joystickIndex = 0;
                    break;
                case InputDevice.Joystick2:
                    joystickIndex = 1;
                    break;
                case InputDevice.Joystick3:
                    joystickIndex = 2;
                    break;
                case InputDevice.Joystick4:
                    joystickIndex = 3;
                    break;
                default:
                    joystickIndex = -1;
                    break;
            }
        }

        return joystickIndex;
    }

    // Call this function during Update
    public bool MapNewInputJoystick(InputName aInputToMap, List<int> aIgnoreList, float aSign = 1.0f)
    {
        if (Device > InputDevice.Keyboard)
        {
            int joystickIndex = GetJoystickIndex();

            if (joystickIndex != -1)
            {
                JoystickState state = InputManager.CM.JoystickStates[joystickIndex];

                // Loop over the list of button states

                for (int buttonIndex = 0; buttonIndex < JoystickMap.JOYSTICK_BUTTONS.Length; buttonIndex++)
                {
                    // TODO - loop over ignore key indexes
                    // for (...)
                    //     if (buttonIndex == ignoreIndex)
                    //         return false
                    if (state.ButtonPressed(JoystickMap.BUTTON_START))
                        continue;
                    if (state.ButtonPressed(JoystickMap.BUTTON_BACK))
                        continue;

                    if (state.ButtonPressed(buttonIndex))
                    {
                        SetJoystickButton(aInputToMap, buttonIndex, aSign);
                        return true;
                    }
                }

                // If we reached here, all buttons have been checked. We can still check the axes for input.
                // Loop over the list of axis states

                for (int axisIndex = 0; axisIndex < JoystickMap.JOYSTICK_AXES.Length; axisIndex++)
                {
                    if (state.AxisPressed(axisIndex, JoystickMap.JOYSTICK_AXIS_DEADZONE))
                    {
                        SetJoystickAxis(aInputToMap, axisIndex, JoystickMap.JOYSTICK_AXIS_DEADZONE);

                        return true;
                    }
                }
            }
        }
        return false;
    }

    // Need to update the states of each axis every frame
    // to detect just pressed / just released states.
    public void UpdateAxisStates()
    {
        if (CurrentConfiguration != null)
        {
            //foreach (KeyValuePair<int, InputMapping> axis in CurrentConfiguration.InputMap)
            //{
            //    InputMapping input = axis.Value;

            //    input.Update();
            //}

            for (int i = 0; i < (int)InputName.MAX_INPUT_NAMES; i++)
            {
                InputMapping input = null;

                CurrentConfiguration.InputMap.TryGetValue(i, out input);

                if (input != null)
                {
                    input.Update();
                }
            }
        }
    }

    // Get the KeyCode that is mapped for a particular input. If this is a button
    // emulating an axis, get the KeyCode that is mapped to the positive or negative axis.
    public KeyCode GetMappedKeyCode(InputName aInputKey, float aSign = 1.0f)
    {
        if (CurrentConfiguration != null)
        {
            InputMapping input = CurrentConfiguration.InputMap[(int)aInputKey];

            if (input is KeyboardButtonInputMapping)
            {
                KeyboardButtonInputMapping keyboard = (KeyboardButtonInputMapping)input;
                return keyboard.GetMappedKeyCode(aSign);
            }
        }

        return KeyCode.None;
    }

    public int GetMappedJoystickButton(InputName aInputKey, float aSign = 1.0f)
    {
        if (CurrentConfiguration != null)
        {
            InputMapping input = CurrentConfiguration.InputMap[(int)aInputKey];

            if (input is JoystickButtonInputMapping)
            {
                JoystickButtonInputMapping joystick = (JoystickButtonInputMapping)input;
                return joystick.GetMappedButtonIndex(aSign);
            }
        }

        return -1;
    }

    public int GetMappedJoystickAxis(InputName aInputKey, float aSign = 1.0f)
    {
        if (CurrentConfiguration != null)
        {
            InputMapping input = CurrentConfiguration.InputMap[(int)aInputKey];

            if (input is JoystickAxisInputMapping)
            {
                JoystickAxisInputMapping joystick = (JoystickAxisInputMapping)input;
                return joystick.GetAxis();
            }
        }

        return -1;
    }

    public string GetInputString(InputName aInputKey, bool aLongFormat = false)
    {
        if (CurrentConfiguration != null)
        {
            InputMapping input = CurrentConfiguration.InputMap[(int)aInputKey];

            return input.GetInputString(aLongFormat);
        }

        return StringError;
    }

    // Remap an existing input, or map a new one.
    public InputMapping SetKeyboardButton(InputName aButtonName, KeyCode aButton, float aSign = 1.0f, bool aCanChangeSensitivity = false, float aSensitivityModifier = 1.0f, float aInputDelay = 0.0f)
    {
        if (CurrentConfiguration != null)
        {
            InputMapping input = null;
            if (CurrentConfiguration.InputMap.ContainsKey((int)aButtonName))
            {
                input = CurrentConfiguration.InputMap[(int)aButtonName];
            }

            KeyboardButtonInputMapping keyboard = null;
            if (input != null && input is KeyboardButtonInputMapping)
            {
                keyboard = (KeyboardButtonInputMapping)input;
            }
            else
            {
                keyboard = new KeyboardButtonInputMapping(this);
            }

            keyboard.player = this;
            CurrentConfiguration.InputMap[(int)aButtonName] = keyboard;
            keyboard.CanChangeSensitivity = aCanChangeSensitivity;
            keyboard.SensitivityModifier = aSensitivityModifier;
            keyboard.InputDelay = aInputDelay;

            // If this button is emulating an axis direction, set the according positive or negative button.
            // By default, any standard button will return a positive value when pressed.
            if (aSign >= 0.0f)
            {
                keyboard.PositiveButtonAxis = aButton;
            }
            else
            {
                keyboard.NegativeButtonAxis = aButton;
            }

            return keyboard;
        }

        return null;
    }

    public InputMapping SetJoystickButton(InputName aButtonName, int aButtonIndex, float aSign = 1.0f, bool aCanChangeSensitivity = false, float aSensitivityModifier = 1.0f, float aInputDelay = 0.0f)
    {
        if (CurrentConfiguration != null)
        {
            InputMapping input = null;
            if (CurrentConfiguration.InputMap.ContainsKey((int)aButtonName))
            {
                input = CurrentConfiguration.InputMap[(int)aButtonName];
            }

            JoystickButtonInputMapping joystick = null;
            if (input != null && input is JoystickButtonInputMapping)
            {
                joystick = (JoystickButtonInputMapping)input;
            }
            else
            {
                joystick = new JoystickButtonInputMapping(this);
            }
            joystick.player = this;
            CurrentConfiguration.InputMap[(int)aButtonName] = joystick;
            joystick.CanChangeSensitivity = aCanChangeSensitivity;
            joystick.SensitivityModifier = aSensitivityModifier;
            joystick.InputDelay = aInputDelay;

            // If this button is emulating an axis direction, set the according positive or negative button.
            // By default, any standard button will return a positive value when pressed.
            if (aSign >= 0.0f)
            {
                joystick.PositiveButtonAxis = aButtonIndex;
            }
            else
            {
                joystick.NegativeButtonAxis = aButtonIndex;
            }

            return joystick;
        }

        return null;
    }

    public JoystickAxisInputMapping SetJoystickAxis(InputName aAxisName, int aAxisIndex, float aAxisDeadZone = -1.0f, bool aCanChangeSensitivity = false, float aSensitivityModifier = 1.0f, float aInputDelay = 0.0f)
    {
        if (CurrentConfiguration != null)
        {
            InputMapping input = null;
            if (CurrentConfiguration.InputMap.ContainsKey((int)aAxisName))
            {
                input = CurrentConfiguration.InputMap[(int)aAxisName];
            }

            JoystickAxisInputMapping joystick = null;
            if (input != null && input is JoystickAxisInputMapping)
            {
                joystick = (JoystickAxisInputMapping)input;
            }
            else
            {
                joystick = new JoystickAxisInputMapping(this);
            }
            joystick.player = this;
            CurrentConfiguration.InputMap[(int)aAxisName] = joystick;

            joystick.SetAxis(aAxisIndex);
            joystick.CanChangeSensitivity = aCanChangeSensitivity;
            joystick.SensitivityModifier = aSensitivityModifier;
            joystick.InputDelay = aInputDelay;

            // Update the axis dead zone

            // Default to the constant from JoystickMap
            if (aAxisDeadZone < 0.0f)
            {
                joystick.AxisDeadZone = JoystickMap.JOYSTICK_AXIS_DEADZONE;
            }
            else
            {
                joystick.AxisDeadZone = aAxisDeadZone;
            }

            return joystick;
        }

        return null;
    }

    /// <summary>
    /// Maps an input in the game to a mouse movement.
    /// </summary>
    /// <param name="aAxisName">The name of the game action being mapped.</param>
    /// <param name="aAxisMapping">The axis name on the device. Use one of the static strings in JoystickMap.</param>
    /// <param name="axisDeadZone">The deadzone detection on the axis.</param>
    public MouseAxisInputMapping SetMouseAxis(InputName aAxisName, string aAxisMapping, float aAxisDeadZone = -1.0f, bool aCanChangeSensitivity = false, float aSensitivityModifier = 1.0f)
    {
        if (CurrentConfiguration != null)
        {
            InputMapping input = null;
            if (CurrentConfiguration.InputMap.ContainsKey((int)aAxisName))
            {
                input = CurrentConfiguration.InputMap[(int)aAxisName];
            }

            MouseAxisInputMapping mouse = null;
            if (input != null && input is MouseAxisInputMapping)
            {
                mouse = (MouseAxisInputMapping)input;
            }
            else
            {
                mouse = new MouseAxisInputMapping(this);
            }
            mouse.player = this;
            CurrentConfiguration.InputMap[(int)aAxisName] = mouse;

            mouse.SetAxis(aAxisMapping);
            mouse.CanChangeSensitivity = aCanChangeSensitivity;
            mouse.SensitivityModifier = aSensitivityModifier;

            // Update the axis dead zone

            // Default to the constant from JoystickMap
            if (aAxisDeadZone < 0.0f)
            {
                mouse.AxisDeadZone = JoystickMap.JOYSTICK_AXIS_DEADZONE;
            }
            else
            {
                mouse.AxisDeadZone = aAxisDeadZone;
            }

            return mouse;
        }

        return null;
    }

    public void SetAxisInverted(InputName aInputToConfigure, bool aIsInverted)
    {
        if (CurrentConfiguration != null)
        {
            InputMapping input = CurrentConfiguration.InputMap[(int)aInputToConfigure];

            if (input != null)
            {
                input.InvertAxis = aIsInverted;
            }
        }
    }

    public bool GetAxisInverted(InputName aInput)
    {
        if (CurrentConfiguration != null)
        {
            InputMapping input = CurrentConfiguration.InputMap[(int)aInput];

            if (input != null)
            {
                return input.InvertAxis;
            }
        }

        return false;
    }

    public string BuildDeviceAxisString(string aShortAxisString)
    {
        string axisString = Device.ToString() + "_" + aShortAxisString;

        return axisString;
    }

    public override bool IsSubmitButtonPressed()
    {
        if (GameMenu.s_SubmitButtonDelay <= 0)
        {
            for (int i = 0; i < SubmitButtons.Length; i++)
            {
                if (GetInput(SubmitButtons[i], InputType.ButtonPressed, true) != 0.0f)
                {
                    GameMenu.s_SubmitButtonDelay = GameMenu.BUTTON_PRESS_DELAY;
                    return true;
                }
            }
        }

        return false;
    }

    public override bool IsCancelButtonPressed()
    {
        if (GameMenu.s_BackButtonDelay <= 0)
        {
            for (int i = 0; i < CancelButtons.Length; i++)
            {
                if (GetInput(CancelButtons[i], InputType.ButtonPressed, true) != 0.0f)
                {
                    GameMenu.s_BackButtonDelay = GameMenu.BUTTON_PRESS_DELAY;
                    return true;
                }
            }
        }

        return false;
    }
}

// If each character class AI is expected to have different behaviour,
// (e.g. if a LeeroyAI is supposed to act differently from a QuarkAI),
// each AI behaviour should be put in its own file.

