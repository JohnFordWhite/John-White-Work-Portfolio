﻿using UnityEngine;
using System.Collections.Generic;
using System;

public class AiInput : BaseInput
{
    private struct Buffer
    {
        public Buffer(InputName aName, float aValue) { name = aName; value = aValue; }
        public InputName name;
        public float value;
    }

    private List<Buffer> m_Buffer = new List<Buffer>();

    // These dictionaries will be looked up with InputName instead of name for
    // readability purposes. The reason for this is behind the scenes, looking up
    // a dictionary key with an enum autoboxes the int value and creates a dummy
    // allocation that the GC needs to clean up later and it's slower.
    // Using an int for the key makes it faster.
    private Dictionary<int, float> m_Inputs = new Dictionary<int, float>();
    private Dictionary<int, float> m_LastInputs = new Dictionary<int, float>();

    public override void LateUpdate()
    {
        base.LateUpdate();

        // As soon as AI characters are selected on CharacterSelectionScene, they are able to be updated.
        // We only want to continue if the game is actually started.
        if (InputManager.CM.CurrentGameState != GameState.PlayGame)
            return;

        //m_LastInputs = new Dictionary<int, float>();
        //foreach (var input in m_Inputs)
        //    m_LastInputs.Add(input.Key, input.Value);

        //foreach (var input in m_Inputs)
        //    m_LastInputs[input.Key] = input.Value;

        // New method to set old input states
        // - Does not create a dummy iterator allocation behind the scenes
        // - Takes the same amount of time (or maybe a tiny bit faster) than the foreach method.
        for (int i = 0; i < (int)InputName._Unconfigurable_Start; i++)
        {
            float value = 0;

            m_Inputs.TryGetValue(i, out value);

            m_LastInputs[i] = value;
        }

        while (m_Buffer.Count > 0)
        {
            SetInput(m_Buffer[0]);
            m_Buffer.RemoveAt(0);
        }
    }

    public override bool GetIsAI()
    {
        return true;
    }

    public AiInput(GameInputComponent gameInput) : base(gameInput) { }

    public void SetInput(InputName aInputName, float aValue)
    {
        m_Buffer.Add(new Buffer(aInputName, aValue));
    }

    public void SetAllInputs(float aValue)
    {
        for (int i = 0; i < (int)(InputName._Unconfigurable_Start); i++)
        {
            SetInput((InputName)(i), aValue);
        }
    }

    private void SetInput(Buffer aBuffer)
    {
        int key = (int)aBuffer.name;

        m_Inputs[key] = Mathf.Clamp(aBuffer.value, -1f, 1f);

        //if (!(m_Inputs.ContainsKey(key)))
        //    m_Inputs.Add(key, Mathf.Clamp(aBuffer.value, -1f, 1f));
        //else
        //    m_Inputs[key] = Mathf.Clamp(aBuffer.value, -1f, 1f);
    }

    public override float GetInput(InputName aInputName, InputType aInputType = InputType.ButtonHeld, bool aRawAxis = false, bool aTestInput = false)
    {
        int key = (int)aInputName;

        float inputValue = 0;
        float prevInputValue = 0;

        if (!m_Inputs.TryGetValue(key, out inputValue) || !m_LastInputs.TryGetValue(key, out prevInputValue))
            return 0f;

        bool prev = !MathUtils.AlmostEquals(prevInputValue, 0);
        bool curr = !MathUtils.AlmostEquals(inputValue, 0);

        switch (aInputType)
        {
            case InputType.ButtonHeld:
                return inputValue;
            case InputType.ButtonPressed:
                return (curr && !prev) ? 1 : 0;
            case InputType.ButtonReleased:
                return (!curr && prev) ? 1 : 0;
        }
        return inputValue;

        //if (m_Inputs.ContainsKey(key))
        //    return m_Inputs[key];
        //return 0f;
    }
}