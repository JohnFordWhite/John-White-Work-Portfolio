﻿// A very generic Controller class designed to be as flexible and expandable as possible.

using UnityEngine;

public abstract class JoystickState
{
    public abstract bool IsSubmitButtonPressed();
    public abstract bool IsCancelButtonPressed();

    public int ControllerIndex
    {
        get
        {
            return m_ControllerIndex;
        }
    }
    protected int m_ControllerIndex;

    public float[] Buttons;
    public float[] PrevButtons;

    public float[] Axes;
    public float[] PrevAxes;

    public JoystickState(int aControllerIndex)
    {
        m_ControllerIndex = aControllerIndex;

        Buttons = new float[JoystickMap.JOYSTICK_BUTTONS.Length];
        PrevButtons = new float[JoystickMap.JOYSTICK_BUTTONS.Length];

        Axes = new float[JoystickMap.JOYSTICK_AXES.Length];
        PrevAxes = new float[JoystickMap.JOYSTICK_AXES.Length];
    }

    public virtual void Reset()
    {
        for (int i = 0; i < Buttons.Length; i++)
        {
            Buttons[i] = 0.0f;
            PrevButtons[i] = 0.0f;
        }

        for (int i = 0; i < Axes.Length; i++)
        {
            Axes[i] = 0.0f;
            PrevAxes[i] = 0.0f;
        }
    }

    public abstract void Update();

    // Helper button checks

    #region ButtonPressed, ButtonReleased, ButtonHeld, AxisPressed, AxisReleased, AxisHeld

    public virtual bool ButtonPressed(int aButtonIndex, bool aTestInput = false)
    {
        // Out of bounds check
        if (aButtonIndex < 0 || aButtonIndex >= Buttons.Length)
        {
#if UNITY_EDITOR
            DebugManager.LogError("Button Pressed - Invalid button index: " + aButtonIndex, Developmer.AllDevelopmers);
#endif
            return false;
        }

        bool pressed = (Buttons[aButtonIndex] == 1.0f && PrevButtons[aButtonIndex] == 0.0f);

#if UNITY_EDITOR
        if (aTestInput)
            DebugManager.Log("ButtonPressed (" + JoystickMap.GetButtonString(aButtonIndex) + "): " + pressed + " - Current State: " + Buttons[aButtonIndex] + ", Previous State: " + PrevButtons[aButtonIndex], Developmer.Evan);
#endif

        return pressed;
    }

    public virtual bool ButtonReleased(int aButtonIndex, bool aTestInput = false)
    {
        // Out of bounds check
        if (aButtonIndex < 0 || aButtonIndex >= Buttons.Length)
        {
#if UNITY_EDITOR
            DebugManager.LogError("Button Released - Invalid button index: " + aButtonIndex, Developmer.AllDevelopmers);
#endif
            return false;
        }

        bool released = (Buttons[aButtonIndex] == 0.0f && PrevButtons[aButtonIndex] == 1.0f);

#if UNITY_EDITOR
        if (aTestInput)
            DebugManager.Log("ButtonReleased (" + JoystickMap.GetButtonString(aButtonIndex) + "): " + released + " - Current State: " + Buttons[aButtonIndex] + ", Previous State: " + PrevButtons[aButtonIndex], Developmer.Evan);
#endif

        return released;
    }

    public virtual bool ButtonHeld(int aButtonIndex, bool aTestInput = false)
    {
        // Out of bounds check
        if (aButtonIndex < 0 || aButtonIndex >= Buttons.Length)
        {
#if UNITY_EDITOR
            DebugManager.LogError("Button Held - Invalid button index: " + aButtonIndex, Developmer.AllDevelopmers);
#endif
            return false;
        }

        bool held = (Buttons[aButtonIndex] == 1.0f && PrevButtons[aButtonIndex] == 0.0f) ||
            (Buttons[aButtonIndex] == 1.0f && PrevButtons[aButtonIndex] == 1.0f);

#if UNITY_EDITOR
        if (aTestInput)
            DebugManager.Log("ButtonHeld (" + JoystickMap.GetButtonString(aButtonIndex) + "): " + held + " - Current State: " + Buttons[aButtonIndex] + ", Previous State: " + PrevButtons[aButtonIndex], Developmer.Evan);
#endif

        return held;
    }

    // Helper axis checks

    public virtual bool AxisPressed(int aAxisIndex, float aDeadzone, bool aTestInput = false)
    {
        // Out of bounds check
        if (aAxisIndex < 0 || aAxisIndex >= Axes.Length)
        {
#if UNITY_EDITOR
            DebugManager.LogError("Axis Pressed - Invalid axis index: " + aAxisIndex, Developmer.AllDevelopmers);
#endif
            return false;
        }

        bool pressed = (Mathf.Abs(Axes[aAxisIndex]) >= aDeadzone && Mathf.Abs(PrevAxes[aAxisIndex]) < aDeadzone);

#if UNITY_EDITOR
        if (aTestInput)
            DebugManager.Log("ButtonPressed (" + JoystickMap.s_AxisStrings[aAxisIndex] + "): " + pressed + " - Current State: " + Axes[aAxisIndex] + ", Previous State: " + PrevAxes[aAxisIndex], Developmer.Evan);
#endif

        return pressed;
    }

    public virtual bool AxisReleased(int aAxisIndex, float aDeadzone, bool aTestInput = false)
    {
        // Out of bounds check
        if (aAxisIndex < 0 || aAxisIndex >= Axes.Length)
        {
#if UNITY_EDITOR
            DebugManager.LogError("Axis Released - Invalid axis index: " + aAxisIndex, Developmer.AllDevelopmers);
#endif
            return false;
        }

        bool released = (Mathf.Abs(Axes[aAxisIndex]) < aDeadzone && Mathf.Abs(PrevAxes[aAxisIndex]) >= aDeadzone);

#if UNITY_EDITOR
        if (aTestInput)
            DebugManager.Log("AxisReleased (" + JoystickMap.s_AxisStrings[aAxisIndex] + "): " + released + " - Current State: " + Axes[aAxisIndex] + ", Previous State: " + PrevAxes[aAxisIndex], Developmer.Evan);
#endif

        return released;
    }

    public virtual bool AxisHeld(int aAxisIndex, float aDeadzone, bool aTestInput = false)
    {
        // Out of bounds check
        if (aAxisIndex < 0 || aAxisIndex >= Axes.Length)
        {
#if UNITY_EDITOR
            DebugManager.LogError("Axis Held - Invalid axis index: " + aAxisIndex, Developmer.AllDevelopmers);
#endif
            return false;
        }

        bool held = (Mathf.Abs(Axes[aAxisIndex]) >= aDeadzone && Mathf.Abs(PrevAxes[aAxisIndex]) < aDeadzone) ||
            (Mathf.Abs(Axes[aAxisIndex]) >= aDeadzone && Mathf.Abs(Axes[aAxisIndex]) >= aDeadzone);

#if UNITY_EDITOR
        if (aTestInput)
            DebugManager.Log("AxisHeld (" + JoystickMap.s_AxisStrings[aAxisIndex] + "): " + held + " - Current State: " + Axes[aAxisIndex] + ", Previous State: " + PrevAxes[aAxisIndex], Developmer.Evan);
#endif

        return held;
    }

    #endregion

    // Misc. helpers

    #region ResetButton, ResetAxis

    public virtual void ResetButton(int aButtonIndex)
    {
        if (aButtonIndex >= Buttons.Length || aButtonIndex < 0)
        {
#if UNITY_EDITOR
            DebugManager.LogError("ResetButton: Invalid button index: " + aButtonIndex, Developmer.AllDevelopmers);
#endif
            return;
        }

        Buttons[aButtonIndex] = 0.0f;
        PrevButtons[aButtonIndex] = 0.0f;
    }

    public virtual void ResetAxis(int aAxisIndex)
    {
        if (aAxisIndex >= Buttons.Length || aAxisIndex < 0)
        {
#if UNITY_EDITOR
            DebugManager.LogError("ResetAxis: Invalid axis index: " + aAxisIndex, Developmer.AllDevelopmers);
#endif
            return;
        }

        Axes[aAxisIndex] = 0.0f;
        PrevAxes[aAxisIndex] = 0.0f;
    }

    #endregion
}
