﻿#if UNITY_EDITOR || UNITY_STANDALONE_WIN || UNITY_STANDALONE_OSX || UNITY_STANDALONE_LINUX

using System;
using XboxCtrlrInput;

public class XboxCtrlrInput_JoystickState : JoystickState
{
    protected static readonly int[] SubmitButtonIndexList =
    {
        0,  //  XboxButton.A
        7,  //  XboxButton.Start
    };

    protected static readonly int[] CancelButtonIndexList =
    {
        1,  //  XboxButton.B
    };

    public override bool IsSubmitButtonPressed()
    {
        for (int i = 0; i < SubmitButtonIndexList.Length; i++)
        {
            if (ButtonPressed(SubmitButtonIndexList[i]))
                return true;
        }

        return false;
    }

    public override bool IsCancelButtonPressed()
    {
        for (int i = 0; i < CancelButtonIndexList.Length; i++)
        {
            if (ButtonPressed(CancelButtonIndexList[i]))
                return true;
        }

        return false;
    }

    protected XboxController m_Controller;

    // Enumerate the XboxButton enum to match up with JoystickMap.JOYSTICK_BUTTONS
    // so that it is consistant across all controllers/interfaces.
    protected static readonly XboxButton[] XboxButtons =
    {
        XboxButton.A,
        XboxButton.B,
        XboxButton.X,
        XboxButton.Y,
        XboxButton.LeftBumper,
        XboxButton.RightBumper,
        XboxButton.Back,
        XboxButton.Start,
        XboxButton.LeftStick,
        XboxButton.RightStick,
        XboxButton.DPadLeft,
        XboxButton.DPadRight,
        XboxButton.DPadUp,
        XboxButton.DPadDown,
    };

    // Enumerate the XboxAxis enum to match up with JoystickMap.JOYSTICK_AXES
    // so that it is consistant across all controllers/interfaces.
    // Any index with a value of 0 won't be used.
    protected static readonly XboxAxis[] XboxAxes =
    {
        XboxAxis.LeftStickX,
        XboxAxis.LeftStickY,
        0, //AXIS_3 corresponds with Unity's joined triggers. DirectInput also has joined Triggers (-1 to +1)
        XboxAxis.RightStickX,
        XboxAxis.RightStickY,
        0, //AXIS_6 corresponds with Unity's D-Pad Horizontal
        0, //AXIS_7 corresponts with Unity's D-Pad Vertical
        XboxAxis.LeftTrigger,
        XboxAxis.RightTrigger
    };

    public XboxCtrlrInput_JoystickState(int aControllerIndex) : base(aControllerIndex)
    {
        switch (aControllerIndex)
        {
            case 0:
                m_Controller = XboxController.First;
                break;
            case 1:
                m_Controller = XboxController.Second;
                break;
            case 2:
                m_Controller = XboxController.Third;
                break;
            case 3:
                m_Controller = XboxController.Fourth;
                break;
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Invalid controller index: " + aControllerIndex, Developmer.AllDevelopmers);
#endif
                break;
        }

        Reset();
    }

    public override void Update()
    {
        for (int i = 0; i < XboxButtons.Length; i++)
        {
            PrevButtons[i] = Buttons[i];
            Buttons[i] = (XCI.GetButton(XboxButtons[i], m_Controller) ? 1.0f : 0.0f);
        }

        for (int i = 0; i < XboxAxes.Length; i++)
        {
            // Skip any axes not being used
            if (i != 0 && XboxAxes[i] == 0)
                continue;

            PrevAxes[i] = Axes[i];
            Axes[i] = XCI.GetAxis(XboxAxes[i], m_Controller);
        }
    }
}

#endif