﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        InputManager                                                                   *
 * FileExtension:   .cs                                                                            *
 * Author:          Evan Campbell                                                                  *
 * Date:            October 9th, 2016                                                              *
 *                                                                                                 *
 * This file should be attached to an empty GameObject. It is responsible for dynamically adding   *
 * and dropping players dynamically at runtime, for a maximum of four players locally. Players are *
 * added to the game in the order that inputs are detected from all plugged in joysticks and the   *
 * keyboard. When a new player is added or dropped, this script is responsible for spawning in     *
 * the correct number of player prefab GameObjects and attaching an input module to it. For        *
 * example, Joystick 1 can be mapped to the player 1 slot and the Keyboard can be mapped to player *
 * 4. This should help with alleviating some of the player frustrations when trying to figure out  *
 * who is in what player slot as soon as possible.                                                 *
 *                                                                                                 *
 * This class can also allow each player to choose the character they want to play as.             *
 *                                                                                                 *
 * This class assumes that the Game has at least a "Main Menu" state and a "Play" state - players  *
 * are only added and dropped during the "Main Menu" state.                                        *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Evan Campbell) - October 9th, 2016                                        *
 * V 1.1 - Fixed bug where the singleton instance would become null if the game lost focus without *
 *         any recovery in game. (Evan Campbell) - October 24th, 2016                              *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
//using XInputDotNetPure;
using XboxCtrlrInput;
using UnityEngine.SceneManagement;
using UnityStandardAssets.ImageEffects;

public class InputManager : MonoBehaviour
{
    [Tooltip("List of players currently in the game.")]
    public List<GameInputComponent> Players;

    [Tooltip("Current state of the game.")]
    public GameState CurrentGameState;

    public List<int> CurrentDevices { get { return m_CurrentDevices; } }

    // Control configurator
    public GameObject ControlConfiguratorPrefab;

    public const int MAX_LOCAL_HUMAN_PLAYERS = 4;
    public const int MAX_PLAYERS = 8;

    public const string BuildVersion = "Alpha Build";

    private static readonly Rect GuiBox = new Rect(5.0f, 0.0f, 100.0f, 20.0f);

    private bool m_LoadingPauseMenu = false;

    protected float m_LastRealtimeFrame = 0.0f;
    protected float m_RealDeltaTime = 0.0f;

    public static InputManager CM
    {
        get
        {
            if (s_Instance == null)
            {
                lock (s_InstanceLock)
                {
                    if (s_Instance == null)
                    {
                        GameObject Managers = new GameObject(StringManagersObject);
                        Managers.AddComponent<InputManager>();
                        DontDestroyOnLoad(Managers);
                    }
                }
            }

            return s_Instance;
        }
    }

    public GameModeManager GameModeManager
    {
        get
        {
            if (m_GameModeManager == null)
            {
                m_GameModeManager = GetComponent<GameModeManager>();

                if (m_GameModeManager == null)
                {
                    m_GameModeManager = gameObject.AddComponent<GameModeManager>();
                }
            }

            return m_GameModeManager;
        }
    }

    public PlayerProfileManager PlayerProfileManager
    {
        get
        {
            if (m_PlayerProfileManager == null)
            {
                m_PlayerProfileManager = GetComponent<PlayerProfileManager>();

                if (m_PlayerProfileManager == null)
                {
                    m_PlayerProfileManager = gameObject.AddComponent<PlayerProfileManager>();
                }
            }

            return m_PlayerProfileManager;
        }
    }

    public static void ResetPlayerID()
    {
        s_PlayerID = 0;
    }
    public static int GenerateNewPlayerID()
    {
        return ++s_PlayerID;
    }
    private static int s_PlayerID;

    public void ResetPlayerNames()
    {
        for (int i = 0; i < Players.Count; i++)
        {
            GameInputComponent input = Players[i];
            input.ResetPlayerName();
        }
    }

    private GameModeManager m_GameModeManager = null;
    private PlayerProfileManager m_PlayerProfileManager = null;

    public bool PlayerAddedThisFrame { get { return (m_JoystickAddedThisFrame || m_KeyboardAddedThisFrame); } }
    public bool CharacterSelectStartedThisFrame;

    //public 

    // The singleton instance of this class.
    private static InputManager s_Instance = null;
    // Mutex lock for CM Getter
    private static object s_InstanceLock = new object();

    private Event m_KeyEvent;
    private bool m_JoystickAddedThisFrame;
    private bool m_KeyboardAddedThisFrame;


    // A list of all current devices in use. Do not allow duplicate entries.
    // Having a reference to what is currently in use saves on time
    // while polling for new devices.
    private List<int> m_CurrentDevices;

    // ControlConfigurator needs to get these
    public JoystickState[] JoystickStates { get { return m_JoystickStates; } }
    private JoystickState[] m_JoystickStates;

    private GameObject m_LoadingScreen = null;

    private const string m_RespawnTagString = "Respawn";

    private const string StringManagersObject = "Managers";
    private const string StringPoolManager = "PoolManager";
    private const string StringParticleManager = "ParticleManager";
    private const string StringPrefabLoadingScreen = "Prefabs/LoadingScreen";

    private const string StringPlayersContainer = "PlayersContainer";

    private const string StringMainMenuScene = "MainMenuScene";
    private const string StringPauseMenuScene = "PauseMenuScene";
    private const string StringPauseMenuCanvas = "PauseMenuCanvas";

    private const string StringPlayerInput = "Player Input: ";
    private const string StringAIPlayer = "AI Player";

    private const string StringFPS = "FPS: ";

    private const string StringInstancedContainer = "InstancedObjectContainer";
    private static GameObject InstancedObjectContainer;

    void Awake()
    {
        if (s_Instance == null)
        {
            lock (s_InstanceLock)
            {
                if (s_Instance == null)
                {
                    // InputManager singleton created here

                    DontDestroyOnLoad(gameObject);
                    s_Instance = this;

                    // set up control manager once in this function
                    InitControlManager();
                }
            }
        }
        else if (s_Instance != null)
        {
            Destroy(gameObject);
        }
    }

    private void InitControlManager()
    {
        // GameModeManager
        m_GameModeManager = s_Instance.GetComponent<GameModeManager>();
        if (m_GameModeManager == null)
            m_GameModeManager = s_Instance.gameObject.AddComponent<GameModeManager>();

        // CameraManager
        CameraManager cameraManager = s_Instance.GetComponent<CameraManager>();
        if (cameraManager == null)
            cameraManager = s_Instance.gameObject.AddComponent<CameraManager>();

        //Loading Screen
        m_LoadingScreen = GameObject.Instantiate(Resources.Load(StringPrefabLoadingScreen) as GameObject, Vector3.zero, Quaternion.identity) as GameObject;

        // Audio Source
        AudioSource audioSource = s_Instance.GetComponent<AudioSource>();
        if (audioSource == null)
        {
            audioSource = s_Instance.gameObject.AddComponent<AudioSource>();
            audioSource.playOnAwake = false;
        }
        
        // Music Manager
        MusicManager musicManager = s_Instance.GetComponent<MusicManager>();
        if (musicManager == null)
            musicManager = s_Instance.gameObject.AddComponent<MusicManager>();

        // Audio Listener
        AudioListener audioListener = s_Instance.GetComponent<AudioListener>();
        if (audioListener == null)
            audioListener = s_Instance.gameObject.AddComponent<AudioListener>();

        //Dialogue Manager
        DialogueManager dialogueManager = s_Instance.GetComponent<DialogueManager>();
        if (dialogueManager == null)
        {
            dialogueManager = s_Instance.gameObject.AddComponent<DialogueManager>();
            s_Instance.gameObject.AddComponent<DialogueInfo>();
        }

        // Kill Feed Service
        KillFeedService kfs = KillFeedService.Instance;
        kfs.gameObject.SetActive(true);

        // Set up lists and gamepad states

        Players = new List<GameInputComponent>();

        m_CurrentDevices = new List<int>();

        m_JoystickAddedThisFrame = false;
        m_KeyboardAddedThisFrame = false;

        m_JoystickStates = new JoystickState[MAX_LOCAL_HUMAN_PLAYERS];
        for (int i = 0; i < MAX_LOCAL_HUMAN_PLAYERS; i++)
        {
            // On different platforms, define different controller interfaces here.
            // On console platforms, the console manufacturer may define a specific input interface to adhere to.
            // See: https://docs.unity3d.com/Manual/PlatformDependentCompilation.html
            {
#if UNITY_EDITOR || UNITY_STANDALONE_WIN || UNITY_STANDALONE_OSX || UNITY_STANDALONE_LINUX
                // The XboxCtrlrInput interface is Windows/OSX/Linux Specific.
                m_JoystickStates[i] = new XboxCtrlrInput_JoystickState(i);
#elif WINDOWS_UWP || UNITY_XBOXONE
                // TODO: define this class
                // UWP apps on Xbox One use https://docs.microsoft.com/en-us/uwp/api/Windows.Gaming.Input.Gamepad
                m_ControllerStates[i] = new XboxOneInput_JoystickState(i);
#elif UNITY_PS4
                // TODO: define this class
                m_ControllerStates[i] = new PS4Input_JoystickState(i);
#endif

            }
        }

#if UNITY_EDITOR
        // If we are starting the game from PlayGame state, we want to just add a character by default.

        if (CurrentGameState == GameState.PlayGame && (Players.Count <= 0))
        {
            DebugManager.Log("Starting from GameScene! Setting up default configuration.", Developmer.Evan);

            // Need to create PoolManager and ParticleManager if they are not in the scene.
            GameObject poolManager = GameObject.Find(StringPoolManager);
            if (poolManager == null)
            {
                poolManager = new GameObject(StringPoolManager);
                poolManager.AddComponent<PoolManagerScript>();
            }

            GameObject particleManager = GameObject.Find(StringParticleManager);
            if (particleManager == null)
            {
                particleManager = new GameObject(StringParticleManager);
                particleManager.AddComponent<ParticleManager>();
            }

            // Adds a default player for testing
            GameInputComponent inputComponent = null;
            inputComponent = AddPlayer(PlayerType.KeyboardPlayer, InputDevice.Keyboard, false);
            inputComponent.Character = CharacterTypes.Quark;
            inputComponent.TeamIndex = 0;
            inputComponent = AddPlayer(PlayerType.JoystickPlayer, InputDevice.Joystick1);
            inputComponent.Character = CharacterTypes.Leeroy;
            inputComponent.TeamIndex = 1;
            inputComponent = AddPlayer(PlayerType.JoystickPlayer, InputDevice.Joystick2);
            inputComponent.Character = CharacterTypes.Paige;
            inputComponent.TeamIndex = 0;
            inputComponent = AddPlayer(PlayerType.JoystickPlayer, InputDevice.Joystick3);
            inputComponent.Character = CharacterTypes.Zeph;
            inputComponent.TeamIndex = 1;
            // Adds AI players
            //AddPlayer(PlayerType.AiPlayer, InputDevice.Undefined);
            //AddPlayer(PlayerType.AiPlayer, InputDevice.Undefined);
            //AddPlayer(PlayerType.AiPlayer, InputDevice.Undefined);
            //AddPlayer(PlayerType.AiPlayer, InputDevice.Undefined);
            //AddPlayer(PlayerType.AiPlayer, InputDevice.Undefined);
            //AddPlayer(PlayerType.AiPlayer, InputDevice.Undefined);
            //AddPlayer(PlayerType.AiPlayer, InputDevice.Undefined);
            //AddPlayer(PlayerType.AiPlayer, InputDevice.Undefined);

            // Sets a default game mode
            m_GameModeManager.TeamsEnabled = false;
            //BaseGameMode gameMode = manager.CreateGameMode(GameModeType.FreePlayGameMode);
            //KingOfTheHillGameMode gameMode = (KingOfTheHillGameMode)m_GameModeManager.CreateGameMode(GameModeType.KingOfTheHillGameMode);
            TerritoriesGameMode gameMode = (TerritoriesGameMode)m_GameModeManager.CreateGameMode(GameModeType.TerritoriesGameMode);
            gameMode.ScoreLimit = 50;
            //gameMode.KothHillRotationOption = HillRotationOption.Random;
            //gameMode.HillRotationInterval = 10;
            gameMode.TimeLimit = 0;
            m_GameModeManager.CurrentGameMode = gameMode;

            StartGame();
        }
#endif
    }

    public void RemoveAIPlayers()
    {
        // Remove AI Players if they exist
        for (int i = Players.Count - 1; i >= 0; i--)
        {
            if (Players[i].IsAI)
                DropPlayerAtIndex(i);
        }
    }

    public void CleanupGame(bool aPlayAgain = false)
    {
        // Need to remove Player components before switching over to the GameOver scene.
        // If not, AI character classes will throw a fit when trying to use NavMesh.
        for (int i = InputManager.CM.Players.Count - 1; i >= 0; i--)
        {
            GameInputComponent playerObject = InputManager.CM.Players[i];

            if (aPlayAgain == true)
            {
                playerObject.gameObject.SetActive(false);
                continue;
            }

            //if (aPlayAgain == false && playerObject.IsAI == true)
            //{
            //    // Destroy all AI players
            //    DropPlayerAtIndex(i);
            //    continue;
            //}

            // Destroy any previous Player object
            //Player player = playerObject.transform.GetComponentInChildren<Player>(true);
            Player player = playerObject.Input.Character;
            if (player != null)
            {
                DestroyImmediate(player.gameObject, true);
            }

            if (playerObject.Input.Character != null)
            {
                DestroyImmediate(playerObject.Input.Character, true);
                playerObject.Input.Character = null;
            }
        }

        // Cleanup Pool Manager objects
        GameObject PoolManager = GameObject.Find(StringPoolManager);
        if (PoolManager != null)
        {
            int poolManagerChildCount = PoolManager.transform.childCount;
#if UNITY_EDITOR
            DebugManager.Log("Destroying PoolManager objects", Developmer.Evan);
#endif
            for (int i = poolManagerChildCount - 1; i >= 0; i--)
            {
                Transform child = PoolManager.transform.GetChild(i);

                DestroyImmediate(child.gameObject, true);
            }

            //List<GameObject> pooledChildren = new List<GameObject>();
            //for (int i = 0; i < poolManagerChildCount; i++)
            //{
            //    Transform child = PoolManager.transform.GetChild(i);

            //    pooledChildren.Add(child.gameObject);
            //}
            //pooledChildren.ForEach(child => DestroyImmediate(child.gameObject, true));

            //Destroy(PoolManager);
        }

        // Clear out any instanced objects. i.e.
        // - Quark Turrets
        // - Quark Cameras
        // - Quark Traps
        // - Decals
        // - Smoke
        // etc.
        GameObject InstancedObjectContainer = InputManager.CM.GetInstancedObjectContainer();
        int childCount = InstancedObjectContainer.transform.childCount;
#if UNITY_EDITOR
        DebugManager.Log("Destroying instanced objects", Developmer.Evan);
#endif
        for (int i = childCount - 1; i >= 0; i--)
        {
            Transform child = InstancedObjectContainer.transform.GetChild(i);

            DestroyImmediate(child.gameObject, true);
        }

        //List<GameObject> instancedChildren = new List<GameObject>();
        //for (int i = 0; i < childCount; i++)
        //{
        //    Transform child = InstancedObjectContainer.transform.GetChild(i);

        //    instancedChildren.Add(child.gameObject);
        //}
        //instancedChildren.ForEach(child => DestroyImmediate(child.gameObject, true));
    }

    public GameObject GetInstancedObjectContainer()
    {
        if (InstancedObjectContainer == null)
        {
            InstancedObjectContainer = GameObject.Find(StringInstancedContainer);
            if (InstancedObjectContainer == null)
            {
                InstancedObjectContainer = new GameObject(StringInstancedContainer);
                DontDestroyOnLoad(InstancedObjectContainer);
            }
        }
        return InstancedObjectContainer;
    }

    // Update is called once per frame
    void Update()
    {
        // Update gamepad states
        for (int i = 0; i < MAX_LOCAL_HUMAN_PLAYERS; i++)
        {
            m_JoystickStates[i].Update();
        }

        switch (CurrentGameState)
        {
            case GameState.PlayerSelect:
                {
                    HandlePlayerSelect();
                    break;
                }
            case GameState.PlayGame:
                {
                    HandlePlayGame();
                    break;
                }
        }

        // Update realtime delta time - This gets updated when Time.timeScale = 0.
        float time = Time.realtimeSinceStartup;
        m_RealDeltaTime = time - m_LastRealtimeFrame;
        m_LastRealtimeFrame = time;

        GameMenu.s_SubmitButtonDelay -= m_RealDeltaTime;
        GameMenu.s_BackButtonDelay -= m_RealDeltaTime;

        if (GameMenu.s_SubmitButtonDelay < 0)
            GameMenu.s_SubmitButtonDelay = 0;
        if (GameMenu.s_BackButtonDelay < 0)
            GameMenu.s_BackButtonDelay = 0;
    }

    void LateUpdate()
    {
        CharacterSelectStartedThisFrame = false;
    }

    void HandlePlayerSelect()
    {
        m_JoystickAddedThisFrame = false;

        // Poll joysticks for new players
        if (CharacterSelectStartedThisFrame == false)
        {
            PollForNewJoysticks();
        }

        if (m_JoystickAddedThisFrame || m_KeyboardAddedThisFrame)
        {
            m_JoystickAddedThisFrame = false;
            m_KeyboardAddedThisFrame = false;

            // This prevents a player from being kicked right after they joined,
            // if the button they pressed was a back button.
            return;
        }

        m_KeyboardAddedThisFrame = false;
    }

    public void Pause(bool aIsGamePaused, int aPausedPlayerIndex = -1)
    {
        if (aIsGamePaused)
        {
            Time.timeScale = 0.0f;

            CurrentGameState = GameState.PauseGame;
            
            Cursor.visible = true;

            if (m_LoadingPauseMenu == false)
            {
                StartCoroutine(HandleLoadPauseMenu(aPausedPlayerIndex));
            }
        }
        else
        {
            Time.timeScale = 1.0f;

            CurrentGameState = GameState.PlayGame;

            Cursor.visible = false;
        }
    }

    IEnumerator HandleLoadPauseMenu(int aPausedPlayerIndex)
    {
        m_LoadingPauseMenu = true;

        SceneManager.LoadScene(StringPauseMenuScene, LoadSceneMode.Additive);

        // Wait one frame to let options scene get loaded
        // before trying to access GameObject from newly loaded scene.
        yield return null;

        GameObject pauseCanvas = GameObject.Find(StringPauseMenuCanvas);

        if (pauseCanvas != null)
        {
            PauseMenuManager pause = pauseCanvas.GetComponent<PauseMenuManager>();
            pause.PausedPlayerIndex = aPausedPlayerIndex;
            pause.UpdateTitleText();
        }

        m_LoadingPauseMenu = false;
    }

    public void QuitGame()
    {
        CurrentGameState = GameState.MainMenu;
        SceneManager.LoadScene(StringMainMenuScene);

        // Destroy all players
        for (int i = 0; i < Players.Count; i++)
        {
            // Remove first index each time since array is shrinking
            DropPlayerAtIndex(0);
        }
    }

    public void RemoveCharacterFromPlayerSlotAtIndex(int index)
    {
        if (index > Players.Count - 1)
            return;

        RemoveCharacterFromPlayerSlot(Players[index]);
    }

    // Removes the character from the player slot
    public void RemoveCharacterFromPlayerSlot(GameInputComponent playerObject)
    {
        if (playerObject != null)
        {
            playerObject.Character = CharacterTypes.MAX_CHARACTER_TYPES;

            // Destroy character if they have one
            if (playerObject.Input.Character != null)
            {
                Destroy(playerObject.Input.Character);
            }
        }
    }

    public void DropPlayerAtIndex(int index)
    {
        if (index > Players.Count - 1)
            return;

        DropPlayer(Players[index]);
    }

    // Removes the player slot - also deletes the child player prefab if it has one.
    public void DropPlayer(GameInputComponent playerObject)
    {
        if (playerObject != null)
        {
            if (playerObject.Input is PlayerInput)
            {
                PlayerInput playerInput = (PlayerInput)playerObject.Input;

                m_CurrentDevices.Remove((int)playerInput.Device);
            }
            playerObject.Input.DropPlayer();
            Destroy(playerObject.gameObject);
            Players.Remove(playerObject);
            Players.Sort(
                (input1, input2) => (input1.CompareTo(input2))
                );

            // Need this check or error will be thrown if not subscribed to.
            if (OnPlayerDropped != null)
            {
                OnPlayerDropped();
            }
        }
    }

    public void StartGame(bool aPlayAgain = false)
    {
        CleanupGame(aPlayAgain);
        
        // Ensure capped player count
        int maxPlayerCount = Mathf.Min(Players.Count, MAX_PLAYERS);
        
        CharacterStates[] states = new CharacterStates[maxPlayerCount];
        CharacterTypes[] types = new CharacterTypes[maxPlayerCount];
        
        for (int i = 0; i < maxPlayerCount; i++)
        {
            GameInputComponent playerObject = Players[i];
            playerObject.gameObject.SetActive(true);

            if (playerObject.IsAI)
                states[i] = CharacterStates.AIController;
            else
                states[i] = CharacterStates.HumanControlled;

            types[i] = playerObject.Character;
        }

        StartGame(states, types);
    }

    public void StartGame(CharacterStates[] aCharacterStates, CharacterTypes[] aCharacterTypes)
    {
        StartCoroutine(HandleStartGame(aCharacterStates, aCharacterTypes));
    }

    private const string LEEROY_CHARACTER_PREFAB_PATH = "Prefabs/Characters/Leeroy";
    private const string ZEPH_CHARACTER_PREFAB_PATH = "Prefabs/Characters/Zeph";
    private const string PAIGE_CHARACTER_PREFAB_PATH = "Prefabs/Characters/Paige";
    private const string QUARK_CHARACTER_PREFAB_PATH = "Prefabs/Characters/Quark";
    private const string AI_PREFIX = "AI: ";
    IEnumerator HandleStartGame(CharacterStates[] aCharacterStates, CharacterTypes[] aCharacterTypes)
    {
        // Ensure capped player count
        int maxPlayerCount = Mathf.Min(aCharacterStates.Length, MAX_PLAYERS);

        // Keeps player IDs in spawn point range at the beginning of each game.
        ResetPlayerID();

        for (int i = 0; i < maxPlayerCount; i++)
        {
            if (aCharacterStates[i] == CharacterStates.Inactive || aCharacterTypes[i] == CharacterTypes.MAX_CHARACTER_TYPES)
                continue;

            CharacterStates state = aCharacterStates[i];
            CharacterTypes type = aCharacterTypes[i];

            GameInputComponent inputComponent = Players[i];
            BaseInput input = inputComponent.Input;

            switch (state)
            {
                case CharacterStates.HumanControlled:
                    {
                        switch (type)
                        {
                            default:
                            case CharacterTypes.Leeroy:
                                input.AddPlayer(LEEROY_CHARACTER_PREFAB_PATH);
                                break;
                            case CharacterTypes.Quark:
                                input.AddPlayer(QUARK_CHARACTER_PREFAB_PATH);
                                break;
                            case CharacterTypes.Zeph:
                                input.AddPlayer(ZEPH_CHARACTER_PREFAB_PATH);
                                break;
                            case CharacterTypes.Paige:
                                input.AddPlayer(PAIGE_CHARACTER_PREFAB_PATH);
                                break;
                        }
                    }
                    break;
                case CharacterStates.AIController:
                    {
                        switch (type)
                        {
                            default:
                            case CharacterTypes.Leeroy:
                                input.AddPlayer(LEEROY_CHARACTER_PREFAB_PATH);
                                input.Character.gameObject.AddComponent<LeeroyAICharacter>();
                                break;
                            case CharacterTypes.Quark:
                                input.AddPlayer(QUARK_CHARACTER_PREFAB_PATH);
                                input.Character.gameObject.AddComponent<QuarkAICharacter>();
                                break;
                            case CharacterTypes.Zeph:
                                input.AddPlayer(ZEPH_CHARACTER_PREFAB_PATH);
                                input.Character.gameObject.AddComponent<ZephAICharacter>();
                                break;
                            case CharacterTypes.Paige:
                                input.AddPlayer(PAIGE_CHARACTER_PREFAB_PATH);
                                input.Character.gameObject.AddComponent<PaigeAICharacter>();
                                break;
                        }

                        HandleAISpawning(input.Character);
                        break;
                    }
                default:
#if UNITY_EDITOR
                    DebugManager.LogError("Character state at " + i + " is invalid: " + state.ToString(), Developmer.AllDevelopmers);
#endif
                    break;
            }

            inputComponent.SetNewPlayerID();
        }

        // GameModeManager - start game mode
        if (GameModeManager != null)
        {
            m_GameModeManager.RestartCurrentGameMode();
        }

        Time.timeScale = 1.0f;
        CurrentGameState = GameState.PlayGame;
        Cursor.visible = false;

        // Wait one frame for map to be set up.
        yield return null;

        // Make sure that the Brightness is set up correctly or a black screen may be displayed.
        OptionsManager.UpdateGameBrightness();

        // Enable players once the spawn points have been initialized.
        GameObject[] SpawnPoints = GameObject.FindGameObjectsWithTag(m_RespawnTagString);
        while (SpawnPoints == null || SpawnPoints.Length <= 0)
        {
            // Wait for map to be loaded before starting the game.
            yield return null;
            SpawnPoints = GameObject.FindGameObjectsWithTag(m_RespawnTagString);
        }

        Information.ClearCachedValues();

        // Initial player spawn
        m_GameModeManager.InitialPlayerSpawn();

        // Make Split Screen Cameras work
        CameraManager cameraManager = GetComponent<CameraManager>();
        if (cameraManager != null)
        {
            cameraManager.UpdateCameraPositions();
        }
#if UNITY_EDITOR
        else
        {
            DebugManager.LogError("InputManager.StartGame(): Camera Manager is null!", Developmer.AllDevelopmers);
        }
#endif
    }

    void HandleAISpawning(Player aAI)
    {
        aAI.name = AI_PREFIX + aAI.name;
        aAI.GetComponent<AICharacter>().CharactersFirstPersonCamera = aAI.FirstPersonPlayerCamera;
        {
            Camera[] cameras = aAI.GetComponentsInChildren<Camera>();
            for (int i = 0; i < cameras.Length; i++)
            {
                Camera c = cameras[i];

                c.enabled = false;

                MonoBehaviour[] behaviours = c.GetComponents<MonoBehaviour>();
                MonoBehaviour[] childBehaviours = c.GetComponentsInChildren<MonoBehaviour>();

                for (int componentIndex = 0; componentIndex < behaviours.Length; componentIndex++)
                {
                    MonoBehaviour component = behaviours[componentIndex];
                    
                    component.enabled = false;
                }
                for (int componentIndex = 0; componentIndex < childBehaviours.Length; componentIndex++)
                {
                    MonoBehaviour component = childBehaviours[componentIndex];

                    component.enabled = false;
                }

                FirstPersonCamera cam = c.GetComponent<FirstPersonCamera>();

                if (cam != null)
                {
                    cam.enabled = true;
                    cam.XMouseSensitivity = 5;
                    cam.YMouseSensitivity = 5;
                }
            }
        }

        {
            DamageBeamScript[] bs = aAI.GetComponentsInChildren<DamageBeamScript>();
            UVScrollScript[] uvs = aAI.GetComponentsInChildren<UVScrollScript>();

            for (int i = 0; i < bs.Length; i++)
                bs[i].enabled = true;
            for (int i = 0; i < uvs.Length; i++)
                uvs[i].enabled = true;
        }

        {
            Canvas[] canvasArray = aAI.GetComponentsInChildren<Canvas>();
            for (int i = 0; i < canvasArray.Length; i++)
            {
                Canvas c = canvasArray[i];

                c.gameObject.SetActive(false);
            }
        }
    }

    void PollForNewJoysticks()
    {
        int numPlayers = Players.Count;

        // Poll for input on all joysticks to add new players (max of 4 including keyboard)
        if (numPlayers < MAX_LOCAL_HUMAN_PLAYERS)
        {
            // Poll each joystick (from 1 to 4) for input.
            for (int joystickIndex = 0; joystickIndex < MAX_LOCAL_HUMAN_PLAYERS; joystickIndex++)
            {
                // Record which joystick is currently being checked
                InputDevice device = (InputDevice)(((int)InputDevice.Joystick1) + joystickIndex);

                if (m_CurrentDevices.Contains((int)device) == false)
                {
                    JoystickState state = JoystickStates[joystickIndex];

                    // Loop over the list of button states

                    for (int buttonIndex = 0; buttonIndex < state.Buttons.Length; buttonIndex++)
                    {
                        // Ignore B button, as this is a cancel button
                        if (buttonIndex == JoystickMap.BUTTON_B)
                            continue;

                        if (state.ButtonPressed(buttonIndex))
                        {
                            StartCoroutine(HandlePollForNewPlayer(PlayerType.JoystickPlayer, device, false));

                            m_JoystickAddedThisFrame = true;

                            return;
                        }
                    }
                }
            }
        }
    }

    IEnumerator HandlePollForNewPlayer(PlayerType aPlayerType, InputDevice aInputDevice, bool aSortPlayerListAfterAdding = true)
    {
        yield return null;

        // Secondary check to make sure this device has not been added previously
        if (CurrentDevices.Contains((int)aInputDevice) == false)
        {
            AddPlayer(aPlayerType, aInputDevice, aSortPlayerListAfterAdding);
        }

        // Wait one frame so that action button for this player is not executed same frame player is added.
        yield return null;
    }

    public GameInputComponent AddPlayer(PlayerType aPlayerType, InputDevice aDevice = InputDevice.Undefined, bool aSortPlayerListAfterAdding = true)
    {
        if (Players.Count >= MAX_PLAYERS)
        {
            return null;
        }

        string playerDummyName;
        
        GameInputComponent inputComponent = null;

        if (aDevice != InputDevice.Undefined)
        {
            playerDummyName = StringPlayerInput + aDevice;
        }
        else
        {
            playerDummyName = StringAIPlayer;
        }

        GameObject playerDummy = new GameObject(playerDummyName);
        DontDestroyOnLoad(playerDummy);

        inputComponent = playerDummy.AddComponent<GameInputComponent>();
        inputComponent.SetNewPlayerID();

        inputComponent.Character = (CharacterTypes)0;

        if (aDevice != InputDevice.Undefined)
        {
            PlayerInput playerInput = new PlayerInput(inputComponent);
            playerInput.Device = aDevice;

            InputDeviceType deviceType = (aDevice == InputDevice.Keyboard ? InputDeviceType.Keyboard : InputDeviceType.Joystick);

            DefaultControls.SetupDefaultControlConfigurationsForPlayer(playerInput, deviceType);

            inputComponent.Input = playerInput;

            m_CurrentDevices.Add((int)aDevice);
        }
        else
        {
            AiInput aiInput = new AiInput(inputComponent);

            inputComponent.Input = aiInput;
        }

        Players.Add(inputComponent);

        if (aSortPlayerListAfterAdding)
        {
            Players.Sort(
                (input1, input2) => (input1.CompareTo(input2))
                );
        }

        // The only reason the list would have more than 8 would be if ai players were added first and human players were added second.
        // Human players are sorted to the front of the list so there is no risk of deleting a human player.
        // This also caps the player count at 8.
        while (Players.Count > MAX_PLAYERS)
        {
            DropPlayerAtIndex(Players.Count - 1);
        }

        // Clean up Hierarchy by parenting the players to a single game object.
        GameObject PlayersContainer = GameObject.Find(StringPlayersContainer);
        if (PlayersContainer == null)
        {
            PlayersContainer = new GameObject(StringPlayersContainer);
            DontDestroyOnLoad(PlayersContainer);
        }
        inputComponent.gameObject.transform.SetParent(PlayersContainer.transform);

        // Need this check or error will be thrown if not subscribed to.
        if (OnPlayerAdded != null)
        {
            OnPlayerAdded();
        }

        return inputComponent;
    }

    void HandlePlayGame()
    {
        // Poll each player for the pause input
        for (int i = 0; i < Players.Count; i++)
        {
            GameInputComponent input = Players[i];

            if (input.IsAI == false)
            {
                // Poll each player for the pause input and switch to Pause State
                if (input.GetInput(InputName.Menu_Pause, InputType.ButtonPressed) != 0.0f ||
                    input.GetInput(InputName.Menu_Alt_Pause, InputType.ButtonPressed) != 0.0f)
                {
                    Pause(true, i);

                    return;
                }
            }
        }
    }

    // GUI Methods

    void OnGUI()
    {
        GUI.Label(GuiBox, BuildVersion);

        if (OptionsManager.VisibleFPS == true)
        {
            int fps = ((int)(Mathf.Floor(1.0f / Time.smoothDeltaTime)));
            if (fps < 0 || Time.timeScale == 0.0f)
                fps = 0;

            GUI.Label(new Rect(5, 20, Screen.width, Screen.height), StringFPS + fps.ToString());
        }

        switch (CurrentGameState)
        {
            // Check for a new Keyboard player being added.
            case GameState.PlayerSelect:
                {
                    if (CharacterSelectStartedThisFrame == false)
                        PollForNewKeyboard();
                    break;
                }
        }
    }

    void PollForNewKeyboard()
    {
        // Event.current only works during OnGUI, therefore we can only poll for players from OnGUI.

        // Poll for input on keyboard to add a new player.
        if (Players.Count < MAX_LOCAL_HUMAN_PLAYERS)
        {
            // Poll keyboard for input
            if (m_CurrentDevices.Contains((int)InputDevice.Keyboard) == false)
            {
                m_KeyEvent = Event.current;

                if ((m_KeyEvent.isKey && m_KeyEvent.keyCode != KeyCode.Escape && Input.GetKeyDown(m_KeyEvent.keyCode)) ||
                    // Shift keys are not reported by this KeyEvent so we need to check manually.
                    Input.GetKey(KeyCode.LeftShift) ||
                    Input.GetKey(KeyCode.RightShift))
                {
                    StartCoroutine(HandlePollForNewPlayer(PlayerType.KeyboardPlayer, InputDevice.Keyboard, false));

                    //AddPlayer(PlayerType.KeyboardPlayer, InputDevice.Keyboard);

                    m_KeyboardAddedThisFrame = true;

                    return;
                }
            }
        }
    }

    /*******************************************************\
    * Misc. Methods                                         *
    \*******************************************************/

    // Events on Adding and Dropping players

    public delegate void AddPlayerDelegate();
    public event AddPlayerDelegate OnPlayerAdded;

    public delegate void DropPlayerDelegate();
    public event DropPlayerDelegate OnPlayerDropped;
}