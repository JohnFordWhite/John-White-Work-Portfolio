﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class CreditsScript : GameMenu
{
    public GameObject ScrollingPanel;

    public float ScrollingSpeed = 100.0f;

    private float m_ScrollAmount = 0.0f;

    private bool m_DoneScrolling = false;

    private const string StringMainMenuScene = "MainMenuScene";

    private RectTransform m_ScrollingPanelRect;

	// Use this for initialization
	protected override void Start ()
    {
        base.Start();

        EnableNavigation();
	}
	
	// Update is called once per frame
	protected override void Update ()
    {
        base.Update();

        if (m_DoneScrolling == false)
        {
            if (EnableInputs == true && IsSubmitButtonPressed())
            {
                TryCurrentSelectableOnClick();
                return;
            }

            if (IsCancelButtonPressed())
            {
                Return();
                return;
            }

            float scrollDelta = ScrollingSpeed * Time.deltaTime;
            m_ScrollAmount += scrollDelta;

            // Scroll the panel
            if (m_ScrollingPanelRect == null)
                m_ScrollingPanelRect = ScrollingPanel.GetComponent<RectTransform>();
            
            Vector2 position = m_ScrollingPanelRect.anchoredPosition;
            position.y += ScrollingSpeed * Time.deltaTime;
            m_ScrollingPanelRect.anchoredPosition = position;

            // Check if the credits have finished scrolling.
            // Navigate back to the MainMenuScene when done.
            if (m_ScrollAmount > m_ScrollingPanelRect.rect.height)
            {
                Return();
            }
        }
	}

    public void Return()
    {
        if (m_DoneScrolling == false)
        {
            EnableInputs = false;

            m_DoneScrolling = true;

            SceneManager.LoadScene(StringMainMenuScene);
        }
    }
}
