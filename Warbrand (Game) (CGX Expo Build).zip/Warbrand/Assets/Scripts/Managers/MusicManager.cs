﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        MusicManager                                                                  *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            February 3rd, 2017                                                             *
 *                                                                                                 *
 * This class handles the switching of music between scenes, as well as playing "game almost over" *
 * music, based on the game mode in progress.                                                      *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - February 3rd, 2017                                          *
\***************************************************************************************************/

using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using UnityEngine.Audio;

public class MusicManager : MonoBehaviour
{
    public static MusicManager Instance { get { return s_Instance; } }
    public static MusicManager s_Instance = null;
    private AudioClip m_IntroClip;
    private AudioClip m_MainMenuClip;
    private AudioClip m_GameEndingClip;
    private AudioClip m_TutorialClip;
    private AudioClip m_GameoverClip;

    private AudioSource m_AudioSource;
    private GameModeManager m_GameModeManager;
    private bool m_CanCheckGameEndMusic = false;
    private float m_GameTime;
    private float m_GameEndingMusicFadeInTime = 30;

    private static object s_InstanceLock = new object();

    private const string m_AudioMixerResource = "AudioMixer";
    private const string m_MusicGroup = "Music";

    private const string m_MainMenuMusicResource = "Audio/Music/main_menu_music";
    private const string m_GameEndingMusicResource = "Audio/Music/game_ending_music";
    private const string m_GameOverMusicResource = "Audio/Music/game_over_music";
    private const string m_SplashIntroMusicResource = "Audio/Music/splash_intro_music";

    private const string m_SplashScreenName = "SplashScreen";
    private const string m_MainMenuSceneName = "MainMenuScene";
    private const string m_CharacterSelectScene = "CharacterSelectionScene";
    private const string m_GameSceneName = "GameScene";
    private const string m_GameOverSceneName = "GameOverScene";

    void Awake()
    {
        if (s_Instance == null)
        {
            lock (s_InstanceLock)
            {
                if (s_Instance == null)
                {
                    DontDestroyOnLoad(gameObject);
                    s_Instance = this;
                }
            }
        }
        else if (s_Instance != null)
        {
            Destroy(gameObject);
        }
    }

    void OnEnable()
    {
        SceneManager.activeSceneChanged += HandleSceneMusicChange;

        m_AudioSource = GetComponent<AudioSource>();
    }

    void Start()
    {
        AudioMixer mixer = Resources.Load(m_AudioMixerResource) as AudioMixer;
        m_AudioSource.outputAudioMixerGroup = mixer.FindMatchingGroups(m_MusicGroup)[0];

        m_GameModeManager = InputManager.CM.GameModeManager;
        
        m_MainMenuClip = Resources.Load(m_MainMenuMusicResource) as AudioClip;
        m_GameEndingClip = Resources.Load(m_GameEndingMusicResource) as AudioClip;
        m_GameoverClip = Resources.Load(m_GameOverMusicResource) as AudioClip;
    }

    void Update()
    {
        if (m_GameModeManager.CurrentGameMode != null && m_CanCheckGameEndMusic)
        {
            m_GameTime = m_GameModeManager.CurrentGameMode.ElapsedTime;
            if (m_GameModeManager.CurrentGameMode.TimeLimit - m_GameTime <= 120)
            {
                StartCoroutine(AudioUtils.FadeIn(m_AudioSource,0, 1, m_GameEndingMusicFadeInTime));
                m_AudioSource.Play();
                m_CanCheckGameEndMusic = false;
            }

            //Debug.Log(m_GameModeManager.CurrentGameMode.TimeLimit + "   " + m_GameTime);
        }
    }

    void HandleSceneMusicChange(Scene aOldScene, Scene aNewScene)
    {
        //Debug.Log("active scene changed to " + aNewScene.name);
        m_CanCheckGameEndMusic = false;

        switch (aNewScene.name)
        {
            case m_SplashScreenName:
                m_AudioSource.clip = Resources.Load(m_SplashIntroMusicResource) as AudioClip;
                m_AudioSource.loop = false;
                m_AudioSource.Play();
                break;
            case m_MainMenuSceneName:
                if (m_AudioSource.clip != m_MainMenuClip)
                {
                    m_AudioSource.clip = m_MainMenuClip;
                    m_AudioSource.loop = true;
                    m_AudioSource.Play();
                }
                break;
            case m_CharacterSelectScene:
                if (m_AudioSource.clip != m_MainMenuClip)
                {
                    m_AudioSource.clip = m_MainMenuClip;
                    m_AudioSource.loop = true;
                    m_AudioSource.Play();
                }
                break;
            case m_GameSceneName:
                m_AudioSource.Stop();
                m_AudioSource.clip = m_GameEndingClip;
                m_AudioSource.loop = true;
                if (m_GameModeManager != null)
                {
                    if (m_GameModeManager.CurrentGameMode.TimeLimit > 0)
                        m_CanCheckGameEndMusic = true;
                }
                break;
            case m_GameOverSceneName:
                m_AudioSource.clip = m_GameoverClip;
                m_AudioSource.loop = true;
                m_AudioSource.Play();
                break;
            default:
                break;
        }
    }
    void OnDestroy()
    {
        SceneManager.activeSceneChanged -= HandleSceneMusicChange;
    }
}
