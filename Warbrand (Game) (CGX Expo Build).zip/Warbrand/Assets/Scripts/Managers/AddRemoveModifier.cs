﻿using UnityEngine;
using System.Collections;

using System.Collections.Generic;

public static class AddRemoveModifier
{
    public static void AddModifier(ref List<float> modifierList, float modifier)
    {
        for (int i = 0; i < modifierList.Capacity; i++)
        {
            if (modifierList[i] == 0.0f)
            {
                modifierList[i] = modifier;
                return;
            }
        }
    }

    public static void RemoveModifier(ref List<float> modifierList, float modifier)
    {
        for (int i = 0; i < modifierList.Capacity; i++)
        {
            if (modifierList[i] == modifier)
            {
                modifierList[i] = 0.0f;
                return;
            }
        }
    }

    public static void UpdateModifierPercent(ref List<float> modifierList, ref float modifierPercent)
    {
        //Determine how abilities are affecting the player's movementspeed;
        modifierPercent = 1;
        for (int i = 0; i < modifierList.Capacity; i++)
        {
            modifierPercent += modifierList[i];
        }

        //Total modifiers can't add up to less than 10%
        //otherwise you run into weird issues of healing when taking damage and moving backwards
        if (modifierPercent < 0.1f)
        {
            modifierPercent = 0.1f;
        }
    }

    public static void RemoveAllModifiers(ref List<float> modifierList)
    {
        for (int i = 0; i < modifierList.Count; i++)
        {
            modifierList[i] = 0.0f;
        }
    }
}
