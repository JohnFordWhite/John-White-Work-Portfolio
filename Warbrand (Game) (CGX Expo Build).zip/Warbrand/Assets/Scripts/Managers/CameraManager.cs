﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class CameraManager : MonoBehaviour
{
    public List<Camera> Cameras { get; private set; }
    public List<Camera> XRayCameras { get; private set; }
    public List<Camera> OutlineCameras { get; private set; }
    public List<Camera> FirstPersonModelCameras { get; private set; }
    public List<Camera> UICameras { get; private set; }
    public List<Canvas> UICanvases { get; private set; }

    private Vector2 m_ReferenceResolution;

	void Start ()
    {
        m_ReferenceResolution = new Vector2(800, 450);
        Cameras = new List<Camera>();
        XRayCameras = new List<Camera>();
        OutlineCameras = new List<Camera>();
        FirstPersonModelCameras = new List<Camera>();
        UICameras = new List<Camera>();
        UICanvases = new List<Canvas>();
        UpdateCameraPositions();
	}

    void Update()
    {
#if UNITY_EDITOR
        if (Input.GetKeyDown(KeyCode.P))
            UpdateCameraPositions();
#endif

        if (InputManager.CM.GameModeManager.CurrentGameMode != null &&
            InputManager.CM.GameModeManager.CurrentGameMode.GameCondition == GameCondition.GameInProgress)
            UpdateUIScale();
    }
	
    public float GetCanvasRatioForPlayer(Player aPlayer)
    {
        float ratio = 1.0f;

        List<Player> players = Information.AllHumanPlayers;

        if (players.Count == 1 || players.Count == 4)
        {
            return (Screen.width / Screen.height) * 2.0f;
        }
        else if (players.Count == 2)
        {
            return (Screen.width * 2.0f) / Screen.height;
        }
        else if (players.Count == 3)
        {
            if (aPlayer == players[0])
            {
                return (Screen.width * 2.0f) / Screen.height;
            }
            else
            {
                return (Screen.width / Screen.height) * 2.0f;
            }
        }

        return ratio;
    }

	public void UpdateCameraPositions()
    {
        // HACK: See comment inside the coroutine
        StartCoroutine(HandleUpdateCameraPositions());
    }

    IEnumerator HandleUpdateCameraPositions()
    {
        // This gives the Player objects a chance to get instantiated.
        yield return null;

        Cameras.Clear();
        XRayCameras.Clear();
        OutlineCameras.Clear();
        FirstPersonModelCameras.Clear();
        UICameras.Clear();
        UICanvases.Clear();

        List<Player> players = Information.AllHumanPlayers;
        
        for (int i = 0; i < players.Count; i++)
        {
            Player player = players[i];

            Cameras.Add(player.PlayerCamera);
            XRayCameras.Add(player.XRayCamera);
            OutlineCameras.Add(player.OutlineCamera);
            FirstPersonModelCameras.Add(player.FirstPersonModelCamera);
            UICameras.Add(player.UICamera);
            UICanvases.Add(player.UICanvas);
        }

        //Resize all normal cameras
        for (int i = 0; i < Cameras.Count; i++)
        {
            if (Cameras[i] == null)
                continue;

            Rect rect = Cameras[i].rect;
            //Canvas UICanvas = UICanvases[i];

            if (Cameras.Count == 1)
            {
                if (i == 0)
                {
                    rect.x = 0;
                    rect.y = 0;
                    rect.width = 1;
                    rect.height = 1;
                }
            }
            else if (Cameras.Count == 2)
            {
                if (i == 0)
                {
                    rect.x = 0;
                    rect.y = 0.5f;
                    rect.width = 1;
                    rect.height = 0.5f;
                }
                else if (i == 1)
                {
                    rect.x = 0;
                    rect.y = 0;
                    rect.width = 1;
                    rect.height = 0.5f;
                }
            }
            else if (Cameras.Count == 3)
            {
                if (i == 0)
                {
                    rect.x = 0.0f;
                    rect.y = 0.5f;
                    rect.width = 1.0f;
                    rect.height = 0.5f;
                }
                else if (i == 1)
                {
                    rect.x = 0;
                    rect.y = 0;
                    rect.width = 0.5f;
                    rect.height = 0.5f;
                }
                else if (i == 2)
                {
                    rect.x = 0.5f;
                    rect.y = 0.0f;
                    rect.width = 0.5f;
                    rect.height = 0.5f;
                }
            }
            else
            {
                if (i == 0)
                {
                    rect.y = 0.5f;
                    rect.x = 0.0f;
                    rect.width = 0.5f;
                    rect.height = 0.5f;
                }
                else if (i == 1)
                {
                    rect.x = 0.5f;
                    rect.y = 0.5f;
                    rect.width = 0.5f;
                    rect.height = 0.5f;
                }
                else if (i == 2)
                {
                    rect.x = 0.0f;
                    rect.y = 0.0f;
                    rect.width = 0.5f;
                    rect.height = 0.5f;
                }
                else if (i == 3)
                {
                    rect.x = 0.5f;
                    rect.y = 0.0f;
                    rect.width = 0.5f;
                    rect.height = 0.5f;
                }
            }

            Cameras[i].rect = rect;
            XRayCameras[i].rect = rect;
            OutlineCameras[i].rect = rect;
            FirstPersonModelCameras[i].rect = rect;
            UICameras[i].rect = rect;
        }

        yield return null;
    }

    void UpdateUIScale()
    {
        for (int i = 0; i < Cameras.Count; i++)
        {
            //Calculate the scale amount for the UI
            float scale = 1;
            float xScale;
            float yScale;
            xScale = (float)Screen.width / m_ReferenceResolution.x;
            yScale = (float)Screen.height / m_ReferenceResolution.y;

            scale = (xScale + yScale) / 2;

            if (UICanvases[i] != null && Cameras[i] != null)
                UICanvases[i].scaleFactor = scale * (0.5f * Cameras[i].rect.height + 0.5f * Cameras[i].rect.width);
        }
    }

    public void HidePlayerCameras()
    {
        StartCoroutine(HandleHidePlayerCameras());
    }

    IEnumerator HandleHidePlayerCameras()
    {
        yield return null;

        Cameras.Clear();
        XRayCameras.Clear();
        OutlineCameras.Clear();
        FirstPersonModelCameras.Clear();
        UICameras.Clear();
        UICanvases.Clear();

        List<Player> players = Information.AllHumanPlayers;
        
        for (int i = 0; i < players.Count; i++)
        {
            Player player = players[i];

            Cameras.Add(player.PlayerCamera);
            XRayCameras.Add(player.XRayCamera);
            OutlineCameras.Add(player.OutlineCamera);
            FirstPersonModelCameras.Add(player.FirstPersonModelCamera);
            UICameras.Add(player.UICamera);
            UICanvases.Add(player.UICanvas);
        }

        // Hide all cameras by resizing them.

        Rect hiddenCameraRect = new Rect(0.0f, 0.0f, 0.0f, 0.0f);

        for (int i = 0; i < Cameras.Count; i++)
        {
            if (Cameras[i] == null)
                continue;

            Cameras[i].rect = hiddenCameraRect;
            XRayCameras[i].rect = hiddenCameraRect;
            OutlineCameras[i].rect = hiddenCameraRect;
            FirstPersonModelCameras[i].rect = hiddenCameraRect;
            UICameras[i].rect = hiddenCameraRect;
        }
    }

    // Helper to update the camera positions in a menu screen, i.e. the CharacterSelectionScene.
    // Cameras passed in are not cameras linked to a player prefab but are loose camera objects in the scene.
    public static void UpdateMenuCameraPositions(Camera[] aPlayerCameras, bool aMakePlayer1CameraFullScreen = false)
    {
        int playerCount = InputManager.CM.Players.Count;

        for (int i = 0; i < aPlayerCameras.Length; i++)
        {
            if (aPlayerCameras[i] == null)
                continue;

            Rect rect = aPlayerCameras[i].rect;
            //Canvas UICanvas = UICanvases[i];

            if (aMakePlayer1CameraFullScreen == false)
            {
                if (playerCount == 1)
                {
                    if (i == 0)
                    {
                        rect.x = 0;
                        rect.y = 0;
                        rect.width = 1;
                        rect.height = 1;
                    }
                }
                else if (playerCount == 2)
                {
                    if (i == 0)
                    {
                        rect.x = 0;
                        rect.y = 0.5f;
                        rect.width = 1;
                        rect.height = 0.5f;
                    }
                    else if (i == 1)
                    {
                        rect.x = 0;
                        rect.y = 0;
                        rect.width = 1;
                        rect.height = 0.5f;
                    }
                }
                else if (playerCount == 3)
                {
                    if (i == 0)
                    {
                        rect.x = 0.0f;
                        rect.y = 0.5f;
                        rect.width = 1.0f;
                        rect.height = 0.5f;
                    }
                    else if (i == 1)
                    {
                        rect.x = 0;
                        rect.y = 0;
                        rect.width = 0.5f;
                        rect.height = 0.5f;
                    }
                    else if (i == 2)
                    {
                        rect.x = 0.5f;
                        rect.y = 0.0f;
                        rect.width = 0.5f;
                        rect.height = 0.5f;
                    }
                }
                else
                {
                    if (i == 0)
                    {
                        rect.y = 0.5f;
                        rect.x = 0.0f;
                        rect.width = 0.5f;
                        rect.height = 0.5f;
                    }
                    else if (i == 1)
                    {
                        rect.x = 0.5f;
                        rect.y = 0.5f;
                        rect.width = 0.5f;
                        rect.height = 0.5f;
                    }
                    else if (i == 2)
                    {
                        rect.x = 0.0f;
                        rect.y = 0.0f;
                        rect.width = 0.5f;
                        rect.height = 0.5f;
                    }
                    else if (i == 3)
                    {
                        rect.x = 0.5f;
                        rect.y = 0.0f;
                        rect.width = 0.5f;
                        rect.height = 0.5f;
                    }
                }
            }
            // If there are more than 1 players active, this ensures that only the 1P camera
            // is visible and fills the whole screen.
            else
            {
                if (i == 0)
                {
                    rect.x = 0;
                    rect.y = 0;
                    rect.width = 1;
                    rect.height = 1;
                }
                // Hides other cameras off screen
                else
                {
                    rect.x = 1;
                    rect.y = 1;
                    rect.width = 0;
                    rect.height = 0;
                }
            }

            aPlayerCameras[i].rect = rect;
        }
    }
}
