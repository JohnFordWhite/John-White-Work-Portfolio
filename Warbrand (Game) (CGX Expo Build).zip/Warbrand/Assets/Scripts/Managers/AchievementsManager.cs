﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public enum Achievements
{
    // The first four bits represent the achievement.
    // The second four bits represent the manner in which
    // the achievement tracks (See tracking types)

    DamageGiven = 17,       // 0001 0001
    DamageTaken = 33,       // 0010 0001
    TimeInAdhesive = 49,    // 0011 0001
    MostHealthHealed = 65,  // 0100 0001
    KilledByGasTrap = 114,  // 0111 0010
    KilledBySpikeTrap = 130,// 1000 0010
    KilledByFan = 146,      // 1001 0010
    TimesShotByTurret = 162,// 1010 0010
    TimesTrapped = 178,     // 1011 0010
    TimeSeenByCamera = 193, // 1100 0001
    TimeInSmokescreen = 209,// 1101 0001
    TimePoisoned = 225,     // 1110 0001
    MAX_ACHIEVEMENTS
}

public static class AchievementsManager
{
    public static string GetStringForAchievement(Achievements aAchievement)
    {
        switch (aAchievement)
        {
            case Achievements.DamageGiven:
                return "Damage Given";
            case Achievements.DamageTaken:
                return "Damage Taken";
            case Achievements.TimeInAdhesive:
                return "Time In Adhesive";
            case Achievements.MostHealthHealed:
                return "Most Health Healed";
            case Achievements.KilledByGasTrap:
                return "Killed By Gas Trap";
            case Achievements.KilledBySpikeTrap:
                return "Killed By Spike Trap";
            case Achievements.KilledByFan:
                return "Killed By Fan";
            case Achievements.TimesShotByTurret:
                return "Times Shot By Turret";
            case Achievements.TimesTrapped:
                return "Times Trapped";
            case Achievements.TimeSeenByCamera:
                return "Time Seen By Camera (Seconds)";
            case Achievements.TimeInSmokescreen:
                return "Time In Smokescreen";
            case Achievements.TimePoisoned:
                return "Time Poisoned";
            default:
#if UNITY_EDITOR
                DebugManager.LogWarning("No achievement string for: " + aAchievement.ToString(), Developmer.AllDevelopmers);
#endif
                break;
        }

        return aAchievement.ToString();
    }

    // This is done this way in case we want to add 
    // different achievements that need different
    // tracking in the future.
    private enum TrackingTypes
    {
        FloatIncrement = 1,             // 0001
        IntegerIncrement = 2,           // 0010
    }

    public static Dictionary<Achievements, Dictionary<Player, int>> IntegerAchievements;
    public static Dictionary<Achievements, Dictionary<Player, float>> FloatAchievements;

    public static void ResetValues()
    {
        Player[] players = Information.AllPlayers.ToArray();
        IntegerAchievements = new Dictionary<Achievements, Dictionary<Player, int>>();
        FloatAchievements = new Dictionary<Achievements, Dictionary<Player, float>>();
        foreach (Achievements ach in Enum.GetValues(typeof(Achievements)))
        {
            switch (GetAchievementTrackingType(ach))
            {
                case TrackingTypes.FloatIncrement:
                    FloatAchievements.Add(ach, new Dictionary<Player, float>());
                    foreach (var player in players)
                        FloatAchievements[ach].Add(player, 0f);
                    break;
                case TrackingTypes.IntegerIncrement:
                    IntegerAchievements.Add(ach, new Dictionary<Player, int>());
                    foreach (var player in players)
                        IntegerAchievements[ach].Add(player, 0);
                    break;
            }
        }
    }

    public static void IncrementInteger(Player aPlayer, Achievements aAchievement, int aIncrement)
    {
        if (aIncrement <= 0)
            return;

        if (GetAchievementTrackingType(aAchievement) != TrackingTypes.IntegerIncrement)
        {
#if UNITY_EDITOR
            DebugManager.LogError("Achievement Type " + aAchievement.ToString() + " has a tracking type of " + ((TrackingTypes)((int)(aAchievement) & 15)).ToString(), Developmer.AllDevelopmers);
#endif
            return;
        }
        if (IntegerAchievements == null || aPlayer == null)
            return;
        if (!(IntegerAchievements.ContainsKey(aAchievement)))
            return;
        if (!(IntegerAchievements[aAchievement].ContainsKey(aPlayer)))
            return;

        IntegerAchievements[aAchievement][aPlayer] += aIncrement;
    }

    public static void IncrementFloat(Player aPlayer, Achievements aAchievement, float aIncrement)
    {
        if (aIncrement <= 0)
            return;

        if (GetAchievementTrackingType(aAchievement) != TrackingTypes.FloatIncrement)
        {
#if UNITY_EDITOR
            DebugManager.LogError("Achievement Type " + aAchievement.ToString() + " has a tracking type of " + ((TrackingTypes)((int)(aAchievement) & 15)).ToString(), Developmer.AllDevelopmers);
#endif
            return;
        }
        if (FloatAchievements == null || aPlayer == null)
            return;
        if (!(FloatAchievements.ContainsKey(aAchievement)))
            return;
        if (!(FloatAchievements[aAchievement].ContainsKey(aPlayer)))
            return;

        FloatAchievements[aAchievement][aPlayer] += aIncrement;
    }

    private static TrackingTypes GetAchievementTrackingType(Achievements aAchievement)
    {
        return (TrackingTypes)((int)(aAchievement) & 15);
    }

    private static Player GetHighestPlayerForAchievement(Achievements aAchievement)
    {
        Player playerToReturn = null;
        float highestValue = 0f;
        switch (GetAchievementTrackingType(aAchievement))
        {
            case TrackingTypes.FloatIncrement:
                foreach (var ach in FloatAchievements[aAchievement])
                {
                    if (ach.Value > highestValue)
                    {
                        highestValue = ach.Value;
                        playerToReturn = ach.Key;
                    }
                }
                break;
            case TrackingTypes.IntegerIncrement:
                foreach (var ach in IntegerAchievements[aAchievement])
                {
                    if (ach.Value > highestValue)
                    {
                        highestValue = ach.Value;
                        playerToReturn = ach.Key;
                    }
                }
                break;
        }

        return playerToReturn;
    }

    public static Achievement[] GetRandomAchievements(ref int aNumberOfAchievements)
    {
        List<Achievements> achievements = new List<Achievements>();
        if (IntegerAchievements != null)
        {
            foreach (var ach in IntegerAchievements)
            {
                Player player = GetHighestPlayerForAchievement(ach.Key);
                if (player == null)
                    continue;

                if (ach.Value[player] > 0)
                    achievements.Add(ach.Key);
            }
        }
        if (FloatAchievements != null)
        {
            foreach (var ach in FloatAchievements)
            {
                Player player = GetHighestPlayerForAchievement(ach.Key);
                if (player == null)
                    continue;

                if (ach.Value[player] > 0)
                    achievements.Add(ach.Key);
            }
        }

        if (achievements.Count < aNumberOfAchievements)
            aNumberOfAchievements = achievements.Count;

        achievements.Shuffle<Achievements>();

        Achievement[] toReturn = new Achievement[aNumberOfAchievements];
        for (int i = 0; i < aNumberOfAchievements; i++)
        {
            if (GetAchievementTrackingType(achievements[i]) == TrackingTypes.IntegerIncrement)
                toReturn[i] = new Achievement(GetHighestPlayerForAchievement(achievements[i]), IntegerAchievements[achievements[i]][GetHighestPlayerForAchievement(achievements[i])], achievements[i]);
            else if (GetAchievementTrackingType(achievements[i]) == TrackingTypes.FloatIncrement)
                toReturn[i] = new Achievement(GetHighestPlayerForAchievement(achievements[i]), FloatAchievements[achievements[i]][GetHighestPlayerForAchievement(achievements[i])], achievements[i]);
        }

        return toReturn;
    }
}

public class Achievement
{
    public Achievement(Player aPlayer, int aValue, Achievements aAchievement)
    {
        m_IntValue = aValue;
        m_FloatValue = 0.0f;
        m_AchievementName = aAchievement;
        Player = aPlayer;
    }
    public Achievement(Player aPlayer, float aValue, Achievements aAchievement)
    {
        m_FloatValue = aValue;
        m_IntValue = 0;
        m_AchievementName = aAchievement;
        Player = aPlayer;
    }

    public float Value
    {
        get
        {
            if (GetValueType() == typeof(int))
                return (float)(m_IntValue);
            else
                return m_FloatValue;
        }
    }

    public Player Player { get; private set; }

    public Type GetValueType()
    {
        if (m_IntValue != 0)
            return typeof(int);
        else
            return typeof(float);
    }

    public Achievements AchievementName
    {
        get
        {
            return m_AchievementName;
        }
    }

    private Achievements m_AchievementName = Achievements.MAX_ACHIEVEMENTS;
    private int m_IntValue = 0;
    private float m_FloatValue = 0;
}