﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using UnityEngine.EventSystems;

public class OptionsScreenScript : GameMenu
{
    public enum OptionsScreenState
    {
        MainOptions,
        GameOptions,
        AudioOptions,
        VideoOptions
    }
    public OptionsScreenState CurrentState;

    // Main Options UI Components
    public GameObject MainOptionsPanel;
    public GameObject MainOptionsFirstGameObject;

    public Button GameOptionsButton;
    public Button AudioOptionsButton;
    public Button VideoOptionsButton;

    // Game Options UI Components
    public GameObject GameOptionsPanel;
    public GameObject GameOptionsFirstGameObject;

    public Button VibrationButtonOn;
    public Button VibrationButtonOff;

    // Audio Options UI Components
    public GameObject AudioOptionsPanel;
    public GameObject AudioOptionsFirstGameObject;

    public Slider VolumeMasterSlider;
    public Slider VolumeVoiceSlider;
    public Slider VolumeMusicSlider;
    public Slider VolumeSESlider;
    public Slider VolumeFootstepsSlider;

    // Video Options UI Components
    public GameObject VideoOptionsPanel;
    public GameObject VideoOptionsFirstGameObject;

    public Button CrosshairButtonOn;
    public Button CrosshairButtonOff;
    public Button FPSButtonOn;
    public Button FPSButtonOff;
    public Slider GameBrightnessSlider;
    public Dropdown ResolutionDropdown;
    public Button FullScreenButtonOn;
    public Button FullScreenButtonOff;
    public Dropdown QualitySettingsDropdown;

    // Reference Sprites
    public Sprite ButtonSprite_Selected;
    public Sprite ButtonSprite_Unselected;

    public Color SelectedColor;
    public Color UnselectedColor;
    public Color HighlightedColor;

    //public Sprite ButtonSpriteOn_Selected;
    //public Sprite ButtonSpriteOn_Unselected;
    //public Sprite ButtonSpriteOff_Selected;
    //public Sprite ButtonSpriteOff_Unselected;

    // Other
    protected Resolution[] m_ScreenResolutions;
    protected string[] m_QualitySettingNames;

    protected override void Start()
    {
        base.Start();

        CurrentState = OptionsScreenState.MainOptions;

        PopulateResolutionsDropdown();

        PopulateQualitySettingsDropdown();

        if (Screen.fullScreen)
        {
            FullscreenOnButtonFunction();
        }
        else
        {
            FullscreenOffButtonFunction();
        }

        UpdateUI();

        EnableNavigation();

        GameBrightnessSlider.value = OptionsManager.GameBrightness;

        //need to set the buttons starting sprites
        if (OptionsManager.Vibration)
            VibrationOnButtonFunction();
        else
            VibrationOffButtonFunction();

        if (OptionsManager.VisibleCrosshair)
            CrosshairOnButtonFunction();
        else
            CrosshairOffButtonFunction();

        if (OptionsManager.VisibleFPS)
            FPSOnButtonFunction();
        else
            FPSOffButtonFunction();


        VolumeMasterSlider.value = OptionsManager.VolumeMaster;
        VolumeVoiceSlider.value = OptionsManager.GetUnclampedVolumeVoice();
        VolumeMusicSlider.value = OptionsManager.GetUnclampedVolumeMusic();
        VolumeSESlider.value = OptionsManager.GetUnclampedVolumeEffects();
        VolumeFootstepsSlider.value = OptionsManager.GetUnclampedVolumeFootsteps();

        GetComponent<Canvas>().worldCamera = Camera.main;
        GetComponent<Canvas>().planeDistance = 1;
    }
    
    protected override void Update()
    {
        base.Update();

        OptionsManager.GameBrightness = GameBrightnessSlider.value;

        OptionsManager.VolumeMaster = VolumeMasterSlider.value;
        OptionsManager.VolumeVoice = VolumeVoiceSlider.value;
        OptionsManager.VolumeMusic = VolumeMusicSlider.value;
        OptionsManager.VolumeEffects = VolumeSESlider.value;
        OptionsManager.VolumeFootsteps = VolumeFootstepsSlider.value;

        if (IsSubmitButtonPressed())
        {
            TryCurrentSelectableOnClick();
            return;
        }

        if (IsCancelButtonPressed())
        {
            BackOutFunction();
            return;
        }
    }

    public void VibrationOnButtonFunction()
    {
        OptionsManager.Vibration = true;
        VibrationButtonOn.GetComponent<Image>().sprite = ButtonSprite_Selected;
        VibrationButtonOff.GetComponent<Image>().sprite = ButtonSprite_Unselected;
        VibrationButtonOn.transform.GetComponentInChildren<Text>().color = SelectedColor;
        VibrationButtonOff.transform.GetComponentInChildren<Text>().color = UnselectedColor;
    }

    public void VibrationOffButtonFunction()
    {
        OptionsManager.Vibration = false;
        VibrationButtonOn.GetComponent<Image>().sprite = ButtonSprite_Unselected;
        VibrationButtonOff.GetComponent<Image>().sprite = ButtonSprite_Selected;
        VibrationButtonOn.transform.GetComponentInChildren<Text>().color = UnselectedColor;
        VibrationButtonOff.transform.GetComponentInChildren<Text>().color = SelectedColor;
    }

    public void CrosshairOnButtonFunction()
    {
        OptionsManager.VisibleCrosshair = true;
        CrosshairButtonOn.GetComponent<Image>().sprite = ButtonSprite_Selected;
        CrosshairButtonOff.GetComponent<Image>().sprite = ButtonSprite_Unselected;
        CrosshairButtonOn.transform.GetComponentInChildren<Text>().color = SelectedColor;
        CrosshairButtonOff.transform.GetComponentInChildren<Text>().color = UnselectedColor;
    }

    public void CrosshairOffButtonFunction()
    {
        OptionsManager.VisibleCrosshair = false;
        CrosshairButtonOn.GetComponent<Image>().sprite = ButtonSprite_Unselected;
        CrosshairButtonOff.GetComponent<Image>().sprite = ButtonSprite_Selected;
        CrosshairButtonOn.transform.GetComponentInChildren<Text>().color = UnselectedColor;
        CrosshairButtonOff.transform.GetComponentInChildren<Text>().color = SelectedColor;
    }

    public void FPSOnButtonFunction()
    {
        OptionsManager.VisibleFPS = true;
        FPSButtonOn.GetComponent<Image>().sprite = ButtonSprite_Selected;
        FPSButtonOff.GetComponent<Image>().sprite = ButtonSprite_Unselected;
        FPSButtonOn.transform.GetComponentInChildren<Text>().color = SelectedColor;
        FPSButtonOff.transform.GetComponentInChildren<Text>().color = UnselectedColor;
    }

    public void FPSOffButtonFunction()
    {
        OptionsManager.VisibleFPS = false;
        FPSButtonOn.GetComponent<Image>().sprite = ButtonSprite_Unselected;
        FPSButtonOff.GetComponent<Image>().sprite = ButtonSprite_Selected;
        FPSButtonOn.transform.GetComponentInChildren<Text>().color = UnselectedColor;
        FPSButtonOff.transform.GetComponentInChildren<Text>().color = SelectedColor;
    }

    public void BackOutFunction()
    {
        if (CurrentState == OptionsScreenState.MainOptions)
        {
            CloseMenu(OptionsScene);
        }
        else
        {
            CurrentState = OptionsScreenState.MainOptions;

            UpdateUI();
        }
    }

    public void GameOptionsButtonFunction()
    {
        CurrentState = OptionsScreenState.GameOptions;

        UpdateUI();
    }

    public void AudioOptionsButtonFunction()
    {
        CurrentState = OptionsScreenState.AudioOptions;

        UpdateUI();
    }

    public void VideoOptionsButtonFunction()
    {
        CurrentState = OptionsScreenState.VideoOptions;

        UpdateUI();
    }

    private const string OptionsScene = "OptionsScene";
    
    
    
    //depricated
    private const string On = "On";
    private const string Off = "Off";
    private string GetStringForBoolValue(bool aValue)
    {
        if (aValue)
            return On;
        return Off;
    }

    void UpdateUI()
    {
        switch (CurrentState)
        {
            case OptionsScreenState.MainOptions:
                MainOptionsPanel.SetActive(true);
                GameOptionsPanel.SetActive(false);
                AudioOptionsPanel.SetActive(false);
                VideoOptionsPanel.SetActive(false);
                FirstSelectableMenuItem = MainOptionsFirstGameObject;
                EventSystem.current.firstSelectedGameObject = MainOptionsFirstGameObject;
                EventSystem.current.SetSelectedGameObject(MainOptionsFirstGameObject);
                break;
            case OptionsScreenState.GameOptions:
                MainOptionsPanel.SetActive(false);
                GameOptionsPanel.SetActive(true);
                AudioOptionsPanel.SetActive(false);
                VideoOptionsPanel.SetActive(false);
                FirstSelectableMenuItem = GameOptionsFirstGameObject;
                EventSystem.current.firstSelectedGameObject = GameOptionsFirstGameObject;
                EventSystem.current.SetSelectedGameObject(GameOptionsFirstGameObject);
                break;
            case OptionsScreenState.AudioOptions:
                MainOptionsPanel.SetActive(false);
                GameOptionsPanel.SetActive(false);
                AudioOptionsPanel.SetActive(true);
                VideoOptionsPanel.SetActive(false);
                FirstSelectableMenuItem = AudioOptionsFirstGameObject;
                EventSystem.current.firstSelectedGameObject = AudioOptionsFirstGameObject;
                EventSystem.current.SetSelectedGameObject(AudioOptionsFirstGameObject);
                break;
            case OptionsScreenState.VideoOptions:
                MainOptionsPanel.SetActive(false);
                GameOptionsPanel.SetActive(false);
                AudioOptionsPanel.SetActive(false);
                VideoOptionsPanel.SetActive(true);
                FirstSelectableMenuItem = VideoOptionsFirstGameObject;
                EventSystem.current.firstSelectedGameObject = VideoOptionsFirstGameObject;
                EventSystem.current.SetSelectedGameObject(VideoOptionsFirstGameObject);
                break;
            default:
#if UNITY_EDITOR
                DebugManager.LogWarning("Invalid Options Screen State: " + CurrentState.ToString(), Developmer.AllDevelopmers);
#endif
                break;
        }
    }

    void PopulateResolutionsDropdown()
    {
        m_ScreenResolutions = Screen.resolutions;

        ResolutionDropdown.ClearOptions();

        int currentResolutionIndex = 0;

        for (int i = 0; i < m_ScreenResolutions.Length; i++)
        {
            Dropdown.OptionData optionData = new Dropdown.OptionData();
            optionData.text = m_ScreenResolutions[i].width.ToString() + " x " + m_ScreenResolutions[i].height.ToString();
            
            ResolutionDropdown.options.Add(optionData);

            // Check if this is the current resolution that is set.
            if (m_ScreenResolutions[i].width == Screen.currentResolution.width &&
                m_ScreenResolutions[i].height == Screen.currentResolution.height)
            {
                currentResolutionIndex = i;
            }
        }

        ResolutionDropdown.value = currentResolutionIndex;
        ResolutionDropdown.RefreshShownValue();

        ResolutionDropdown.onValueChanged.AddListener(
            delegate
            {
                ResolutionDropdownChanged(ResolutionDropdown);
            });
    }

    public void ResolutionDropdownChanged(Dropdown aTarget)
    {
        //DebugManager.Log("Resolution changed: " + aTarget.value.ToString(), Developmer.Evan);

        Resolution newResolution = m_ScreenResolutions[aTarget.value];

        Screen.SetResolution(newResolution.width, newResolution.height, Screen.fullScreen);
    }

    public void FullscreenOnButtonFunction()
    {
        Screen.fullScreen = true;
        UpdateFullScreenButtons();
    }

    public void FullscreenOffButtonFunction()
    {
        Screen.fullScreen = false;
        
        StartCoroutine(UpdateFullScreenButtons());
    }

    IEnumerator UpdateFullScreenButtons()
    {
        // We won't be able to tell if full screen has occured until the next frame.
        yield return null;

        if (Screen.fullScreen == true)
        {
            FullScreenButtonOn.GetComponent<Image>().sprite = ButtonSprite_Selected;
            FullScreenButtonOff.GetComponent<Image>().sprite = ButtonSprite_Unselected;
            FullScreenButtonOn.transform.GetComponentInChildren<Text>().color = SelectedColor;
            FullScreenButtonOff.transform.GetComponentInChildren<Text>().color = UnselectedColor;
        }
        else
        {
            FullScreenButtonOn.GetComponent<Image>().sprite = ButtonSprite_Unselected;
            FullScreenButtonOff.GetComponent<Image>().sprite = ButtonSprite_Selected;
            FullScreenButtonOn.transform.GetComponentInChildren<Text>().color = UnselectedColor;
            FullScreenButtonOff.transform.GetComponentInChildren<Text>().color = SelectedColor;
        }
    }

    void PopulateQualitySettingsDropdown()
    {
        m_QualitySettingNames = QualitySettings.names;

        QualitySettingsDropdown.ClearOptions();

        int currentQualitySettingIndex = 0;

        for (int i = 0; i < m_QualitySettingNames.Length; i++)
        {
            Dropdown.OptionData optionData = new Dropdown.OptionData();
            optionData.text = m_QualitySettingNames[i];

            QualitySettingsDropdown.options.Add(optionData);

            // Check if this is the current quality option.
            if (i == QualitySettings.GetQualityLevel())
            {
                currentQualitySettingIndex = i;
            }
        }

        QualitySettingsDropdown.value = currentQualitySettingIndex;
        QualitySettingsDropdown.RefreshShownValue();

        QualitySettingsDropdown.onValueChanged.AddListener(
            delegate
            {
                QualitySettingsDropdownChanged(QualitySettingsDropdown);
            });
    }

    public void QualitySettingsDropdownChanged(Dropdown aTarget)
    {
        //DebugManager.Log("Resolution changed: " + aTarget.value.ToString(), Developmer.Evan);

        int newQualitySetting = aTarget.value;

        QualitySettings.SetQualityLevel(newQualitySetting, true);
    }
}