﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        DialogueManager                                                                *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            March 24th, 2017                                                               *
 *                                                                                                 *
 * Handles queuing and playing dialogue. Also handles checking for some specific dialogue triggers.*
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - March 24th, 2017                                            *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Audio;

public enum DialogueCheck
{
    PlayerSight,
    Death,
    Turret,
    None
}

public class DialogueManager : MonoBehaviour
{
    //
    //Public
    //
    public static DialogueManager Instance { get { return s_Instance; } }
    public static DialogueManager s_Instance = null;

    [Tooltip("Random # between 5-10 will be added to this variable")]
    public float RandCheckSurroundingsTimer;

    //
    //Private
    //
    private DialogueInfo m_DialogueInfo;

    private Dictionary<DialogueContext, List<AudioClip>> m_PaigeDialogueDictionary;
    private Dictionary<DialogueContext, List<AudioClip>> m_LeeroyDialogueDictionary;
    private Dictionary<DialogueContext, List<AudioClip>> m_QuarkDialogueDictionary;
    private Dictionary<DialogueContext, List<AudioClip>> m_ZephDialogueDictionary;

    private List<Player> m_PlayersInGame = new List<Player>();
    private List<Player> m_PlayersInOverlapSphere = new List<Player>();

    private AudioSource m_AudioSource1;
    private AudioSource m_AudioSource2;

    private const string m_AudioMixerResource = "AudioMixer";
    private const string m_DialogueGroup = "Voice";

    private Queue<AudioClip> m_AudioClipsToPlay = new Queue<AudioClip>();

    private DialogueContext m_DialogueContext = DialogueContext.None;

    private DialogueCheck m_DialogueCheck = DialogueCheck.None;

    private LayerMask m_LayerMask;

    private float m_OverlapSphereRadius = 50;

    private float m_RandtimerLength = 60f;

    void Awake()
    {
        if (s_Instance == null)
        {
            DontDestroyOnLoad(gameObject);
            s_Instance = this;
        }
        else if (s_Instance != null)
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        m_DialogueInfo = GetComponent<DialogueInfo>();
        m_PaigeDialogueDictionary = m_DialogueInfo.PaigeDialogueDictionary;
        m_LeeroyDialogueDictionary = m_DialogueInfo.LeeroyDialogueDictionary;
        m_QuarkDialogueDictionary = m_DialogueInfo.QuarkDialogueDictionary;
        m_ZephDialogueDictionary = m_DialogueInfo.ZephDialogueDictionary;

        m_LayerMask = 1 << (LayerMask.NameToLayer("Player1Model") |
                                          LayerMask.NameToLayer("Player2Model") |
                                          LayerMask.NameToLayer("Player3Model") |
                                          LayerMask.NameToLayer("Player4Model") |
                                          LayerMask.NameToLayer("Player5Model") |
                                          LayerMask.NameToLayer("Player6Model") |
                                          LayerMask.NameToLayer("Player7Model") |
                                          LayerMask.NameToLayer("Player8Model") |
                                          LayerMask.NameToLayer("QuarkTurret"));

        AudioMixer mixer = Resources.Load(m_AudioMixerResource) as AudioMixer;

        m_AudioSource1 = gameObject.AddComponent<AudioSource>();
        m_AudioSource1.playOnAwake = false;
        m_AudioSource1.outputAudioMixerGroup = mixer.FindMatchingGroups(m_DialogueGroup)[0];

        m_AudioSource2 = gameObject.AddComponent<AudioSource>();
        m_AudioSource2.playOnAwake = false;
        m_AudioSource2.outputAudioMixerGroup = mixer.FindMatchingGroups(m_DialogueGroup)[0];

        RandCheckSurroundingsTimer = m_RandtimerLength;
    }

    void Update()
    {
        RandCheckSurroundingsTimer -= Time.deltaTime;

        if (m_AudioClipsToPlay.Count > 0)
        {
            if (!m_AudioSource1.isPlaying)
            {
                AudioClip tempSource1Clip = m_AudioClipsToPlay.Peek();
                m_AudioSource1.clip = tempSource1Clip;
                m_AudioSource1.Play();
                m_AudioClipsToPlay.Dequeue();
            }
            else if (!m_AudioSource2.isPlaying)
            {
                AudioClip tempSource2Clip = m_AudioClipsToPlay.Peek();
                m_AudioSource2.clip = tempSource2Clip;
                m_AudioSource2.Play();
                m_AudioClipsToPlay.Dequeue();
            }
        }

        if (InputManager.CM.CurrentGameState == GameState.PlayGame)
        {
            if (RandCheckSurroundingsTimer <= 0)
            {
                RandCheckSurroundingsTimer = m_RandtimerLength + Random.Range(5, 10);

                CheckSurroundings(true,DialogueCheck.PlayerSight);
            }
        }
    }

    public void PlayDialogue(CharacterTypes aSpeaker, DialogueContext aContext, bool aMustPlayEventually, bool aMustPlayNow)
    {
        //TODO: if !aMustPlayEventually && !aMustPlayNow, then check how big the queue is, and if it's small, add sound to queue
        switch (aSpeaker)
        {
            case CharacterTypes.Paige:
                if (m_PaigeDialogueDictionary.ContainsKey(aContext))
                {
                    int randClip = Random.Range(0, m_PaigeDialogueDictionary[aContext].Count);

                    if (aMustPlayNow)
                    {
                        m_AudioSource1.PlayOneShot(m_PaigeDialogueDictionary[aContext][randClip]);
                    }
                    else if(aMustPlayEventually)
                    {
                        m_AudioClipsToPlay.Enqueue(m_PaigeDialogueDictionary[aContext][randClip]);
                    }
                }
                else
                {
                    DebugManager.Log("Sorry m8, can't play Dialogue. You may be trying to use a context (" + aContext + ") that doesn't exist for " + aSpeaker.ToString(),Developmer.Jon);
                }
                break;
            case CharacterTypes.Quark:
                if (m_QuarkDialogueDictionary.ContainsKey(aContext))
                {
                    int randClip = Random.Range(0, m_QuarkDialogueDictionary[aContext].Count);

                    if (aMustPlayNow)
                    {
                        m_AudioSource1.PlayOneShot(m_QuarkDialogueDictionary[aContext][randClip]);
                    }
                    else if (aMustPlayEventually)
                    {
                        m_AudioClipsToPlay.Enqueue(m_QuarkDialogueDictionary[aContext][randClip]);
                    }
                }
                else
                {
                    DebugManager.Log("Sorry m8, can't play Dialogue. You may be trying to use a context (" + aContext + ") that doesn't exist for " + aSpeaker.ToString(), Developmer.Jon);
                }
                break;
            case CharacterTypes.Leeroy:
                if (m_LeeroyDialogueDictionary.ContainsKey(aContext))
                {
                    int randClip = Random.Range(0, m_LeeroyDialogueDictionary[aContext].Count);

                    if (aMustPlayNow)
                    {
                        m_AudioSource1.PlayOneShot(m_LeeroyDialogueDictionary[aContext][randClip]);
                    }
                    else if (aMustPlayEventually)
                    {
                        m_AudioClipsToPlay.Enqueue(m_LeeroyDialogueDictionary[aContext][randClip]);
                    }
                }
                else
                {
                    DebugManager.Log("Sorry m8, can't play Dialogue. You may be trying to use a context (" + aContext + ") that doesn't exist for " + aSpeaker.ToString(),Developmer.Jon);
                }
                break;
            case CharacterTypes.Zeph:
                if (m_ZephDialogueDictionary.ContainsKey(aContext))
                {
                    int randClip = Random.Range(0, m_ZephDialogueDictionary[aContext].Count);

                    if (aMustPlayNow)
                    {
                        m_AudioSource1.PlayOneShot(m_ZephDialogueDictionary[aContext][randClip]);
                    }
                    else if (aMustPlayEventually)
                    {
                        m_AudioClipsToPlay.Enqueue(m_ZephDialogueDictionary[aContext][randClip]);
                    }
                }
                else
                {
                    DebugManager.Log("Sorry m8, can't play Dialogue. You may be trying to use a context (" + aContext + ") that doesn't exist for " + aSpeaker.ToString(),Developmer.Jon);
                }
                break;
            default:
                break;
        }
    }

    /// <summary>
    /// If aRandomPlayer == false, then aGameobjectToCheckFrom has to be valid. If aRandomPlayer == true, aGameobjectToCheckFrom can be null.
    /// </summary>
    void CheckSurroundings(bool aRandomPlayer, DialogueCheck aCheckType, GameObject aGameobjectToCheckFrom = null)
    {
        GameObject gameobjectToCheckFrom = null;

        m_PlayersInGame = Information.AllPlayers;

        if(aRandomPlayer)
        {
            int randPlayerNum = Random.Range(0, m_PlayersInGame.Count);

            Player randPlayerToCheck = m_PlayersInGame[randPlayerNum];
            if (randPlayerToCheck != null)
            {
#if UNITY_EDITOR
                DebugManager.Log("Checking at player: " + randPlayerToCheck.name, Developmer.Jon);
#endif
                gameobjectToCheckFrom = randPlayerToCheck.gameObject;
            }
        }
        else
        {
            gameobjectToCheckFrom = aGameobjectToCheckFrom;
        }

        if (gameobjectToCheckFrom != null)
        {
            Collider[] collidersNearCheck = Physics.OverlapSphere(gameobjectToCheckFrom.transform.position, m_OverlapSphereRadius, ~Physics.IgnoreRaycastLayer, QueryTriggerInteraction.Ignore);

            //Debug.Log(collidersNearRandPlayer.Length);

            Player playerThatWasCheckedFrom = gameobjectToCheckFrom.GetComponentInChildren<Player>();

            if (gameobjectToCheckFrom.GetComponentInChildren<Player>() != null)
            {
                for (int i = 0; i < collidersNearCheck.Length; i++)
                {
                    Collider col = collidersNearCheck[i];

                    Player playerInOverlapSphere = null;

                    PlayerHitboxScript hitbox = col.GetComponent<PlayerHitboxScript>();

                    if (hitbox != null)
                    {
                        playerInOverlapSphere = hitbox.Owner;
                        //Debug.Log(col.name);
                    }

                    if (playerInOverlapSphere != null && !m_PlayersInOverlapSphere.Contains(playerInOverlapSphere))
                    {
                        if (playerInOverlapSphere != playerThatWasCheckedFrom)
                        {
                            RaycastHit hit;
                            if (Physics.Raycast(playerThatWasCheckedFrom.PlayerCamera.transform.position, (playerInOverlapSphere.PlayerCamera.transform.position - playerThatWasCheckedFrom.PlayerCamera.transform.position), out hit, m_OverlapSphereRadius, ~Physics.IgnoreRaycastLayer, QueryTriggerInteraction.Ignore))
                            {
                                Player player = hit.transform.GetComponent<Player>();

                                if (player != null)
                                {
                                    if (player == playerInOverlapSphere)
                                    {
                                        m_PlayersInOverlapSphere.Add(playerInOverlapSphere);
    #if UNITY_EDITOR
                                        DebugManager.Log("added a player", Developmer.Jon);
    #endif
                                    }
                                    else
                                    {
    #if UNITY_EDITOR
                                        DebugManager.Log("there was a hit, but no player", Developmer.Jon);
    #endif
                                    }
                                }
                            }
                            else
                            {
    #if UNITY_EDITOR
                                DebugManager.Log("there was no hit", Developmer.Jon);
    #endif
                            }
                        }
                    }
                }

                float dist = float.MaxValue;

                Player closestPlayer = null;

                for (int i = 0; i < m_PlayersInOverlapSphere.Count; i++)
                {
                    if (Vector3.Distance(playerThatWasCheckedFrom.transform.position, m_PlayersInOverlapSphere[i].transform.position) < dist)
                    {
                        dist = Vector3.Distance(playerThatWasCheckedFrom.transform.position, m_PlayersInOverlapSphere[i].transform.position);
                        closestPlayer = m_PlayersInOverlapSphere[i];
                    }
                }

                DebugManager.Log(closestPlayer, Developmer.Jon);

                DialogueContext dialogueContext = DialogueContext.None;

                if (closestPlayer != null)
                {
                    if (aCheckType == DialogueCheck.PlayerSight)
                    {
                        switch (closestPlayer.Character)
                        {
                            case CharacterTypes.Paige:
                                dialogueContext = DialogueContext.SeePaige;
                                break;
                            case CharacterTypes.Quark:
                                dialogueContext = DialogueContext.SeeQuark;
                                break;
                            case CharacterTypes.Leeroy:
                                dialogueContext = DialogueContext.SeeLeeroy;
                                break;
                            case CharacterTypes.Zeph:
                                dialogueContext = DialogueContext.SeeZeph;
                                break;
                            default:
                                break;
                        }
                    }
                    else
                    {
    #if UNITY_EDITOR
                        DebugManager.Log("closest player null, returning", Developmer.Jon);
    #endif
                        return;
                    }
                }


                PlayDialogue(playerThatWasCheckedFrom.Character, dialogueContext, true, false);
            }
        }
        //Debug.Log("In Sphere: " + m_PlayersInOverlapSphere.Count);

        m_PlayersInOverlapSphere.Clear();
    }
}
