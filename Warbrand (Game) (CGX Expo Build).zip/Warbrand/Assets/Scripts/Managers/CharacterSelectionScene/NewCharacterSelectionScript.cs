﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
//using XInputDotNetPure;
using UnityEngine.EventSystems;

public enum CharacterSelectionSceneState
{
    SelectingCharacters,
    EditingControls,
    SelectingAI,
    SelectingGameModes,
    SelectingTeams,
    MAX
}

public class NewCharacterSelectionScript : GameMenu
{
    #region Class Variables
    //
    // Public
    //

    [Header("Player Setup")]
    public Camera[] PlayerCameras;

    // The indices of each CameraPosition MUST match the character at the same index in CharacterOrderByCameras.
    public GameObject[] CameraPositions;
    public CharacterTypes[] CharacterOrderByCameras;
    public GameObject ScreenCameraPoint;

    public CharacterSelectionSceneState CurrentState = CharacterSelectionSceneState.SelectingCharacters;

    // UI GameObjects

    [Space(10)]
    [Header("UI Components")]
    public GameObject ComputerScreenCanvas;
    public GameObject AddControllerText;

    public GameObject ProfileSelectButtonPrefab;
    public GameObject VirtualKeyboardPrefab;

    public Sprite UnselectedButtonImage;
    public Sprite SelectedButtonImage;

    public GameObject ControlConfiguratorPrefab;

    // AI Setup UI

    [Space(10)]
    [Header("AI Setup UI Components")]
    public GameObject SetupAIPanel;
    public GameObject SetupAIPanelFirstGameObject;
    public GameObject SetupAIPanelStartButton;
    public GameObject SetupAIPanelBackButton;

    public Text LeeroyNumber;
    public Text PaigeNumber;
    public Text QuarkNumber;
    public Text ZephNumber;

    public Text TotalNumber;

    public Slider LeeroySlider;
    public Slider PaigeSlider;
    public Slider QuarkSlider;
    public Slider ZephSlider;

    // Game Setup UI

    [Space(10)]
    [Header("Game Mode Setup UI Components")]
    public GameObject SetupGameModePanel;
    public GameObject SetupGameModePanelFirstGameObject;
    public GameObject SetupGameModePanelStartButton;
    public GameObject SetupGameModePanelFocusButton;
    public GameObject SetupGameModePanelBackButton;

    public Text GameModeNameButtonText;

    public GameObject TeamsPanel;
    public Text TeamsFocusButtonText;
    public GameObject TeamsFocusButton;

    public GameObject ScorePanel;
    public Text ScoreFocusButtonText;
    public GameObject ScoreFocusButton;

    public GameObject TimePanel;
    public Text TimeFocusButtonText;
    public GameObject TimeFocusButton;

    public GameObject RespawnTimePanel;
    public Text RespawnTimeFocusButtonText;
    public GameObject RespawnTimeFocusButton;

    //public GameObject DeathmatchConfigurationPanel;

    //public GameObject StockConfigurationPanel;

    public GameObject KothConfigurationPanel;
    public Text KothHillRotationButtonText;
    public GameObject KothHillRotationFocusButton;
    public GameObject KothHillChangeIntervalPanel;
    public Text KothHillChangeIntervalButtonText;
    public GameObject KothHillChangeIntervalFocusButton;

    //public GameObject TerritoriesConfigurationPanel;

    //public GameObject JuggernautConfigurationPanel;

    // Teams Setup UI

    [Space(10)]
    [Header("Teams Setup UI Components")]
    public GameObject TeamsSetupPanel;
    public GameObject TeamsSetupPanelFirstGameObject;
    public GameObject SetupTeamsPanelStartButton;
    public GameObject SetupTeamsPanelBackButton;
    public GameObject[] TeamsSetupPlayerPanels;
    public GameObject[] TeamsSetupPlayerFocusButtons;
    public Text[] TeamsSetupPlayerFocusButtonTexts;
    public GameObject[] TeamsSetupPlayerTeamPanels;
    public Text[] TeamsSetupPlayerTeamPanelTexts;

    // Other

    [Space(10)]
    [Header("Misc. Components")]
    [Tooltip("How close to the screen the camera must be before it is considered to be at its destination. Tweaking this number will affect how fast the canvas will appear.")]
    public float CameraToScreenStoppingDistance = 0.025f;

    // These GameObjects are under the PlayerSelectCanvas object in the inspector.
    public GameObject AddControllerCanvas;
    public GameObject PlayerSelectCanvas;
    public GameObject AllLockedInCanvas;
    public PlayerInformationPanel[] PlayerInformationPanels;
    public GameObject PlayerInformationTopPanel;
    public GameObject PlayerInformationBottomPanel;

    public GameObject ReadyForBattlePanel;

    // Game Mode Setup

    public GameModeType[] GameModes;
    protected GameModeType CurrentSelectedGameMode;

    public const int MinScoreLimit = 1;
    public const int MaxScoreLimit = 100;

    [Range(MinScoreLimit, MaxScoreLimit)]
    protected float ScoreLimit = 5;

    public const int MinTimeLimit = 0;
    public const int MaxTimeLimit = 120;

    [Range(MinTimeLimit, MaxTimeLimit)]
    protected float TimeLimit = 10;

    public const int MinRespawnTime = 0;
    public const int MaxRespawnTime = 60;

    [Range(MinRespawnTime, MaxRespawnTime)]
    protected float RespawnTime = 5.0f;

    protected bool m_TeamsEnabled;

    protected List<int> m_TeamIndexes;

    // King of the Hill specific

    public const int KothScoreInterval = 10;

    protected HillRotationOption KothHillRotationOption;

    public const int KothMinRotationTime = 10;
    public const int KothMaxRotationTime = 300;
    protected int KothRotationTime = 30;

    //
    // Private
    //
    private AudioSource m_AudioSource;

    private AudioClip m_LockedInClip1;
    private AudioClip m_LockedInClip2;
    private AudioClip m_LockedInClip3;
    private AudioClip m_LockedInClip4;
    private AudioClip m_UnlockedClip;
    private AudioClip m_GameStartingClip;

    private const string StringFormatPlayerSlot = "Player {0}";
    private const string StringSelectPlayer = "<   Select Character   >";
    private const string StringLockedIn = "Locked In!";

    private const string StringPlayerCamera = "Player Camera";
    private const string StringCreateNewProfile = "CREATE NEW PROFILE";
    private const string StringDefaultProfile = "Default Profile";
    private const string StringClearAllProfiles = "Delete all Profiles";
    private const string StringFormatPlayerSlotProfile = "Player {0} - Enter your profile name:";

    private const string StringFreeplayGameMode = "Free Play";
    private const string StringDeathmatchGameMode = "Deathmatch";
    private const string StringStockGameMode = "Stock";
    private const string StringKingOfTheHillGameMode = "King of the Hill";
    private const string StringTerritoriesGameMode = "Territories";
    private const string StringJuggernautGameMode = "Juggernaut";

    private const string StringKills = " Kills";
    private const string StringKill = " Kill";
    private const string StringLives = " Lives";
    private const string StringLife = " Life";
    private const string StringMinutes = " Minutes";
    private const string StringMinute = " Minute";
    private const string StringInfinite = "Infinite";

    private const string StringSeconds = " Seconds";
    private const string StringSecond = " Second";
    private const string StringInstant = "Instant";

    private const string StringPoints = " Points";
    private const string StringHillRotationOptionOrdered = "Ordered";
    private const string StringHillRotationOptionStatic = "Static";
    private const string StringHillRotationOptionRandom = "Random";
    private const string StringInvalid = "<Invalid Option> ";

    private const string StringNextScene = "GameScene";
    private const string SceneMainMenuScene = "MainMenuScene";

    private const string StringOn = "On";
    private const string StringOff = "Off";

    private const string m_RespawnTagString = "Respawn";

    private const string StringLeeroy = "Leeroy";
    private const string StringZeph = "Zeph";
    private const string StringQuark = "Quark";
    private const string StringPaige = "Paige";

    private const string m_StringSoundFXPath = "Audio/SoundFX/";
    private const string m_StringLockedInClip1Path = m_StringSoundFXPath + "character_select_locked_1";
    private const string m_StringLockedInClip2Path = m_StringSoundFXPath + "character_select_locked_2";
    private const string m_StringLockedInClip3Path = m_StringSoundFXPath + "character_select_locked_3";
    private const string m_StringLockedInClip4Path = m_StringSoundFXPath + "character_select_locked_4";
    private const string m_StringUnlockedClip = m_StringSoundFXPath + "character_select_unlocked";
    private const string m_StringGameStartingClip = m_StringSoundFXPath + "game_starting";

    // If a player is selecting profile or editing controls,
    // cannot go back to main menu or proceed to AI/Game Mode setup.

    private bool m_PlayerSelectingProfile = false;

    private bool m_PlayerEditingControls = false;

    #endregion

    protected override void Start()
    {
        base.Start();

        m_AudioSource = GetComponent<AudioSource>();

        m_LockedInClip1 = Resources.Load(m_StringLockedInClip1Path) as AudioClip;
        m_LockedInClip2 = Resources.Load(m_StringLockedInClip2Path) as AudioClip;
        m_LockedInClip3 = Resources.Load(m_StringLockedInClip3Path) as AudioClip;
        m_LockedInClip4 = Resources.Load(m_StringLockedInClip4Path) as AudioClip;
        m_UnlockedClip = Resources.Load(m_StringUnlockedClip) as AudioClip;
        m_GameStartingClip = Resources.Load(m_StringGameStartingClip) as AudioClip;

        //

        UpdateEventSystemForMenu();

        // Update player names
        InputManager.CM.ResetPlayerNames();

        InputManager.CM.CurrentGameState = GameState.PlayerSelect;
        InputManager.CM.CharacterSelectStartedThisFrame = true;

        InputManager.CM.PlayerProfileManager.LoadProfiles();
        AddDefaultButtonsToPlayerProfileLists();
        BuildPlayerProfileLists();

        UpdatePlayerInformationOnPlayersChanged();

        CurrentSelectedGameMode = 0;
        ScoreLimit = 10;
        TimeLimit = 10;
        KothRotationTime = 30;
		KothHillRotationOption = HillRotationOption.Static;

        m_TeamsEnabled = false;

        m_TeamIndexes = new List<int>();
        for (int i = 0; i < InputManager.MAX_PLAYERS; i++)
        {
            m_TeamIndexes.Add(0);
        }

        UpdateGameModeSetupButtonTexts();
        
    }

    protected override void Update()
    {
        base.Update();
        
        switch (CurrentState)
        {
            case CharacterSelectionSceneState.SelectingCharacters:
                HandlePlayerInput();
                LerpCameras();
                UpdateCameraPositions(false);
                break;
            case CharacterSelectionSceneState.SelectingAI:
                UpdateCameraPositions(true);
                if (!m_CameraOnScreen)
                    MoveCameraToScreen();
                else
                {
                    EnableNavigation();

                    HandlePlayerInput();

                    int totalPlayers = InputManager.CM.Players.Count + (int)(LeeroySlider.value) + (int)(QuarkSlider.value) + (int)(ZephSlider.value) + (int)(PaigeSlider.value);
                    TotalNumber.text = totalPlayers.ToString() + "/" + InputManager.MAX_PLAYERS.ToString();

                    LeeroySlider.maxValue = InputManager.MAX_PLAYERS - totalPlayers + LeeroySlider.value;
                    QuarkSlider.maxValue = InputManager.MAX_PLAYERS - totalPlayers + QuarkSlider.value;
                    ZephSlider.maxValue = InputManager.MAX_PLAYERS - totalPlayers + ZephSlider.value;
                    PaigeSlider.maxValue = InputManager.MAX_PLAYERS - totalPlayers + PaigeSlider.value;

                    LeeroyNumber.text = ((int)(LeeroySlider.value)).ToString();
                    PaigeNumber.text = ((int)(PaigeSlider.value)).ToString();
                    QuarkNumber.text = ((int)(QuarkSlider.value)).ToString();
                    ZephNumber.text = ((int)(ZephSlider.value)).ToString();
                }
                break;
            case CharacterSelectionSceneState.SelectingGameModes:
                HandlePlayerInput();
                break;
            case CharacterSelectionSceneState.SelectingTeams:
                HandlePlayerInput();
                break;
        }
    }


    #region Camera Management (Movement, Creation/Deletion, etc.)

    bool m_CameraOnScreen = false;
    void MoveCameraToScreen()
    {
        PlayerCameras[0].transform.position = Vector3.Lerp(PlayerCameras[0].transform.position, ScreenCameraPoint.transform.position, 0.3f);
        PlayerCameras[0].transform.rotation = Quaternion.Lerp(PlayerCameras[0].transform.rotation, ScreenCameraPoint.transform.rotation, 0.3f);

        if (MathUtils.AlmostEquals(Vector3.Distance(PlayerCameras[0].transform.position, ScreenCameraPoint.transform.position), 0f, CameraToScreenStoppingDistance))
        {
            //EnableNavigation();
            ComputerScreenCanvas.SetActive(true);
            m_CameraOnScreen = true;

            //ForceSelectionOfFirstMenuItem();

            UpdateEventSystemForMenu();
        }
    }

    void TransferToScreen()
    {
        // RECODE: Make this smooth
        for (int i = 1; i < PlayerCameras.Length; i++)
            PlayerCameras[i].enabled = false;

        Rect rect = new Rect(0, 0, 1, 1);
        PlayerCameras[0].rect = /*get*/ rect;
    }

    void TransferToCharacterSelection()
    {
        // RECODE: Make this smooth
        for (int i = 0; i < PlayerCameras.Length; i++)
        {
            PlayerCameras[i].enabled = true;
        }

        UpdateCameraPositions(false);
    }

    private void LerpCameras()
    {
        for (int i = 0; i < InputManager.CM.Players.Count; i++)
        {
            GameInputComponent input = InputManager.CM.Players[i];

            int cameraPositionIndex = GetCameraPositionIndexForCharacter(input.Character);

            PlayerCameras[i].transform.position = Vector3.Lerp(
                PlayerCameras[i].transform.position,
                CameraPositions[cameraPositionIndex].transform.position,
                0.3f);
            PlayerCameras[i].transform.rotation = Quaternion.Lerp(
                PlayerCameras[i].transform.rotation,
                CameraPositions[cameraPositionIndex].transform.rotation,
                0.3f);
        }
    }

    private int GetCameraPositionIndexForCharacter(CharacterTypes aCharacter)
    {
        // TODO: Make the Camera Points match up with CharacterTypes enum.

        switch(aCharacter)
        {
            case CharacterTypes.Leeroy:
                return 0;
            case CharacterTypes.Zeph:
                return 1;
            case CharacterTypes.Quark:
                return 2;
            case CharacterTypes.Paige:
                return 3;
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Invalid CharacterType: " + aCharacter.ToString(), Developmer.AllDevelopmers);
#endif
                break;
        }

        return -1;
    }

    private void ChangePlayerCharacterChoice(int aPlayerIndex, float aDirection)
    {
        if (InputManager.CM.Players[aPlayerIndex].LockedIn == true)
            return;

        // The order of the camera points does not match the CharacterTypes enum
        // so we have to get the predetermined index of the character in terms of Camera Points index.

        GameInputComponent player = InputManager.CM.Players[aPlayerIndex];

        int index = 0;
        for (int i = 0; i < CharacterOrderByCameras.Length; i++)
        {
            if (player.Character == CharacterOrderByCameras[i])
            {
                index = i;
                break;
            }
        }

        index += (int)aDirection;
        if (index < 0)
            index = CharacterOrderByCameras.Length - 1;
        if (index >= CharacterOrderByCameras.Length)
            index = 0;

        player.Character = CharacterOrderByCameras[index];
    }

    void UpdateCameraPositions(bool aMakePlayer1CameraFullScreen)
    {
        CameraManager.UpdateMenuCameraPositions(PlayerCameras, aMakePlayer1CameraFullScreen);
    }

    #endregion


    #region Handle Player Input

    void HandlePlayerInput()
    {
        if (EnableInputs == true)
        {
            if (InputManager.CM.Players.Count > 0)
            {
                int playersSelectingProfile = 0;
                int playersEditingControls = 0;
                int playersCreatingProfile = 0;
                bool allLocked = true;
                int PlayersLockedInCount = 0;
                if (CurrentState == CharacterSelectionSceneState.SelectingCharacters)
                {
                    for (int i = 0; i < InputManager.CM.Players.Count; i++)
                    {
                        bool locked = InputManager.CM.Players[i].LockedIn;

                        if (!locked)
                        {
                            allLocked = false;
                            //break;
                        }
                        else
                        {
                            PlayersLockedInCount++;
                        }
                    }

                    for (int i = 0; i < PlayerInformationPanels.Length; i++)
                    {
                        PlayerInformationPanel panel = PlayerInformationPanels[i];

                        if (panel.CurrentState == PlayerInformationPanel.State.SelectingProfile)
                            playersSelectingProfile++;

                        if (panel.CurrentState == PlayerInformationPanel.State.CreatingProfile)
                            playersCreatingProfile++;

                        if (panel.CurrentState == PlayerInformationPanel.State.EditingControls)
                            playersEditingControls++;
                    }
                }

                ReadyForBattlePanel.SetActive(allLocked && CurrentState == CharacterSelectionSceneState.SelectingCharacters);

                for (int i = 0; i < InputManager.CM.Players.Count; i++)
                {
                    GameInputComponent playerObject = InputManager.CM.Players[i];
                    if (playerObject.IsAI)
                        continue;

                    if (playerObject.EditingControls == false)
                    {
                        PlayerInput input = playerObject.Input as PlayerInput;

                        float horizontal = 0f;
                        horizontal = input.GetInput(InputName.Menu_Horizontal, InputType.ButtonPressed, true) + input.GetInput(InputName.Menu_Alt_Horizontal, InputType.ButtonPressed, true);
                        if (horizontal != 0.0f)
                        {
                            switch (CurrentState)
                            {
                                case CharacterSelectionSceneState.SelectingCharacters:
                                    {
                                        PlayerInformationPanel panel = PlayerInformationPanels[i];

                                        if (panel.CurrentState == PlayerInformationPanel.State.SelectingCharacter)
                                        {
                                            if (!MathUtils.AlmostEquals(horizontal, 0f))
                                            {
                                                ChangePlayerCharacterChoice(i, Mathf.Sign(horizontal));
                                                UpdateCharacterNameAtIndex(i);
                                            }

                                            panel.UpdateAbilityDescriptionsForCharacter(i);
                                            panel.UpdateAbilityButtonIcons(i);
                                        }
                                    }
                                    break;
                                case CharacterSelectionSceneState.SelectingGameModes:
                                    GameModeSetupButtonInput((int)horizontal);
                                    break;
                                case CharacterSelectionSceneState.SelectingTeams:
                                    TeamsSetupButtonFunction(-1, (int)horizontal);
                                    break;
                            }
                            return;
                        }


                        if (playerObject.PickingProfile == true && CurrentState == CharacterSelectionSceneState.SelectingCharacters)
                        {
                            float vertical = input.GetInput(InputName.Menu_Vertical, InputType.ButtonPressed, true) + input.GetInput(InputName.Menu_Alt_Vertical, InputType.ButtonPressed, true);
                            if (!MathUtils.AlmostEquals(vertical, 0f))
                            {
                                int direction = (int)Mathf.Sign(vertical);

                                playerObject.CurrentProfileButtonIndex -= direction;
                                if (playerObject.CurrentProfileButtonIndex < 0)
                                    playerObject.CurrentProfileButtonIndex = 0;
                                if (playerObject.CurrentProfileButtonIndex >= PlayerInformationPanels[i].TotalProfileButtonsCount)
                                    playerObject.CurrentProfileButtonIndex = PlayerInformationPanels[i].TotalProfileButtonsCount - 1;

                                PlayerInformationPanels[i].SelectProfileButtonAtIndex(playerObject.CurrentProfileButtonIndex);
                            }
                        }

                        //float startButton = input.GetInput(InputName.Jump, InputType.ButtonPressed, true) + input.GetInput(InputName.Menu_Pause, InputType.ButtonPressed, true);
                        //if (!MathUtils.AlmostEquals(startButton, 0f))
                        if (input.IsSubmitButtonPressed())
                        {
                            switch (CurrentState)
                            {
                                case CharacterSelectionSceneState.SelectingCharacters:
                                    {
                                        if (playerObject.PickingProfile == true)
                                        {
                                            PlayerInformationPanels[i].SelectCurrentProfileButton(i);
                                            return;
                                        }

                                        // Once all players are locked in,
                                        // one player can press start/enter to transfer to the screen.
                                        if (allLocked == false)
                                        {
                                            if (playerObject.LockedIn == false)
                                            {
                                                PlayersLockedInCount++;

                                                playerObject.LockedIn = true;
                                                PlayerInformationPanels[i].PlayerLockedInText.text = StringLockedIn;

                                                AudioClip lockedInClip = null;

                                                switch (PlayersLockedInCount)
                                                {
                                                    case 1:
                                                        lockedInClip = m_LockedInClip1;
                                                        break;
                                                    case 2:
                                                        lockedInClip = m_LockedInClip2;
                                                        break;
                                                    case 3:
                                                        lockedInClip = m_LockedInClip3;
                                                        break;
                                                    case 4:
                                                        lockedInClip = m_LockedInClip4;
                                                        break;
                                                    default:
                                                        break;
                                                }

                                                m_AudioSource.PlayOneShot(lockedInClip);

                                                DialogueManager.Instance.PlayDialogue(InputManager.CM.Players[i].Character, DialogueContext.CharSelected, false, true);
                                            }
                                        }
                                        else
                                        {
                                            // Only allowed to go to selecting AI if no players are changing their settings.
                                            if (playersSelectingProfile == 0 && playersEditingControls == 0)
                                            {
                                                CurrentState = CharacterSelectionSceneState.SelectingAI;
                                                UpdateEventSystemForMenu();
                                                TransferToScreen();
                                                ShowCurrentPlayerInformationPanels(false);
                                                ReadyForBattlePanel.SetActive(false);
                                                AddControllerCanvas.SetActive(false);
                                                PlayerSelectCanvas.SetActive(false);
                                                AllLockedInCanvas.SetActive(false);
                                            }
                                        }
                                        break;
                                    }
                                case CharacterSelectionSceneState.SelectingAI:
                                    // If start button pressed
                                    if (EventSystem.current.currentSelectedGameObject == SetupAIPanelStartButton)
                                    {
                                        StartButton();
                                    }
                                    // If back button pressed
                                    else if (EventSystem.current.currentSelectedGameObject == SetupAIPanelBackButton)
                                    {
                                        BackButton();
                                    }
                                    // Other button pressed?
                                    else
                                    {
                                        StartButton();
                                    }
                                    break;
                                case CharacterSelectionSceneState.SelectingGameModes:
                                    // If start button pressed
                                    if (EventSystem.current.currentSelectedGameObject == SetupGameModePanelStartButton)
                                    {
                                        StartButton();
                                    }
                                    // If back button pressed
                                    else if (EventSystem.current.currentSelectedGameObject == SetupGameModePanelBackButton)
                                    {
                                        BackButton();
                                    }
                                    // Other button pressed?
                                    else
                                    {
                                        StartButton();
                                    }
                                    break;
                                case CharacterSelectionSceneState.SelectingTeams:
                                    // If start button pressed
                                    if (EventSystem.current.currentSelectedGameObject == SetupTeamsPanelStartButton)
                                    {
                                        StartButton();
                                    }
                                    // If back button pressed
                                    else if (EventSystem.current.currentSelectedGameObject == SetupTeamsPanelBackButton)
                                    {
                                        BackButton();
                                    }
                                    // Other button pressed?
                                    else
                                    {
                                        StartButton();
                                    }
                                    break;
                            }

                            return;
                        }

                        //float cancelButton = input.GetInput(InputName.Menu_Cancel, InputType.ButtonPressed);
                        //if (!MathUtils.AlmostEquals(cancelButton, 0f))
                        if (input.IsCancelButtonPressed() && CurrentState != CharacterSelectionSceneState.EditingControls)
                        {
                            switch (CurrentState)
                            {
                                case CharacterSelectionSceneState.SelectingCharacters:
                                    if (/*playersSelectingProfile == 0 &&*/ playersCreatingProfile == 0 && playersEditingControls == 0)
                                    {
                                        BackButton(i);
                                    }
                                    else
                                    {
                                        PlayerInformationPanel panel = PlayerInformationPanels[i];

                                        if (panel.CurrentState == PlayerInformationPanel.State.SelectingProfile ||
                                            panel.CurrentState == PlayerInformationPanel.State.EditingControls)
                                        {
                                            panel.SetState(PlayerInformationPanel.State.SelectingCharacter);
                                            return;
                                        }
                                    }
                                    break;
                                case CharacterSelectionSceneState.SelectingAI:
                                case CharacterSelectionSceneState.SelectingGameModes:
                                case CharacterSelectionSceneState.SelectingTeams:
                                    BackButton(i);
                                    break;
                                default:
#if UNITY_EDITOR
                                    DebugManager.LogError("Invalid CharacterSelectionSceneState: " + CurrentState.ToString(), Developmer.Evan);
#endif
                                    break;
                            }
                            return;
                        }

                        // Show the character's abilities when holding the TAB/Back button
                        GameObject abilityDescriptionsPanel = PlayerInformationPanels[i].AbilityDescriptionsParent;
                        if (CurrentState == CharacterSelectionSceneState.SelectingCharacters && abilityDescriptionsPanel != null)
                        {
                            bool showAbilities = (input.GetInput(InputName.Menu_Scoreboard, InputType.ButtonHeld, true) != 0.0f);

                            if (abilityDescriptionsPanel.activeSelf != showAbilities)
                                abilityDescriptionsPanel.SetActive(showAbilities);
                        }

                        // Select profiles
                        float selectProfileButton = input.GetInput(InputName.Menu_Option, InputType.ButtonPressed);
                        if (!MathUtils.AlmostEquals(selectProfileButton, 0.0f))
                        {
                            if (CurrentState == CharacterSelectionSceneState.SelectingCharacters &&
                                PlayerInformationPanels[i].CurrentState == PlayerInformationPanel.State.SelectingCharacter)
                            {
                                PlayerInformationPanels[i].SetState(PlayerInformationPanel.State.SelectingProfile);

                                playerObject.PickingProfile = true;
                                playerObject.CurrentProfileButtonIndex = 0;

                                PlayerInformationPanels[i].SelectProfileButtonAtIndex(playerObject.CurrentProfileButtonIndex);

                                return;
                            }
                        }

                        // Edit controls
                        float editControlsButton = input.GetInput(InputName.Menu_Configure, InputType.ButtonPressed);
                        if (!MathUtils.AlmostEquals(editControlsButton, 0.0f) && CurrentState == CharacterSelectionSceneState.SelectingCharacters)
                        {
                            CurrentState = CharacterSelectionSceneState.EditingControls;
                            InputManager.CM.CurrentGameState = GameState.ConfigureControls;

                            GameObject controlConfiguratorObject = Instantiate(ControlConfiguratorPrefab);

                            EditControlScript configurator = controlConfiguratorObject.GetComponent<EditControlScript>();
                            configurator.SetupPlayerObject(i, InputManager.CM.Players[i]);

                            configurator.ParentMenu = this;
                            gameObject.SetActive(false);

                            playerObject.EditingControls = true;
                            PlayerInformationPanels[i].SetState(PlayerInformationPanel.State.EditingControls, InputManager.CM.Players[i].Character);
                            return;

                            //if (PlayerInformationPanels[i].EditControlsPanel != null)
                            //{
                            //    if (CurrentState == CharacterSelectionSceneState.SelectingCharacters &&
                            //        PlayerInformationPanels[i].CurrentState == PlayerInformationPanel.State.SelectingCharacter)
                            //    {
                            //        playerObject.EditingControls = true;
                            //        PlayerInformationPanels[i].SetState(PlayerInformationPanel.State.EditingControls, InputManager.CM.Players[i].Character);
                            //        return;
                            //    }
                            //}
                        }
                    }// End Player.EditingControls == false
                }
            }
            else
            {
                if (CurrentState == CharacterSelectionSceneState.SelectingCharacters)
                {
                    // Handle escape/b from the keyboard or any of the controllers.
                    if (IsCancelButtonPressed())
                    {
                        BackButton();
                        return;
                    }
                }
            }

            if (CurrentState != CharacterSelectionSceneState.SelectingCharacters)
            {
                if (IsSubmitButtonPressed())
                {
                    TryCurrentSelectableOnClick();
                    return;
                }
            }
        }
    }

    public void BackButton(int aPlayerIndex = -1)
    {
        if (EnableInputs == true)
        {
            EnableInputs = false;

            StartCoroutine(HandleBackButton(aPlayerIndex));
        }
    }

    IEnumerator HandleBackButton(int aPlayerIndex = -1)
    {
        yield return null;

        if (InputManager.CM.Players.Count <= 0)
        {
            EnableInputs = false;
            SceneManager.LoadScene(SceneMainMenuScene);
            yield break;
        }

        switch (CurrentState)
        {
            case CharacterSelectionSceneState.SelectingCharacters:
                if (aPlayerIndex >= 0)
                {
                    if (PlayerInformationPanels[aPlayerIndex].CurrentState == PlayerInformationPanel.State.SelectingCharacter)
                    {
                        GameInputComponent playerObject = InputManager.CM.Players[aPlayerIndex];

                        if (playerObject != null && playerObject.LockedIn)
                        {
                            UnlockPlayerAtIndex(aPlayerIndex);
                        }
                        else
                        {
                            DropPlayer(aPlayerIndex);
                        }
                        if (InputManager.CM.Players.Count <= 0)
                        {
                            InputManager.ResetPlayerID();
                            if (AddControllerText.gameObject.activeSelf != false)
                                AddControllerText.SetActive(false);
                            SceneManager.LoadScene(SceneMainMenuScene);
                        }
                    }
                    else if (PlayerInformationPanels[aPlayerIndex].CurrentState == PlayerInformationPanel.State.SelectingProfile)
                    {
                        PlayerInformationPanels[aPlayerIndex].SetState(PlayerInformationPanel.State.SelectingCharacter);
                        InputManager.CM.Players[aPlayerIndex].PickingProfile = false;
                    }
                }

                break;
            case CharacterSelectionSceneState.SelectingAI:
                DisableNavigation();
                CurrentState = CharacterSelectionSceneState.SelectingCharacters;

                // Need to clear out any AI characters that were created.
                for (int i = InputManager.CM.Players.Count - 1; i >= 0; i--)
                {
                    GameInputComponent input = InputManager.CM.Players[i];
                    if (input.IsAI)
                    {
                        InputManager.CM.DropPlayerAtIndex(i);
                    }
                }

                InputManager.ResetPlayerID();
                InputManager.CM.ResetPlayerNames();

                ComputerScreenCanvas.SetActive(false);
                m_CameraOnScreen = false;
                ShowCurrentPlayerInformationPanels(true);
                TransferToCharacterSelection();
                AddControllerCanvas.SetActive(true);
                PlayerSelectCanvas.SetActive(true);
                AllLockedInCanvas.SetActive(true);
                break;
            case CharacterSelectionSceneState.SelectingGameModes:
                CurrentState = CharacterSelectionSceneState.SelectingAI;

                // Need to clear out any AI characters that were created.
                // For some reason, if AI players are kept, the slider values get messed up.
                for (int i = InputManager.CM.Players.Count - 1; i >= 0; i--)
                {
                    GameInputComponent input = InputManager.CM.Players[i];
                    if (input.IsAI)
                    {
                        InputManager.CM.DropPlayerAtIndex(i);
                    }
                }

                InputManager.ResetPlayerID();
                InputManager.CM.ResetPlayerNames();

                LeeroyNumber.text = (0).ToString();
                PaigeNumber.text = (0).ToString();
                QuarkNumber.text = (0).ToString();
                ZephNumber.text = (0).ToString();
                LeeroySlider.value = 0;
                PaigeSlider.value = 0;
                QuarkSlider.value = 0;
                ZephSlider.value = 0;
                TotalNumber.text = InputManager.CM.Players.Count.ToString();

                UpdateEventSystemForMenu();
                break;
            case CharacterSelectionSceneState.SelectingTeams:
                CurrentState = CharacterSelectionSceneState.SelectingGameModes;
                UpdateEventSystemForMenu();
                break;
            default:
#if UNITY_EDITOR
                DebugManager.LogError("BackButton: Unsupported CharacterSelectionSceneState: " + CurrentState.ToString(), Developmer.Evan);
#endif
                break;
        }

        EnableInputs = true;
    }

    public void StartButton()
    {
        if (EnableInputs == true)
        {
            EnableInputs = false;

            StartCoroutine(HandleStartButton());
        }
    }

    IEnumerator HandleStartButton()
    {
        yield return null;

        if (CurrentState == CharacterSelectionSceneState.SelectingAI)
        {
            // Keep track of old team ids
            Dictionary<int, int> oldTeamIds = new Dictionary<int, int>();

            // Need to clear out any AI characters that were created.
            for (int i = InputManager.CM.Players.Count - 1; i >= 0; i--)
            {
                GameInputComponent input = InputManager.CM.Players[i];

                oldTeamIds[input.PlayerID] = input.TeamIndex;

                if (input.IsAI)
                {
                    InputManager.CM.DropPlayerAtIndex(i);
                }
            }

            InputManager.ResetPlayerID();
            InputManager.CM.ResetPlayerNames();

            // Add in the AI players

            for (int i = 0; i < LeeroySlider.value; i++)
            {
                GameInputComponent comp = InputManager.CM.AddPlayer(PlayerType.AiPlayer);
                comp.Character = CharacterTypes.Leeroy;
            }
            for (int i = 0; i < PaigeSlider.value; i++)
            {
                GameInputComponent comp = InputManager.CM.AddPlayer(PlayerType.AiPlayer);
                comp.Character = CharacterTypes.Paige;
            }
            for (int i = 0; i < QuarkSlider.value; i++)
            {
                GameInputComponent comp = InputManager.CM.AddPlayer(PlayerType.AiPlayer);
                comp.Character = CharacterTypes.Quark;
            }
            for (int i = 0; i < ZephSlider.value; i++)
            {
                GameInputComponent comp = InputManager.CM.AddPlayer(PlayerType.AiPlayer);
                comp.Character = CharacterTypes.Zeph;
            }

            InputManager.ResetPlayerID();
            InputManager.CM.ResetPlayerNames();

            // Reset player IDs
            for (int i = 0; i < InputManager.CM.Players.Count; i++)
            {
                GameInputComponent input = InputManager.CM.Players[i];

                input.SetNewPlayerID();

                if (oldTeamIds.ContainsKey(input.PlayerID))
                {
                    input.TeamIndex = oldTeamIds[input.PlayerID];
                }
            }

            CurrentState = CharacterSelectionSceneState.SelectingGameModes;

            yield return null;

            UpdateEventSystemForMenu();

            EnableInputs = true;
        }
        else if (CurrentState == CharacterSelectionSceneState.SelectingGameModes)
        {
            if (m_TeamsEnabled == false)
            {
                StartCoroutine(HandleStartGame());
            }
            else
            {
                SetupTeamsPanel();

                CurrentState = CharacterSelectionSceneState.SelectingTeams;

                yield return null;

                UpdateEventSystemForMenu();

                EnableInputs = true;
            }
        }
        else if (CurrentState == CharacterSelectionSceneState.SelectingTeams)
        {
            StartCoroutine(HandleStartGame());
        }
    }

    IEnumerator HandleStartGame()
    {
        m_AudioSource.PlayOneShot(m_GameStartingClip);

        // Sets correct names for AI players.
        InputManager.CM.ResetPlayerNames();

        GameModeManager manager = InputManager.CM.GameModeManager;

        // If free play mode is selected, turn off score and time limits.
        if (CurrentSelectedGameMode == GameModeType.FreePlayGameMode)
        {
            ScoreLimit = 0;
            TimeLimit = 0;
        }
        // Convert time in minutes to seconds
        else
        {
            TimeLimit = TimeLimit * 60;
        }
        // Force unique team indexes if teams are disabled.
        if (m_TeamsEnabled == false)
        {
#if UNITY_EDITOR
            DebugManager.Log("Teams are disabled. Generating default team IDs for each player.", Developmer.Evan);
#endif
            for (int i = 0; i < InputManager.CM.Players.Count; i++)
            {
                GameInputComponent input = InputManager.CM.Players[i];
                input.TeamIndex = i;
            }
        }
        // Likewise, if number of teams matches number of players in the game, disable team mode altogether.
        if (m_TeamsEnabled == true)
        {
            // Add up unique team indexes and compare the count to the number of players created.
            List<int> teamsList = new List<int>();
            for (int i = 0; i < InputManager.CM.Players.Count; i++)
            {
                GameInputComponent input = InputManager.CM.Players[i];
                if (teamsList.Contains(input.TeamIndex) == false)
                {
                    teamsList.Add(input.TeamIndex);
                }
            }

            if (teamsList.Count == InputManager.CM.Players.Count)
            {
                m_TeamsEnabled = false;
            }
        }

        LoadingScreen.Instance.LoadScreenSceneSwitch(StringNextScene);

        yield return null;

        //SceneManager.LoadScene(StringNextScene);

        manager.TeamsEnabled = m_TeamsEnabled;
        BaseGameMode gameMode = manager.CreateGameMode(CurrentSelectedGameMode);

        // Setup specific game mode settings.
        if (gameMode is KingOfTheHillGameMode)
        {
            KingOfTheHillGameMode koth = (KingOfTheHillGameMode)gameMode;
            koth.ScoreLimit = ScoreLimit * KothScoreInterval;
            koth.TimeLimit = TimeLimit;
            koth.KothHillRotationOption = KothHillRotationOption;
            koth.HillRotationInterval = KothRotationTime;

            // Turn off hill rotation if required.
            if (KothHillRotationOption == HillRotationOption.Static)
            {
                koth.HillRotationInterval = 0.0f;
            }
        }
        else if (gameMode is TerritoriesGameMode)
        {
            TerritoriesGameMode territories = (TerritoriesGameMode)gameMode;
            territories.ScoreLimit = ScoreLimit * KothScoreInterval;
            territories.TimeLimit = TimeLimit;
        }
        else
        {
            gameMode.ScoreLimit = ScoreLimit;
            gameMode.TimeLimit = TimeLimit;
        }

        manager.CurrentGameMode = gameMode;
        manager.SetRespawnTime(RespawnTime);

        InputManager.CM.StartGame(true);

        yield return null;
    }

    public override void OnEditControlsScriptComplete(int aPlayerIndex)
    {
        //Debug.Log("OnEditControlsScriptComplete");

        InputManager.CM.CurrentGameState = GameState.PlayerSelect;

        InputManager.CM.Players[aPlayerIndex].EditingControls = false;

        PlayerInformationPanels[aPlayerIndex].SetState(PlayerInformationPanel.State.SelectingCharacter);

        CurrentState = CharacterSelectionSceneState.SelectingCharacters;

        //if (PlayerInformationPanels[aPlayerIndex].EditControlsPanel != null)
        //{
        //    NewEditControlScript editControlScript = PlayerInformationPanels[aPlayerIndex].EditControlsPanel;

        //    editControlScript.gameObject.SetActive(false);

        //    InputManager.CM.Players[aPlayerIndex].EditingControls = false;

        //    PlayerInformationPanels[aPlayerIndex].SetState(PlayerInformationPanel.State.SelectingCharacter);
        //}
    }

    #endregion


    #region Human Player Character Selection / Setup

    void UpdatePlayerInformationPanels()
    {
        int playerCount = InputManager.CM.Players.Count;

        if (playerCount <= 0)
        {
            for (int i = 0; i < PlayerInformationPanels.Length; i++)
            {
                PlayerInformationPanel panel = PlayerInformationPanels[i];

                panel.gameObject.SetActive(false);
            }
        }
        else if (playerCount == 1)
        {
            /*
             * +--+--+
             * |     |
             * + P1  +
             * |     |
             * +--+--+
             */

            PlayerInformationPanels[0].gameObject.SetActive(true);
            PlayerInformationPanels[1].gameObject.SetActive(false);
            PlayerInformationPanels[2].gameObject.SetActive(false);
            PlayerInformationPanels[3].gameObject.SetActive(false);
        }
        else if (playerCount == 2)
        {
            /*
             * +-----+
             * | P1  |
             * +-----+
             * | P2  |
             * +-----+
             */

            PlayerInformationPanels[0].gameObject.SetActive(true);
            PlayerInformationPanels[1].gameObject.SetActive(true);
            PlayerInformationPanels[2].gameObject.SetActive(false);
            PlayerInformationPanels[3].gameObject.SetActive(false);
            // Player 2 on bottom half of screen
            PlayerInformationPanels[1].transform.SetParent(PlayerInformationBottomPanel.transform, false);
        }
        else if (playerCount == 3)
        {
            /*
             * +-----+
             * | P1  |
             * +--+--+
             * |P2|P3|
             * +--+--+
             */

            PlayerInformationPanels[0].gameObject.SetActive(true);
            PlayerInformationPanels[1].gameObject.SetActive(true);
            PlayerInformationPanels[2].gameObject.SetActive(true);
            PlayerInformationPanels[3].gameObject.SetActive(false);
            // Player 2 on bottom-left corner of screen
            PlayerInformationPanels[1].transform.SetParent(PlayerInformationBottomPanel.transform, false);
            // Player 3 on bottom-right corner of screen
            PlayerInformationPanels[2].transform.SetParent(PlayerInformationBottomPanel.transform, false);
            PlayerInformationPanels[2].transform.SetAsLastSibling();
        }
        else if (playerCount == 4)
        {
            /*
             * +--+--+
             * |P1|P2|
             * +--+--+
             * |P3|P4|
             * +--+--+
             */

            // Player 1 on top-right corner of screen
            PlayerInformationPanels[0].gameObject.SetActive(true);
            PlayerInformationPanels[1].gameObject.SetActive(true);
            // Player 3 on bottom-left corner of screen
            PlayerInformationPanels[2].gameObject.SetActive(true);
            PlayerInformationPanels[3].gameObject.SetActive(true);
            // Player 2 on top-right corner of screen
            PlayerInformationPanels[1].transform.SetParent(PlayerInformationTopPanel.transform, false);
            PlayerInformationPanels[1].transform.SetAsLastSibling();
            // Player 4 on bottom-right corner of screen
            PlayerInformationPanels[3].transform.SetAsLastSibling();
        }
        else
        {
            for (int i = 0; i < PlayerInformationPanels.Length; i++)
            {
                PlayerInformationPanel panel = PlayerInformationPanels[i];

                panel.gameObject.SetActive(false);
            }
        }
    }

    void ShowCurrentPlayerInformationPanels(bool aShow)
    {
        for (int i = 0; i < InputManager.CM.Players.Count; i++)
        {
            PlayerInformationPanels[i].gameObject.SetActive(aShow);
        }
    }
    
    private void DropPlayer(int aID)
    {
        InputManager.CM.DropPlayerAtIndex(aID);

        InputManager.ResetPlayerID();
        InputManager.CM.ResetPlayerNames();
    }

    private void UnlockPlayerAtIndex(int aPlayerIndex)
    {
        GameInputComponent input = InputManager.CM.Players[aPlayerIndex];

        input.LockedIn = false;
        PlayerInformationPanels[aPlayerIndex].PlayerLockedInText.text = StringSelectPlayer;

        m_AudioSource.PlayOneShot(m_UnlockedClip);
    }

    private void UpdateCharacterNameAtIndex(int aPlayerIndex)
    {
        CharacterTypes character = InputManager.CM.Players[aPlayerIndex].Character;

        switch (character)
        {
            case CharacterTypes.Leeroy:
                PlayerInformationPanels[aPlayerIndex].CharacterNameText.text = StringLeeroy;
                break;
            case CharacterTypes.Zeph:
                PlayerInformationPanels[aPlayerIndex].CharacterNameText.text = StringZeph;
                break;
            case CharacterTypes.Quark:
                PlayerInformationPanels[aPlayerIndex].CharacterNameText.text = StringQuark;
                break;
            case CharacterTypes.Paige:
                PlayerInformationPanels[aPlayerIndex].CharacterNameText.text = StringPaige;
                break;
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Invalid CharacterType: " + character.ToString(), Developmer.AllDevelopmers);
#endif
                break;
        }
    }

    #endregion


    #region Handle Loading Player Profiles And Populating Profiles Dropdowns

    void AddDefaultButtonsToPlayerProfileLists()
    {
        // Loop over each player slot
        for (int playerIndex = 0; playerIndex < InputManager.MAX_LOCAL_HUMAN_PLAYERS; playerIndex++)
        {
            // Need to create this temp index to pass into the delegate or it will create a closure
            int tempIndex = playerIndex;

            // Create new entry button
            InterfaceUtils.MakeButton(
                PlayerInformationPanels[tempIndex].CommandButtonsPanel,
                ProfileSelectButtonPrefab,
                StringCreateNewProfile,
                delegate { StartVirtualKeyboard(tempIndex); }
                );

            // Default profile button
            InterfaceUtils.MakeButton(
                PlayerInformationPanels[tempIndex].CommandButtonsPanel,
                ProfileSelectButtonPrefab,
                StringDefaultProfile,
                delegate { SetDefaultProfileAtPlayerIndex(tempIndex); }
                );

#if UNITY_EDITOR
            // Clear all profiles button
            InterfaceUtils.MakeButton(
                PlayerInformationPanels[tempIndex].CommandButtonsPanel,
                ProfileSelectButtonPrefab,
                StringClearAllProfiles,
                delegate { ClearProfiles(); }
                );
#endif
        }
    }

    public override void VirtualKeyboardResponse(VirtualKeyboardValue aResponse)
    {
#if UNITY_EDITOR
        DebugManager.Log("VirtualKeyboardResponse: " + aResponse.ToString(), Developmer.Evan);
#endif

        if (aResponse.InputStatus == VirtualKeyboard.Status.Confirmed)
        {
            // Add the new profile to the list
            PlayerInput input = new PlayerInput(null);
            input.ProfileName = aResponse.InputText;

            DefaultControls.SetupDefaultControlConfigurationsForPlayer(input, InputDeviceType.Undefined);

            InputManager.CM.PlayerProfileManager.AddProfile(input);

            // Update UI and player configuration

            UpdatePlayerProfileButtonAtIndex(aResponse.PlayerIndex, aResponse.InputText);

            PlayerProfileManager profileManager = InputManager.CM.PlayerProfileManager;
            SetUserProfileAtIndex(aResponse.InputText, aResponse.PlayerIndex, profileManager.PlayerProfiles.Count - 1, false);

            // Hide the profile select list
            InputManager.CM.Players[aResponse.PlayerIndex].PickingProfile = false;

            // Need to update the player profile lists with the new entry.
            BuildPlayerProfileLists();
        }

        PlayerInformationPanels[aResponse.PlayerIndex].SetState(PlayerInformationPanel.State.SelectingCharacter);
    }

    public void SetDefaultProfileAtPlayerIndex(int aPlayerIndex)
    {
        if (EnableInputs == true && InputManager.CM.CurrentGameState == GameState.PlayerSelect)
        {
            GameInputComponent playerObject = InputManager.CM.Players[aPlayerIndex];
            PlayerInput player = playerObject.Input as PlayerInput;

            InputDeviceType deviceType = (player.Device == InputDevice.Keyboard ? InputDeviceType.Keyboard : InputDeviceType.Joystick);

            DefaultControls.SetupDefaultControlConfigurationsForPlayer(player, deviceType);

            playerObject.Input = player;
            player.Input = playerObject;
            player.ProfileName = string.Empty;

            player.ResetDevice();
            playerObject.ResetPlayerName();

            // Reset text on the player profile button
            UpdatePlayerProfileButtonAtIndex(aPlayerIndex, string.Format(StringFormatPlayerSlot, (aPlayerIndex + 1).ToString()));

            SetScrollViewButtonImageSprite(
                PlayerInformationPanels[aPlayerIndex].CommandButtonsPanel,
                1,
                aPlayerIndex,
                UnselectedButtonImage
                );

            playerObject.PickingProfile = false;
            playerObject.CurrentProfileButtonIndex = 0;
            PlayerInformationPanels[aPlayerIndex].SetState(PlayerInformationPanel.State.SelectingCharacter);
        }
    }

    void UpdatePlayerProfileButtonAtIndex(int aPlayerIndex, string aButtonText)
    {
        // Update the player's button text to be their profile name
        //Button button = PlayerProfileButtons[aPlayerIndex];
        //if (button != null)
        //{
        //    button.transform.FindChild(StringTextGameObject).GetComponent<Text>().text = aButtonText;

        //    InputManager.CM.Players[aPlayerIndex].PickingProfile = false;
        //}
    }

    void BuildPlayerProfileLists()
    {
        StartCoroutine(HandleLoadPlayerProfileLists());
    }

    void ClearProfiles()
    {
        for (int i = 0; i < InputManager.CM.Players.Count; i++)
        {
            GameInputComponent playerObject = InputManager.CM.Players[i];

            PlayerInput input = playerObject.Input as PlayerInput;

            InputDeviceType deviceType = (input.Device == InputDevice.Keyboard ? InputDeviceType.Keyboard : InputDeviceType.Joystick);

            DefaultControls.SetupDefaultControlConfigurationsForPlayer(input, deviceType);

            playerObject.PickingProfile = false;
            playerObject.CurrentProfileButtonIndex = 0;

            input.ProfileName = string.Empty;
            input.ResetDevice();
            playerObject.ResetPlayerName();

            PlayerInformationPanels[i].SetState(PlayerInformationPanel.State.SelectingCharacter);

            // Need to clear the lists of profiles
            int childCount = PlayerInformationPanels[i].ProfileButtonsPanel.transform.childCount;

            for (int index = childCount - 1; index >= 0; index--)
            {
                Transform child = PlayerInformationPanels[i].ProfileButtonsPanel.transform.GetChild(index);

                DestroyImmediate(child.gameObject);
            }
        }

        InputManager.CM.PlayerProfileManager.ClearProfilesList();
    }

    IEnumerator HandleLoadPlayerProfileLists()
    {
        yield return null;
        PlayerProfileManager profileManager = InputManager.CM.PlayerProfileManager;

        bool jobFinished = false;

        do
        {
            List<PlayerInput> PlayerProfiles = new List<PlayerInput>(profileManager.PlayerProfiles.Values);
            jobFinished = profileManager.IsJobFinished();

            if (PlayerProfiles != null)
            {
                int numProfilesInScrollview = PlayerInformationPanels[0].ProfileButtonsPanel.transform.childCount;
                int numProfilesInProfileManager = PlayerProfiles.Count;

                if (numProfilesInScrollview < numProfilesInProfileManager)
                {
                    //Loop over the buffer of profiles that need to be added to the scroll list view
                    for (int i = numProfilesInScrollview; i < numProfilesInProfileManager; i++)
                    {
                        //Loop over each player to add profile to their scroll view
                        for (int playerIndex = 0; playerIndex < InputManager.MAX_LOCAL_HUMAN_PLAYERS; playerIndex++)
                        {
                            // Need to store these values inside loop or delegate will use the index values past the last index.
                            int tempPlayerIndex = playerIndex;
                            int buttonIndex = i;
                            string profileName = PlayerProfiles[buttonIndex].ProfileName;

                            //This function hides the external loop counter so that the delegate
                            // will not use the int value at the end of the loop.
                            MakePlayerProfileButton(
                                PlayerInformationPanels[tempPlayerIndex].ProfileButtonsPanel,
                                ProfileSelectButtonPrefab,
                                profileName,
                                tempPlayerIndex,
                                buttonIndex
                                );
                        }
                    }
                }
            }

            yield return null;
        } while (jobFinished == false);
    }

    void MakePlayerProfileButton(GameObject aParent, UnityEngine.Object aButtonPrefab, string aProfileName, int aPlayerIndex, int aButtonIndex)
    {
        InterfaceUtils.MakeButton(
            aParent,
            aButtonPrefab,
            aProfileName,
            delegate { HandleSelectUserProfileButton(aProfileName, aPlayerIndex, aButtonIndex, true); }
            );
    }

    void HandleSelectUserProfileButton(string aProfileName, int aPlayerIndex, int aButtonIndex, bool unselectProfile)
    {
        // Update UI and player configuration

        UpdatePlayerProfileButtonAtIndex(aPlayerIndex, aProfileName);

        SetUserProfileAtIndex(aProfileName, aPlayerIndex, aButtonIndex, unselectProfile);

        // Hide the profile select list
        InputManager.CM.Players[aPlayerIndex].PickingProfile = false;

        PlayerInformationPanels[aPlayerIndex].SetState(PlayerInformationPanel.State.SelectingCharacter);
    }

    void SetUserProfileAtIndex(string aProfileName, int aPlayerIndex, int aButtonIndex, bool unselectProfile)
    {
#if UNITY_EDITOR
        DebugManager.Log("SetUserProfileAtIndex: " + aProfileName + ", " + aPlayerIndex.ToString() + ", " + aButtonIndex.ToString() + ", " + unselectProfile.ToString(), Developmer.Evan);
#endif

        if (aProfileName != null && aProfileName.Length > 0 && aPlayerIndex >= 0)
        {
            PlayerProfileManager profileManager = InputManager.CM.PlayerProfileManager;

            GameInputComponent playerObject = InputManager.CM.Players[aPlayerIndex];
            PlayerInput currentPlayer = playerObject.Input as PlayerInput;

            // Get the player input from the list of profiles.
            PlayerInput storedPlayer = null;
            if (InputManager.CM.PlayerProfileManager.PlayerProfiles.ContainsKey(aProfileName))
            {
                storedPlayer = profileManager.PlayerProfiles[aProfileName];
            }

#if UNITY_EDITOR
            if (storedPlayer == null)
            {
                DebugManager.LogError("The stored player '" + aProfileName + "' is null!", Developmer.Evan);
            }
            else
            {
                DebugManager.Log("Stored player: " + storedPlayer.ToString(), Developmer.Evan);
            }
#endif

            if (playerObject != null && currentPlayer != null && storedPlayer != null)
            {
                // Remember the device currently being used.
                InputDevice currentDevice = currentPlayer.Device;

                // Copy over the input configurations from the stored profile to the current profile.
                // Rebinds GameInputComponent with new PlayerInput and fixes references.
                currentPlayer = storedPlayer;
                currentPlayer.Device = currentDevice;
                currentPlayer.Input = playerObject;
                playerObject.Input = currentPlayer;

                // Set current device configuration.
                if (currentPlayer.Device == InputDevice.Keyboard)
                {
                    currentPlayer.CurrentConfiguration = currentPlayer.InputConfigurations[InputDeviceType.Keyboard.ToString()];
                }
                else if (currentPlayer.Device >= InputDevice.Joystick1)
                {
                    currentPlayer.CurrentConfiguration = currentPlayer.InputConfigurations[InputDeviceType.Joystick.ToString()];
                }
#if UNITY_EDITOR
                else
                {
                    DebugManager.LogError("Did not know what the user's device was!", Developmer.Evan);
                }
#endif

                currentPlayer.ResetDevice();

                playerObject.ResetPlayerName();

                // Update the player's button
                UpdatePlayerProfileButtonAtIndex(aPlayerIndex, storedPlayer.ProfileName);
            }

            // This should happen no matter what - even if there is an error selecting profile.

            if (unselectProfile == true)
            {
                SetScrollViewButtonImageSprite(
                    PlayerInformationPanels[aPlayerIndex].ProfileButtonsPanel,
                    aButtonIndex,
                    aPlayerIndex,
                    UnselectedButtonImage
                    );
            }

            playerObject.PickingProfile = false;
            playerObject.CurrentProfileButtonIndex = 0;
            PlayerInformationPanels[aPlayerIndex].SetState(PlayerInformationPanel.State.SelectingCharacter);
        }
    }

    public void StartVirtualKeyboard(int aPlayerIndex)
    {
        if (EnableInputs && InputManager.CM.CurrentGameState == GameState.PlayerSelect)
        {
            GameInputComponent gameInput = InputManager.CM.Players[aPlayerIndex];

            SetScrollViewButtonImageSprite(
                PlayerInformationPanels[aPlayerIndex].CommandButtonsPanel,
                0,
                aPlayerIndex,
                UnselectedButtonImage
                );

            gameInput.PickingProfile = false;
            gameInput.CurrentProfileButtonIndex = 0;
            PlayerInformationPanels[aPlayerIndex].SetState(PlayerInformationPanel.State.CreatingProfile);
            
            GameObject keyboardObject;
            keyboardObject = Instantiate(VirtualKeyboardPrefab) as GameObject;
            VirtualKeyboard keyboard = keyboardObject.GetComponent<VirtualKeyboard>();
            keyboard.ParentMenu = this;
            EnableInputs = false;
            keyboard.Init(string.Format(StringFormatPlayerSlotProfile, (aPlayerIndex + 1).ToString()), aPlayerIndex);
        }
    }

    void SetScrollViewButtonColor(GameObject aButtonParent, int aButtonIndex, int aPlayerIndex, Color aButtonColor)
    {
#if UNITY_EDITOR
        DebugManager.Log("Index passed in: " + aButtonIndex, Developmer.Evan);
#endif

        if (aButtonParent != null)
        {
            GameObject buttonAtIndex = aButtonParent.transform.GetChild(aButtonIndex).gameObject;
            if (buttonAtIndex != null)
            {
                Button button = buttonAtIndex.GetComponent<Button>();
                if (button != null)
                {
                    ColorBlock colors = button.colors;
                    colors.normalColor = aButtonColor;
                    button.colors = colors;
                }
            }
        }
    }

    void SetScrollViewButtonImageSprite(GameObject aButtonParent, int aButtonIndex, int aPlayerIndex, Sprite aSprite)
    {
#if UNITY_EDITOR
        DebugManager.Log("Index passed in: " + aButtonIndex, Developmer.Evan);
#endif

        if (aButtonParent != null)
        {
            GameObject buttonAtIndex = aButtonParent.transform.GetChild(aButtonIndex).gameObject;
            if (buttonAtIndex != null)
            {
                Button button = buttonAtIndex.GetComponent<Button>();
                if (button != null)
                {
                    button.image.sprite = aSprite;
                }
            }
        }
    }

    #endregion


    #region Game Mode Setup

    protected void UpdateGameModeSetupButtonTexts()
    {
        bool TeamsSelectable = true;

        // Update game mode button
        switch (CurrentSelectedGameMode)
        {
            case GameModeType.FreePlayGameMode:
                GameModeNameButtonText.text = StringFreeplayGameMode;
                break;
            case GameModeType.DeathmatchGameMode:
                GameModeNameButtonText.text = StringDeathmatchGameMode;
                break;
            case GameModeType.StockGameMode:
                GameModeNameButtonText.text = StringStockGameMode;
                break;
            case GameModeType.KingOfTheHillGameMode:
                GameModeNameButtonText.text = StringKingOfTheHillGameMode;
                break;
            case GameModeType.TerritoriesGameMode:
                GameModeNameButtonText.text = StringTerritoriesGameMode;
                break;
            // Turn off teams for Juggernaut
            case GameModeType.JuggernautGameMode:
                TeamsSelectable = false;
                GameModeNameButtonText.text = StringJuggernautGameMode;
                break;
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Unsupported game mode: " + CurrentSelectedGameMode.ToString(), Developmer.Evan);
#endif
                break;
        }

        if (TeamsSelectable == false)
        {
            if (TeamsPanel.activeSelf == true)
            {
                TeamsFocusButtonText.text = StringOff;
                m_TeamsEnabled = false;
                TeamsPanel.SetActive(false);
            }
        }
        else
        {
            //if (TeamsPanel.activeSelf == false)
            {
                TeamsPanel.SetActive(true);
                if (m_TeamsEnabled == true)
                {
                    TeamsFocusButtonText.text = StringOn;
                }
                else
                {
                    TeamsFocusButtonText.text = StringOff;
                }
            }
        }

        // Respawn timer 
        RespawnTimeFocusButtonText.text = (RespawnTime > 1 ? RespawnTime.ToString() + StringSeconds : (RespawnTime > 0 ? RespawnTime.ToString() + StringSecond : StringInstant));

        // Update game mode property buttons/panels

        // Free Play Mode
        if (CurrentSelectedGameMode == GameModeType.FreePlayGameMode)
        {
            ScorePanel.SetActive(false);
            TimePanel.SetActive(false);
        }
        else
        {
            ScorePanel.SetActive(true);
            TimePanel.SetActive(true);
        }

        // Deathmatch
        if (CurrentSelectedGameMode == GameModeType.DeathmatchGameMode)
        {
            //DeathmatchConfigurationPanel.SetActive(true);
            ScoreFocusButtonText.text = ScoreLimit.ToString() + (ScoreLimit > 1 ? StringKills : StringKill);
            TimeFocusButtonText.text = (TimeLimit > 0 ? TimeLimit.ToString() + (TimeLimit > 1 ? StringMinutes : StringMinute) : StringInfinite);
        }
        else
        {
            //DeathmatchConfigurationPanel.SetActive(false);
        }

        // Stock
        if (CurrentSelectedGameMode == GameModeType.StockGameMode)
        {
            //StockConfigurationPanel.SetActive(true);
            ScoreFocusButtonText.text = ScoreLimit.ToString() + (ScoreLimit > 1 ? StringLives : StringLife);
            TimeFocusButtonText.text = (TimeLimit > 0 ? TimeLimit.ToString() + (TimeLimit > 1 ? StringMinutes : StringMinute) : StringInfinite);
        }
        else
        {
            //StockConfigurationPanel.SetActive(false);
        }

        // King of the Hill
        if (CurrentSelectedGameMode == GameModeType.KingOfTheHillGameMode)
        {
            KothConfigurationPanel.SetActive(true);
            ScoreFocusButtonText.text = (ScoreLimit * KothScoreInterval).ToString() + StringPoints;
            TimeFocusButtonText.text = (TimeLimit > 0 ? TimeLimit.ToString() + (TimeLimit > 1 ? StringMinutes : StringMinute) : StringInfinite);
            KothHillRotationButtonText.text = GetStringNameForHillRotation();
            KothHillChangeIntervalButtonText.text = KothRotationTime.ToString();

            if (KothHillRotationOption == HillRotationOption.Static ||
                KothHillRotationOption == HillRotationOption.MAX_OPTION)
            {
                // Prevent situation where the button is currently focused but is disabled, preventing further navigation.
                if (EventSystem.current.currentSelectedGameObject == KothHillChangeIntervalFocusButton)
                {
                    EventSystem.current.SetSelectedGameObject(EventSystem.current.firstSelectedGameObject);
                }
                KothHillChangeIntervalPanel.SetActive(false);
            }
            else
            {
                KothHillChangeIntervalPanel.SetActive(true);
            }
        }
        else
        {
            KothConfigurationPanel.SetActive(false);
        }

        // Territories
        if (CurrentSelectedGameMode == GameModeType.TerritoriesGameMode)
        {
            //TerritoriesConfigurationPanel.SetActive(true);

            ScoreFocusButtonText.text = (ScoreLimit * KothScoreInterval).ToString() + StringPoints;
            TimeFocusButtonText.text = (TimeLimit > 0 ? TimeLimit.ToString() + (TimeLimit > 1 ? StringMinutes : StringMinute) : StringInfinite);
        }
        else
        {
            //TerritoriesConfigurationPanel.SetActive(false);
        }

        // Juggernaut
        if (CurrentSelectedGameMode == GameModeType.JuggernautGameMode)
        {
            //JuggernautConfigurationPanel.SetActive(true);
            ScoreFocusButtonText.text = ScoreLimit.ToString() + (ScoreLimit > 1 ? StringKills : StringKill);
            TimeFocusButtonText.text = (TimeLimit > 0 ? TimeLimit.ToString() + (TimeLimit > 1 ? StringMinutes : StringMinute) : StringInfinite);
        }
        else
        {
            //JuggernautConfigurationPanel.SetActive(false);
        }
    }

    // Game mode setup buttons

    public void GameModeTypeButtonFunction(int aDirection)
    {
        if (EnableInputs == true)
        {
            EnableInputs = false;

            if (aDirection < 0)
            {
                if (CurrentSelectedGameMode == 0)
                {
                    CurrentSelectedGameMode = (GameModeType)(GameModes.Length - 1);
                }
                else
                {
                    CurrentSelectedGameMode--;
                }
                UpdateGameModeSetupButtonTexts();
            }
            else if (aDirection > 0)
            {
                if (CurrentSelectedGameMode == (GameModeType)(GameModes.Length - 1))
                {
                    CurrentSelectedGameMode = 0;
                }
                else
                {
                    CurrentSelectedGameMode++;
                }
                UpdateGameModeSetupButtonTexts();
            }

            ForceSelectionOfFirstMenuItem();

            EnableInputs = true;
        }
    }

    public void GameModeTeamsButtonFunction(int aDirection)
    {
        m_TeamsEnabled = !m_TeamsEnabled;

        UpdateGameModeSetupButtonTexts();
    }

    public void GameModeScoreLimitButtonFunction(int aDirection)
    {
        if (EnableInputs == true)
        {
            if (aDirection < 0)
            {
                ScoreLimit--;
                if (ScoreLimit < MinScoreLimit)
                {
                    ScoreLimit = MinScoreLimit;
                }
            }
            else if (aDirection > 0)
            {
                ScoreLimit++;
                if (ScoreLimit > MaxScoreLimit)
                {
                    ScoreLimit = MaxScoreLimit;
                }
            }
            UpdateGameModeSetupButtonTexts();
        }
    }

    public void GameModeTimeLimitButtonFunction(int aDirection)
    {
        if (EnableInputs == true)
        {
            if (aDirection < 0)
            {
                TimeLimit--;
                if (TimeLimit < MinTimeLimit)
                {
                    TimeLimit = MinTimeLimit;
                }
            }
            else if (aDirection > 0)
            {
                TimeLimit++;
                if (TimeLimit > MaxTimeLimit)
                {
                    TimeLimit = MaxTimeLimit;
                }
            }
            UpdateGameModeSetupButtonTexts();
        }
    }

    public void GameModeRespawnTimeButtonFunction(int aDirection)
    {
        if (EnableInputs == true)
        {
            if (aDirection < 0)
            {
                RespawnTime--;
                if (RespawnTime < MinRespawnTime)
                {
                    RespawnTime = MinRespawnTime;
                }
            }
            else if (aDirection > 0)
            {
                RespawnTime++;
                if (RespawnTime > MaxRespawnTime)
                {
                    RespawnTime = MaxRespawnTime;
                }
            }
            UpdateGameModeSetupButtonTexts();
        }
    }

    public void KingOfTheHillRotationButtonFunction(int aDirection)
    {
        if (EnableInputs == true)
        {
            if (aDirection < 0)
            {
                if (KothHillRotationOption == 0)
                {
                    KothHillRotationOption = HillRotationOption.MAX_OPTION;
                }
                KothHillRotationOption--;
            }
            else if (aDirection > 0)
            {
                KothHillRotationOption++;
                if (KothHillRotationOption == HillRotationOption.MAX_OPTION)
                {
                    KothHillRotationOption = 0;
                }
            }
            UpdateGameModeSetupButtonTexts();
        }
    }

    public void KingOfTheHillChangeIntervalButtonFunction(int aDirection)
    {
        if (EnableInputs == true)
        {
            if (aDirection < 0)
            {
                KothRotationTime -= KothScoreInterval;
                if (KothRotationTime < KothMinRotationTime)
                {
                    KothRotationTime = KothMinRotationTime;
                }
            }
            else if (aDirection > 0)
            {
                KothRotationTime += KothScoreInterval;
                if (KothRotationTime > KothMaxRotationTime)
                {
                    KothRotationTime = KothMaxRotationTime;
                }
            }
            UpdateGameModeSetupButtonTexts();
        }
    }

    string GetStringNameForHillRotation()
    {
        switch (KothHillRotationOption)
        {
            case HillRotationOption.Ordered:
                return StringHillRotationOptionOrdered;
            case HillRotationOption.Static:
                return StringHillRotationOptionStatic;
            case HillRotationOption.Random:
                return StringHillRotationOptionRandom;
            default:
                return StringInvalid + KothHillRotationOption.ToString();
        }
    }

    // Game mode setup left/right button selections
    public void GameModeSetupButtonInput(int aDirection)
    {
        if (CurrentState == CharacterSelectionSceneState.SelectingGameModes)
        {
            // Game mode type selection
            if (EventSystem.current.currentSelectedGameObject == SetupGameModePanelFocusButton)
            {
                GameModeTypeButtonFunction(aDirection);
                return;
            }
            // Teams On/Off selection
            if (EventSystem.current.currentSelectedGameObject == TeamsFocusButton)
            {
                GameModeTeamsButtonFunction(aDirection);
            }
            // Score limit selection
            if (EventSystem.current.currentSelectedGameObject == ScoreFocusButton)
            {
                GameModeScoreLimitButtonFunction(aDirection);
                return;
            }
            // Time limit selection
            if (EventSystem.current.currentSelectedGameObject == TimeFocusButton)
            {
                GameModeTimeLimitButtonFunction(aDirection);
                return;
            }
            // Respawn time selection
            if (EventSystem.current.currentSelectedGameObject == RespawnTimeFocusButton)
            {
                GameModeRespawnTimeButtonFunction(aDirection);
                return;
            }
            // King of the Hill - Hill rotation and time interval
            if (EventSystem.current.currentSelectedGameObject == KothHillRotationFocusButton)
            {
                KingOfTheHillRotationButtonFunction(aDirection);
                return;
            }
            if (EventSystem.current.currentSelectedGameObject == KothHillChangeIntervalFocusButton)
            {
                KingOfTheHillChangeIntervalButtonFunction(aDirection);
                return;
            }
        }
        else if (CurrentState == CharacterSelectionSceneState.SelectingTeams)
        {
            // Player team selection
            for (int i = 0; i < InputManager.MAX_PLAYERS; i++)
            {
                if (EventSystem.current.currentSelectedGameObject == TeamsSetupPlayerFocusButtons[i])
                {
                    TeamsSetupButtonFunction(i, aDirection);
                    return;
                }
            }
        }
    }

    #endregion


    #region Teams Setup

    public void SetupTeamsPanel()
    {
        InputManager.CM.ResetPlayerNames();

        for (int i = 0; i < InputManager.MAX_PLAYERS; i++)
        {
            if (i < InputManager.CM.Players.Count)
            {
                GameInputComponent input = InputManager.CM.Players[i];
                if (input.TeamIndex < 0 || input.TeamIndex >= InputManager.MAX_PLAYERS)
                {
                    input.TeamIndex = 0;
                }

                string name = input.LongPlayerName;

                TeamsSetupPlayerPanels[i].SetActive(true);
                TeamsSetupPlayerFocusButtonTexts[i].text = name;// + " - " + input.Character.ToString();

                Color newColor = BaseGameMode.TeamColors[input.TeamIndex];
                newColor.a = 1.0f;

                TeamsSetupPlayerTeamPanels[i].GetComponent<Image>().color = newColor;
                TeamsSetupPlayerTeamPanelTexts[i].text = BaseGameMode.TeamNames[input.TeamIndex];
            }
            else
            {
                TeamsSetupPlayerPanels[i].SetActive(false);
            }
        }
    }

    public void TeamsSetupButtonFunction(int aPlayerIndex, int aDirection)
    {
        // If -1 passed in, need to determine which button is selected.
        if (aPlayerIndex < 0)
        {
            for (int i = 0; i < InputManager.MAX_PLAYERS; i++)
            {
                if (EventSystem.current.currentSelectedGameObject == TeamsSetupPlayerFocusButtons[i])
                {
                    aPlayerIndex = i;
                    break;
                }
            }
            // If there was no button selected above, don't continue
            // i.e. the EventSystem's current selection is the Start or Back button
            if (aPlayerIndex < 0)
            {
                return;
            }
        }

        GameInputComponent input = InputManager.CM.Players[aPlayerIndex];
        if (aDirection < 0)
        {
            if (input.TeamIndex == 0)
            {
                input.TeamIndex = InputManager.MAX_PLAYERS - 1;
            }
            else
            {
                input.TeamIndex--;
            }
        }
        else if (aDirection > 0)
        {
            if (input.TeamIndex == InputManager.MAX_PLAYERS - 1)
            {
                input.TeamIndex = 0;
            }
            else
            {
                input.TeamIndex++;
            }
        }

        Color newColor = BaseGameMode.TeamColors[input.TeamIndex];
        newColor.a = 1.0f;

        TeamsSetupPlayerTeamPanels[aPlayerIndex].GetComponent<Image>().color = newColor;
        TeamsSetupPlayerTeamPanelTexts[aPlayerIndex].text = BaseGameMode.TeamNames[input.TeamIndex];
    }


    #region TeamsSetupPlayerPlayerXFunction Button Handlers
    // Unity UI buttons do not allow for more than one param to be used,
    // thus these functions are needed as a wrapper for TeamsSetupButtonFunction.
    public void TeamsSetupPlayerOneFunction(int aDirection)
    {
        TeamsSetupButtonFunction(0, aDirection);
    }

    public void TeamsSetupPlayerTwoFunction(int aDirection)
    {
        TeamsSetupButtonFunction(1, aDirection);
    }

    public void TeamsSetupPlayerThreeFunction(int aDirection)
    {
        TeamsSetupButtonFunction(2, aDirection);
    }

    public void TeamsSetupPlayerFourFunction(int aDirection)
    {
        TeamsSetupButtonFunction(3, aDirection);
    }

    public void TeamsSetupPlayerFiveFunction(int aDirection)
    {
        TeamsSetupButtonFunction(4, aDirection);
    }

    public void TeamsSetupPlayerSixFunction(int aDirection)
    {
        TeamsSetupButtonFunction(5, aDirection);
    }

    public void TeamsSetupPlayerSevenFunction(int aDirection)
    {
        TeamsSetupButtonFunction(6, aDirection);
    }

    public void TeamsSetupPlayerEightFunction(int aDirection)
    {
        TeamsSetupButtonFunction(7, aDirection);
    }
    #endregion

    #endregion


    #region GameMenu EventSystem Code

    void UpdateEventSystemForMenu()
    {
        StartCoroutine(HandleEventSystemUpdate());
    }

    IEnumerator HandleEventSystemUpdate()
    {
        switch (CurrentState)
        {
            case CharacterSelectionSceneState.SelectingCharacters:
                SetupAIPanel.SetActive(false);
                SetupGameModePanel.SetActive(false);
                TeamsSetupPanel.SetActive(false);

                //yield return null;

                DisableNavigation();

                break;
            case CharacterSelectionSceneState.SelectingAI:
                SetupAIPanel.SetActive(true);
                SetupGameModePanel.SetActive(false);
                TeamsSetupPanel.SetActive(false);

                //yield return null;

                FirstSelectableMenuItem = SetupAIPanelFirstGameObject;
                EventSystem.current.SetSelectedGameObject(FirstSelectableMenuItem);

                EnableNavigation();

                //yield return null;

                ForceSelectionOfFirstMenuItem();

                break;
            case CharacterSelectionSceneState.SelectingGameModes:
                SetupGameModePanel.SetActive(true);
                SetupAIPanel.SetActive(false);
                TeamsSetupPanel.SetActive(false);

                //yield return null;

                FirstSelectableMenuItem = SetupGameModePanelFirstGameObject;
                EventSystem.current.SetSelectedGameObject(FirstSelectableMenuItem);

                EnableNavigation();

                //yield return null;

                ForceSelectionOfFirstMenuItem();

                break;
            case CharacterSelectionSceneState.SelectingTeams:
                SetupGameModePanel.SetActive(false);
                SetupAIPanel.SetActive(false);
                TeamsSetupPanel.SetActive(true);

                FirstSelectableMenuItem = TeamsSetupPanelFirstGameObject;
                EventSystem.current.SetSelectedGameObject(FirstSelectableMenuItem);

                EnableNavigation();

                ForceSelectionOfFirstMenuItem();

                break;
            default:
#if UNITY_EDITOR
                DebugManager.LogError("Invalid CharacterSelectionSceneState: " + CurrentState.ToString(), Developmer.Evan);
#endif
                break;
        }
        yield return null;
    }

    #endregion

    #region Reacting to InputManager Adding and Dropping Players

    void UpdatePlayerInformationOnPlayersChanged()
    {
        if (CurrentState == CharacterSelectionSceneState.SelectingCharacters)
        {
            UpdatePlayerInformationPanels();

            for (int i = 0; i < PlayerCameras.Length; i++)
            {
                bool setActive = false;
                bool lockedIn = false;

                GameInputComponent player = null;

                if (i < InputManager.CM.Players.Count)
                {
                    setActive = true;
                    player = InputManager.CM.Players[i];
                    lockedIn = player.LockedIn;
                }

                Camera cam = PlayerCameras[i];
                if (cam.gameObject.activeSelf != setActive)
                    cam.gameObject.SetActive(setActive);

                if (setActive)
                {
                    // Once at least one camera is added, we don't have to display this anymore.
                    // Even if removing players, if number of players reaches 0, we automatically
                    // go back to the Main Menu so there is no need to see it then.
                    if (AddControllerText.gameObject.activeSelf != false)
                        AddControllerText.SetActive(false);

                    int cameraPositionIndex = GetCameraPositionIndexForCharacter(player.Character);
                    GameObject cameraPosition = CameraPositions[cameraPositionIndex];

                    cam.transform.position = cameraPosition.transform.position;
                    cam.transform.rotation = cameraPosition.transform.rotation;

                    UpdateCharacterNameAtIndex(i);
                }

                PlayerInformationPanel panel = PlayerInformationPanels[i];
                if (lockedIn)
                {
                    panel.PlayerLockedInText.text = StringLockedIn;
                }
                else
                {
                    panel.PlayerLockedInText.text = StringSelectPlayer;
                }

                panel.UpdateAbilityDescriptionsForCharacter(i);
                panel.UpdateAbilityButtonIcons(i);
                panel.UpdateControlsButtonIcons(i);

                // Update selecting profile
                if (player != null && player.PickingProfile == true)
                {
                    panel.SetState(PlayerInformationPanel.State.SelectingProfile);
                    panel.SelectProfileButtonAtIndex(player.CurrentProfileButtonIndex);
                }
                else
                {
                    panel.SetState(PlayerInformationPanel.State.SelectingCharacter);
                    panel.SelectProfileButtonAtIndex(0);
                }
            }

            CameraManager.UpdateMenuCameraPositions(PlayerCameras, false);
            UpdatePlayerInformationPanels();
        }
    }


    // This event gets fired after InputManager has added a player.
    public void OnPlayerAdded()
    {
        UpdatePlayerInformationOnPlayersChanged();
    }

    // This event gets fired after InputManager has dropped a player.
    public void OnPlayerDropped()
    {
        UpdatePlayerInformationOnPlayersChanged();
    }

    public void OnEnable()
    {
        //Debug.Log("NewCharacterSelectionScript - OnEnable");
        InputManager.CM.OnPlayerAdded += OnPlayerAdded;
        InputManager.CM.OnPlayerDropped += OnPlayerDropped;
    }

    public void OnDisable()
    {
        //Debug.Log("NewCharacterSelectionScript - OnDisable");
        InputManager.CM.OnPlayerAdded -= OnPlayerAdded;
        InputManager.CM.OnPlayerDropped -= OnPlayerDropped;
    }

    #endregion
}