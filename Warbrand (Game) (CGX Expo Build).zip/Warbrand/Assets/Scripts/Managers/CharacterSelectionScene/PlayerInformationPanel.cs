﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

// TODO: remove all if (EditControlsPanel != null) checks

// A container class for all of the UI GameObjects
public class PlayerInformationPanel : MonoBehaviour
{
    public NewCharacterSelectionScript ParentMenu;
    public int PlayerIndex;

    [Tooltip("Components of the ProfilesPanel Panel")]
    public GameObject ProfilesPanel;
    public ScrollRect ProfilesScrollRect;
    public GameObject ProfilesPanelScrollViewViewport;
    public GameObject ProfilesPanelScrollViewContent;
    public GameObject CommandButtonsPanel;
    public GameObject ProfileButtonsPanel;

    [Space(10)]
    [Tooltip("Components of the CharacterSelection Panel")]
    public GameObject CharacterSelectionPanel;
    public Text CharacterNameText;
    public Text PlayerLockedInText;

    [Space(10)]
    [Tooltip("Ability Description Panels Parent")]
    public GameObject AbilityDescriptionsParentPrefab;

    [Space(10)]
    public NewEditControlScript EditControlsPanel;

    // Controls button icons

    [Space(10)]
    [Tooltip("Controls Button Icons")]
    public HudButtonIconHelper CharacterSelection_SelectButtonImage;
    public HudButtonIconHelper CharacterSelection_BackButtonImage;
    public HudButtonIconHelper CharacterSelection_ConfigureControlsButtonImage;
    public HudButtonIconHelper CharacterSelection_SelectProfileButtonImage;
    public HudButtonIconHelper CharacterSelection_ShowAbilitiesButtonImage;

    public HudButtonIconHelper ProfileSelect_SelectButtonImage;
    public HudButtonIconHelper ProfileSelect_BackButtonImage;

    // Ability descriptions
    public GameObject AbilityDescriptionsParent = null;
    protected AbilityDescription[] AbilityDescriptions = null;

    protected int m_SelectedProfileButtonIndex = -1;

    public int TotalProfileButtonsCount
    {
        get
        {
            return CommandButtonsPanel.transform.childCount + ProfileButtonsPanel.transform.childCount;
        }
    }

    public enum State
    {
        SelectingCharacter,
        SelectingProfile,
        CreatingProfile,
        EditingControls
    }

    // Misc. Properties
    [HideInInspector]
    public State CurrentState
    {
        get
        {
            return m_CurrentState;
        }
    }
    protected State m_CurrentState = State.SelectingCharacter;

    void Awake()
    {
        if (AbilityDescriptionsParentPrefab != null)
        {
            GameObject AbilityDescriptionsParentInstance = Instantiate(AbilityDescriptionsParentPrefab) as GameObject;

            if (AbilityDescriptionsParentInstance != null)
            {
                AbilityDescriptionsParent = AbilityDescriptionsParentInstance;

                AbilityDescriptionsParentInstance.transform.SetParent(CharacterSelectionPanel.transform, false);

                AbilityDescriptionsParentInstance.transform.SetAsFirstSibling();

                // This should be equal to AbilityDescription.AbilityIndex.MAX_ABILITY_INDEX or something is wrong.
                int childCount = AbilityDescriptionsParentInstance.transform.childCount;

                AbilityDescriptions = new AbilityDescription[(int)AbilityDescription.AbilityIndex.MAX_ABILITY_INDEX];

                for (int i = 0; i < childCount; i++)
                {
                    AbilityDescriptions[i] = AbilityDescriptionsParentInstance.transform.GetChild(i).GetComponent<AbilityDescription>();
                }
            }
        }

        if (EditControlsPanel == null)
        {
            EditControlsPanel = GetComponentInChildren<NewEditControlScript>();
        }

        if (EditControlsPanel != null)
        {
            EditControlsPanel.ParentMenu = ParentMenu;
            EditControlsPanel.PlayerIndex = PlayerIndex;
            EditControlsPanel.PopulateInputsList();
            EditControlsPanel.OnEditControlScriptComplete += ParentMenu.OnEditControlsScriptComplete;
        }
    }

    void OnDestroy()
    {
        if (EditControlsPanel != null)
        {
            EditControlsPanel.OnEditControlScriptComplete -= ParentMenu.OnEditControlsScriptComplete;
        }
    }

    public void SetState(State aState, CharacterTypes aCharacterType = 0)
    {
        m_CurrentState = aState; 

        switch (aState)
        {
            case State.SelectingCharacter:
                CharacterSelectionPanel.SetActive(true);
                ProfilesPanel.SetActive(false);
                if (EditControlsPanel != null)
                {
                    EditControlsPanel.gameObject.SetActive(false);
                }
                break;
            case State.SelectingProfile:
                m_SelectedProfileButtonIndex = -1;
                SelectProfileButtonAtIndex(0);
                CharacterSelectionPanel.SetActive(false);
                ProfilesPanel.SetActive(true);
                if (EditControlsPanel != null)
                {
                    EditControlsPanel.gameObject.SetActive(false);
                }
                break;
            case State.CreatingProfile:
                CharacterSelectionPanel.SetActive(false);
                ProfilesPanel.SetActive(false);
                if (EditControlsPanel != null)
                {
                    EditControlsPanel.gameObject.SetActive(false);
                }
                break;
            case State.EditingControls:
                CharacterSelectionPanel.SetActive(false);
                ProfilesPanel.SetActive(false);
                //if (EditControlsPanel != null)
                //{
                //    EditControlsPanel.gameObject.SetActive(true);
                //    EditControlsPanel.SetSelectInputToConfigurePanelVisible(aCharacterType);
                //}
                break;
        }
    }

	public void UpdateAbilityDescriptionsForCharacter(int aPlayerIndex)
    {
        if (aPlayerIndex < InputManager.CM.Players.Count)
        {
            GameInputComponent input = InputManager.CM.Players[aPlayerIndex];

            switch (input.Character)
            {
                case CharacterTypes.Leeroy:
                    UpdateDescriptions(CharacterTypes.Leeroy);
                    break;
                case CharacterTypes.Zeph:
                    UpdateDescriptions(CharacterTypes.Zeph);
                    break;
                case CharacterTypes.Quark:
                    UpdateDescriptions(CharacterTypes.Quark);
                    break;
                case CharacterTypes.Paige:
                    UpdateDescriptions(CharacterTypes.Paige);
                    break;
                default:
#if UNITY_EDITOR
                    DebugManager.LogError("Invalid character type: " + input.Character.ToString(), Developmer.AllDevelopmers);
#endif
                    break;
            }
        }
    }

    void UpdateDescriptions(CharacterTypes aCharacter)
    {
        for (int i = 0; i < (int)AbilityDescription.AbilityIndex.MAX_ABILITY_INDEX; i++)
        {
            AbilityDescriptions[i].SetAbilityIconAndDescription(aCharacter, (AbilityDescription.AbilityIndex)i);
        }
    }

    public void UpdateAbilityButtonIcons(int aPlayerIndex)
    {
        if (aPlayerIndex < InputManager.CM.Players.Count)
        {
            PlayerInput input = InputManager.CM.Players[aPlayerIndex].Input as PlayerInput;

            for (int i = 0; i < AbilityDescription.InputNames.Length; i++)
            {
                InputName inputName = AbilityDescription.InputNames[i];

                AbilityDescriptions[i].ButtonIconImage.UpdateAbilityIconButton(input, inputName);

                if (inputName == InputName.Attack2)
                {
                    // We only want to show Attack2 (shield) if the character is Leeroy.
                    bool showAttack2IfLeeroy = false;

                    if (input.Input.Character == CharacterTypes.Leeroy)
                    {
                        showAttack2IfLeeroy = true;
                    }

                    if (AbilityDescriptions[i].gameObject.activeSelf != showAttack2IfLeeroy)
                    {
                        AbilityDescriptions[i].gameObject.SetActive(showAttack2IfLeeroy);
                    }
                }
            }
        }
    }

    public void UpdateControlsButtonIcons(int aPlayerIndex)
    {
        if (aPlayerIndex < InputManager.CM.Players.Count)
        {
            PlayerInput input = InputManager.CM.Players[aPlayerIndex].Input as PlayerInput;

            CharacterSelection_SelectButtonImage.UpdateAbilityIconButton(input, InputName.Menu_Pause);
            CharacterSelection_BackButtonImage.UpdateAbilityIconButton(input, InputName.Menu_Cancel);
            CharacterSelection_ConfigureControlsButtonImage.UpdateAbilityIconButton(input, InputName.Menu_Configure);
            CharacterSelection_SelectProfileButtonImage.UpdateAbilityIconButton(input, InputName.Menu_Option);
            CharacterSelection_ShowAbilitiesButtonImage.UpdateAbilityIconButton(input, InputName.Menu_Scoreboard);

            ProfileSelect_SelectButtonImage.UpdateAbilityIconButton(input, InputName.Menu_Pause);
            ProfileSelect_BackButtonImage.UpdateAbilityIconButton(input, InputName.Menu_Cancel);
        }
    }

    public void SelectProfileButtonAtIndex(int aButtonIndex)
    {
        int commandButtonsCount = CommandButtonsPanel.transform.childCount;
        int profileButtonsCount = ProfileButtonsPanel.transform.childCount;
        int totalProfileButtons = commandButtonsCount + profileButtonsCount;

        if (aButtonIndex < 0)
            aButtonIndex = 0;
        if (aButtonIndex >= totalProfileButtons)
            aButtonIndex = totalProfileButtons - 1;

        if (m_SelectedProfileButtonIndex != aButtonIndex)
        {
            // Set previously selected button to unselected image sprite
            if (m_SelectedProfileButtonIndex != -1)
            {
                if (m_SelectedProfileButtonIndex < commandButtonsCount)
                {
                    Button button = CommandButtonsPanel.transform.GetChild(m_SelectedProfileButtonIndex).GetComponent<Button>();
                    button.image.sprite = ParentMenu.UnselectedButtonImage;
                }
                else
                {
                    Button button = ProfileButtonsPanel.transform.GetChild(m_SelectedProfileButtonIndex - commandButtonsCount).GetComponent<Button>();
                    button.image.sprite = ParentMenu.UnselectedButtonImage;
                }
            }

            // Set the new selected button to the selected image sprite
            if (aButtonIndex < commandButtonsCount)
            {
                Button button = CommandButtonsPanel.transform.GetChild(aButtonIndex).GetComponent<Button>();
                button.image.sprite = ParentMenu.SelectedButtonImage;
            }
            else
            {
                Button button = ProfileButtonsPanel.transform.GetChild(aButtonIndex - commandButtonsCount).GetComponent<Button>();
                button.image.sprite = ParentMenu.SelectedButtonImage;
            }

            // Update the local selected button index
            m_SelectedProfileButtonIndex = aButtonIndex;

            //Update the scrolling of the scroll view's viewport
            InterfaceUtils.SetScrollViewViewportHeightPosition(ProfilesScrollRect, ProfilesPanelScrollViewContent, m_SelectedProfileButtonIndex, totalProfileButtons);
        }
    }

    public void SelectCurrentProfileButton(int aPlayerIndex)
    {
        int commandButtonsCount = CommandButtonsPanel.transform.childCount;
        int profileButtonsCount = ProfileButtonsPanel.transform.childCount;
        int totalProfileButtons = commandButtonsCount + profileButtonsCount;

        if (m_SelectedProfileButtonIndex < commandButtonsCount)
        {
            Button button = CommandButtonsPanel.transform.GetChild(m_SelectedProfileButtonIndex).GetComponent<Button>();
            button.onClick.Invoke();
        }
        else
        {
            Button button = ProfileButtonsPanel.transform.GetChild(m_SelectedProfileButtonIndex - commandButtonsCount).GetComponent<Button>();
            button.onClick.Invoke();
        }
    }
}
