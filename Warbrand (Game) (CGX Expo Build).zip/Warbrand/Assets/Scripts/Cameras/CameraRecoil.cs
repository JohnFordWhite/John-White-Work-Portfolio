﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        CameraRecoil                                                                   *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            January 19th, 2017                                                             *
 *                                                                                                 *
 * Bucks the camera up and then down, to simulate shotgun recoil.                                  *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - January 19th, 2017                                          *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;

public class CameraRecoil : MonoBehaviour
{
    public float BuckAmount = 1.5f;
    public float BuckLength = 0.1f;

    public void Recoil()
    {
        if (transform.rotation.eulerAngles.x >0 && transform.rotation.eulerAngles.x < 90 || transform.rotation.eulerAngles.x > 275 && transform.rotation.eulerAngles.x < 360)
                StartCoroutine(RecoilCR(BuckLength/2));
    }
    
    IEnumerator RecoilCR(float aTime)
    {
        float originalTime = aTime;
        Quaternion startRot = transform.rotation;
        Quaternion newRot = Quaternion.Euler(transform.rotation.eulerAngles.x + -BuckAmount, transform.rotation.eulerAngles.y, transform.rotation.eulerAngles.z);

        while (aTime > 0.0f)
        {

            aTime -= Time.deltaTime;

            transform.rotation = Quaternion.Lerp(startRot, Quaternion.Euler(transform.rotation.eulerAngles.x + -BuckAmount, transform.rotation.eulerAngles.y, transform.rotation.eulerAngles.z), 1 - (aTime / originalTime));

            yield return null;
        }

        aTime = originalTime;
        Quaternion currentRot = transform.rotation;
        newRot = Quaternion.Euler(startRot.x, transform.rotation.eulerAngles.y, transform.rotation.eulerAngles.z);


        while (aTime > 0.0f)
        {
            aTime -= Time.deltaTime;

            transform.rotation = Quaternion.Lerp(currentRot, Quaternion.Euler(startRot.eulerAngles.x, transform.rotation.eulerAngles.y, transform.rotation.eulerAngles.z), 1 - (aTime / originalTime));

            yield return null;
        }

    }
}
