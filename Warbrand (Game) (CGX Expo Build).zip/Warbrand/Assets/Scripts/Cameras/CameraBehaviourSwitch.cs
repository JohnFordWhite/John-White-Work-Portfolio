﻿using UnityEngine;
using System.Collections;

public class CameraBehaviourSwitch
{
    //
    //Public
    //
    public Player Owner = null;


    //
    //Private
    //
    private CameraManager m_CameraManager = null;

    //strings
    private const string m_ManagerPath = "Managers";

    public CameraBehaviourSwitch(Player aPlayer)
    {
        Owner = aPlayer;
    }

    public void ChangeCamera()
    {
        if (GameObject.Find(m_ManagerPath).GetComponent<CameraManager>() != null)
        {
            m_CameraManager = GameObject.Find(m_ManagerPath).GetComponent<CameraManager>();
        }
        else
        {
            return;
        }

        if (Owner.ThirdPersonPlayerCamera.gameObject.activeSelf == true)
        {
            Owner.ThirdPersonPlayerCamera.gameObject.SetActive(false);
            Owner.FirstPersonPlayerCamera.gameObject.SetActive(true);
            Owner.PlayerCamera = Owner.FirstPersonPlayerCamera.GetComponent<Camera>();
            Owner.XRayCamera = Owner.FirstPersonPlayerCamera.GetComponentInChildren<Camera>();

            Canvas[] canvasArray = Owner.GetComponentsInChildren<Canvas>();
            for (int i = 0; i < canvasArray.Length; i++)
            {
                Canvas canvas = canvasArray[i];

                canvas.worldCamera = Owner.FirstPersonPlayerCamera;
            }
        }
        else
        {
            Owner.ThirdPersonPlayerCamera.gameObject.SetActive(true);
            Owner.FirstPersonPlayerCamera.gameObject.SetActive(false);
            Owner.PlayerCamera = Owner.ThirdPersonPlayerCamera.GetComponent<Camera>();
            Owner.XRayCamera = Owner.ThirdPersonPlayerCamera.GetComponentInChildren<Camera>();

            Canvas[] canvasArray = Owner.GetComponentsInChildren<Canvas>();
            for (int i = 0; i < canvasArray.Length; i++)
            {
                Canvas canvas = canvasArray[i];

                canvas.worldCamera = Owner.ThirdPersonPlayerCamera;
            }
        }

        m_CameraManager.UpdateCameraPositions();
    }
}
