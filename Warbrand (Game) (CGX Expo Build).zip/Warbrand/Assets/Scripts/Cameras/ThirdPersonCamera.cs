﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        ThirdPersonCamera                                                              *
 * FileExtension:   .cs                                                                            *
 * Author:          Nathan Pringle                                                                 *
 * Date:            September 16th, 2016                                                           *
 *                                                                                                 *
 * This file should be attached to a Camera Object in order to replicate a third person point of   *
 * view. Camera does not have to be a child of its target: if it is put as a child, the code will  *
 * remove this.                                                                                    *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Nathan Pringle) - September 16th, 2016                                    *
 * V 1.1 - Fixed Clipping Throug Objects (John White) - October 6th, 2016                          *
 * V 1.2 - Switched input from Unity's InputManager to Ruthless Fusion Games InputManager          *
 *         (Evan Campbell) - October 10th, 2016                                                    *
\***************************************************************************************************/

using UnityEngine;

public class ThirdPersonCamera : MonoBehaviour
{
    // 
    // Public Fields
    // 
    [Tooltip("The Distance the camera should be away from the target")]
    public float DefaultDistance = 10.0f;

    [Tooltip("The Target to follow")]
    public GameObject Target = null;

    [Tooltip("Check this if you would like to lock the mouse to the middle of the screen and disable it. Note: To undo this in the editor, press ESCAPE.")]
    public bool LockMouse = true;

    [Tooltip("Don't let the mouse look too high or too low, otherwise you get weird results. Keep this number low, but not too low.")]
    public float LockVerticalRotationValue = 0.5f;

    [Tooltip("The higher this number, the faster the mouse will move.")]
    public float MouseSensitivity = 7.5f;

    [Tooltip("If this is checked, the target will rotate along with the camera")]
    public bool RotateTarget = true;

    [Tooltip("Turn this on if the player should be able to look around while their player is stunned.")]
    public bool AllowRotationIfStunned = false;
    
    [Tooltip("The Player GameObject that this camera belongs to.")]
    public Player Owner;

    //
    // Private Fields
    //
    private Vector3 m_Rotation = Vector3.zero;
    private GameObject m_PivotPoint;
    private int m_ID;
    private int m_RaycastHitMask;
    private GameInputComponent m_GameInput;
    private bool m_HasBeenEnabledBefore = false;

    private const string m_CameraPivotPointTransform = "Camera Pivot Point";

    // Use this for initialization
    void Start ()
    {
        // If we need to, lock the mouse
        Cursor.lockState = ((LockMouse) ? CursorLockMode.Locked : CursorLockMode.None);

        // If the mouse is locked, we don't want to see it. Turn it off
        Cursor.visible = !LockMouse;

        // TODO: Uncomment this
        // If there is no target then just attach a first person camera instead
        //if (Target == null)
        //{
        //    this.enabled = false;
        //    gameObject.AddComponent<FirstPersonCamera>();
        //    return;
        //}

        // Create a pivot point for the camera
        m_PivotPoint = new GameObject(m_CameraPivotPointTransform);
        m_PivotPoint.transform.parent = null;
        gameObject.transform.SetParent(m_PivotPoint.transform);
    }
	
    void OnEnable()
    {
        //Debug.Log("3P enabled");
        if(m_HasBeenEnabledBefore)
        {
            m_Rotation = Target.transform.eulerAngles;
            m_PivotPoint.transform.eulerAngles = m_Rotation;
            transform.position = m_PivotPoint.transform.position + (-(m_PivotPoint.transform.forward.normalized));
        }

        m_HasBeenEnabledBefore = true;
    }

    // Update is called once per frame
    void Update ()
    {

#if UNITY_EDITOR
        if (Input.GetKey(KeyCode.Escape) || InputManager.CM.CurrentGameState != GameState.PlayGame)
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
#else
        // Hide cursor on PlayGame state, show otherwise.
        if (InputManager.CM.CurrentGameState != GameState.PlayGame)
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
#endif

        if (InputManager.CM.CurrentGameState != GameState.PlayGame || Target == null)
            return;

        // TODO: clean this up. This requires the Target and assumes that it has the GameInputComponent.
        if (m_GameInput == null)
        {
            m_GameInput = Owner.GameInput;
        }

        // TODO: Uncomment this
        //m_ID = Target.GetComponent<Player>().ID;
        // Update the position of the pivot point
        m_PivotPoint.transform.position = Target.transform.position;
        //m_PivotPoint.transform.position = Vector3.Lerp(m_PivotPoint.transform.position, Target.transform.position, Time.smoothDeltaTime);


        // Rotate the pivot point
        HandleRotation();
        LockRotation();

        // Set the pivot points rotation. Given that the camera is a child, this will also rotate and transform the camera
        m_PivotPoint.transform.eulerAngles = m_Rotation;

        transform.position = Vector3.Lerp(transform.position, m_PivotPoint.transform.position + (-(m_PivotPoint.transform.forward.normalized) * (DefaultDistance)), Time.deltaTime);

        CheckIfObstructed();

        // Make sure we're the correct distance away, as well as looking at the correct area
        //transform.position = m_PivotPoint.transform.position + (-(m_PivotPoint.transform.forward.normalized) * (Distance - m_DistanceToSubtract));
        transform.LookAt(m_PivotPoint.transform);

        if (RotateTarget && Target != null)
        {
            Target.transform.eulerAngles = transform.eulerAngles;

            Vector3 rot = Target.transform.eulerAngles;
            rot.x = 0;
            Target.transform.eulerAngles = rot;
        }
    }

    void HandleRotation()
    {
        // Get the actual values of the mouse movement
        
        // TODO: Verify - Get this working with the Input Manager
        //float x = Input.GetAxis("Mouse X");
        //float y = Input.GetAxis("Mouse Y");

        float x = 0.0f;
        float y = 0.0f;

        bool canRotate = true;

        if (Owner != null)
        {
            if (Owner.StunTime > 0.0f && AllowRotationIfStunned == false || Owner.AbilityBlockingRotation == true)
            {
                canRotate = false;
            }
        }

        if (m_GameInput != null && canRotate)
        {
            x = m_GameInput.GetInput(InputName.LookHorizontal);
            y = m_GameInput.GetInput(InputName.LookVertical);
        }

        // Gets the cameras current rotation. m_Rotation should still be set to the cameras rotation, so this is just a safety thing
        m_Rotation = m_PivotPoint.transform.rotation.eulerAngles;

        // If you're confused as to why we're changing the x axis with the y input and vise versa, take a look at the editor.
        // Take a look at where the three axis are pointed, then press "E" to swap to rotation version. Take a look at the colours of each circle.
        m_Rotation.x -= y * MouseSensitivity;
        m_Rotation.y += x * MouseSensitivity;
        m_Rotation.z = 0;
    }

    void LockRotation()
    {
        // Make sure we don't look too low.
        if (m_Rotation.x > 90 - LockVerticalRotationValue && m_Rotation.x < 180)
            m_Rotation.x = 90 - LockVerticalRotationValue;

        // Makes sure we don't look too high.
        if (m_Rotation.x < 270 + LockVerticalRotationValue && m_Rotation.x > 180)
            m_Rotation.x = 270 + LockVerticalRotationValue;
    }

    public void PlaceBehindTarget()
    {
        m_Rotation = Target.transform.eulerAngles;
        m_PivotPoint.transform.eulerAngles = m_Rotation;
        transform.position = m_PivotPoint.transform.position + (-(m_PivotPoint.transform.forward.normalized) * DefaultDistance);
        CheckIfObstructed();
    }

    bool CheckIfObstructed()
    {
        Vector3 rayStart = Target.transform.position;
        Vector3 rayEnd = transform.position;
        Vector3 rayDir = rayEnd - rayStart;

        // If the distance is zero, don't do anything
        float rayDist = rayDir.magnitude;
        if (rayDist <= 0.0f)
            return false;

        // Normalize
        rayDir /= rayDist;

        // Get all the objects that are in between the camera and the player
        //TODO: use layer masks to stop the raycast from hitting the player
        RaycastHit[] hitInfos = Physics.SphereCastAll(rayStart, 0.4f, rayDir, rayDist);
        if (hitInfos.Length <= 0)
            return false;
        
        float minMoveUpDist = float.MaxValue;
        for (int i = 0; i < hitInfos.Length; i++)
        {
            RaycastHit hitInfo = hitInfos[i];

            GameObject obstacleObject = hitInfo.collider.gameObject;

            //RECODE: to be removed once layer masks are implemented
            // If the object is us, our target, or a trigger, continue
            if (obstacleObject == gameObject)
                continue;
            if (obstacleObject == Target)
                continue;
            if (obstacleObject.transform.IsChildOf(Target.transform))
                continue;
            if (hitInfo.collider.isTrigger)
                continue;

            //TODO: implement fading of objects that are too close to the camera

            minMoveUpDist = Mathf.Min(minMoveUpDist, hitInfo.distance);
        }
        
        if (minMoveUpDist < float.MaxValue)
        {
            transform.position = rayStart + rayDir * minMoveUpDist;
            return true;
        }
        return false;
    }
}
