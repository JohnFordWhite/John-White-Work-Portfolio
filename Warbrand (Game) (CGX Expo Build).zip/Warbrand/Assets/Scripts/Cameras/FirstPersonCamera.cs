﻿/******************************************** File Header ********************************************\
 *                                                                                                   *
 * FileName:        FirstPersonCamera                                                                *
 * FileExtension:   .cs                                                                              *
 * Author:          Nathan Pringle                                                                   *
 * Date:            September 16th, 2016                                                             *
 *                                                                                                   *
 * This file should be attached to a Camera Object in order to replicate a first person point of     *
 * view. For basic shapes (such as capsules), the camera should be a child of the capsule, and its   *
 * transform should be at (0, 0, 0)                                                                  *
 *                                                                                                   *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR   *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS    *
 * FOR A PARTICULAR PURPOSE.                                                                         *
 *                                                                                                   *
 * V 1.0 - Created File (Nathan Pringle) - September 16th, 2016                                      *
 * V 1.1 - Added public values for x/y axis sensitivity (Jon Roffey) - October 10th, 2016            *
 *       - Added cursor lock functionality from ThirdPersonCamera (Jon Roffey) - October 10th, 2016  *
 *       - Updated inputs to work with the new InputManager (Jon Roffey) - October 10th, 2016        *
\*****************************************************************************************************/

using UnityEngine;

public class FirstPersonCamera : MonoBehaviour
{
    // 
    // Public Fields
    // 
    [Tooltip("Check this if you would like to lock the mouse to the middle of the screen and disable it. Note: To undo this in the editor, press ESCAPE.")]
    public bool LockMouse = true;

    [Tooltip("Don't let the mouse look too high or too low, otherwise you get weird results. Keep this number low, but not too low.")]
    public float LockVerticalRotationValue = 0.5f;

    [Tooltip("The higher this number, the faster the mouse will move on the X axis.")]
    public float XMouseSensitivity = 1f;

    [Tooltip("The higher this number, the faster the mouse will move on the Y axis.")]
    public float YMouseSensitivity = 1f;

    public bool MoveParent = true;

    [Tooltip("Turn this on if the player should be able to look around while their player is stunned.")]
    public bool AllowRotationIfStunned = false;

    [Tooltip("The Player GameObject that this camera belongs to.")]
    public Player Owner;

    //
    // Private Fields
    //
    private Vector3 m_Rotation = Vector3.zero;
    private GameInputComponent m_GameInput;
    private int m_ID;
    private LayerMask m_ParentLayer;
    private LayerMask m_AimAssistMask;

    // Runs on start
    void Start()
    {
        transform.GetComponentInParent<Rigidbody>().freezeRotation = true;

        // If we need to, lock the mouse
        Cursor.lockState = ((LockMouse) ? CursorLockMode.Locked : CursorLockMode.None);

        // If the mouse is locked, we don't want to see it. Turn it off
        Cursor.visible = !LockMouse;

        m_ParentLayer = transform.parent.gameObject.layer;

        m_AimAssistMask = ~((1 << LayerMask.NameToLayer("UnplacedObjects")) |
                            (1 << LayerMask.NameToLayer("Ignore Raycast")) |
                            (1 << LayerMask.NameToLayer("WallCollider")) |
                            (1 << LayerMask.NameToLayer("Shield")) |
                            (1 << LayerMask.NameToLayer("Hook")) |
                            (1 << LayerMask.NameToLayer("Weapons")) |
                            (1 << LayerMask.NameToLayer("Ragdoll")));
        m_AimAssistMask -= 1 << m_ParentLayer;

        GetComponent<Camera>().cullingMask = GetComponent<Camera>().cullingMask & ~(1 << m_ParentLayer);
        //Debug.Log(LayerMask.LayerToName(m_ParentLayer));
    }

    void OnEnable()
    {
        //Debug.Log("1P enabled");
    }

    void Update()
    {
#if UNITY_EDITOR
        if (Input.GetKey(KeyCode.Escape) || InputManager.CM.CurrentGameState != GameState.PlayGame)
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
#else
        // Hide cursor on PlayGame state, show otherwise.
        if (InputManager.CM.CurrentGameState != GameState.PlayGame)
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
#endif


        if (InputManager.CM.CurrentGameState != GameState.PlayGame)
            return;

        // TODO: Cleanup but allow for dropping non-players into scene without null reference errors
        if (m_GameInput == null && transform.parent != null && transform.parent.parent != null)
        {
            m_GameInput = Owner.GameInput;
        }

        //TODO: Uncomment
        //if (transform.parent != null)
            //m_ID = transform.parent.GetComponent<Player>().ID;

        // Takes the inputs and moves the mouse
        HandleRotation();

        // Makes sure we aren't looking too high or too low
        LockRotation();

        // Finally, sets the actual angle of the camera
        if (MoveParent && transform.parent != null)
        {
            Vector3 rotation = m_Rotation;
            rotation.x = 0;
            transform.parent.transform.eulerAngles = rotation;
            transform.eulerAngles = m_Rotation;
        }
        else
            transform.eulerAngles = m_Rotation;
    }

    void HandleRotation()
    {
        // Get the actual values of the mouse movement
        float x = 0.0f;
        float y = 0.0f;

        bool canRotate = true;

        if (Owner != null && Owner.StunTime > 0.0f && AllowRotationIfStunned == false || Owner.AbilityBlockingRotation == true)
        {
            canRotate = false;
        }

        //Aim Assist
        float AimAssistFactor = 1.0f;

        if (!Owner.IsAI && (Owner.GameInput.Input as PlayerInput).Device != InputDevice.Keyboard)
        {
            RaycastHit hitinfo;
            if (Physics.SphereCast(transform.position, 0.2f, transform.forward, out hitinfo, 100, m_AimAssistMask, QueryTriggerInteraction.Ignore))
            {
                if (hitinfo.collider.gameObject.GetComponent<PlayerHitboxScript>() != null)
                {
                    AimAssistFactor = 0.35f;
                }
            }
        }

        if (m_GameInput != null && canRotate)
        {
            x = m_GameInput.GetInput(InputName.LookHorizontal);
            y = m_GameInput.GetInput(InputName.LookVertical);
        }

        // Gets the cameras current rotation. m_Rotation should still be set to the cameras rotation, so this is just a safety thing
        m_Rotation = transform.rotation.eulerAngles;

        // If you're confused as to why we're changing the x axis with the y input and vise versa, take a look at the editor.
        // Take a look at where the three axis are pointed, then press "E" to swap to rotation version. Take a look at the colours of each circle.
        m_Rotation.x -= y * XMouseSensitivity * AimAssistFactor * Time.smoothDeltaTime;
        m_Rotation.y += x * YMouseSensitivity * AimAssistFactor * Time.smoothDeltaTime;
        m_Rotation.z = 0;
    }

    void LockRotation()
    {
        // Make sure we don't look too low.
        if (m_Rotation.x > 90 - LockVerticalRotationValue && m_Rotation.x < 180)
            m_Rotation.x = 90 - LockVerticalRotationValue;

        // Makes sure we don't look too high.
        if (m_Rotation.x < 270 + LockVerticalRotationValue && m_Rotation.x > 180)
            m_Rotation.x = 270 + LockVerticalRotationValue;
    }
}
