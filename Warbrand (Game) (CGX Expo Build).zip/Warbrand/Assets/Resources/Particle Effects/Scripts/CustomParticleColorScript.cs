﻿using UnityEngine;
using System.Collections;

public class CustomParticleColorScript : MonoBehaviour
{
    //
    //public
    //
    public bool ModifyColor = true;
    public bool ModifyAlpha = true;

    //
    //private
    //
    private ParticleSystem m_System;
    private Renderer m_Renderer;
    private float m_ElapsedTime = 0;
    private float m_ParticleSystemProgress;

    private GradientAlphaKey[] m_AlphaKeys;
    private float m_Opacity = 1;

    private GradientColorKey[] m_ColorKeys;
    private Color m_Color = Color.black;

    //strings
    private const string m_OpacityUniform = "_Opacity";
    private const string m_ColorUniform = "_Color";

    void Start ()
    {
        m_System = gameObject.GetComponent<ParticleSystem>();
        m_Renderer = gameObject.GetComponent<Renderer>();
        m_AlphaKeys = m_System.colorOverLifetime.color.gradient.alphaKeys;
        m_Opacity = m_AlphaKeys[0].alpha;
        m_ColorKeys = m_System.colorOverLifetime.color.gradient.colorKeys;
        m_Color = m_ColorKeys[0].color;
        m_Renderer.material.SetFloat(m_OpacityUniform, m_Opacity);
    }
	
	void FixedUpdate ()
    {
        if(m_System.isPlaying)
        {
            m_ElapsedTime += Time.fixedDeltaTime;
            m_ParticleSystemProgress = m_ElapsedTime / m_System.duration;
            //m_System.colorOverLifetime.color.gradient.alphaKeys[0].alpha;

            if (ModifyColor)
            {
                GetColorValue();
                m_Renderer.material.SetColor(m_ColorUniform, m_Color);
            }
            if (ModifyAlpha)
            {
                GetOpacityValue();
                m_Renderer.material.SetFloat(m_OpacityUniform, m_Opacity);
            }
        }
        else
        {
            m_ElapsedTime = 0;
        }
	}

    void GetOpacityValue()
    {
        //Is the particle system progress before the first alpha key?
        if(m_ParticleSystemProgress < m_AlphaKeys[0].time)
        {
            m_Opacity = m_AlphaKeys[0].alpha;
            return;
        }
        //Is the particle system progress after the last alpha key?
        else if (m_ParticleSystemProgress > m_AlphaKeys[m_AlphaKeys.Length - 1].time)
        {
            m_Opacity = m_AlphaKeys[m_AlphaKeys.Length - 1].alpha;
            return;
        }
        //Don't check the last alpha key. This is dealt with above and there won't be any key after it to check against anyways.
        for (int i = 0; i < m_AlphaKeys.Length - 1; i++)
        {
            //Make sure we aren't checking the last key
            if (m_ParticleSystemProgress > m_AlphaKeys[i].time && m_ParticleSystemProgress < m_AlphaKeys[i + 1].time)
            {
                //Get our current progress between keys as a value from 0 - 1. 0 is the first key, 1 is the second.
                float progressBetweenKeys = (m_ParticleSystemProgress - m_AlphaKeys[i].time) / (m_AlphaKeys[i + 1].time - m_AlphaKeys[i].time);

                //Depending on the progress between keys, make the opacity closer to either the first or last key
                m_Opacity = 0;
                m_Opacity += m_AlphaKeys[i].alpha * (1 - progressBetweenKeys);
                m_Opacity += m_AlphaKeys[i + 1].alpha * progressBetweenKeys;
                return;
            }
        }
    }

    void GetColorValue()
    {
        //Is the particle system progress before the first alpha key?
        if (m_ParticleSystemProgress < m_ColorKeys[0].time)
        {
            m_Color = m_ColorKeys[0].color;
            return;
        }
        //Is the particle system progress after the last alpha key?
        else if (m_ParticleSystemProgress > m_ColorKeys[m_ColorKeys.Length - 1].time)
        {
            m_Color = m_ColorKeys[m_ColorKeys.Length - 1].color;
            return;
        }
        //Don't check the last alpha key. This is dealt with above and there won't be any key after it to check against anyways.
        for (int i = 0; i < m_ColorKeys.Length - 1; i++)
        {
            //Make sure we aren't checking the last key
            if (m_ParticleSystemProgress > m_ColorKeys[i].time && m_ParticleSystemProgress < m_ColorKeys[i + 1].time)
            {
                //Get our current progress between keys as a value from 0 - 1. 0 is the first key, 1 is the second.
                float progressBetweenKeys = (m_ParticleSystemProgress - m_ColorKeys[i].time) / (m_ColorKeys[i + 1].time - m_ColorKeys[i].time);

                //Depending on the progress between keys, make the opacity closer to either the first or last key
                Vector3 color = Vector3.zero;
                //R
                color.x += m_ColorKeys[i].color.r * (1 - progressBetweenKeys);
                color.x += m_ColorKeys[i + 1].color.r * progressBetweenKeys;

                //G
                color.y += m_ColorKeys[i].color.g * (1 - progressBetweenKeys);
                color.y += m_ColorKeys[i + 1].color.g * progressBetweenKeys;

                //B
                color.z += m_ColorKeys[i].color.b * (1 - progressBetweenKeys);
                color.z += m_ColorKeys[i + 1].color.b * progressBetweenKeys;

                m_Color.r = color.x;
                m_Color.g = color.y;
                m_Color.b = color.z;
                return;
            }
        }
    }
}
