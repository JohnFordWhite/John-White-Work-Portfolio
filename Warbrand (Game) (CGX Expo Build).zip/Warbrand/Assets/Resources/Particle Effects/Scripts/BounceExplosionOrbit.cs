﻿using UnityEngine;
using System.Collections;

public class BounceExplosionOrbit : MonoBehaviour
{
    public float OrbitSpeed = 0.5f;
    //public float InitialOrbitRadius = 0.5f;
    public float MaxOrbitRadius = 5.0f;

    private ParticleSystem m_System;
    private ParticleSystem.Particle[] m_Particles;
    private float[] m_AnglesTheta;
    private float[] m_AnglesPhi;
    private float m_Radius;
    private float m_RadiusIncreasePerSecond;
    private float m_TimePassed = 0;

    void Start()
    {
        if (m_System == null)
            m_System = GetComponent<ParticleSystem>();

        if (m_Particles == null || m_Particles.Length < m_System.maxParticles)
            m_Particles = new ParticleSystem.Particle[m_System.maxParticles];

        m_AnglesTheta = new float[m_System.maxParticles];
        m_AnglesPhi = new float[m_System.maxParticles];

        for(int i = 0; i < m_System.maxParticles; i++)
        {
            m_AnglesTheta[i] = Random.Range(0, 359);
            m_AnglesPhi[i] = Random.Range(0, 359);
        }

        m_Radius = 0;
        m_RadiusIncreasePerSecond = MaxOrbitRadius / (m_System.duration / 2);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        m_TimePassed += Time.fixedDeltaTime;
        int numParticlesAlive = m_System.GetParticles(m_Particles);

        for (int i = 0; i < m_System.maxParticles; i++)
        {
            m_AnglesTheta[i] += Time.fixedDeltaTime * OrbitSpeed;
            m_AnglesPhi[i] += Time.fixedDeltaTime * OrbitSpeed;
        }

        if(m_TimePassed > (m_System.duration/2))
        {
            m_RadiusIncreasePerSecond = -Mathf.Abs(m_RadiusIncreasePerSecond);
        }

        m_Radius += m_RadiusIncreasePerSecond * Time.fixedDeltaTime;

        if (m_Radius < 0)
        {
            m_Radius = 0;
        }

        //m_Radius = 2;


        Vector3 particlePosition = Vector3.zero;
        for (int i = 0; i < numParticlesAlive; i++)
        {
            particlePosition.x = m_Radius * Mathf.Cos(m_AnglesTheta[i]) * Mathf.Sin(m_AnglesPhi[i]);
            particlePosition.y = m_Radius * Mathf.Sin(m_AnglesTheta[i]) * Mathf.Sin(m_AnglesPhi[i]);
            particlePosition.z = m_Radius * Mathf.Cos(m_AnglesPhi[i]);
            m_Particles[i].position = particlePosition;
        }

        m_System.SetParticles(m_Particles, numParticlesAlive);
    }
}
