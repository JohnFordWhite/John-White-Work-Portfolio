﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        DeactivateParticleSysGO                                                        *
 * FileExtension:   .cs                                                                            *
 * Author:          Jon Roffey                                                                     *
 * Date:            January 18th, 2017                                                             *
 *                                                                                                 *
 * Stops all particle systems on a GameObject after a set amount of time, then deactivates         *
 * the GameObject that the script is on. Useful for handling particle systems that need to be      *
 * returned to the pool.                                                                           *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (Jon Roffey) - January 18th, 2017                                          *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DeactivateParticleSysGO : MonoBehaviour
{
    //
    //Public
    //
    public float DeactivationTimer = 3f;

    //
    //Private
    //
    private ParticleSystem[] m_ParticleSystems;
    
    void Start()
    {
        m_ParticleSystems = GetComponentsInChildren<ParticleSystem>();
    }

    void Update()
    {
        DeactivationTimer -= Time.deltaTime;
        if (DeactivationTimer <= 0)
        {
            for (int i = 0; i < m_ParticleSystems.Length; i++)
            {
                m_ParticleSystems[i].Stop();
            }
            DeactivationTimer = 3f;
            gameObject.SetActive(false);
        }
    }
}
