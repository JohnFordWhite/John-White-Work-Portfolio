﻿/******************************************* File Header *******************************************\
*                                                                                                 *
* FileName:        BuildTurret                                                                    *
* FileExtension:   .cs                                                                            *
* Author:          Nicholas Brennan                                                               *
* Date:            October 12th, 2016                                                             *
*                                                                                                 *
* This script is meant to be put on an empty GameObject that has a collider on it that encompasses*
* all of the pieces of Quark's turret (which also need to be children of the empty Game Object).  *
* This script will handle the appearance of Quark's turret while it is being built.               *
*                                                                                                 *
* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
* FOR A PARTICULAR PURPOSE.                                                                       *
*                                                                                                 *
* V 1.0 - Created File (Nicholas Brennan) - October 12th, 2016                                    *
* V 1.1 - Cleaned up / optimized code and added functionality (John White) - October 20th, 2016	  *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;

public class BuildTurret : MonoBehaviour
{
    //
    //Public
    //
    public Texture TurretTexture;
    public Texture NoiseTexture;
    public Color CompleteColor = Color.white;
    public Color ProgressColor = Color.red;
    public float ProgressBandSize = 0.03f;
    public float ConstructionCompletionRequired = 50.0f;
    public float TextureCompletionRequired = 50.0f;
    public float CompletionRate = 20.0f;
    public float NearTextureTolerance = 0.05f;

    [HideInInspector]
    public bool IsUnobstructed;
    [HideInInspector]
    public bool IsOnGround;
    [HideInInspector]
    public bool IsInValidPlacementLocation;
    [HideInInspector]
    public bool IsPlaced;

    public AudioClip BuildClip;

    //
    //Private
    //
    Renderer[] m_Renderers;
    float m_TurretHeight;
    float m_TurretPosY;
    float m_CompletionAmount;

    private AudioSource m_AudioSource;
    private float m_StartVolume = 1.0f;

    private Shader m_PlaceObjectShader;
    private Shader m_ConstructTurretShader;
    private Shader m_TextureTurretShader;
    private Shader m_TurretShader;

    private TurretScript m_TurretScript;

    private Player m_Owner;

    //strings
    private const string m_PlacementColorUniform = "_PlacementColor";
    private const string m_CompleteColorUniform = "_CompleteColor";
    private const string m_ProgressColorUniform = "_ProgressColor";
    private const string m_ProgressBandSizeUniform = "_ProgressBandSize";
    private const string m_ObjectHeightUniform = "_ObjectHeight";
    private const string m_ConstructionSpeedUniform = "_ConstructionSpeed";
    private const string m_ObjectPosYUniform = "_ObjectPosY";
    private const string m_CompletionAmountUniform = "_CompletionAmount";
    private const string m_UntexturedColorUniform = "_UntexturedColor";
    private const string m_NearColorUniform = "_NearColor";
    private const string m_MainTexUniform = "_MainTex";
    private const string m_NoiseTexUniform = "_NoiseTex";
    private const string m_NearToleranceUniform = "_NearTolerance";
    private const string m_TextureSpeedUniform = "_TextureSpeed";
    private const string m_TurretColorUniform = "_Color";
    private const string m_TurretTexturedColorUniform = "_TexturedColor";

    private const string m_PlaceObjectShaderName = "Custom/PlaceObject";
    private const string m_ConstructTurretShaderName = "Custom/ConstructTurret";
    private const string m_TextureTurretShaderName = "Custom/TextureTurret";
    private const string m_FinalShaderName = "Custom/StandardXRayObstacle";

    private const string m_QuarkTurretString = "QuarkTurret";

    void Start ()
    {
        IsPlaced = false;
        IsUnobstructed = true;
        m_TurretHeight = GetComponent<Collider>().bounds.size.y;
        m_TurretPosY = transform.position.y;
        m_Renderers = gameObject.GetComponentsInChildren<Renderer>();
        m_CompletionAmount = 0;
        m_AudioSource = GetComponent<AudioSource>();
        m_AudioSource.clip = BuildClip;

        m_PlaceObjectShader = Shader.Find(m_PlaceObjectShaderName);
        m_ConstructTurretShader = Shader.Find(m_ConstructTurretShaderName);
        m_TextureTurretShader = Shader.Find(m_TextureTurretShaderName);
        m_TurretShader = Shader.Find(m_FinalShaderName);

        m_TurretScript = GetComponent<TurretScript>();
    }

    public void Reset()
    {
        m_CompletionAmount = 0;
        IsPlaced = false;
        IsUnobstructed = true;
        IsOnGround = false;
        IsInValidPlacementLocation = IsUnobstructed && IsOnGround;
    }

    public void Place()
    {
        IsPlaced = true;
    }

    public void SetOwner(Player owner)
    {
        m_Owner = owner;
    }
	
	void Update ()
    {
        if(IsUnobstructed == true && IsOnGround == true)
        {
            IsInValidPlacementLocation = true;
        }
        else
        {
            IsInValidPlacementLocation = false;
        }

        //Turret is being placed
        if(IsPlaced == false)
        {
            for (int i = 0; i < m_Renderers.Length; i++)
            {
                Renderer renderer = m_Renderers[i];

                if(renderer.gameObject.GetComponent<ParticleSystem>() == null)
                {
                    if (IsInValidPlacementLocation)
                    {
                        renderer.material.SetColor(m_PlacementColorUniform, Color.green);
                    }
                    else
                    {
                        renderer.material.SetColor(m_PlacementColorUniform, Color.red);
                    }
                }
            }
        }
        //Turret has been placed
        else
        {
            gameObject.layer = LayerMask.NameToLayer(m_QuarkTurretString);

            if(!m_AudioSource.isPlaying)
            {
                m_AudioSource.volume = 0.1f;
                m_AudioSource.Play();
            }

            m_CompletionAmount += CompletionRate * Time.fixedDeltaTime;
            //Turret is constructing
            if (m_CompletionAmount < (ConstructionCompletionRequired))
            {
                m_TurretPosY = transform.position.y;
                for (int i = 0; i < m_Renderers.Length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    renderer.gameObject.layer = LayerMask.NameToLayer(m_QuarkTurretString);

                    if (renderer.gameObject.GetComponent<ParticleSystem>() == null)
                    {
                        //If the renderer is still using the PlaceTurret shader, change it to the ConstructTurret shader
                        if (renderer.material.shader != m_ConstructTurretShader)
                        {
                            renderer.material.shader = m_ConstructTurretShader;
                            renderer.material.SetColor(m_CompleteColorUniform, CompleteColor);
                            renderer.material.SetColor(m_ProgressColorUniform, BaseGameMode.TeamColors[m_Owner.TeamIndex]);
                            renderer.material.SetFloat(m_ProgressBandSizeUniform, ProgressBandSize);
                            renderer.material.SetFloat(m_ObjectHeightUniform, m_TurretHeight);

                            float constructionSpeed = m_TurretHeight / ConstructionCompletionRequired;
                            renderer.material.SetFloat(m_ConstructionSpeedUniform, constructionSpeed);
                        }
                        renderer.material.SetFloat(m_ObjectPosYUniform, m_TurretPosY);
                        renderer.material.SetFloat(m_CompletionAmountUniform, m_CompletionAmount);
                    }
                }
            }
            //Turret is texturing
            else if (m_CompletionAmount < (ConstructionCompletionRequired + TextureCompletionRequired))
            {
                for (int i = 0; i < m_Renderers.Length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    if (renderer.gameObject.GetComponent<ParticleSystem>() == null)
                    {
                        //If the renderer is still using the ConstructTurret shader, change it to the TextureTurret shader
                        if (renderer.material.shader != m_TextureTurretShader)
                        {
                            renderer.material.shader = m_TextureTurretShader;

                            renderer.material.SetColor(m_UntexturedColorUniform, CompleteColor);
                            renderer.material.SetColor(m_TurretTexturedColorUniform, BaseGameMode.TeamColors[m_Owner.TeamIndex]);
                            renderer.material.SetColor(m_NearColorUniform, BaseGameMode.TeamColors[m_Owner.TeamIndex]);
                            renderer.material.SetFloat(m_NearToleranceUniform, NearTextureTolerance);
                            //renderer.material.SetTexture(m_MainTexUniform, TurretTexture);
                            renderer.material.SetTexture(m_NoiseTexUniform, NoiseTexture);

                            float textureSpeed = 1 / TextureCompletionRequired;
                            renderer.material.SetFloat(m_TextureSpeedUniform, textureSpeed);
                        }

                        renderer.material.SetFloat(m_CompletionAmountUniform, m_CompletionAmount - (ConstructionCompletionRequired));
                    }
                }
            }
            //Turret is finished building
            else
            {
                StartCoroutine(AudioUtils.FadeOut(m_AudioSource, m_StartVolume, 0.3f));

                //activate the turret
                for (int i = 0; i < m_Renderers.Length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    if (renderer.gameObject.GetComponent<ParticleSystem>() == null)
                    {
                        if (renderer.material.shader != m_TurretShader)
                        {
                            renderer.material.shader = m_TurretShader;
                            //renderer.material.SetTexture(m_MainTexUniform, TurretTexture);
                            renderer.material.SetColor(m_TurretColorUniform, BaseGameMode.TeamColors[m_Owner.TeamIndex]);
                        }
                    }
                }

                m_TurretScript.ActivateTurret();
                this.enabled = false;
            }
        }
    }

    public void AddCompletion(float amount)
    {
        m_CompletionAmount += amount;
    }

    void OnTriggerStay(Collider other)
    {
        if (other.isTrigger == false)
        {
            IsUnobstructed = false;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.isTrigger == false)
        {
            IsUnobstructed = true;
        }
    }
}
