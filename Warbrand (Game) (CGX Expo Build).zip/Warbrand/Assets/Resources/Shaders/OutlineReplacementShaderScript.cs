﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class OutlineReplacementShaderScript : MonoBehaviour
{
    //
    //Public
    //
    public Color OutlineColor = Color.red;
    public float OutlineThickness = 2.0f;
    public Player Owner;
    [HideInInspector]
    public RenderTexture m_RenderTexture;

    //
    //Private
    //
    private Shader m_OutlineShader;

    //strings
    private const string m_ReplacementTagString = "Outline";

    private const string m_OutlineReplacementShaderName = "Hidden/OutlineReplacementShader";

    private const string m_Player1OutlineViewResource = "Render Textures/Player1OutlineView";
    private const string m_Player2OutlineViewResource = "Render Textures/Player2OutlineView";
    private const string m_Player3OutlineViewResource = "Render Textures/Player3OutlineView";
    private const string m_Player4OutlineViewResource = "Render Textures/Player4OutlineView";

    private const string m_Player1ModelMask = "Player1Model";
    private const string m_Player2ModelMask = "Player2Model";
    private const string m_Player3ModelMask = "Player3Model";
    private const string m_Player4ModelMask = "Player4Model";
    private const string m_Player5ModelMask = "Player5Model";
    private const string m_Player6ModelMask = "Player6Model";
    private const string m_Player7ModelMask = "Player7Model";
    private const string m_Player8ModelMask = "Player8Model";
    private const string m_FloorMask = "Floor";
    private const string m_WallsMask = "Walls";
    private const string m_QuarkTurretMask = "QuarkTurret";
    private const string m_PropsMask = "Props";

    private Camera m_Camera;

    void Start()
    {
        m_OutlineShader = Shader.Find(m_OutlineReplacementShaderName);

        m_Camera = GetComponent<Camera>();
    }

    void Update()
    {
        if(m_RenderTexture == null)
        {
            AssignRenderTexture();
        }
        gameObject.transform.position = gameObject.transform.parent.transform.position;
        gameObject.transform.rotation = gameObject.transform.parent.transform.rotation;
        m_Camera.SetReplacementShader(m_OutlineShader, m_ReplacementTagString);
    }

    void AssignRenderTexture()
    {
        if (Owner.GameInput == null)
            return;

        switch(Owner.GameInput.PlayerID)
        {
            case 1:
                m_RenderTexture = Resources.Load(m_Player1OutlineViewResource) as RenderTexture;
                break;
            case 2:
                m_RenderTexture = Resources.Load(m_Player2OutlineViewResource) as RenderTexture;
                break;
            case 3:
                m_RenderTexture = Resources.Load(m_Player3OutlineViewResource) as RenderTexture;
                break;
            case 4:
                m_RenderTexture = Resources.Load(m_Player4OutlineViewResource) as RenderTexture;
                break;
        }

        Owner.OutlineCamera.targetTexture = m_RenderTexture;
    }
    
    void OnEnable()
    {
        
    }

    void OnDisable()
    {

    }

    void OnPreRender()
    {
        int CullMask = 0;

        CullMask += 1 << LayerMask.NameToLayer(m_Player1ModelMask);
        CullMask += 1 << LayerMask.NameToLayer(m_Player2ModelMask);
        CullMask += 1 << LayerMask.NameToLayer(m_Player3ModelMask);
        CullMask += 1 << LayerMask.NameToLayer(m_Player4ModelMask);
        CullMask += 1 << LayerMask.NameToLayer(m_Player5ModelMask);
        CullMask += 1 << LayerMask.NameToLayer(m_Player6ModelMask);
        CullMask += 1 << LayerMask.NameToLayer(m_Player7ModelMask);
        CullMask += 1 << LayerMask.NameToLayer(m_Player8ModelMask);
        CullMask += 1 << LayerMask.NameToLayer(m_FloorMask);
        CullMask += 1 << LayerMask.NameToLayer(m_WallsMask);
        CullMask += 1 << LayerMask.NameToLayer(m_PropsMask);
        CullMask += 1 << LayerMask.NameToLayer(m_QuarkTurretMask);

        CullMask -= 1 << Owner.gameObject.layer;

        m_Camera.cullingMask = CullMask;
    }
}
