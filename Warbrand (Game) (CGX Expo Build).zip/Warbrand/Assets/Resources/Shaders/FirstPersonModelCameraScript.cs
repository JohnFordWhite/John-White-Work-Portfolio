﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class FirstPersonModelCameraScript : MonoBehaviour
{
    public Player Owner;

    private Camera m_Camera;
    private int m_CullMask;

	void Start ()
    {
        m_Camera = gameObject.GetComponent<Camera>();

    }
	
	void Update ()
    {
    }

    void OnPreRender()
    {
        m_CullMask = 0;
        m_CullMask += 1 << Owner.gameObject.layer;
        m_Camera.cullingMask = m_CullMask;

        Owner.gameObject.GetComponent<HeadInfo>().MakeInvisible();
    }

    void OnPostRender()
    {
        //Owner.gameObject.GetComponent<HeadInfo>().MakeVisible();
    }

    IEnumerator MakeVisible()
    {
        while(true)
        {
            yield return new WaitForEndOfFrame();
            Owner.gameObject.GetComponent<HeadInfo>().MakeVisible();
        }
    }
}
