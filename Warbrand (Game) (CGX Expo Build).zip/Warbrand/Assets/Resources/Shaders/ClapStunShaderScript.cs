﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class ClapStunShaderScript : MonoBehaviour
{
    public float m_DistortionSize = 1.0f;
    public float m_DistortionTime = 0.3f;
    public float m_DistortionAmount = 0.02f;

    private Material m_Mat;
    private float m_Timer = float.MaxValue;

    private const string m_OuterDistanceThresholdUniform = "_OuterDistanceThreshold";
    private const string m_InnerDistanceThresholdUniform = "_InnerDistanceThreshold";
    private const string m_DistortAmountUniform = "_DistortAmount";
    private const string m_LocalPositionUniform = "_LocalPosition";

    void Start ()
    {
        m_Mat = GetComponent<Renderer>().sharedMaterial;
	}
	
	// Update is called once per frame
	void Update ()
    {
        Vector4 localPosition = transform.InverseTransformPoint(transform.position);
        localPosition.Scale(transform.localScale);
        localPosition.w = 1;

        m_Timer += Time.deltaTime;
        if(m_Timer > m_DistortionTime)
        {
            Deactivate();
        }
        else
        {
            float outerRing = (5.0f / m_DistortionTime) * m_Timer;
            float innerRing = outerRing - m_DistortionSize;

            m_Mat.SetFloat(m_OuterDistanceThresholdUniform, outerRing);
            m_Mat.SetFloat(m_InnerDistanceThresholdUniform, innerRing);
            m_Mat.SetFloat(m_DistortAmountUniform, m_DistortionAmount);
            m_Mat.SetVector(m_LocalPositionUniform, localPosition);
        }
	}

    public void Reset(Vector3 position)
    {
        gameObject.SetActive(true);
        transform.position = position;
        m_Timer = 0;
    }

    void Deactivate()
    {
        gameObject.SetActive(false);
    }

    void OnEnable()
    {
        CameraPreRender.onPreCull += LookAtCamera;
    }

    void OnDisable()
    {
        CameraPreRender.onPreCull -= LookAtCamera;
    }

    void LookAtCamera()
    {
        //we want to look back
        //Vector3 difference = Camera.current.transform.position - transform.position;
        //transform.LookAt(transform.position - difference, Camera.current.transform.up);

        if (Camera.current != null)
        {
            transform.LookAt(Camera.current.transform);
            Vector3 angles = transform.eulerAngles;
            angles.x += 90;
            transform.eulerAngles = angles;
        }
    }
}
