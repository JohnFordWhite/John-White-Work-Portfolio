﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        SmokeOverlayScript                                                             *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 20th, 2016                                                             *
 *                                                                                                 *
 * This script is to be attached to an image that will obscure the player's vision when they enter *
 * a smoke cloud. FadeIn and FadeOut will be called from a SmokeScript that will be attached to the*
 * smoke cloud.                                                                                    *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 20th, 2016                                          *
 *                                                                                                 *
\***************************************************************************************************/
using UnityEngine;
using System.Collections;

public class SmokeImageEffectScript : MonoBehaviour
{
    private Material m_SmokeMaterialPrefab;
    private Material m_SmokeMaterial;
    private float FadeTime = 0.5f;
    private bool m_FadingIn = false;
    private float m_FadeTimer;
    private float m_EffectAlpha = 0.0f;
    private float m_MaxAlpha = 0.95f;
    private CanvasRenderer m_CanvasRenderer;

    private const string m_SmokeOverlayMaterialResource = "Materials/ShaderMaterials/ImageEffectMaterials/SmokeOverlayMaterial";

    private const string m_EffectAlphaUniform = "_EffectAlpha";

    void Start ()
    {
        m_FadeTimer = 0;
        m_CanvasRenderer = GetComponent<CanvasRenderer>();

        m_SmokeMaterialPrefab = Resources.Load(m_SmokeOverlayMaterialResource) as Material;
        m_SmokeMaterial = MonoBehaviour.Instantiate(m_SmokeMaterialPrefab);
	}
	
	void Update ()
    {
	    if(m_FadingIn)
        {
            m_FadeTimer += Time.deltaTime;
            if (m_FadeTimer > FadeTime)
                m_FadeTimer = FadeTime;
        }
        else
        {
            m_FadeTimer -= Time.deltaTime;
            if (m_FadeTimer < 0)
                m_FadeTimer = 0;
        }

        //Change canvas alpha depending on m_FadeTimer
        float m_EffectAlpha = m_FadeTimer / FadeTime;
        if (m_EffectAlpha > m_MaxAlpha)
        {
            m_EffectAlpha = m_MaxAlpha;
        }

        if(m_EffectAlpha <= 0)
        {
            this.enabled = false;
        }
        //Debug.Log(m_EffectAlpha);
        m_SmokeMaterial.SetFloat(m_EffectAlphaUniform, m_EffectAlpha);
        m_FadingIn = false;
	}

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        Graphics.Blit(source, destination, m_SmokeMaterial);
    }
    public void FadeIn()
    {
        m_FadingIn = true;
    }
}
