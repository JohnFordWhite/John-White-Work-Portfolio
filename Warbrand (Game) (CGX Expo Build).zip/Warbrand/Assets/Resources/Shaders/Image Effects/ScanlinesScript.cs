﻿using UnityEngine;
using System.Collections;

public class ScanlinesScript : MonoBehaviour
{
    public Material ScanlinesMaterial;

	void Start ()
    {
	}
	
	void Update ()
    {
	}

    void OnRenderImage(RenderTexture src, RenderTexture dest)
    {
        Graphics.Blit(src, dest, ScanlinesMaterial);
    }
}
