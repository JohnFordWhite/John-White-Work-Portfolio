﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class HealingImageEffectScript : MonoBehaviour
{
    //
    //Public
    //
    public Material material;
    [HideInInspector]
    public bool Healing = false;
    [HideInInspector]
    public float m_EffectAlpha = 0;

    //
    //Private
    //
    [SerializeField]
    private float FadeSpeed = 2;
    private float m_HealingMaxTime = 0.25f;
    private float m_HealingTimer = 0;

    private const string m_EffectAlphaUniform = "_EffectFade";

    void Start()
    {
    }

    void Update()
    {
        if (m_HealingTimer <= 0)
            Healing = false;

        if (Healing)
        {
            m_EffectAlpha += FadeSpeed * Time.fixedDeltaTime;
            m_HealingTimer -= Time.fixedDeltaTime;
        }
        else
            m_EffectAlpha -= FadeSpeed * Time.fixedDeltaTime;

        if (m_EffectAlpha >= 1)
        {
            m_EffectAlpha = 1;
        }
        else if (m_EffectAlpha <= 0)
        {
            m_EffectAlpha = 0;
        }

        if (!Healing && m_EffectAlpha <= 0)
        {
            this.enabled = false;
        }
    }

    public void ResetTimer()
    {
        this.enabled = true;
        Healing = true;
        m_HealingTimer = m_HealingMaxTime;
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {

        material.SetFloat(m_EffectAlphaUniform, m_EffectAlpha);
        Graphics.Blit(source, destination, material);
    }
}