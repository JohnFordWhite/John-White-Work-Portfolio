﻿using UnityEngine;
using System.Collections;

public class InjectionImageEffectScript : MonoBehaviour {

    //
    //public
    //
    public Material material;
    [HideInInspector]
    public bool EffectEnabled;

    public float MaxFOVChange = 3.0f;
    public float FOVChangeFrequency = 1.0f;
    public float PulseSpeed = 10.0f;
    public float FadeSpeed = 2;
    //
    //private
    //

    private Camera m_Camera;
    private float m_OriginalFOV;
    private float m_FOVChangeAmount = 0.0f;
    private float m_FOVChangeTimer;

    private bool m_Pulsing = false;
    private float m_PulseTimer = 0.0f;
    private float m_EffectAlpha = 0;

    private string m_EffectAlphaUniform = "_EffectFade";

    void Start ()
    {
        m_FOVChangeTimer = FOVChangeFrequency;
        m_Camera = GetComponent<Camera>();
        m_OriginalFOV = m_Camera.fieldOfView;
	}
	
	void Update ()
    {
        //Don't do the effect if there's no screen effect, but don't interrupt a pulse
        if (m_EffectAlpha <= 0 & m_Pulsing == false)
        {
            this.enabled = false;
        }
        m_FOVChangeTimer -= Time.fixedDeltaTime;

        if(m_FOVChangeTimer <= 0)
        {
            m_Pulsing = true;
            m_PulseTimer = 0;
            m_FOVChangeTimer = FOVChangeFrequency;
        }

        if(m_Pulsing)
        {
            m_PulseTimer += Time.fixedDeltaTime;

            float sineValue = Mathf.Sin(m_PulseTimer * PulseSpeed);

            if(sineValue < 0)
            {
                m_Pulsing = false;
                m_Camera.fieldOfView = m_OriginalFOV;
            }
            else
            {
                //Get a value between 0 and 1 based on time passed
                m_FOVChangeAmount = sineValue * MaxFOVChange;

                //Only make the pulse weaker if the effect is fading out
                if(EffectEnabled == false)
                    m_FOVChangeAmount *= m_EffectAlpha;

                m_Camera.fieldOfView = m_OriginalFOV - m_FOVChangeAmount;
            }
        }
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (EffectEnabled)
            m_EffectAlpha += FadeSpeed * Time.fixedDeltaTime;
        else
            m_EffectAlpha -= FadeSpeed * Time.fixedDeltaTime;

        if (m_EffectAlpha >= 1)
        {
            m_EffectAlpha = 1;
        }
        else if (m_EffectAlpha <= 0)
        {
            m_EffectAlpha = 0;
        }

        material.SetFloat(m_EffectAlphaUniform, m_EffectAlpha);
        Graphics.Blit(source, destination, material);
    }

    public void EnableEffect()
    {
        EffectEnabled = true;
        m_FOVChangeTimer = 0;
    }
}
