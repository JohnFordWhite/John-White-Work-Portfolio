﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class InvincibleImageEffectScript : MonoBehaviour
{
    //
    //Public
    //
    public Material material;
    [HideInInspector]
    public float m_EffectAlpha = 0;

    //
    //Private
    //
    private const string m_EffectAlphaUniform = "_Invincible";

    void Start()
    {
    }

    void Update()
    {
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        material.SetFloat(m_EffectAlphaUniform, m_EffectAlpha);
        Graphics.Blit(source, destination, material);
    }
}