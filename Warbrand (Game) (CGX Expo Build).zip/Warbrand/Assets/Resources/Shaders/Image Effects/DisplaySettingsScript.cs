﻿using UnityEngine;
using System.Collections;

public class DisplaySettingsScript : MonoBehaviour
{
    public Material DisplaySettingsMaterial;

	void Start ()
    {
	}
	
	void Update ()
    {
	}

    void OnRenderImage(RenderTexture src, RenderTexture dest)
    {
        Graphics.Blit(src, dest, DisplaySettingsMaterial);
    }
}
