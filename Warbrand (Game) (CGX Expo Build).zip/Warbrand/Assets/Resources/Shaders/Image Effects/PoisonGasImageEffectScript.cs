﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class PoisonGasImageEffectScript : MonoBehaviour
{
    //
    //Public
    //
    public Material material;
    [HideInInspector]
    public bool Poisoned = false;
    public float FadeSpeed = 1;

    //
    //Private
    //
    public float m_EffectAlpha = 0;

    private const string m_EffectAlphaUniform = "_EffectFade";

    void Start()
    {
    }

    void Update()
    {
        if (Poisoned)
            m_EffectAlpha += FadeSpeed * Time.fixedDeltaTime;
        else
            m_EffectAlpha -= FadeSpeed * Time.fixedDeltaTime;

        if (m_EffectAlpha >= 1)
        {
            m_EffectAlpha = 1;
        }
        else if (m_EffectAlpha <= 0)
        {
            m_EffectAlpha = 0;
        }

        if(!Poisoned && m_EffectAlpha <= 0)
        {
            this.enabled = false;
        }
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {

        material.SetFloat(m_EffectAlphaUniform, m_EffectAlpha);
        Graphics.Blit(source, destination, material);
    }
}