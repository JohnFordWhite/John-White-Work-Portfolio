﻿using UnityEngine;
using System.Collections;

public class OutlineImageEffectScript : MonoBehaviour
{
    public OutlineReplacementShaderScript ReplacementShaderScript;
    public Camera MainCamera;

    private Material m_OutlineMaterialPrefab;
    private Material m_OutlineMaterial;
    private Material m_BlurMaterial;
    private RenderTexture m_OutlineTexture;
    private RenderTexture m_Blurred;

    private const string m_OutlineOverlayMaterialResource = "Materials/ShaderMaterials/ImageEffectMaterials/OutlineOverlayMaterial";
    private const string m_BlurMaterialResource = "Materials/ShaderMaterials/ImageEffectMaterials/BlurMaterial";

    private const string m_CameraScaleXUniform = "_CameraScaleX";
    private const string m_CameraScaleYUniform = "_CameraScaleY";
    private const string m_CameraOffsetXUniform = "_CameraOffsetX";
    private const string m_CameraOffsetYUniform = "_CameraOffsetY";
    private const string m_OutlineTexUniform = "_OutlineTex";
    private const string m_BlurredOutlineTexUniform = "_BlurredOutlineTex";

    void Start()
    {
        m_OutlineMaterialPrefab = Resources.Load(m_OutlineOverlayMaterialResource) as Material;
        m_OutlineMaterial = MonoBehaviour.Instantiate(m_OutlineMaterialPrefab);
        m_BlurMaterial = Resources.Load(m_BlurMaterialResource) as Material;
        m_Blurred = new RenderTexture(Screen.width >> 1, Screen.height >> 1, 0);
    }

    void Update()
    {
        if (InputManager.CM.GameModeManager.CurrentGameMode.GameCondition != GameCondition.GameInProgress)
            return;

        if (m_OutlineTexture == null)
        {
            m_OutlineTexture = ReplacementShaderScript.m_RenderTexture;
        }      
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        m_OutlineMaterial.SetFloat(m_CameraScaleXUniform, MainCamera.rect.width);
        m_OutlineMaterial.SetFloat(m_CameraScaleYUniform, MainCamera.rect.height);
        m_OutlineMaterial.SetFloat(m_CameraOffsetXUniform, MainCamera.rect.x);
        m_OutlineMaterial.SetFloat(m_CameraOffsetYUniform, MainCamera.rect.y);

        Graphics.Blit(m_OutlineTexture, m_Blurred);
        for (int i = 0; i < 4; i++)
        {
            var temp = RenderTexture.GetTemporary(m_Blurred.width, m_Blurred.height);
            Graphics.Blit(m_Blurred, temp, m_BlurMaterial, 0);
            Graphics.Blit(temp, m_Blurred, m_BlurMaterial, 1);
            RenderTexture.ReleaseTemporary(temp);
        }

        m_OutlineMaterial.SetTexture(m_OutlineTexUniform, m_OutlineTexture);
        m_OutlineMaterial.SetTexture(m_BlurredOutlineTexUniform, m_Blurred);

        if(m_OutlineMaterial != null)
        {
            Graphics.Blit(source, destination, m_OutlineMaterial); 
        }
    }
}