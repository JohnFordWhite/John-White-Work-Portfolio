﻿/******************************************* File Header *******************************************\
*                                                                                                 *
* FileName:        BuildElectricWall                                                              *
* FileExtension:   .cs                                                                            *
* Author:          John White                                                                     *
* Date:            October 29th, 2016                                                             *
*                                                                                                 *
* This script is meant to be put on an empty GameObject that has a collider on it that encompasses*
* all of the pieces of Quark's electric wall (which also need to be children of the empty         *
* Game Object). This script will handle the appearance of Quark's wall while it is being built.   *
*                                                                                                 *
* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
* FOR A PARTICULAR PURPOSE.                                                                       *
*                                                                                                 *
* V 1.0 - Created File (John White) - October 29th, 2016                                          *
\***************************************************************************************************/

using UnityEngine;
using System.Collections;

public class BuildElectricWall : MonoBehaviour
{
    //
    //Public
    //
    public Texture WallTexture;
    public Color CompleteColor = Color.white;
    public Color ProgressColor = Color.blue;
    public float ProgressBandSize = 0.03f;
    public float ConstructionCompletionRequired = 50.0f;
    public float CompletionRate = 20.0f;

    [HideInInspector]
    public bool IsUnobstructed;
    [HideInInspector]
    public bool IsOnGround;
    [HideInInspector]
    public bool IsInValidPlacementLocation;
    [HideInInspector]
    public bool IsPlaced;

    //
    //Private
    //
    Renderer[] m_Renderers;
    float m_WallHeight;
    float m_WallPosY;
    float m_CompletionAmount;

    private AudioSource m_AudioSource;

    private ElectricWallScript m_ElectricWallScript;

    private Shader m_PlaceObjectShader;
    private Shader m_ConstructTurretShader;
    private Shader m_StandardShader;

    //Strings
    private const string m_PlacementColorUniform = "_PlacementColor";
    private const string m_CompleteColorUniform = "_CompleteColor";
    private const string m_ProgressColorUniform = "_ProgressColor";
    private const string m_ProgressBandSizeUniform = "_ProgressBandSize";
    private const string m_ObjectHeightUniform = "_ObjectHeight";
    private const string m_ConstructionSpeedUniform = "_ConstructionSpeed";
    private const string m_ObjectPosYUniform = "_ObjectPosY";
    private const string m_CompletionAmountUniform = "_CompletionAmount";

    private const string m_PlaceObjectShaderName = "Custom/PlaceObject";
    private const string m_ConstructTurretShaderName = "Custom/ConstructTurret";
    private const string m_StandardShaderName = "Standard";


    void Start ()
    {
        IsPlaced = false;
        IsUnobstructed = true;
        m_WallHeight = GetComponent<Collider>().bounds.size.y;
        m_WallPosY = transform.position.y;
        m_Renderers = gameObject.GetComponentsInChildren<Renderer>();
        m_CompletionAmount = 0;
        m_AudioSource = GetComponent<AudioSource>();

        m_ElectricWallScript = GetComponent<ElectricWallScript>();

        m_PlaceObjectShader = Shader.Find(m_PlaceObjectShaderName);
        m_ConstructTurretShader = Shader.Find(m_ConstructTurretShaderName);
        m_StandardShader = Shader.Find(m_StandardShaderName);
        
        for (int i = 0; i < m_Renderers.Length; i++)
        {
            Renderer renderer = m_Renderers[i];

            renderer.material.shader = m_PlaceObjectShader;
        }
    }
	
	void Update ()
    {
        if(IsUnobstructed == true && IsOnGround == true)
        {
            IsInValidPlacementLocation = true;
        }
        else
        {
            IsInValidPlacementLocation = false;
        }

        //Wall is being placed
        if(IsPlaced == false)
        {
            for (int i = 0; i < m_Renderers.Length; i++)
            {
                Renderer renderer = m_Renderers[i];

                if(IsInValidPlacementLocation)
                {
                    renderer.material.SetColor(m_PlacementColorUniform, Color.green);
                }
                else
                {
                    renderer.material.SetColor(m_PlacementColorUniform, Color.red);
                }
            }
        }
        //Wall has been placed
        else
        {
            m_CompletionAmount += CompletionRate * Time.fixedDeltaTime;
            //Wall is constructing
            if (m_CompletionAmount < ConstructionCompletionRequired)
            {
                m_WallPosY = transform.position.y;
                for (int i = 0; i < m_Renderers.Length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    //If the renderer is still using the PlaceTurret shader, change it to the ConstructTurret shader
                    if (renderer.material.shader = m_PlaceObjectShader)
                    {
                        renderer.material.shader = m_ConstructTurretShader;
                        renderer.material.SetColor(m_CompleteColorUniform, CompleteColor);
                        renderer.material.SetColor(m_ProgressColorUniform, ProgressColor);
                        renderer.material.SetFloat(m_ProgressBandSizeUniform, ProgressBandSize);
                        renderer.material.SetFloat(m_ObjectHeightUniform, m_WallHeight);

                        float constructionSpeed = m_WallHeight / ConstructionCompletionRequired;
                        renderer.material.SetFloat(m_ConstructionSpeedUniform, constructionSpeed);
                    }
                    renderer.material.SetFloat(m_ObjectPosYUniform, m_WallPosY);
                    renderer.material.SetFloat(m_CompletionAmountUniform, m_CompletionAmount);
                }
            }
            //Wall is finished building
            else
            {
                m_AudioSource.Play();

                //activate the wall
                for (int i = 0; i < m_Renderers.Length; i++)
                {
                    Renderer renderer = m_Renderers[i];

                    renderer.material.shader = m_StandardShader;
                    //3000 is "transparent"
                    renderer.material.renderQueue = 3000;
                }

                m_ElectricWallScript.ActivateWall();
                this.enabled = false;
            }
        }
    }

    public void AddCompletion(float amount)
    {
        m_CompletionAmount += amount;
    }

    void OnTriggerStay(Collider other)
    {
        if (other.isTrigger == false)
        {
            IsUnobstructed = false;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.isTrigger == false)
        {
            IsUnobstructed = true;
        }
    }
}
