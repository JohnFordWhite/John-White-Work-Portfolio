﻿/******************************************* File Header *******************************************\
*                                                                                                 *
* FileName:        XRayReplacementShaderScript		                                              *
* FileExtension:   .cs                                                                            *
* Author:          John White                                                                     *
* Date:            October 23th, 2016                                                             *
*                                                                                                 *
* This camera uses a replacement shader. This camera will only render object with the tag         *
* "XRay" = "On". It will render those objects using the XRayReplacementShader. It will only render*
* the fragments of those objects that are obscured by an object using the                         *
* StandardXRayObstacle shader. This camera renders overtop of Quark's main camera.                *
*                                                                                                 *
* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
* FOR A PARTICULAR PURPOSE.                                                                       *
*                                                                                                 *
* V 1.0 - Created File (John White) - October 23th, 2016                                          *
\***************************************************************************************************/
using UnityEngine;
using System.Collections.Generic;

public class XRayReplacementShaderScript : MonoBehaviour
{
    //
    //Public
    //
    public Color EnemyXRayColor = Color.red;
    public Color FriendlyXRayColor = Color.cyan;
    public float XRayThickness = 2.0f;
    public Player Owner;
    [HideInInspector]
    public Renderer[] m_PlayerRenderers;

    //
    //Private
    //
    Shader m_XRayShader;
    int m_CullMask;

    private Camera m_Camera;

    //strings
    private const string m_ReplacementTagString = "XRay";
    private const string m_CullLayer1Name = "Player1Model";
    private const string m_CullLayer2Name = "Player2Model";
    private const string m_CullLayer3Name = "Player3Model";
    private const string m_CullLayer4Name = "Player4Model";
    private const string m_CullLayer5Name = "Player5Model";
    private const string m_CullLayer6Name = "Player6Model";
    private const string m_CullLayer7Name = "Player7Model";
    private const string m_CullLayer8Name = "Player8Model";

    private const string m_XRayReplacementShaderName = "Hidden/XRayReplacementShader";

    private const string m_XRayColorUniform = "_XRayColor";

    void Start()
    {
        m_XRayShader = Shader.Find(m_XRayReplacementShaderName);
        m_PlayerRenderers = Owner.GetComponentsInChildren<Renderer>();

        for(int i = 0; i < m_PlayerRenderers.Length; i++)
        {
            m_PlayerRenderers[i].material.SetColor(m_XRayColorUniform, EnemyXRayColor);
        }

        //CameraPreRender.onPreCull += ChangePlayerXRayColors;

        m_Camera = GetComponent<Camera>();
    }

    // Update is called once per frame
    void Update()
    {
        gameObject.transform.position = gameObject.transform.parent.transform.position;
        gameObject.transform.rotation = gameObject.transform.parent.transform.rotation;
        m_Camera.SetReplacementShader(m_XRayShader, m_ReplacementTagString);
    }

    void OnEnable()
    {

    }

    void OnDisable()
    {

    }

    void OnRender()
    {

    }

    void OnPreRender()
    {
        m_CullMask = 0;

        RevealTeammates();

        ChangePlayerXRayColors();

        //determine the culling mask that this xray camera should use
        if(Owner.CanSeePlayer1XRay)
        {
            m_CullMask += 1 << LayerMask.NameToLayer(m_CullLayer1Name);
        }
        if (Owner.CanSeePlayer2XRay)
        {
            m_CullMask += 1 << LayerMask.NameToLayer(m_CullLayer2Name);
        }
        if (Owner.CanSeePlayer3XRay)
        {
            m_CullMask += 1 << LayerMask.NameToLayer(m_CullLayer3Name);
        }
        if (Owner.CanSeePlayer4XRay)
        {
            m_CullMask += 1 << LayerMask.NameToLayer(m_CullLayer4Name);
        }
        if (Owner.CanSeePlayer5XRay)
        {
            m_CullMask += 1 << LayerMask.NameToLayer(m_CullLayer5Name);
        }
        if (Owner.CanSeePlayer6XRay)
        {
            m_CullMask += 1 << LayerMask.NameToLayer(m_CullLayer6Name);
        }
        if (Owner.CanSeePlayer7XRay)
        {
            m_CullMask += 1 << LayerMask.NameToLayer(m_CullLayer7Name);
        }
        if (Owner.CanSeePlayer8XRay)
        {
            m_CullMask += 1 << LayerMask.NameToLayer(m_CullLayer8Name);
        }

        m_Camera.cullingMask = m_CullMask;

        Owner.CanSeePlayer1XRay = false;
        Owner.CanSeePlayer2XRay = false;
        Owner.CanSeePlayer3XRay = false;
        Owner.CanSeePlayer4XRay = false;
        Owner.CanSeePlayer5XRay = false;
        Owner.CanSeePlayer6XRay = false;
        Owner.CanSeePlayer7XRay = false;
        Owner.CanSeePlayer8XRay = false;
    }

    void RevealTeammates()
    {
        List<Player> allPlayers = Information.AllPlayers;

        for (int i = 0; i < allPlayers.Count; i++)
        {
            Player player = allPlayers[i];

            if (Owner.TeamIndex == player.TeamIndex &&
                Owner != player)
            {
                switch (player.GameInput.PlayerID)
                {
                    case 1:
                        Owner.CanSeePlayer1XRay = true;
                        break;
                    case 2:
                        Owner.CanSeePlayer2XRay = true;
                        break;
                    case 3:
                        Owner.CanSeePlayer3XRay = true;
                        break;
                    case 4:
                        Owner.CanSeePlayer4XRay = true;
                        break;
                    case 5:
                        Owner.CanSeePlayer5XRay = true;
                        break;
                    case 6:
                        Owner.CanSeePlayer6XRay = true;
                        break;
                    case 7:
                        Owner.CanSeePlayer7XRay = true;
                        break;
                    case 8:
                        Owner.CanSeePlayer8XRay = true;
                        break;
                }
            }
        }
    }

    //adjusts the color of other players xray outlines. is called just before this camera is rendered
    void ChangePlayerXRayColors()
    {
        for (int i = 0; i < Information.AllPlayers.Count; i++)
        {
            Player player = Information.AllPlayers[i];

            if (player != Owner)
            {
                if (Owner.TeamIndex == player.TeamIndex)
                {
                    player.ChangeXRayColor(FriendlyXRayColor);
                }
                else
                {
                    player.ChangeXRayColor(EnemyXRayColor);
                }
            }
        }
    }
}
