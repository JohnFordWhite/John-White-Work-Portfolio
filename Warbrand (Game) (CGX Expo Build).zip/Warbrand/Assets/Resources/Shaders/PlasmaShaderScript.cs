﻿using UnityEngine;
using System.Collections;

public class PlasmaShaderScript : MonoBehaviour
{
    public GameObject ArmShield;
    private Vector4[] m_Hits = new Vector4[20];
    private float m_HitTime = 1.0f;

    private Renderer m_Renderer;

    private const string StringPropertyHits = "_Hits";

    private const string PlasmaMaterialResource = "Materials/ShaderMaterials/PlasmaMaterial";


    void Start ()
    {
        Material PlasmaMaterial = Resources.Load(PlasmaMaterialResource) as Material;

        m_Renderer = GetComponent<Renderer>();

        m_Renderer.material = MonoBehaviour.Instantiate(PlasmaMaterial);
        for (int i = 0; i < m_Hits.Length; i++)
        {
            m_Hits[i] = Vector4.zero;
        }
	}
	
	void Update ()
    {
        for (int i = 0; i < m_Hits.Length; i++)
        {
            if (m_Hits[i].w > 0)
            {
                m_Hits[i].w -= Time.deltaTime * 2;
            }
        }
	    m_Renderer.material.SetVectorArray(StringPropertyHits, m_Hits);
	}

    public void OnEnable()
    {
        if (ArmShield != null)
            ArmShield.SetActive(false);
    }

    public void OnDisable()
    {
        if (ArmShield != null)
            ArmShield.SetActive(true);
    }

    public void ManualHit(Vector4 position)
    {
        int index = GetInactiveHit();
        m_Hits[index] = transform.InverseTransformPoint(position);
        m_Hits[index].w = m_HitTime;
    }

    int GetInactiveHit()
    {
        for (int i = 0; i < m_Hits.Length; i++)
        {
           if(m_Hits[i].w <= 0)
           {
               return i;
           }
        }
#if UNITY_EDITOR
        DebugManager.Log("Couldn't find an inactive hit", Developmer.John);
#endif
        return 0;
    }
}
