﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Puddle                                                                         *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 13th, 2016                                                             *
 *                                                                                                 *
 * This file should be attached to an object that is being rendered by the Puddle shader. This     *
 * script calculates the locations and the times of the ripples and passes them to the shader.     *
 * In order for reflections to work, EACH PUDDLE NEEDS IT'S OWN CUBEMAP                            *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 13th, 2016                                          *
 * V 1.1 - Added m_PuddleMaterial (John White) - October 17th, 2016                                *
 * V 1.2 - Puddles automatically bake their reflection (John White - October 17th 2016             *
\***************************************************************************************************/
using UnityEngine;
using System.Collections;

public class Puddle : MonoBehaviour
{
    //
    //Public
    //
    //how long before a ripple gets disabled
    public float RippleLife = 7.0f;
    //Affects how fast the ripple travels
    public float RippleSpeed = 3.0f;
    //Affects the max/min height of the ripple
    public float RippleStrength = 0.7f;
    //Affects how frequenctly the ripple fluctuates. Also affects the width of the ripples.
    public float RippleFrequency = 10.0f;
    //How quickly the ripple decays
    public float RippleDecay = 20.0f;

    public Cubemap BakedReflections;
    
    //
    //Private
    //
    private Material m_PuddleMaterial;
    private Vector4[] RipplePositions = new Vector4[10];
    private float[] RippleTimes = new float[10];

    //strings
    private const string m_RippleSpeedUniform = "_RippleSpeed";
    private const string m_RippleStrengthUniform = "_RippleStrength";
    private const string m_RippleFrequencyUniform = "_RippleFrequency";
    private const string m_RippleDecayUniform = "_RippleDecay";
    private const string m_RippleTimesUniform = "_RippleTimes";
    private const string m_RippleLocationsUniform = "_RippleLocations";

    private const string m_PuddleShaderName = "Custom/Puddle";

    private const string m_CubemapCamera = "CubemapCamera";

    void Start ()
    {
        //Automatically update cubemap used for baked reflections
        BakeReflections();
        m_PuddleMaterial = GetComponent<Renderer>().material;
        m_PuddleMaterial.shader = Shader.Find(m_PuddleShaderName);
        for(int i = 0; i < 10; i++)
        {
            RipplePositions[i] = Vector4.zero;
            RippleTimes[i] = -1;
        }

        m_PuddleMaterial.SetFloat(m_RippleSpeedUniform, RippleSpeed);
        m_PuddleMaterial.SetFloat(m_RippleStrengthUniform, RippleStrength);
        m_PuddleMaterial.SetFloat(m_RippleFrequencyUniform, RippleFrequency);
        m_PuddleMaterial.SetFloat(m_RippleDecayUniform, RippleDecay);

        m_PuddleMaterial.SetFloatArray(m_RippleTimesUniform, RippleTimes);
        m_PuddleMaterial.SetVectorArray(m_RippleLocationsUniform, RipplePositions);
    }
	
	void Update ()
    {
        for (int i = 0; i < 10; i++)
        {
            //if the ripple time is less than 0, it's been disabled so don't update it
            if (RippleTimes[i] >= 0)
            {
                RippleTimes[i] += Time.deltaTime;
            }

            if(RippleTimes[i] >= RippleLife)
            {
                RippleTimes[i] = -1;
            }
        }

        m_PuddleMaterial.SetFloat(m_RippleSpeedUniform, RippleSpeed);
        m_PuddleMaterial.SetFloat(m_RippleStrengthUniform, RippleStrength);
        m_PuddleMaterial.SetFloat(m_RippleFrequencyUniform, RippleFrequency);
        m_PuddleMaterial.SetFloat(m_RippleDecayUniform, RippleDecay);
        m_PuddleMaterial.SetFloatArray(m_RippleTimesUniform, RippleTimes);
    }

    void OnTriggerEnter(Collider other)
    {
        //The location of a disabled ripple will be set to the position of the object that touched the water
        Vector4 otherPosition = (other.transform.position);
        otherPosition.y = gameObject.transform.position.y;
        otherPosition.w = 1;

        //get the first ripple in the array that is disabled (time is < 0)
        for(int i = 0; i < 10; i++)
        {
            if(RippleTimes[i] < 0)
            {
                RippleTimes[i] = 0;
                RipplePositions[i] = otherPosition;

                m_PuddleMaterial.SetVectorArray(m_RippleLocationsUniform, RipplePositions);

                return;
            }
        }
#if UNITY_EDITOR
        DebugManager.LogWarning("Couldn't find any disabled ripples", Developmer.John);
#endif
    }

    void BakeReflections()
    {
        // create temporary camera for rendering
        GameObject go = new GameObject(m_CubemapCamera);
        Camera cam = go.AddComponent<Camera>();
        // place it on the object
        go.transform.position = transform.position;
        go.transform.rotation = Quaternion.identity;
        // render into cubemap		
        cam.RenderToCubemap(BakedReflections);

        // destroy temporary camera
        DestroyImmediate(go);
    }
}
