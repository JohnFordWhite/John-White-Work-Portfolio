﻿/******************************************* File Header *******************************************\
 *                                                                                                 *
 * FileName:        Flag                                                                           *
 * FileExtension:   .cs                                                                            *
 * Author:          John White                                                                     *
 * Date:            October 16th, 2016                                                             *
 *                                                                                                 *
 * This file should be attached to an object that is being rendered by the flag shader. This       *
 * script tracks how much totatl time has elapsed. This script can take in a time offset so that   *
 * all flags in the scene aren't perfectly in sync.                                                *
 *                                                                                                 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  *
 * FOR A PARTICULAR PURPOSE.                                                                       *
 *                                                                                                 *
 * V 1.0 - Created File (John White) - October 16th, 2016                                          *
 * V 1.1 - Added TimeOffset (John White) - October 17th, 2016                                      *
\***************************************************************************************************/
using UnityEngine;
using System.Collections;

public class Flag : MonoBehaviour {

    //It looks weird if all of the flags are perfectly in sync, so use this to offset the time for each one
    public float TimeOffset = 0;

    private float m_WaveTime;
    private const string m_WaveTimeUniform = "_WaveTime";

    private Renderer m_Renderer;

	void Start ()
    {
        m_WaveTime = TimeOffset;

        m_Renderer = GetComponent<Renderer>();
	}
	
	void Update ()
    {
        m_WaveTime += Time.deltaTime;

        m_Renderer.material.SetFloat(m_WaveTimeUniform, m_WaveTime);
	}
}
