﻿using UnityEngine;
using System.Collections;

public class PlasmaShaderHitboxScript : MonoBehaviour
{
    public PlasmaShaderScript plasmaScript;
    public Player Owner;

    private const string m_ShieldHitString = "ShieldHit";

    private int m_ShieldHitHash = Animator.StringToHash(m_ShieldHitString);

    public void ManualHit(Vector4 position)
    {
        Owner.PlayerAnimator.SetTrigger(m_ShieldHitHash);
        plasmaScript.ManualHit(position);
    }

    void OnCollisionEnter(Collision hit)
    {
        plasmaScript.ManualHit(hit.contacts[0].point);
    }
}
