﻿using UnityEngine;
using System.Collections;

public class UVScrollScript : MonoBehaviour
{
    public float XOffsetRate = 10;
    public float YOffsetRate = 10;

    float m_OffsetX = 0;
    float m_OffsetY = 0;
    Renderer m_Renderer;
	// Use this for initialization
	void Start ()
    {
        m_Renderer = gameObject.GetComponent<Renderer>();
        m_Renderer.material.mainTextureOffset = new Vector2(m_OffsetX, m_OffsetY);
    }
	
	// Update is called once per frame
	void Update ()
    {
        m_OffsetX += XOffsetRate * Time.deltaTime;
        m_OffsetY += YOffsetRate * Time.deltaTime;

        m_Renderer.material.mainTextureOffset = new Vector2(m_OffsetX, m_OffsetY);
    }
}
