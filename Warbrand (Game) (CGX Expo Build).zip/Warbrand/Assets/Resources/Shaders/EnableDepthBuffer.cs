﻿using UnityEngine;
using System.Collections;
[ExecuteInEditMode]
public class EnableDepthBuffer : MonoBehaviour
{
    private Camera cam;
    public DepthTextureMode depthTextureMode = DepthTextureMode.DepthNormals;

	void Start ()
    {
        cam = gameObject.GetComponent<Camera>();
        cam.depthTextureMode = depthTextureMode;
	}
	
	void Update ()
    {
    }
}
