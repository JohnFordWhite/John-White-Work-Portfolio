Bebas Neue - http://www.dafont.com/bebas-neue.font
Taken at December 12, 2016
Listed as 100% free on dafont.com



Copperplate Gothic
COPRGTB
COPRGTL
Taken from Windows Fonts